import base64,importlib.util,json,hashlib
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path('/workspace/scratch/654b1ee6916f/UI-Spec-Studio')
spec=importlib.util.spec_from_file_location('preview',root/'tools/preview_readme.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
out=Path('/workspace/scratch/654b1ee6916f/readme-v118')
rows=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell')
 for lang,file,title in [('en','README.md','See the design take shape'),('zh','README.zh-CN.md','直接看见设计如何形成')]:
  document=module.render_document((root/file).read_text(),lang)
  for p in (root/'docs/assets').glob('*.svg'):
   document=document.replace('docs/assets/'+p.name,'data:image/svg+xml;base64,'+base64.b64encode(p.read_bytes()).decode())
  for theme,width,height in [('light',1440,1000),('dark',390,844)]:
   context=browser.new_context(viewport={'width':width,'height':height},color_scheme=theme,device_scale_factor=1)
   page=context.new_page();page.set_content(document,wait_until='load');page.evaluate('document.fonts.ready')
   heading=page.get_by_role('heading',name=title,exact=True)
   heading.evaluate('(e)=>scrollTo(0,e.getBoundingClientRect().top+scrollY-24)')
   name=f'section-{lang}-{theme}-{width}.png';page.screenshot(path=str(out/name))
   rows.append({'language':lang,'theme':theme,'viewport':page.viewport_size,'path':name,'document_overflow':page.evaluate('document.documentElement.scrollWidth>innerWidth+1'),'heading':heading.inner_text(),'file_sha256':hashlib.sha256((root/file).read_bytes()).hexdigest()})
   context.close()
 browser.close()
(out/'section-check.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print('Four native viewport section captures complete')
