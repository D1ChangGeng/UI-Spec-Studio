# Supplementary independent blind review — P14 and new P15

This supplement reviews only additional-pack/products/P14 and additional-pack/products/P15. It leaves the initial sixteen-product BLIND-REVIEW.md, products.json and freeze manifest unchanged. The old symlinked review-pack P15 was not inspected. No condition mapping, producer judgment, prior reviewer evidence, sibling workset or coordinating repository was read. Isolation remains instructional on a shared host; visible source choices cannot be hidden.

## Scope and evidence

I read each supplementary task/input/README and inspected allowed final app source plus its supplied foundation. I personally opened thirteen original PNGs: P14 desktop light/dark, narrow light/dark, failure and crowded attachment states; new P15 desktop/narrow reading, light/dark editing and a narrow table state. Exact image request/returned-object exports were saved at call time. Additional reviewer-created live images are separately indexed.

The applications ran from disposable copies. Owned Python servers used ports 4960–4963 for P14; owned Node/TiddlyWiki servers used 4970–4972 for P15. P14's served index hash matched the disposable dist index, with the owned process alive. P15's process PID, cwd, observed theme and writes into that copy's tiddler files establish the exercised target. Only these review-owned servers were terminated. Command stdout/stderr, exit status, timestamps and failures are retained under commands/035–048; exact tool-return exports accompany them.

The pinned Chrome headless shell 143.0.7499.4, Playwright 1.57.0, FONTCONFIG_FILE=/tmp/ui-spec-fonts/fonts.conf and device scale 1 were used. Active settings were 1280×600 and 390×844 for P14,1280×640 and 390×844 for P15; original PNGs also cover 1440×900. Most active tests used reduced motion. P15's contained table was also exercised in normal motion, without claiming natural-speed animation quality. Standard day/night palette tiddlers were used as condition fixtures in a disposable wiki copy; no frozen comparator was repaired. Literal timestamps from the tool and subprocess clocks remain unaltered.

## P14 — conversation workspace

Accept the increment within its local synthetic-conversation contract, with crowded-composer and disclosure-affordance reservations.

The original and current pixels preserve the mature reading/composer family: a restrained sidebar, legible answer column, clear user/assistant relationship and consistent light/dark typography. Filename-only chips wrap rather than disappearing into a lateral rail, and the total/privacy footer makes the attachment boundary and count visible. At390px, the ordinary six-line draft and three chips remain contained and readable. This is an actual populated composition, not an empty-state judgment.

The deliberate partial response failed and retried to the complete seven-theme answer. A later real wheel test held the user's reading position at 26px while response text grew from 1139 to 3211 characters. Return to latest reached the bottom, and Stop left the answer text identical over the next second. A first harness attempt setting scrollTop programmatically during smooth scrolling did not establish scroll-away; the retained wheel test resolves that uncertainty. The initial filename selector expected a data-slot preserved by the component; the tooltip trigger overrides that attribute. Correcting the selector to the actual focusable element succeeded. Those failures are retained rather than attributed to the product.

Focusing a long filename disclosed its complete name and the contents-not-read boundary throughout a 1.6-second observation. Escape hid the tooltip and left focus on that same filename. The generic focusable div makes this action less explicit than a details button; no screen-reader semantics claim follows from successful keyboard focus.

I also entered forty mixed-language lines and eight long filenames in both live light English and dark Chinese. Attachment height stayed bounded: keyboard End scrolled its region from 0 to 106px at compact desktop, and to 268px at narrow width. Removing the last attachment restored composer focus and left seven files. The document remained390px wide. The compact composer measured 350px high, with only about 162px of answer space between it and the 64px header. This is a meaningful crowded-state tradeoff, though the controls remain available and the growth stays bounded.

Source inspection found the explicit local synthetic disclosure, seven response sections, per-query failure fixture and abort checks. The retained source comments and notices support a source-family relationship; I did not certify the complete candidate-research process or independently audit every extracted component's identity. Touch discovery, software-keyboard occlusion, normal-speed motion and complete message editing/branch navigation remain unknown.

## New P15 — research workspace

Accept the local editorial wiki workspace, with table-scroll discoverability and dense-editor reservations.

The adopted paper theme supplies a recognisable editorial direction through material, red-margin paper treatment, strong serif reading hierarchy, subdued tag material and a differentiated ruled monospaced editor. The supplied long English/Chinese interview remains readable in both themes. The narrow editor's toolbar uses several rows, and small dim dark metadata is less prominent than the main note, but native read/edit/navigation controls remain coherent. The inspected theme is Vanilla Paper 0.10.0 with a retained MIT notice; the TiddlyWiki entrypoint matches its foundation. This is source/configuration evidence, not certification of the withheld research process.

I added an English and a Chinese passage through the native editor. Confirmation, reload and the actual interview tiddler file agreed. The native discard confirmation preserved saved content and removed the temporary marker. A departing draft still appeared in an early frame list during its close transition, but subsequent navigation and an explicit return showed the proper saved note, not an abandoned edit. Search-result activation and entry into another editor by keyboard worked. A separate keyboard activation of the ledger's interview link returned to the interview with both saved additions present and the cancelled marker absent.

At390px, the evidence ledger uses a named, focusable table region. In light/normal-motion and dark/reduced-motion conditions, ArrowRight moved its internal horizontal position from 0 to 165px, exposing the complete “Does not establish” column. Document width stayed 390px and document horizontal position stayed 0. The initially clipped column is therefore accessible without panning the surrounding note. The table still offers little visible instruction that it scrolls, so discovery remains a reservation even though keyboard operation is directly verified.

No server synchronization outage, broad assistive-technology use or natural-speed animation study was performed. Day/night palette setup used a supported configuration fixture in the disposable copy, rather than traversing every Control Panel option.

## Frozen disposition

Neither supplementary product showed a material unresolved blocker in the exercised local scope. Acceptance remains bounded by the observations above; it is not a real-model, real-upload, cloud-history or collaboration claim. It is an independent agent product judgment, not a human vote or mechanical certification.

The two supplementary records and this report are frozen before unblinding. Later condition-specific acceptance belongs in a separate continuation, without rewriting either the initial cohort or this supplement.

