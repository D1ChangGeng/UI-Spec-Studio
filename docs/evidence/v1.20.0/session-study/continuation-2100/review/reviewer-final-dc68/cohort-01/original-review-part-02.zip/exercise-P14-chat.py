import asyncio,json,pathlib,subprocess,os,time,traceback,re
from playwright.async_api import async_playwright
BASE=pathlib.Path('/workspace/scratch/dc68edd00fe1/independent-review')
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path=BROWSER,headless=True,env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
  for i,pid in enumerate(['P14']):
   port=4960+i;dest=BASE/'copies'/pid/'app';out=BASE/'behavior'/pid/'followup';out.mkdir(parents=True)
   log=open(out/'server.log','w');server=subprocess.Popen(['python3','-m','http.server',str(port),'--bind','127.0.0.1','--directory','dist'],cwd=dest,stdout=log,stderr=subprocess.STDOUT)
   ctx=await browser.new_context(viewport={'width':1280,'height':600},device_scale_factor=1,reduced_motion='reduce');page=await ctx.new_page();page.set_default_timeout(5000)
   r={'product':pid,'started_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'steps':[]}
   try:
    await asyncio.sleep(.3);await page.goto(f'http://127.0.0.1:{port}/?theme=light&lang=en');await page.wait_for_timeout(400)
    text=page.locator('textarea:visible').last
    await text.fill('Independent review [fail]');await text.press('Enter');await page.wait_for_timeout(2500)
    r['steps'].append({'step':'failed_question','body':(await page.locator('body').inner_text())[-2500:]})
    await page.screenshot(path=str(out/'failure.png'))
    retry=page.get_by_role('button',name=re.compile('Retry|Reload|Regenerate'))
    r['retry_controls']=await retry.all_text_contents()
    if await retry.count():await retry.last.click();await page.wait_for_timeout(10500)
    r['steps'].append({'step':'retry','body_tail':(await page.locator('body').inner_text())[-1500:]})
    await text.fill('Continue the research thread');await text.press('Enter');await page.wait_for_timeout(600)
    viewport=page.locator('[data-aui-thread-viewport]')
    if not await viewport.count():viewport=page.locator('div.overflow-y-scroll').first
    await viewport.evaluate('(e)=>e.scrollTop=0');await page.wait_for_timeout(100)
    before=await viewport.evaluate('(e)=>({top:e.scrollTop,height:e.scrollHeight,client:e.clientHeight})');await page.wait_for_timeout(1600);after=await viewport.evaluate('(e)=>({top:e.scrollTop,height:e.scrollHeight,client:e.clientHeight})')
    r['steps'].append({'step':'scroll_away_stream','before':before,'after':after})
    latest=page.get_by_role('button',name=re.compile('Return to latest|Scroll to bottom'))
    if await latest.count():await latest.click();await page.wait_for_timeout(100)
    r['steps'].append({'step':'return_latest','scroll':await viewport.evaluate('(e)=>({top:e.scrollTop,height:e.scrollHeight,client:e.clientHeight})')})
    stop=page.get_by_role('button',name=re.compile('Stop generating|Cancel response|Stop response'))
    r['stop_count']=await stop.count()
    if await stop.count():await stop.click()
    before_len=len(await page.locator('body').inner_text());await page.wait_for_timeout(700);r['steps'].append({'step':'stopped','before_length':before_len,'after_length':len(await page.locator('body').inner_text()),'composer_enabled':await text.is_enabled()})
    attach=page.get_by_role('button',name=re.compile('Add attachment|Add Attachment|Attach local filenames|Add local filename')).first
    async with page.expect_file_chooser() as chooser:await attach.click()
    fc=await chooser.value
    names=['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','research-interview-accessibility-and-reading-continuity-very-long-filename.txt']
    await fc.set_files([{'name':n,'mimeType':'text/plain','buffer':b'local synthetic fixture'} for n in names]);await page.wait_for_timeout(300)
    await text.fill('Compare the evidence.\n保留阅读位置。\nIdentify uncertainty.\n观察输入增长。\nRead previous passages.\n继续讨论。')
    await page.set_viewport_size({'width':390,'height':844});await page.wait_for_timeout(100);await page.screenshot(path=str(out/'attachments-narrow.png'))
    triggers=page.locator('button').filter(has_text='城市出行')
    if not await triggers.count():triggers=page.locator('button[aria-label*="城市出行"]').filter(has_not=page.locator('svg.lucide-x'))
    r['attachment_buttons']=await page.locator('button').evaluate_all('(es)=>es.map(e=>({text:e.innerText,label:e.getAttribute("aria-label")}))')
    candidates=page.locator('button[aria-label*="城市出行"]').filter(has_not=page.locator('span.sr-only'))
    # Match the independently observed document disclosure controls, excluding remove.
    found=page.get_by_role('button',name=re.compile('^(View attachment|View filename|Details for|Document attachment).*城市出行'))
    r['detail_control_count']=await found.count()
    if await found.count():
     await found.first.focus();await page.keyboard.press('Enter');await page.wait_for_timeout(300)
     r['steps'].append({'step':'attachment_details','dialog':await page.get_by_role('dialog').all_text_contents()});await page.screenshot(path=str(out/'attachment-dialog.png'))
     await page.keyboard.press('Escape');r['steps'].append({'step':'escape_focus','active':await page.evaluate('document.activeElement.outerHTML')})
    r['document_overflow']=await page.evaluate('({width:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth})')
   except Exception as e:r['error']=str(e);r['traceback']=traceback.format_exc();print(r['traceback'],flush=True)
   finally:
    (out/'result.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(pid,json.dumps(r,ensure_ascii=False),flush=True);await ctx.close();server.terminate();server.wait();log.close()
  await browser.close()
asyncio.run(main())
