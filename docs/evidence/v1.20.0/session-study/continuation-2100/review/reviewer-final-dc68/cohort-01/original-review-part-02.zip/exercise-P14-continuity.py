import asyncio,json,pathlib,subprocess,os,time,traceback,re
from playwright.async_api import async_playwright
BASE=pathlib.Path('/workspace/scratch/dc68edd00fe1/independent-review')
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path=BROWSER,headless=True,env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
  for i,pid in enumerate(['P14']):
   port=4961+i;dest=BASE/'copies'/pid/'app';out=BASE/'behavior'/pid/'continuity';out.mkdir(parents=True);log=open(out/'server.log','w')
   server=subprocess.Popen(['python3','-m','http.server',str(port),'--bind','127.0.0.1','--directory','dist'],cwd=dest,stdout=log,stderr=subprocess.STDOUT)
   ctx=await browser.new_context(viewport={'width':1280,'height':600},device_scale_factor=1,reduced_motion='reduce');page=await ctx.new_page();page.set_default_timeout(5000);r={'product':pid,'port':port,'started_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
   try:
    await asyncio.sleep(.3)
    if server.poll() is not None:raise Exception('Our server exited before navigation')
    await page.goto(f'http://127.0.0.1:{port}/?theme=light&lang=en');r['server_identity']={'process_pid':server.pid,'process_alive':server.poll() is None,'served_index_sha256':__import__('hashlib').sha256(await (await page.request.get(f'http://127.0.0.1:{port}/')).body()).hexdigest(),'copy_index_sha256':__import__('hashlib').sha256((dest/'dist/index.html').read_bytes()).hexdigest()};await page.wait_for_timeout(300)
    text=page.locator('textarea:visible').last;await text.fill('Continuity review');await text.press('Enter');await page.wait_for_timeout(700)
    viewport=page.locator('div.overflow-y-scroll').first;await viewport.hover();await page.mouse.wheel(0,-10000);await page.wait_for_timeout(200)
    content=page.locator('[data-slot="aui_assistant-message-content"]').last
    r['stream_before']={'scroll':await viewport.evaluate('(e)=>e.scrollTop'),'text_length':len(await content.inner_text())}
    await page.wait_for_timeout(1700);r['stream_after']={'scroll':await viewport.evaluate('(e)=>e.scrollTop'),'text_length':len(await content.inner_text())}
    latest=page.get_by_role('button',name=re.compile('Return to latest|Scroll to bottom'))
    r['latest_visible']=await latest.is_visible()
    if await latest.is_visible():await latest.click();await page.wait_for_timeout(100)
    r['returned_scroll']=await viewport.evaluate('(e)=>({top:e.scrollTop,height:e.scrollHeight,client:e.clientHeight})')
    await page.get_by_role('button',name='Stop generating',exact=True).click();await page.wait_for_timeout(150);r['stop_before']=await content.inner_text();await page.wait_for_timeout(1000);r['stop_after']=await content.inner_text()
    async with page.expect_file_chooser() as chooser:await page.get_by_role('button',name=re.compile('Add attachment|Add Attachment|Attach local filenames|Add local filename')).first.click()
    fc=await chooser.value;name='城市出行访谈摘要_2026-10-31_final-revised-notes.txt';await fc.set_files([{'name':name,'mimeType':'text/plain','buffer':b'synthetic'}]);await page.wait_for_timeout(200);await page.set_viewport_size({'width':390,'height':844})
    if pid in ['P09','P14']:
     trigger=page.locator('[data-slot="composer-attachment"][aria-label*="城市出行"]');await trigger.focus();await page.wait_for_timeout(400);r['disclosure']=await page.get_by_role('tooltip').all_text_contents();await page.screenshot(path=str(out/'disclosure.png'));await page.keyboard.press('Escape');await page.wait_for_timeout(500);r['after_escape_tooltips']=await page.get_by_role('tooltip').count()
    else:
     trigger=page.get_by_role('button',name=re.compile('^(View attachment|View filename|Details for).*城市出行'));await trigger.focus();await page.keyboard.press('Enter');await page.wait_for_timeout(500);r['disclosure']=await page.get_by_role('dialog').all_text_contents();await page.screenshot(path=str(out/'disclosure.png'));await page.keyboard.press('Escape');await page.wait_for_timeout(600);r['after_escape_dialogs']=await page.get_by_role('dialog').count()
    r['focus_after_escape']=await page.evaluate('({tag:document.activeElement.tagName,label:document.activeElement.getAttribute("aria-label"),text:document.activeElement.innerText})')
   except Exception as e:r['error']=str(e);r['traceback']=traceback.format_exc()
   finally:
    (out/'result.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(pid,json.dumps(r,ensure_ascii=False),flush=True);await ctx.close();server.terminate();server.wait();log.close()
  await browser.close()
asyncio.run(main())
