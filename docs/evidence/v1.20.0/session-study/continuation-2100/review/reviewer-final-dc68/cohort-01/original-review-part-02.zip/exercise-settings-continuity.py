import asyncio,json,pathlib,subprocess,os,time,traceback,re
from playwright.async_api import async_playwright
BASE=pathlib.Path('/workspace/scratch/dc68edd00fe1/independent-review')
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path=BROWSER,headless=True,env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
  for i,pid in enumerate(['P01','P03','P05','P06','P08','P16','P18']):
   port=4890+i;dest=BASE/'copies'/pid/'app';out=BASE/'behavior'/pid/'continuity';out.mkdir(parents=True);log=open(out/'server.log','w');server=subprocess.Popen(['python3','-m','http.server',str(port),'--bind','127.0.0.1'],cwd=dest,stdout=log,stderr=subprocess.STDOUT)
   ctx=await browser.new_context(viewport={'width':1280,'height':600},device_scale_factor=1,reduced_motion='reduce');page=await ctx.new_page();page.set_default_timeout(5000);r={'product':pid,'started_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
   try:
    await asyncio.sleep(.3)
    if server.poll() is not None:raise Exception('Our server exited before navigation')
    await page.goto(f'http://127.0.0.1:{port}/?theme=light&lang=en');await page.wait_for_timeout(150)
    name=page.locator('#business-name');save=page.locator('#save-settings')
    await name.fill('Persisted origin');await save.focus();await page.keyboard.press('Enter');await page.wait_for_timeout(900)
    await page.evaluate('window.fieldnotes.setFailureMode(true)');await name.fill('Failed submitted snapshot');await save.focus();await page.keyboard.press('Enter');await page.wait_for_timeout(950);await name.fill('Later unsaved edit')
    retry=page.get_by_role('button',name=re.compile('^Retry save$|^Try again$'))
    if await retry.count():await retry.first.focus();await page.keyboard.press('Enter')
    else:await save.focus();await page.keyboard.press('Enter')
    await page.wait_for_timeout(950);r['retry_with_new_draft']={'field':await name.input_value(),'storage':await page.evaluate("localStorage.getItem('fieldnotes-settings-v1')"),'status':await page.locator('#save-status').inner_text(),'focus':await page.evaluate('document.activeElement.outerHTML')}
    cancel=page.get_by_role('button',name='Cancel',exact=True);await cancel.focus();await page.keyboard.press('Enter');r['cancel_restore']=await name.input_value()
    if pid in ['P01','P08','P18']:
     close=page.locator('.toast .btn-close');await close.focus();await page.keyboard.press('Enter');await page.wait_for_timeout(350);r['close_focus']=await page.evaluate('document.activeElement.outerHTML');r['toast_visible']=await page.locator('.toast').is_visible()
    long='跨城市田野研究协作小组 — Longitudinal everyday-mobility research programme';await name.fill(long);await page.locator('#business-id').fill(long);await page.set_viewport_size({'width':390,'height':844});await name.scroll_into_view_if_needed();await page.screenshot(path=str(out/'long-narrow.png'));r['overflow']=await page.evaluate('({width:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth})')
    if pid=='P01':await page.set_viewport_size({'width':1280,'height':600});await page.goto(f'http://127.0.0.1:{port}/toast-source-preview.html');await page.wait_for_timeout(200);await page.screenshot(path=str(out/'toast-source.png'))
   except Exception as e:r['error']=str(e);r['traceback']=traceback.format_exc()
   finally:
    (out/'result.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(pid,json.dumps(r,ensure_ascii=False),flush=True);await ctx.close();server.terminate();server.wait();log.close()
  await browser.close()
asyncio.run(main())
