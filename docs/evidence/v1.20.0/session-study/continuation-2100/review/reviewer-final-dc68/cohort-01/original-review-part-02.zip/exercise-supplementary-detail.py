import asyncio,json,pathlib,subprocess,os,time,hashlib
from playwright.async_api import async_playwright
BASE=pathlib.Path('/workspace/scratch/dc68edd00fe1/independent-review')
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
 async with async_playwright() as pw:
  b=await pw.chromium.launch(executable_path=BROWSER,headless=True,env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
  out=BASE/'behavior/P14/detail';out.mkdir(parents=True);log=open(out/'server.log','w');dest=BASE/'copies/P14/app';port=4963
  s=subprocess.Popen(['python3','-m','http.server',str(port),'--bind','127.0.0.1','--directory','dist'],cwd=dest,stdout=log,stderr=subprocess.STDOUT)
  results=[]
  try:
   await asyncio.sleep(.3);assert s.poll() is None
   for theme,lang in [('light','en'),('dark','zh')]:
    c=await b.new_context(viewport={'width':1280,'height':600},device_scale_factor=1,reduced_motion='reduce');p=await c.new_page()
    try:
     await p.goto(f'http://127.0.0.1:{port}/?theme={theme}&lang={lang}');await p.wait_for_timeout(300);r={'theme':theme,'locale':lang,'server_pid':s.pid,'source_index_sha256':hashlib.sha256((dest/'dist/index.html').read_bytes()).hexdigest(),'served_index_sha256':hashlib.sha256(await (await p.request.get(f'http://127.0.0.1:{port}/')).body()).hexdigest()}
     async with p.expect_file_chooser() as pending:await p.get_by_role('button',name='Add Attachment',exact=True).click()
     fc=await pending.value;names=[f'城市出行访谈摘要_{i}_2026-10-31_final-revised-notes.txt' for i in range(8)];await fc.set_files([{'name':n,'mimeType':'text/plain','buffer':b'synthetic fixture'} for n in names]);await p.wait_for_timeout(250)
     inp=p.locator('textarea:visible').last;await inp.fill('\n'.join(f'{i} 请比较事实与解释 and reading continuity.' for i in range(40)))
     region=p.locator('.aui-composer-attachments');await region.focus();before=await region.evaluate('(e)=>({top:e.scrollTop,height:e.scrollHeight,client:e.clientHeight})');await p.keyboard.press('End');await p.wait_for_timeout(250);after=await region.evaluate('(e)=>({top:e.scrollTop,height:e.scrollHeight,client:e.clientHeight})')
     r['attachment_keyboard_scroll']={'before':before,'after':after};r['composer_rect']=await p.locator('.aui-composer-root').evaluate('(e)=>({top:e.getBoundingClientRect().top,bottom:e.getBoundingClientRect().bottom,height:e.getBoundingClientRect().height})');await p.screenshot(path=str(out/f'{theme}-compact.png'))
     await p.set_viewport_size({'width':390,'height':844});await region.focus();await p.keyboard.press('End');await p.wait_for_timeout(250);r['narrow_attachment_scroll']=await region.evaluate('(e)=>({top:e.scrollTop,height:e.scrollHeight,client:e.clientHeight})');r['narrow_overflow']=await p.evaluate('({client:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth})');await p.screenshot(path=str(out/f'{theme}-narrow.png'))
     await p.get_by_role('button',name='Remove '+names[-1],exact=True).focus();await p.keyboard.press('Enter');await p.wait_for_timeout(250);r['remove_focus']=await p.evaluate('({tag:document.activeElement.tagName,label:document.activeElement.getAttribute("aria-label"),class:document.activeElement.className})');r['remaining_files']=await region.locator('button').count();results.append(r)
    finally:await c.close()
  finally:s.terminate();s.wait();log.close();(out/'result.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print('P14 DETAIL',json.dumps(results,ensure_ascii=False),flush=True)
  out=BASE/'behavior/P15/tables';out.mkdir(parents=True);log=open(out/'server.log','w');dest=BASE/'copies/P15/wiki-followup4';port=4971;s=subprocess.Popen(['node','vendor/tiddlywiki/tiddlywiki.js','wiki','--listen','host=127.0.0.1',f'port={port}'],cwd=dest,stdout=log,stderr=subprocess.STDOUT);r={'product':'P15','server_pid':s.pid,'copy_cwd':str(dest),'conditions':[]}
  try:
   await asyncio.sleep(1);assert s.poll() is None
   for motion,palette in [('no-preference','Day'),('reduce','Night')]:
    c=await b.new_context(viewport={'width':390,'height':844},device_scale_factor=1,reduced_motion=motion);p=await c.new_page()
    try:
     await p.goto(f'http://127.0.0.1:{port}/#Evidence%20ledger');await p.wait_for_timeout(700)
     # Standard supported palette tiddler is a condition fixture, not a product repair.
     palette_title='$:/palettes/VanillaPaper'+palette
     exists=await p.evaluate('(title)=>!!$tw.wiki.getTiddler(title)',palette_title);assert exists,palette_title
     await p.evaluate('(title)=>$tw.wiki.addTiddler({title:"$:/palette",text:title})',palette_title);await p.wait_for_timeout(500)
     region=p.get_by_role('region',name='Evidence ledger table',exact=True);await region.scroll_into_view_if_needed();await region.focus();before=await region.evaluate('(e)=>({left:e.scrollLeft,width:e.clientWidth,scroll:e.scrollWidth})')
     for _ in range(10):await p.keyboard.press('ArrowRight')
     await p.wait_for_timeout(500);after=await region.evaluate('(e)=>({left:e.scrollLeft,width:e.clientWidth,scroll:e.scrollWidth})');await p.screenshot(path=str(out/f'{palette.lower()}-keyboard-right.png'))
     item={'motion':motion,'palette':palette_title,'before':before,'after':after,'document':await p.evaluate('({width:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth,left:document.scrollingElement.scrollLeft})'),'focused':await p.evaluate('document.activeElement.getAttribute("aria-label")')};r['conditions'].append(item)
    finally:await c.close()
  finally:s.terminate();s.wait();log.close();(out/'result.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print('P15 TABLE',json.dumps(r,ensure_ascii=False),flush=True)
  await b.close()
asyncio.run(main())
