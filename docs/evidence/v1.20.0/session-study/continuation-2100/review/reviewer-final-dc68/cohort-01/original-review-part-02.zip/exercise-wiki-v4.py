import asyncio,json,pathlib,subprocess,os,time,traceback,shutil
from playwright.async_api import async_playwright
BASE=pathlib.Path('/workspace/scratch/dc68edd00fe1/independent-review')
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def body_editor(page):
 for frame in page.frames:
  inputs=frame.locator('textarea:visible')
  for n in range(await inputs.count()):
   el=inputs.nth(n)
   value=await el.input_value()
   if len(value)>200:return el,value
 raise Exception('No populated visible body editor found; frame editors: '+str([(f.url,await f.locator('textarea').count()) for f in page.frames]))
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path=BROWSER,headless=True,env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
  for i,pid in enumerate(['P02','P12','P13']):
   port=4790+i;dest=BASE/'copies'/pid/'wiki-followup4';shutil.copytree(BASE/'review-pack/products'/pid/'app',dest)
   out=BASE/'behavior'/pid/'followup4';out.mkdir(parents=True);log=open(out/'server.log','w')
   server=subprocess.Popen(['node','vendor/tiddlywiki/tiddlywiki.js','wiki','--listen','host=127.0.0.1',f'port={port}'],cwd=dest,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
   ctx=await browser.new_context(viewport={'width':1280,'height':640},device_scale_factor=1,reduced_motion='reduce');page=await ctx.new_page();page.set_default_timeout(6000)
   page.on('dialog',lambda d:asyncio.create_task(d.accept()))
   r={'product':pid,'started_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'steps':[]}
   try:
    for _ in range(30):
     try:await page.goto(f'http://127.0.0.1:{port}/');break
     except:await asyncio.sleep(.3)
    await page.wait_for_timeout(1200)
    title='访谈笔记 — 傍晚通勤';frame=page.locator('.tc-tiddler-frame[data-tiddler-title="'+title+'"]')
    await frame.locator('button[title="Edit this tiddler"]').click();await page.wait_for_timeout(250)
    r['buttons_after_edit']=await page.locator('button').evaluate_all('(els)=>els.map(e=>({title:e.title,aria:e.getAttribute("aria-label")}))')
    el,original=await body_editor(page)
    text=original+'\n\nIndependent reviewer saved English passage.\n独立审阅保存中文段落。'
    await el.fill(text);await page.locator('button[title="Confirm changes to this tiddler"]').first.click();await page.wait_for_timeout(1800);await page.reload();await page.wait_for_timeout(900)
    r['steps'].append({'step':'save_reload','english_visible':await page.get_by_text('Independent reviewer saved English passage.',exact=False).count(),'chinese_visible':await page.get_by_text('独立审阅保存中文段落。',exact=False).count(),'disk_matches':[str(p.relative_to(dest)) for p in (dest/'wiki/tiddlers').glob('*') if p.is_file() and 'Independent reviewer saved English passage.' in p.read_text(errors='replace')]})
    frame=page.locator('.tc-tiddler-frame[data-tiddler-title="'+title+'"]');await frame.locator('button[title="Edit this tiddler"]').click();await page.wait_for_timeout(150);el,content=await body_editor(page);await el.fill(content+'\nCANCELLED REVIEW TEXT');await page.locator('button[title="Discard changes to this tiddler"]').first.click();await page.wait_for_timeout(350)
    r['steps'].append({'step':'cancel','cancelled_visible':await page.get_by_text('CANCELLED REVIEW TEXT',exact=False).count(),'draft_frames':await page.locator('.tc-tiddler-frame').evaluate_all('(es)=>es.map(e=>e.getAttribute("data-tiddler-title"))')})
    ledger=page.get_by_role('link',name='Evidence ledger',exact=True).first;await ledger.click();await page.wait_for_timeout(300)
    r['steps'].append({'step':'ledger','frames':await page.locator('.tc-tiddler-frame').evaluate_all('(es)=>es.map(e=>e.getAttribute("data-tiddler-title"))'),'tables':await page.locator('.tc-tiddler-frame[data-tiddler-title="Evidence ledger"] table').count()})
    search=page.locator('input[type="search"]')
    if not await search.count():search=page.locator('.tc-search input')
    if not await search.count():search=page.locator('input').first
    await page.locator('input:visible').first.fill('Quiet route');await page.wait_for_timeout(700);await page.get_by_role('link',name='Quiet route — working draft',exact=True).last.focus();await page.keyboard.press('Enter');await page.wait_for_timeout(250);q=page.locator('.tc-tiddler-frame[data-tiddler-title="Quiet route — working draft"]');await q.locator('button[title="Edit this tiddler"]').focus();await page.keyboard.press('Enter');await page.wait_for_timeout(200);r['steps'].append({'step':'search','visible_text':(await page.locator('body').inner_text())[-1800:]})
    await page.set_viewport_size({'width':390,'height':844});ledgerframe=page.locator('.tc-tiddler-frame[data-tiddler-title="Evidence ledger"]');await ledgerframe.scroll_into_view_if_needed();await page.screenshot(path=str(out/'narrow-ledger.png'));r['ledger_geometry']=await ledgerframe.locator('table').evaluate('(e)=>({left:e.getBoundingClientRect().left,right:e.getBoundingClientRect().right,parent:e.parentElement.outerHTML.slice(0,1200)})')
    r['document_overflow']=await page.evaluate('({width:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth})')
   except Exception as e:r['error']=str(e);r['traceback']=traceback.format_exc();print(r['traceback'],flush=True)
   finally:
    (out/'result.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(pid,json.dumps(r,ensure_ascii=False),flush=True);await ctx.close();server.terminate();server.wait();log.close()
  await browser.close()
asyncio.run(main())
