import asyncio,json,pathlib,shutil,subprocess,os,time,traceback
from playwright.async_api import async_playwright
BASE=pathlib.Path('/workspace/scratch/dc68edd00fe1/independent-review')
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path=BROWSER,headless=True,env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf','PLAYWRIGHT_BROWSERS_PATH':'/tmp/ui-spec-preview-browser'})
  for i,pid in enumerate(['P01','P03','P05','P06','P08','P16','P18','P04','P07','P09','P10','P11','P17','P02','P12','P13']):
   if os.environ.get('ONLY') and pid not in os.environ['ONLY'].split(','): continue
   product=BASE/'review-pack/products'/pid; family=json.loads((product/'capture-index.json').read_text())['task_family']
   dest=BASE/'copies'/pid/'app'
   if not dest.exists(): shutil.copytree(product/'app',dest)
   port=4660+i; out=BASE/'behavior'/pid;out.mkdir(parents=True,exist_ok=True)
   cmd=['node','vendor/tiddlywiki/tiddlywiki.js','wiki','--listen','host=127.0.0.1',f'port={port}'] if family=='T3' else ['python3','-m','http.server',str(port),'--bind','127.0.0.1','--directory', 'dist' if family=='T2' else '.']
   logs=open(out/'server.log','a'); server=subprocess.Popen(cmd,cwd=dest,stdout=logs,stderr=subprocess.STDOUT,env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
   ctx=await browser.new_context(viewport={'width':1280,'height':640 if family=='T3' else 600},device_scale_factor=1,reduced_motion='reduce')
   page=await ctx.new_page(); events=[];page.on('pageerror',lambda e:events.append(str(e)))
   result={'product':pid,'family':family,'viewport':page.viewport_size,'started_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'steps':[]}
   try:
    for attempt in range(40):
     try: await page.goto(f'http://127.0.0.1:{port}/?theme=light&lang=en',timeout=3000);break
     except: await asyncio.sleep(.3)
    await page.wait_for_timeout(1800)
    result['initial_controls']=await page.locator('input,textarea,button').evaluate_all("(els)=>els.map(e=>({tag:e.tagName,id:e.id,label:e.getAttribute('aria-label'),title:e.title,text:e.textContent,value:e.value,placeholder:e.placeholder}))")
    if family in ['T1','T4']:
     name=page.locator('#business-name'); await name.fill('Review bilingual 林玫');await page.locator('#save-settings').click();await page.wait_for_timeout(1200)
     result['steps'].append({'step':'save','storage':await page.evaluate("localStorage.getItem('fieldnotes-settings-v1')"),'status':await page.locator('#save-status').inner_text()})
     await page.reload();await name.wait_for(); result['steps'].append({'step':'reload','value':await name.input_value()})
     await page.evaluate('window.fieldnotes.setFailureMode(true)');await name.fill('Failed snapshot 林玫');await page.locator('#save-settings').click();await page.wait_for_timeout(1050)
     result['steps'].append({'step':'failure','value':await name.input_value(),'storage':await page.evaluate("localStorage.getItem('fieldnotes-settings-v1')"),'body':(await page.locator('body').inner_text())[-4500:]})
     await page.screenshot(path=str(out/'failure.png'))
     retry=page.get_by_role('button',name='Retry save',exact=True)
     if not await retry.count(): retry=page.locator('#retry-save')
     result['retry_count']=await retry.count()
     if await retry.count():await retry.first.click()
     else:await page.locator('#save-settings').click()
     await page.wait_for_timeout(1100);await page.reload();result['steps'].append({'step':'retry_reload','value':await name.input_value(),'storage':await page.evaluate("localStorage.getItem('fieldnotes-settings-v1')")})
     await name.fill('');await page.locator('#save-settings').click();await page.wait_for_timeout(100)
     result['steps'].append({'step':'invalid','active':await page.evaluate('document.activeElement.id'),'invalid':await name.get_attribute('aria-invalid'),'description':await name.get_attribute('aria-describedby')})
     await name.fill('Pending snapshot');await page.locator('#save-settings').click();await name.fill('Newer unsaved draft');await page.wait_for_timeout(1100)
     result['steps'].append({'step':'pending_edit','value':await name.input_value(),'status':await page.locator('#save-status').inner_text(),'storage':await page.evaluate("localStorage.getItem('fieldnotes-settings-v1')")})
     await page.set_viewport_size({'width':390,'height':844});await page.screenshot(path=str(out/'narrow.png'))
    elif family=='T2':
     textarea=page.locator('textarea').last;await textarea.fill('Independent review [fail]');await textarea.press('Enter');await page.wait_for_timeout(2300)
     result['steps'].append({'step':'failure','body':(await page.locator('body').inner_text())[-6000:],'buttons':await page.locator('button').evaluate_all("(e)=>e.map(x=>({text:x.innerText,label:x.getAttribute('aria-label'),title:x.title}))")})
     await page.screenshot(path=str(out/'failure.png'))
     retry=page.get_by_role('button',name='Reload',exact=True)
     if not await retry.count(): retry=page.get_by_role('button',name='Regenerate',exact=True)
     if not await retry.count(): retry=page.locator('button').filter(has_text='Retry')
     result['retry_count']=await retry.count()
     if await retry.count():await retry.last.click();await page.wait_for_timeout(11000)
     result['steps'].append({'step':'retry','body':(await page.locator('body').inner_text())[-2000:]})
     await textarea.fill('Follow-up continuity');await textarea.press('Enter');await page.wait_for_timeout(350)
     stop=page.get_by_role('button',name='Stop',exact=True)
     result['stop_count']=await stop.count()
     if await stop.count():await stop.click()
     await page.set_viewport_size({'width':390,'height':844});await page.screenshot(path=str(out/'narrow.png'))
    elif family=='T3':
     result['body']=(await page.locator('body').inner_text())[:6000]
     result['tiddlers']=await page.locator('.tc-tiddler-frame').evaluate_all("(els)=>els.map(e=>({title:e.getAttribute('data-tiddler-title'),buttons:[...e.querySelectorAll('button')].map(b=>({title:b.title,aria:b.getAttribute('aria-label')}))}))")
     frame=page.locator('.tc-tiddler-frame').filter(has=page.locator('h2',has_text='Fieldnotes')).first
     if not await frame.count():frame=page.locator('.tc-tiddler-frame').first
     await frame.locator('button[title*="Edit"]').click()
     await page.wait_for_timeout(300)
     result['edit_controls']=await page.locator('textarea,input,button').evaluate_all("(els)=>els.map(e=>({tag:e.tagName,title:e.title,aria:e.getAttribute('aria-label'),value:e.value,class:e.className}))")
     await page.screenshot(path=str(out/'editor.png'))
    result['page_errors']=events
   except Exception as e:result['error']=str(e);result['traceback']=traceback.format_exc();print(pid,'FAIL',traceback.format_exc(),flush=True)
   finally:
    (out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(pid,json.dumps(result,ensure_ascii=False),flush=True)
    await ctx.close();server.terminate()
    try:server.wait(timeout=5)
    except:server.kill()
    logs.close()
  await browser.close()
asyncio.run(main())

