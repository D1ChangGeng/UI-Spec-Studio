from pathlib import Path
from playwright.sync_api import sync_playwright
import subprocess,time,json,hashlib,urllib.request,re,os,signal
r=Path('/workspace/scratch/dc68edd00fe1/ui-study/w15');o=r/'evidence/final-build';o.mkdir(exist_ok=True)
s=subprocess.Popen(['python3','-m','http.server','55117','--bind','127.0.0.1','--directory',str(r/'app/dist')],cwd=r/'app',stdout=(o/'server.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=lambda:(o/'child-identity.json').write_text(json.dumps({'cwd':os.getcwd(),'pid':os.getpid()})));time.sleep(.5)
html=urllib.request.urlopen('http://127.0.0.1:55117/').read().decode();assets=re.findall(r'(?:src|href)="(/assets/[^\"]+)"',html);proof=[]
for asset in assets:
 data=urllib.request.urlopen('http://127.0.0.1:55117'+asset).read();local=r/'app/dist'/asset.lstrip('/');assert data==local.read_bytes();proof.append({'url':asset,'sha256':hashlib.sha256(data).hexdigest(),'matchesPhysicalBuild':True})
(o/'identity.json').write_text(json.dumps({'actualChild':json.loads((o/'child-identity.json').read_text()),'servedDirectory':str(r/'app/dist'),'strictUniquePort':55117,'assets':proof,'sourceHashes':{str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'app/src').rglob('*') if p.is_file()}},indent=2))
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox']);page=b.new_page(viewport={'width':1280,'height':600});page.goto('http://127.0.0.1:55117/?theme=dark&lang=zh');inp=page.get_by_role('textbox',name='Message input',exact=True);inp.fill('请比较研究资料\nKeep observations distinct\n保留阅读位置\nCheck evidence\n跨语言研究笔记\nContinue the thread')
 with page.expect_file_chooser() as fc:page.get_by_role('button',name='Add Attachment',exact=True).click()
 fc.value.set_files([{'name':'notes.txt','mimeType':'text/plain','buffer':b''},{'name':'城市出行访谈摘要_2026-10-31_final-revised-notes.txt','mimeType':'text/plain','buffer':b''},{'name':'accessibility-research-interviews-synthesis-final-version.txt','mimeType':'text/plain','buffer':b''}]);page.wait_for_timeout(250);page.screenshot(path=str(o/'final-current.png'));assert '3 个文件名' in page.locator('body').inner_text();b.close()
os.killpg(s.pid,signal.SIGTERM);print(json.dumps(proof,indent=2))
