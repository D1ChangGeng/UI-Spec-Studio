# Meridian continuity observation

At 1280×600, dark/Chinese, reading position remained user-controlled across scroll-away, repeated questions, composer growth and attachment growth. A keyboard Stop focus defect was reproduced; the primary agent’s repair passed a targeted recheck.

| Episode | Observed result |
|---|---|
| Streaming and repeat question | New turn begins at its question/top. Composer stays stable and input retains focus. |
| Scroll-away | ScrollTop stayed 0 while content height grew 3145→3302. Earlier visible material remained anchored. |
| Return latest | Explicit arrow revealed the answer ending and retained input focus. Streaming had already completed, so continued following after return remains unverified. |
| Stop | Before repair, keyboard activation left focus on BODY. After repair, focus returned to Message input at both sampled checkpoints; scrollTop stayed 496. |
| Failure/retry | Error initially lay below the visible top-anchored response. Return latest revealed the failure box; retry succeeded and retained input focus. |
| Expanded composer | Six lines grew composer height 94→206px; five filenames grew it to 310px. ScrollTop stayed 4470. About 202px of reading space remained; actions stayed reachable. |
| Filename disclosure | Hover exposed the complete long filename and filename-only explanation within the viewport. Later tooltip focus/tap changes were not covered. |

One temporal concern remains: visible text continued revealing after Stop—494→582 characters during the repair recheck. The adapter checks abort before and after its delay; buffered Markdown reveal is plausible, but unproven. This does not establish additional adapter chunks. Failure feedback also initially appears below the reading position; the primary subsequently added an alert role and clearer retry naming, which this observer did not test.

Personally reviewed full-size ordered captures 01–05, 08–22 and 24–25 through actual `view_image` responses. These establish sampled spatial states and controlled interactions, **not natural-speed smoothness**, precise latency or screen-reader behavior.

Report: [FINAL.md](sandbox:/workspace/scratch/dc68edd00fe1/ui-study/w15/evidence/observer/FINAL.md). Original commands, stdout/stderr, capture timestamps, geometry, source digests and actual image-tool responses are retained under `evidence/observer`. No product source was changed by this observer; probe servers were stopped.
