Same-family attachment chips are available at the starter’s **exact pinned revision**, `ff654d8156680b839774296ef644b57ab1078425`, MIT. I acquired the source, rendered the unchanged upstream demo locally, personally viewed progress/settled/removal captures, and operated removal successfully. Product code was not changed.

Research report: [FINAL.md](sandbox:/workspace/scratch/dc68edd00fe1/ui-study/w15/evidence/research/FINAL.md).

The adoptable exports are `ComposerAttachments` and `ComposerAttachmentChip` in [composer-source.tsx](sandbox:/workspace/scratch/dc68edd00fe1/ui-study/w15/evidence/research/composer-source.tsx), with coordinated [surface-source.tsx](sandbox:/workspace/scratch/dc68edd00fe1/ui-study/w15/evidence/research/surface-source.tsx). Exact original files:

- [Composer source](https://github.com/assistant-ui/assistant-ui/blob/ff654d8156680b839774296ef644b57ab1078425/packages/ui/src/components/react/assistant-ui/elements/composer.tsx)
- [Original demo](https://github.com/assistant-ui/assistant-ui/blob/ff654d8156680b839774296ef644b57ab1078425/apps/docs/components/demo/elements/composer-attachments.tsx)
- [Surface tokens](https://github.com/assistant-ui/assistant-ui/blob/ff654d8156680b839774296ef644b57ab1078425/packages/ui/src/components/react/assistant-ui/elements/surfaces.tsx)

The chips visibly coordinate an icon square, filename, smaller metadata and trailing remove action. Two filenames can be distinguished immediately. Progress uses a spinner and thin lower line; completion replaces that with metadata/removal. Removing `trace.log` retained `screenshot.png`.

![Original source demo, settled](sandbox:/workspace/scratch/dc68edd00fe1/ui-study/w15/evidence/research/chip-demo-done.png)

This is an original-demo local render with the project stylesheet, not an integrated Meridian result. Documentation-stage centering was omitted, so the source’s bounded composer appears at the upper left.

The useful adoption scope is **attachment chips only**. The standalone source’s `ComposerInput` is a single-line `<input>` and should not replace the current multiline runtime textarea. Retain current composer/dropzone, send/cancel, viewport and runtime ownership.

Important limits:

- Chip names use `max-w-36 truncate`; retain existing tooltip or another supported full-name disclosure, then test keyboard/touch.
- Map removal by stable attachment ID, especially when filenames repeat.
- Metadata must reflect the filename-only local adapter; avoid importing fictitious upload/size claims.
- `ComposerAttachments` wraps. Several rows plus a large textarea require a compact-height contextual trial.

Current official assistant-ui documentation describes `turnAnchor="top"` as defaulting `autoScroll=false`, maintaining the question/answer start rather than following every chunk. It also provides `topAnchorMessageClamp` for tall questions. The current Thread already uses top anchoring, sticky `ViewportFooter` and `ScrollToBottom`; verify pinned APIs and preserve their ownership before introducing another scroll hook. This reframed the inquiry from adding scrolling to testing existing reading policy under growth.

Compared alternatives:

| Candidate | Useful difference | Evidence limit |
|---|---|---|
| [AI Elements Attachments](https://elements.ai-sdk.dev/components/attachments) | Grid, inline badges and metadata lists; separate Conversation behavior | Official documentation retrieved; public render failed. Migration to shadcn/ui is announced. |
| [Ant Design X Attachments](https://ant-design-x.antgroup.com/components/attachments) | Explicit wrap/scrollX/scrollY and Sender.Header disclosure composition | Documentation retrieved; public render failed. Larger token/dependency integration scope. |
| [use-stick-to-bottom](https://github.com/stackblitz-labs/use-stick-to-bottom) | Resize-aware bottom following with explicit return | Repository discovered; not rendered. Behavior foundation, not complete visual composer. |

Original tool results, source responses, failures, command exports and personally viewed captures are retained under `evidence/research/`. [VISUAL-REVIEW.md](sandbox:/workspace/scratch/dc68edd00fe1/ui-study/w15/evidence/research/VISUAL-REVIEW.md) distinguishes viewed states from unverified conditions.

Temporal evidence is a controlled sampled sequence and real removal operation; natural-time playback and animation smoothness remain unverified. Integrated checks still need compact height, dark/Chinese, mobile, long-name disclosure, manual scrolling during streaming, return focus, stop, failure/retry and repeat-question continuity.
