from playwright.sync_api import sync_playwright
from pathlib import Path
import json,time,subprocess,os,signal
root=Path('/workspace/scratch/dc68edd00fe1/ui-study/w15');out=root/'evidence/episode';out.mkdir(exist_ok=True)
server=subprocess.Popen(['npm','run','dev','--','--host','127.0.0.1','--port','4415'],cwd=root/'app',stdout=(out/'server.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True)
time.sleep(1.5)
log=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1280,'height':600},device_scale_factor=1)
 page.goto('http://127.0.0.1:4415/?theme=light&lang=en');page.wait_for_timeout(500)
 page.get_by_role('textbox',name='Message input',exact=True).fill('Please compare field research notes.')
 page.get_by_role('button',name='Send message',exact=True).click()
 viewport=page.locator('[data-slot=aui_thread-viewport]')
 def snap(name):
  page.screenshot(path=str(out/(name+'.png')))
  log.append({'name':name,'time':time.monotonic(),'scroll':viewport.evaluate('(e)=>({top:e.scrollTop,height:e.clientHeight,total:e.scrollHeight})'),'lastLength':page.locator('[data-role=assistant]').last.inner_text().__len__(),'focus':page.evaluate('document.activeElement?.getAttribute("aria-label")')})
 page.wait_for_timeout(1800);snap('01-stream')
 viewport.hover();page.mouse.wheel(0,-850);page.wait_for_timeout(250);snap('02-away')
 page.wait_for_timeout(2300);snap('03-away-growing')
 page.get_by_role('button',name='Scroll to bottom',exact=True).click();page.wait_for_timeout(700);snap('04-return')
 page.wait_for_timeout(1000);snap('05-return-growing')
 page.get_by_role('button',name='Stop generating',exact=True).click();page.wait_for_timeout(100);snap('06-stopped')
 page.wait_for_timeout(500);snap('07-stop-stable')
 (out/'log.json').write_text(json.dumps(log,indent=2))
 b.close()
os.killpg(server.pid,signal.SIGTERM)
print(json.dumps(log,indent=2))
