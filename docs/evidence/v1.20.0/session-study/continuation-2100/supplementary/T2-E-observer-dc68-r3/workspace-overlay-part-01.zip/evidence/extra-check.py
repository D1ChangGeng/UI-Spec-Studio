from pathlib import Path
from playwright.sync_api import sync_playwright
import time,subprocess,json,os,signal
r=Path('/workspace/scratch/dc68edd00fe1/ui-study/w15');o=r/'evidence/extra';o.mkdir(exist_ok=True)
s=subprocess.Popen(['npm','run','dev','--','--host','127.0.0.1','--port','55116','--strictPort'],cwd=r/'app',stdout=(o/'server.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True);time.sleep(1.3)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox']);page=b.new_page(viewport={'width':1280,'height':600});page.set_default_timeout(5000);page.goto('http://127.0.0.1:55116/?theme=dark&lang=zh');inp=page.get_by_role('textbox',name='Message input',exact=True)
 inp.fill('\n'.join(f'{i} 请比较研究资料中的事实与解释 and reading continuity.' for i in range(40)))
 with page.expect_file_chooser() as fc:page.get_by_role('button',name='Add Attachment',exact=True).click()
 fc.value.set_files([{'name':f'城市出行访谈摘要_{i}_2026-10-31_final-revised-notes.txt','mimeType':'text/plain','buffer':b''} for i in range(8)])
 region=page.get_by_role('region',name='8 local filenames',exact=True);region.focus();page.keyboard.press('End');page.wait_for_timeout(200)
 assert inp.evaluate('(e)=>e.clientHeight<=192 && e.scrollHeight>e.clientHeight')
 assert region.evaluate('(e)=>e.scrollHeight>e.clientHeight')
 page.screenshot(path=str(o/'long-input-many-files.png'))
 inp.fill('[fail] 中文重试检查');page.get_by_role('button',name='Send message',exact=True).click();page.locator('.aui-message-error-message').wait_for();page.screenshot(path=str(o/'dark-failure.png'))
 page.get_by_role('button',name='Retry response',exact=True).last.click();page.get_by_role('button',name='Stop generating',exact=True).wait_for();page.wait_for_timeout(200);page.get_by_role('button',name='Stop generating',exact=True).click();page.wait_for_timeout(150)
 lastuser=page.locator('[data-role=user]').last;lastuser.scroll_into_view_if_needed();lastuser.hover();page.get_by_role('button',name='Edit',exact=True).last.click();editor=page.locator('.aui-edit-composer-input');editor.fill('Edited local research question');page.get_by_role('button',name='Update',exact=True).click();page.get_by_role('button',name='Stop generating',exact=True).wait_for();page.wait_for_timeout(100);page.get_by_role('button',name='Stop generating',exact=True).click();page.wait_for_timeout(150)
 assert 'Edited local research question' in page.locator('[data-role=user]').last.inner_text()
 (o/'checks.json').write_text(json.dumps({'longMixedInputCappedAndScrollable':True,'eightFilenamesRetainedScrollable':True,'darkFailureRetry':True,'editUpdateContinued':True,'stopFocus':page.evaluate('document.activeElement.getAttribute("aria-label")')},indent=2));print((o/'checks.json').read_text());b.close()
os.killpg(s.pid,signal.SIGTERM)
