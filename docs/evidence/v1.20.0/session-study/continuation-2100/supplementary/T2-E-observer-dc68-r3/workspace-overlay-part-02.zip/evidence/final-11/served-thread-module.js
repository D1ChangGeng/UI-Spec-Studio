import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/assistant-ui/elements/thread.aui.tsx");const createContext = __vite__cjsImport14_react["createContext"]; const useContext = __vite__cjsImport14_react["useContext"]; const useLayoutEffect = __vite__cjsImport14_react["useLayoutEffect"]; const useRef = __vite__cjsImport14_react["useRef"]; const useState = __vite__cjsImport14_react["useState"];const _jsxDEV = __vite__cjsImport15_react_jsxDevRuntime["jsxDEV"];"use client";
import { ComposerAddAttachment, ComposerAttachments, UserMessageAttachments } from "/src/components/assistant-ui/elements/attachment.aui.tsx";
import { File, getFileHref } from "/src/components/assistant-ui/elements/file.tsx";
import { ThreadFollowupSuggestions } from "/src/components/assistant-ui/elements/follow-up-suggestions.aui.tsx";
import { Image } from "/src/components/assistant-ui/elements/image.tsx";
import { MarkdownText } from "/src/components/assistant-ui/elements/markdown-text.tsx";
import { Reasoning, ReasoningContent, ReasoningRoot, ReasoningText, ReasoningTrigger } from "/src/components/assistant-ui/elements/reasoning.aui.tsx";
import { ToolFallback } from "/src/components/assistant-ui/elements/tool-fallback.aui.tsx";
import { ToolGroupContent, ToolGroupRoot, ToolGroupTrigger } from "/src/components/assistant-ui/elements/tool-group.aui.tsx";
import { TooltipIconButton } from "/src/components/assistant-ui/elements/tooltip-icon-button.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Skeleton } from "/src/components/ui/skeleton.tsx";
import { cn } from "/src/lib/utils.ts";
import { ActionBarMorePrimitive, ActionBarPrimitive, AuiIf, BranchPickerPrimitive, ComposerPrimitive, ErrorPrimitive, groupPartByType, MessagePrimitive, SuggestionPrimitive, ThreadPrimitive, useAuiState } from "/node_modules/.vite/deps/@assistant-ui_react.js?v=f4d2f50f";
import { ArrowDownIcon, ArrowUpIcon, AudioLinesIcon, CheckIcon, ChevronLeftIcon, ChevronRightIcon, CopyIcon, DownloadIcon, MicIcon, MoreHorizontalIcon, PencilIcon, PhoneIcon, RefreshCwIcon, SquareIcon, PlayIcon, ThumbsDownIcon, ThumbsUpIcon } from "/node_modules/.vite/deps/lucide-react.js?v=f4d2f50f";
import __vite__cjsImport14_react from "/node_modules/.vite/deps/react.js?v=f4d2f50f";
var _jsxFileName = "/workspace/scratch/dc68edd00fe1/ui-study/w15/app/src/components/assistant-ui/elements/thread.aui.tsx";
import __vite__cjsImport15_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f4d2f50f";
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$(), _s6 = $RefreshSig$(), _s7 = $RefreshSig$(), _s8 = $RefreshSig$(), _s9 = $RefreshSig$(), _s10 = $RefreshSig$();
const DefaultToolGroup = ({ group, children }) => {
	_s();
	const [open, setOpen] = useState(false);
	return /* @__PURE__ */ _jsxDEV(ToolGroupRoot, {
		variant: "ghost",
		open: open || group.counts.requiresAction > 0,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ _jsxDEV(ToolGroupTrigger, {
			count: group.indices.length,
			active: group.status.type === "running"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 91,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV(ToolGroupContent, { children }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 95,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 86,
		columnNumber: 5
	}, this);
};
_s(DefaultToolGroup, "xG1TONbKtDWtdOTrXaTAsNhPg/Q=");
_c = DefaultToolGroup;
const shouldShowComposerResume = (s) => !!s.thread.canResume && s.composer.type === "thread" && s.composer.isEmpty;
const reasoningDuration = (timing) => timing?.completedAt === undefined ? undefined : Math.round((timing.completedAt - timing.startedAt) / 1e3);
const messageGroupBy = groupPartByType({
	reasoning: ["group-chainOfThought", "group-reasoning"],
	"tool-call": ["group-chainOfThought", "group-tool"],
	"standalone-tool-call": []
});
const TASK_GROUP_PATH = ["group-chainOfThought", "group-task"];
const taskAwareGroupBy = (part, context) => {
	const path = messageGroupBy(part, context);
	return part.type === "tool-call" && part.messages !== undefined && path.length > 0 && !context?.toolUIs?.[part.toolName]?.length ? TASK_GROUP_PATH : path;
};
const EMPTY_COMPONENTS = {};
const ThreadComponentsContext = createContext(EMPTY_COMPONENTS);
_c2 = ThreadComponentsContext;
// Startup exposes a loading placeholder thread; treat it as a new chat so
// the composer mounts centered. Loads after startup keep the docked layout.
const isNewChatView = (s) => s.thread.messages.length === 0 && (!s.thread.isLoading || s.threads.isLoading);
// A switched thread that is still fetching its history: skeleton, not welcome.
const isHistoryLoadingView = (s) => s.thread.messages.length === 0 && s.thread.isLoading && !s.thread.isDisabled && !s.threads.isLoading;
const ThreadHistorySkeleton = () => /* @__PURE__ */ _jsxDEV("div", {
	"data-slot": "aui_thread-history-skeleton",
	role: "status",
	className: "animate-in fade-in fill-mode-both flex flex-col gap-y-6 [animation-delay:150ms] [animation-duration:200ms]",
	children: [
		/* @__PURE__ */ _jsxDEV("span", {
			className: "sr-only",
			children: "Loading conversation"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 192,
			columnNumber: 5
		}, this),
		/* @__PURE__ */ _jsxDEV(Skeleton, { className: "ml-auto h-9 w-2/5 rounded-xl motion-reduce:animate-none" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 193,
			columnNumber: 5
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col gap-y-2",
			children: [
				/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-4 w-11/12 motion-reduce:animate-none" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 195,
					columnNumber: 7
				}, this),
				/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-4 w-4/5 motion-reduce:animate-none" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 196,
					columnNumber: 7
				}, this),
				/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-4 w-3/5 motion-reduce:animate-none" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 197,
					columnNumber: 7
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 194,
			columnNumber: 5
		}, this),
		/* @__PURE__ */ _jsxDEV(Skeleton, { className: "ml-auto h-9 w-1/3 rounded-xl motion-reduce:animate-none" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 199,
			columnNumber: 5
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col gap-y-2",
			children: [/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-4 w-10/12 motion-reduce:animate-none" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 201,
				columnNumber: 7
			}, this), /* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-4 w-2/3 motion-reduce:animate-none" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 202,
				columnNumber: 7
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 200,
			columnNumber: 5
		}, this)
	]
}, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 187,
	columnNumber: 3
}, this);
_c3 = ThreadHistorySkeleton;
export const Thread = ({ components = EMPTY_COMPONENTS, autoFocus = true }) => {
	_s2();
	const isEmpty = useAuiState(isNewChatView);
	return /* @__PURE__ */ _jsxDEV(ThreadComponentsContext.Provider, {
		value: components,
		children: /* @__PURE__ */ _jsxDEV(ThreadRoot, {
			isEmpty,
			autoFocus
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 215,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 214,
		columnNumber: 5
	}, this);
};
_s2(Thread, "iNHTDx1GGQn8W1bvzLaGHkzlSro=", false, function() {
	return [useAuiState];
});
_c4 = Thread;
const ThreadRoot = ({ isEmpty, autoFocus }) => {
	_s3();
	const { Welcome = ThreadWelcome } = useContext(ThreadComponentsContext);
	return /* @__PURE__ */ _jsxDEV(ThreadPrimitive.Root, {
		className: "aui-root aui-thread-root bg-background @container flex h-full flex-col",
		style: {
			["--thread-max-width"]: "44rem",
			["--composer-bg"]: "color-mix(in oklab, var(--color-muted) 30%, transparent)",
			["--composer-radius"]: "1rem",
			["--composer-padding"]: "8px"
		},
		children: /* @__PURE__ */ _jsxDEV(ThreadPrimitive.Viewport, {
			turnAnchor: "bottom",
			"data-slot": "aui_thread-viewport",
			className: "relative flex flex-1 flex-col overflow-x-auto overflow-y-scroll scroll-smooth",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: cn("mx-auto flex w-full max-w-(--thread-max-width) flex-1 flex-col px-4 pt-4", isEmpty && "justify-center"),
				children: [
					/* @__PURE__ */ _jsxDEV(AuiIf, {
						condition: isNewChatView,
						children: /* @__PURE__ */ _jsxDEV(Welcome, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 249,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 248,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(AuiIf, {
						condition: isHistoryLoadingView,
						children: /* @__PURE__ */ _jsxDEV(ThreadHistorySkeleton, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 252,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 251,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(ThreadLoadEarlier, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 255,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						"data-slot": "aui_message-group",
						className: "mb-14 flex flex-col gap-y-6 empty:hidden",
						children: /* @__PURE__ */ _jsxDEV(ThreadPrimitive.Messages, { children: () => /* @__PURE__ */ _jsxDEV(ThreadMessage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 262,
							columnNumber: 22
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 261,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 257,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(ThreadPrimitive.ViewportFooter, {
						className: cn("aui-thread-viewport-footer bg-background flex flex-col gap-4 overflow-visible pb-4 md:pb-6", !isEmpty && "sticky bottom-0 mt-auto rounded-t-(--composer-radius)"),
						children: [
							/* @__PURE__ */ _jsxDEV(ThreadScrollToBottom, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 273,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(ThreadFollowupSuggestions, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 274,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(Composer, { autoFocus }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 275,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(AuiIf, {
								condition: (s) => isNewChatView(s) && s.composer.isEmpty,
								children: /* @__PURE__ */ _jsxDEV(ThreadSuggestions, {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 277,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 276,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 266,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 242,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 237,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 227,
		columnNumber: 5
	}, this);
};
_s3(ThreadRoot, "s649FEug4AJsosqqd0txGfAdH2s=");
_c5 = ThreadRoot;
const ThreadMessage = () => {
	_s4();
	const { AssistantMessage: AssistantMessageComponent = AssistantMessage } = useContext(ThreadComponentsContext);
	const role = useAuiState((s) => s.message.role);
	const isEditing = useAuiState((s) => s.message.composer.isEditing);
	const isSpoken = useAuiState((s) => s.message.metadata.modality === "voice");
	if (isEditing) return /* @__PURE__ */ _jsxDEV(EditComposer, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 293,
		columnNumber: 25
	}, this);
	if (isSpoken) return /* @__PURE__ */ _jsxDEV(SpokenMessage, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 294,
		columnNumber: 24
	}, this);
	if (role === "user") return /* @__PURE__ */ _jsxDEV(UserMessage, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 295,
		columnNumber: 31
	}, this);
	return /* @__PURE__ */ _jsxDEV(AssistantMessageComponent, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 296,
		columnNumber: 10
	}, this);
};
_s4(ThreadMessage, "Dr2f1TvMOfeBXXTV0cun5luc7X0=", false, function() {
	return [
		useAuiState,
		useAuiState,
		useAuiState
	];
});
_c6 = ThreadMessage;
const useVoiceRunPosition = () => {
	_s5();
	return useAuiState((s) => {
		const before = s.thread.messages[s.message.index - 1]?.metadata.modality === "voice";
		const after = s.thread.messages[s.message.index + 1]?.metadata.modality === "voice";
		if (before) return after ? "middle" : "end";
		return after ? "start" : "single";
	});
};
_s5(useVoiceRunPosition, "kbE+C4pk3mcZo+W+dXJ9ArS6lK4=", false, function() {
	return [useAuiState];
});
const SpokenText = ({ text }) => /* @__PURE__ */ _jsxDEV("p", {
	className: "aui-spoken-message-text m-0",
	children: text
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 312,
	columnNumber: 3
}, this);
_c7 = SpokenText;
const SpokenMessage = () => {
	_s6();
	const role = useAuiState((s) => s.message.role);
	const position = useVoiceRunPosition();
	const isSpeaking = useAuiState((s) => s.message.role === "assistant" && s.message.status?.type === "running");
	const opensExchange = position === "start" || position === "single";
	return /* @__PURE__ */ _jsxDEV(MessagePrimitive.Root, {
		"data-slot": "aui_spoken-message-root",
		"data-role": role,
		"data-voice-run": position,
		className: cn("aui-spoken-message bg-muted/40 mx-2 px-3 py-1.5 [contain-intrinsic-size:auto_48px] [content-visibility:auto]", position === "single" && "rounded-xl py-2", position === "start" && "rounded-t-xl pt-2", position === "middle" && "-mt-6", position === "end" && "-mt-6 rounded-b-xl pb-2"),
		children: [opensExchange && /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "aui_spoken-exchange-header",
			className: "text-muted-foreground mb-1.5 flex items-center gap-1.5 text-xs",
			children: [/* @__PURE__ */ _jsxDEV(PhoneIcon, {
				className: "size-3",
				"aria-hidden": true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 342,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Voice conversation" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 343,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 338,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "aui_spoken-message-content",
			className: "text-foreground flex items-start gap-2 text-sm leading-relaxed",
			children: [
				/* @__PURE__ */ _jsxDEV("span", {
					className: "text-muted-foreground mt-1 shrink-0",
					"aria-hidden": true,
					children: role === "user" ? /* @__PURE__ */ _jsxDEV(MicIcon, { className: "size-3.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 352,
						columnNumber: 13
					}, this) : /* @__PURE__ */ _jsxDEV(AudioLinesIcon, { className: "size-3.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 354,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 350,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					className: "sr-only",
					children: role === "user" ? "You said" : "Assistant said"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 357,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "min-w-0 flex-1 wrap-break-word",
					children: [/* @__PURE__ */ _jsxDEV(MessagePrimitive.Parts, { components: { Text: SpokenText } }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 361,
						columnNumber: 11
					}, this), isSpeaking && /* @__PURE__ */ _jsxDEV("span", {
						"data-slot": "aui_spoken-message-indicator",
						role: "status",
						className: "text-muted-foreground ms-1 animate-pulse font-sans",
						"aria-label": "Assistant is speaking",
						children: "●"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 363,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 360,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(SpokenActionBar, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 373,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 346,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 325,
		columnNumber: 5
	}, this);
};
_s6(SpokenMessage, "TavhQulRNR/A7Kt4bY6z+4Hk3U4=", false, function() {
	return [
		useAuiState,
		useVoiceRunPosition,
		useAuiState
	];
});
_c8 = SpokenMessage;
const SpokenActionBar = () => {
	return /* @__PURE__ */ _jsxDEV(ActionBarPrimitive.Root, {
		hideWhenRunning: true,
		autohide: "always",
		className: "aui-spoken-action-bar text-muted-foreground flex shrink-0 gap-1",
		children: /* @__PURE__ */ _jsxDEV(ActionBarPrimitive.Copy, {
			asChild: true,
			children: /* @__PURE__ */ _jsxDEV(TooltipIconButton, {
				tooltip: "Copy",
				className: "size-6",
				children: [/* @__PURE__ */ _jsxDEV(AuiIf, {
					condition: (s) => s.message.isCopied,
					children: /* @__PURE__ */ _jsxDEV(CheckIcon, { className: "animate-in zoom-in-50 fade-in duration-200 ease-out" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 389,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 388,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(AuiIf, {
					condition: (s) => !s.message.isCopied,
					children: /* @__PURE__ */ _jsxDEV(CopyIcon, { className: "animate-in zoom-in-75 fade-in duration-150" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 392,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 391,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 387,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 386,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 381,
		columnNumber: 5
	}, this);
};
_c9 = SpokenActionBar;
const FOCUSABLE_SELECTOR = "a[href], button:not([disabled]), input:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex='-1']):not([disabled])";
const nextFocusable = (start) => {
	for (let element = start.nextElementSibling; element; element = element.nextElementSibling) {
		const target = element.matches(FOCUSABLE_SELECTOR) ? element : element.querySelector(FOCUSABLE_SELECTOR);
		if (target instanceof HTMLElement) return target;
	}
	return null;
};
const ThreadLoadEarlier = () => {
	_s7();
	const visible = useAuiState((s) => s.thread.hasEarlier || s.thread.isLoadingEarlier);
	const loading = useAuiState((s) => s.thread.isLoadingEarlier);
	const slotRef = useRef(null);
	const focusedRef = useRef(null);
	// The last page removes the button; a keyboard user on it continues from the
	// next control in tab order rather than from the document body.
	useLayoutEffect(() => {
		const focused = focusedRef.current;
		const slot = slotRef.current;
		if (visible || !focused || focused.isConnected || !slot) return;
		focusedRef.current = null;
		const active = document.activeElement;
		if (active && active !== document.body) return;
		nextFocusable(slot)?.focus();
	}, [visible]);
	return /* @__PURE__ */ _jsxDEV("div", {
		ref: slotRef,
		className: "contents",
		onFocus: (event) => {
			focusedRef.current = event.target;
		},
		children: [/* @__PURE__ */ _jsxDEV("span", {
			role: "status",
			className: "sr-only",
			children: loading ? "Loading earlier messages" : ""
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 445,
			columnNumber: 7
		}, this), visible && /* @__PURE__ */ _jsxDEV(ThreadPrimitive.LoadEarlier, {
			asChild: true,
			children: /* @__PURE__ */ _jsxDEV(Button, {
				variant: "ghost",
				size: "sm",
				"data-slot": "aui_thread-load-earlier",
				className: "aui-thread-load-earlier text-muted-foreground mb-6 self-center rounded-full",
				children: /* @__PURE__ */ _jsxDEV("span", {
					className: cn(loading && "shimmer motion-reduce:animate-none"),
					children: loading ? "Loading earlier messages" : "Load earlier messages"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 456,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 450,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 449,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 438,
		columnNumber: 5
	}, this);
};
_s7(ThreadLoadEarlier, "lDyF7iI8q6Z3Z/zr5MaGV9NWrSA=", false, function() {
	return [useAuiState, useAuiState];
});
_c10 = ThreadLoadEarlier;
const ThreadScrollToBottom = () => {
	return /* @__PURE__ */ _jsxDEV(ThreadPrimitive.ScrollToBottom, {
		behavior: "instant",
		asChild: true,
		children: /* @__PURE__ */ _jsxDEV(TooltipIconButton, {
			tooltip: "Scroll to bottom",
			variant: "outline",
			className: "aui-thread-scroll-to-bottom dark:border-border dark:bg-background dark:hover:bg-accent absolute -top-12 z-10 self-center rounded-full p-4 disabled:invisible",
			children: /* @__PURE__ */ _jsxDEV(ArrowDownIcon, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 476,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 471,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 470,
		columnNumber: 5
	}, this);
};
_c11 = ThreadScrollToBottom;
const ThreadWelcome = () => {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "aui-thread-welcome-root mb-6 flex flex-col px-2",
		children: /* @__PURE__ */ _jsxDEV("p", {
			className: "aui-thread-welcome-message-inner fade-in slide-in-from-bottom-1 animate-in fill-mode-both text-2xl font-medium tracking-tight duration-200",
			children: "How can I help you today?"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 485,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 484,
		columnNumber: 5
	}, this);
};
_c12 = ThreadWelcome;
const ThreadSuggestions = () => {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "aui-thread-welcome-suggestions flex w-full flex-col",
		children: /* @__PURE__ */ _jsxDEV(ThreadPrimitive.Suggestions, { children: () => /* @__PURE__ */ _jsxDEV(ThreadSuggestionItem, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 496,
			columnNumber: 16
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 495,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 494,
		columnNumber: 5
	}, this);
};
_c13 = ThreadSuggestions;
const ThreadSuggestionItem = () => {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "aui-thread-welcome-suggestion-display fade-in slide-in-from-bottom-2 animate-in fill-mode-both duration-200",
		children: /* @__PURE__ */ _jsxDEV(SuggestionPrimitive.Trigger, {
			send: true,
			asChild: true,
			children: /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				className: "aui-thread-welcome-suggestion group hover:bg-foreground/[0.03] focus-visible:ring-ring/50 flex w-full items-baseline gap-2.5 rounded-md px-2 py-2 text-start text-sm transition-colors outline-none focus-visible:ring-1 motion-reduce:transition-none",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					"aria-hidden": true,
					className: "text-muted-foreground/60 group-hover:text-foreground font-mono text-xs transition-colors motion-reduce:transition-none",
					children: ">"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 510,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "min-w-0 flex-1 truncate",
					children: [
						/* @__PURE__ */ _jsxDEV(SuggestionPrimitive.Title, { className: "aui-thread-welcome-suggestion-text-1 text-foreground" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 517,
							columnNumber: 13
						}, this),
						" ",
						/* @__PURE__ */ _jsxDEV(SuggestionPrimitive.Description, { className: "aui-thread-welcome-suggestion-text-2 text-muted-foreground empty:hidden" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 518,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 516,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 506,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 505,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 504,
		columnNumber: 5
	}, this);
};
_c14 = ThreadSuggestionItem;
const Composer = ({ autoFocus }) => {
	return /* @__PURE__ */ _jsxDEV(ComposerPrimitive.Root, {
		className: "aui-composer-root relative flex w-full flex-col",
		children: /* @__PURE__ */ _jsxDEV(ComposerPrimitive.AttachmentDropzone, {
			asChild: true,
			children: /* @__PURE__ */ _jsxDEV("div", {
				"data-slot": "aui_composer-shell",
				className: "border-foreground/10 focus-within:border-foreground/25 data-[dragging=true]:border-ring flex w-full cursor-text flex-col gap-2 rounded-(--composer-radius) border bg-(--composer-bg) p-(--composer-padding) transition-[border-color] data-[dragging=true]:border-dashed data-[dragging=true]:bg-[color-mix(in_oklab,var(--color-accent)_50%,var(--color-background))]",
				children: [
					/* @__PURE__ */ _jsxDEV(ComposerAttachments, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 534,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(ComposerPrimitive.Input, {
						placeholder: "Send a message...",
						className: "aui-composer-input caret-primary placeholder:text-muted-foreground/60 max-h-48 min-h-10 w-full resize-none bg-transparent px-2.5 py-1 text-base leading-6 outline-none",
						rows: 1,
						autoFocus,
						enterKeyHint: "send",
						"aria-label": "Message input"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 535,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(ComposerAction, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 543,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 530,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 529,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 528,
		columnNumber: 5
	}, this);
};
_c15 = Composer;
const ComposerAction = () => {
	_s8();
	const { ComposerExtra } = useContext(ThreadComponentsContext);
	// The stop control only cancels the send while no run it could stop is going.
	const isSending = useAuiState((s) => s.composer.submission !== undefined && !(s.thread.isRunning && s.thread.capabilities.cancel));
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "aui-composer-action-wrapper relative flex items-center justify-between",
		children: [ComposerExtra ? /* @__PURE__ */ _jsxDEV("div", {
			className: "aui-composer-action-start flex items-center gap-1.5",
			children: [/* @__PURE__ */ _jsxDEV(ComposerAddAttachment, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 563,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV(ComposerExtra, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 564,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 562,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV(ComposerAddAttachment, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 567,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center gap-1.5",
			children: [
				/* @__PURE__ */ _jsxDEV(AuiIf, {
					condition: (s) => s.thread.capabilities.dictation,
					children: [/* @__PURE__ */ _jsxDEV(AuiIf, {
						condition: (s) => s.composer.dictation == null,
						children: /* @__PURE__ */ _jsxDEV(ComposerPrimitive.Dictate, {
							asChild: true,
							children: /* @__PURE__ */ _jsxDEV(TooltipIconButton, {
								tooltip: "Voice input",
								side: "bottom",
								type: "button",
								variant: "ghost",
								size: "icon",
								className: "aui-composer-dictate text-muted-foreground hover:text-foreground size-7 rounded-full",
								"aria-label": "Start voice input",
								children: /* @__PURE__ */ _jsxDEV(MicIcon, { className: "aui-composer-dictate-icon size-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 582,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 573,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 572,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 571,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(AuiIf, {
						condition: (s) => s.composer.dictation != null,
						children: /* @__PURE__ */ _jsxDEV(ComposerPrimitive.StopDictation, {
							asChild: true,
							children: /* @__PURE__ */ _jsxDEV(TooltipIconButton, {
								tooltip: "Stop dictation",
								side: "bottom",
								type: "button",
								variant: "ghost",
								size: "icon",
								className: "aui-composer-stop-dictation text-destructive size-7 rounded-full",
								"aria-label": "Stop voice input",
								children: /* @__PURE__ */ _jsxDEV(SquareIcon, { className: "aui-composer-stop-dictation-icon size-3.5 animate-pulse fill-current" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 597,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 588,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 587,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 586,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 570,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(AuiIf, {
					condition: (s) => (!s.composer.canCancel || s.thread.voice !== undefined && s.composer.submission === undefined) && !shouldShowComposerResume(s),
					children: /* @__PURE__ */ _jsxDEV(ComposerPrimitive.Send, {
						asChild: true,
						children: /* @__PURE__ */ _jsxDEV(TooltipIconButton, {
							tooltip: "Send message",
							side: "bottom",
							type: "button",
							variant: "default",
							size: "icon",
							className: "aui-composer-send size-7 rounded-full",
							"aria-label": "Send message",
							children: /* @__PURE__ */ _jsxDEV(ArrowUpIcon, { className: "aui-composer-send-icon size-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 620,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 611,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 610,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 602,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(AuiIf, {
					condition: shouldShowComposerResume,
					children: /* @__PURE__ */ _jsxDEV(ComposerPrimitive.Resume, {
						asChild: true,
						children: /* @__PURE__ */ _jsxDEV(TooltipIconButton, {
							tooltip: "Resume generating",
							side: "bottom",
							type: "button",
							variant: "default",
							size: "icon",
							className: "aui-composer-resume size-7 rounded-full",
							"aria-label": "Resume generating",
							children: /* @__PURE__ */ _jsxDEV(PlayIcon, { className: "aui-composer-resume-icon size-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 635,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 626,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 625,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 624,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(AuiIf, {
					condition: (s) => s.composer.canCancel && (s.thread.voice === undefined || s.composer.submission !== undefined),
					children: /* @__PURE__ */ _jsxDEV(ComposerPrimitive.Cancel, {
						asChild: true,
						children: /* @__PURE__ */ _jsxDEV(Button, {
							type: "button",
							variant: "default",
							size: "icon",
							className: "aui-composer-cancel size-7 rounded-full",
							"aria-label": isSending ? "Cancel sending" : "Stop generating",
							onClick: () => requestAnimationFrame(() => document.querySelector(".aui-composer-input")?.focus()),
							children: /* @__PURE__ */ _jsxDEV(SquareIcon, { className: "aui-composer-cancel-icon size-3.5 fill-current" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 655,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 647,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 646,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 639,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 569,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 560,
		columnNumber: 5
	}, this);
};
_s8(ComposerAction, "fiSBgvABja4sY/yCcAlEIdRNTCQ=", false, function() {
	return [useAuiState];
});
_c16 = ComposerAction;
const MessageError = () => {
	return /* @__PURE__ */ _jsxDEV(MessagePrimitive.Error, { children: /* @__PURE__ */ _jsxDEV(ErrorPrimitive.Root, {
		role: "alert",
		className: "aui-message-error-root border-destructive bg-destructive/10 text-destructive dark:bg-destructive/5 mt-2 rounded-md border p-3 text-sm dark:text-red-200",
		children: /* @__PURE__ */ _jsxDEV(ErrorPrimitive.Message, { className: "aui-message-error-message line-clamp-2" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 668,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 667,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 666,
		columnNumber: 5
	}, this);
};
_c17 = MessageError;
const AssistantMessage = () => {
	_s9();
	const { ToolFallback: ToolFallbackComponent = ToolFallback, ToolGroup, ReasoningGroup, TaskGroup: TaskGroupComponent } = useContext(ThreadComponentsContext);
	const groupBy = TaskGroupComponent ? taskAwareGroupBy : messageGroupBy;
	const ACTION_BAR_PT = "pt-1.5";
	// Keep the action bar inside the contained root's paint box, then cancel its reserved space in flow.
	const ACTION_BAR_HEIGHT = `min-h-7.5 ${ACTION_BAR_PT}`;
	return /* @__PURE__ */ _jsxDEV(MessagePrimitive.Root, {
		"data-slot": "aui_assistant-message-root",
		"data-role": "assistant",
		className: "fade-in slide-in-from-bottom-1 animate-in relative -mb-7.5 pb-7.5 duration-150 [contain-intrinsic-size:auto_200px] [content-visibility:auto]",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "aui_assistant-message-content",
			className: "text-foreground px-2 leading-relaxed wrap-break-word",
			children: [/* @__PURE__ */ _jsxDEV(MessagePrimitive.GroupedParts, {
				groupBy,
				children: ({ part, children }) => {
					switch (part.type) {
						case "group-chainOfThought": return /* @__PURE__ */ _jsxDEV("div", {
							"data-slot": "aui_chain-of-thought",
							children
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 701,
							columnNumber: 24
						}, this);
						case "group-task": return TaskGroupComponent ? /* @__PURE__ */ _jsxDEV(TaskGroupComponent, { group: part }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 704,
							columnNumber: 19
						}, this) : null;
						case "group-tool":
							if (ToolGroup) {
								return /* @__PURE__ */ _jsxDEV(ToolGroup, {
									group: part,
									children
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 708,
									columnNumber: 26
								}, this);
							}
							return /* @__PURE__ */ _jsxDEV(DefaultToolGroup, {
								group: part,
								children
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 711,
								columnNumber: 19
							}, this);
						case "group-reasoning": {
							if (ReasoningGroup) {
								return /* @__PURE__ */ _jsxDEV(ReasoningGroup, {
									group: part,
									children
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 716,
									columnNumber: 21
								}, this);
							}
							const running = part.status.type === "running";
							return /* @__PURE__ */ _jsxDEV(ReasoningRoot, {
								streaming: running,
								children: [/* @__PURE__ */ _jsxDEV(ReasoningTrigger, {
									active: running,
									duration: reasoningDuration(part.timing)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 722,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV(ReasoningContent, {
									"aria-busy": running,
									children: /* @__PURE__ */ _jsxDEV(ReasoningText, { children }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 727,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 726,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 721,
								columnNumber: 19
							}, this);
						}
						case "text": return /* @__PURE__ */ _jsxDEV(MarkdownText, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 733,
							columnNumber: 24
						}, this);
						case "reasoning": return /* @__PURE__ */ _jsxDEV(Reasoning, { ...part }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 735,
							columnNumber: 24
						}, this);
						case "tool-call": return part.toolUI ?? /* @__PURE__ */ _jsxDEV(ToolFallbackComponent, { ...part }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 737,
							columnNumber: 39
						}, this);
						case "data": return part.dataRendererUI;
						case "file": return /* @__PURE__ */ _jsxDEV("div", {
							"data-slot": "aui_assistant-message-file",
							className: "py-1",
							children: /* @__PURE__ */ _jsxDEV(MessageFile, { ...part }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 743,
								columnNumber: 21
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 742,
							columnNumber: 19
						}, this);
						case "image": return /* @__PURE__ */ _jsxDEV("div", {
							"data-slot": "aui_assistant-message-image",
							className: "py-1",
							children: /* @__PURE__ */ _jsxDEV(Image, { ...part }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 749,
								columnNumber: 21
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 748,
							columnNumber: 19
						}, this);
						case "indicator": return /* @__PURE__ */ _jsxDEV("span", {
							"data-slot": "aui_assistant-message-indicator",
							className: "animate-pulse font-sans",
							"aria-label": "Assistant is working",
							children: "●"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 754,
							columnNumber: 19
						}, this);
						default: return null;
					}
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 697,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV(MessageError, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 767,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 693,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "aui_assistant-message-footer",
			className: cn("ms-2 flex items-center", ACTION_BAR_HEIGHT),
			children: [/* @__PURE__ */ _jsxDEV(BranchPicker, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 774,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV(AssistantActionBar, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 775,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 770,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 688,
		columnNumber: 5
	}, this);
};
_s9(AssistantMessage, "boS+/3GNTusHOkJF400Ib2+m3Fw=");
_c18 = AssistantMessage;
const AssistantActionBar = () => {
	_s10();
	const failed = useAuiState((s) => s.message.status?.type === "incomplete" && s.message.status.reason === "error");
	return /* @__PURE__ */ _jsxDEV(ActionBarPrimitive.Root, {
		hideWhenRunning: true,
		autohide: "not-last",
		className: "aui-assistant-action-bar-root text-muted-foreground animate-in fade-in col-start-3 row-start-2 -ms-1 flex gap-1 duration-200",
		children: [
			/* @__PURE__ */ _jsxDEV(ActionBarPrimitive.Copy, {
				asChild: true,
				children: /* @__PURE__ */ _jsxDEV(TooltipIconButton, {
					tooltip: "Copy",
					children: [/* @__PURE__ */ _jsxDEV(AuiIf, {
						condition: (s) => s.message.isCopied,
						children: /* @__PURE__ */ _jsxDEV(CheckIcon, { className: "animate-in zoom-in-50 fade-in duration-200 ease-out" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 792,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 791,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(AuiIf, {
						condition: (s) => !s.message.isCopied,
						children: /* @__PURE__ */ _jsxDEV(CopyIcon, { className: "animate-in zoom-in-75 fade-in duration-150" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 795,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 794,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 790,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 789,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(AuiIf, {
				condition: (s) => s.thread.capabilities.feedback,
				children: [/* @__PURE__ */ _jsxDEV(ActionBarPrimitive.FeedbackPositive, {
					asChild: true,
					children: /* @__PURE__ */ _jsxDEV(TooltipIconButton, {
						tooltip: "Helpful",
						className: "data-[submitted=true]:bg-accent data-[submitted=true]:text-accent-foreground",
						children: /* @__PURE__ */ _jsxDEV(ThumbsUpIcon, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 805,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 801,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 800,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV(ActionBarPrimitive.FeedbackNegative, {
					asChild: true,
					children: /* @__PURE__ */ _jsxDEV(TooltipIconButton, {
						tooltip: "Not helpful",
						className: "data-[submitted=true]:bg-accent data-[submitted=true]:text-accent-foreground",
						children: /* @__PURE__ */ _jsxDEV(ThumbsDownIcon, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 813,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 809,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 808,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 799,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(ActionBarPrimitive.Reload, {
				asChild: true,
				children: /* @__PURE__ */ _jsxDEV(TooltipIconButton, {
					tooltip: failed ? "Retry response" : "Refresh",
					children: /* @__PURE__ */ _jsxDEV(RefreshCwIcon, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 819,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 818,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 817,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(ActionBarMorePrimitive.Root, { children: [/* @__PURE__ */ _jsxDEV(ActionBarMorePrimitive.Trigger, {
				asChild: true,
				children: /* @__PURE__ */ _jsxDEV(TooltipIconButton, {
					tooltip: "More",
					className: "data-[state=open]:bg-accent",
					children: /* @__PURE__ */ _jsxDEV(MoreHorizontalIcon, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 828,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 824,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 823,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV(ActionBarMorePrimitive.Content, {
				side: "bottom",
				align: "start",
				sideOffset: 6,
				className: "aui-action-bar-more-content bg-popover text-popover-foreground data-[state=open]:fade-in-0 data-[state=open]:zoom-in-95 data-[state=open]:animate-in data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[state=closed]:animate-out data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 min-w-[8rem] overflow-hidden rounded-xl border p-1.5",
				children: /* @__PURE__ */ _jsxDEV(ActionBarPrimitive.ExportMarkdown, {
					asChild: true,
					children: /* @__PURE__ */ _jsxDEV(ActionBarMorePrimitive.Item, {
						className: "aui-action-bar-more-item hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground flex items-center gap-2 rounded-lg px-2.5 py-1.5 text-sm outline-none select-none",
						children: [/* @__PURE__ */ _jsxDEV(DownloadIcon, { className: "size-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 839,
							columnNumber: 15
						}, this), "Export as Markdown"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 838,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 837,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 831,
				columnNumber: 9
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 822,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 784,
		columnNumber: 5
	}, this);
};
_s10(AssistantActionBar, "h6HcwV8xFAhscanY/NK2bhowiyc=", false, function() {
	return [useAuiState];
});
_c19 = AssistantActionBar;
const MessageFile = (part) => {
	const image = part.mimeType.toLowerCase().startsWith("image/") ? getFileHref(part.data, part.mimeType, part.sourceType) : null;
	if (!image) return /* @__PURE__ */ _jsxDEV(File, { ...part }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 853,
		columnNumber: 22
	}, this);
	return /* @__PURE__ */ _jsxDEV(Image, {
		type: "image",
		image,
		status: part.status,
		...part.filename !== undefined && { filename: part.filename }
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 855,
		columnNumber: 5
	}, this);
};
_c20 = MessageFile;
const UserFilePart = (part) => /* @__PURE__ */ _jsxDEV("div", {
	"data-slot": "aui_user-message-file",
	className: "py-1",
	children: /* @__PURE__ */ _jsxDEV(MessageFile, { ...part }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 866,
		columnNumber: 5
	}, this)
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 865,
	columnNumber: 3
}, this);
_c21 = UserFilePart;
const UserImagePart = (part) => /* @__PURE__ */ _jsxDEV("div", {
	"data-slot": "aui_user-message-image",
	className: "py-1",
	children: /* @__PURE__ */ _jsxDEV(Image, { ...part }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 872,
		columnNumber: 5
	}, this)
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 871,
	columnNumber: 3
}, this);
_c22 = UserImagePart;
const UserMessage = () => {
	return /* @__PURE__ */ _jsxDEV(MessagePrimitive.Root, {
		"data-slot": "aui_user-message-root",
		className: "fade-in slide-in-from-bottom-1 animate-in grid auto-rows-auto grid-cols-[minmax(72px,1fr)_auto] content-start gap-y-2 px-2 duration-150 [contain-intrinsic-size:auto_200px] [content-visibility:auto] [&:where(>*)]:col-start-2",
		"data-role": "user",
		children: [
			/* @__PURE__ */ _jsxDEV(UserMessageAttachments, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 883,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "aui-user-message-content-wrapper relative col-start-2 min-w-0",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "aui-user-message-content peer bg-muted text-foreground rounded-(--composer-radius) px-4 py-2 wrap-break-word empty:hidden",
					children: /* @__PURE__ */ _jsxDEV(MessagePrimitive.Parts, { components: {
						File: UserFilePart,
						Image: UserImagePart
					} }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 887,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 886,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "aui-user-action-bar-wrapper absolute start-0 top-1/2 -translate-x-full -translate-y-1/2 pe-2 peer-empty:hidden rtl:translate-x-full",
					children: /* @__PURE__ */ _jsxDEV(UserActionBar, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 892,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 891,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 885,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(BranchPicker, {
				"data-slot": "aui_user-branch-picker",
				className: "col-span-full col-start-1 -me-1 justify-end"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 896,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 878,
		columnNumber: 5
	}, this);
};
_c23 = UserMessage;
const UserActionBar = () => {
	return /* @__PURE__ */ _jsxDEV(ActionBarPrimitive.Root, {
		hideWhenRunning: true,
		autohide: "not-last",
		className: "aui-user-action-bar-root flex flex-col items-end",
		children: /* @__PURE__ */ _jsxDEV(ActionBarPrimitive.Edit, {
			asChild: true,
			children: /* @__PURE__ */ _jsxDEV(TooltipIconButton, {
				tooltip: "Edit",
				className: "aui-user-action-edit",
				children: /* @__PURE__ */ _jsxDEV(PencilIcon, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 913,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 912,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 911,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 906,
		columnNumber: 5
	}, this);
};
_c24 = UserActionBar;
const EditComposer = () => {
	return /* @__PURE__ */ _jsxDEV(MessagePrimitive.Root, {
		"data-slot": "aui_edit-composer-wrapper",
		className: "flex flex-col px-2 [contain-intrinsic-size:auto_200px] [content-visibility:auto]",
		children: /* @__PURE__ */ _jsxDEV(ComposerPrimitive.Root, {
			className: "aui-edit-composer-root border-foreground/10 focus-within:border-foreground/25 ms-auto flex w-full max-w-[85%] cursor-text flex-col rounded-(--composer-radius) border bg-(--composer-bg) transition-[border-color]",
			children: [/* @__PURE__ */ _jsxDEV(ComposerPrimitive.Input, {
				className: "aui-edit-composer-input text-foreground min-h-14 w-full resize-none bg-transparent px-4 pt-3 pb-1 text-base outline-none",
				autoFocus: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 927,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "aui-edit-composer-footer mx-2.5 mb-2.5 flex items-center gap-1.5 self-end",
				children: [/* @__PURE__ */ _jsxDEV(ComposerPrimitive.Cancel, {
					asChild: true,
					children: /* @__PURE__ */ _jsxDEV(Button, {
						variant: "ghost",
						size: "sm",
						className: "h-8 px-3",
						children: "Cancel"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 933,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 932,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(ComposerPrimitive.Send, {
					asChild: true,
					children: /* @__PURE__ */ _jsxDEV(Button, {
						size: "sm",
						className: "h-8 px-3",
						children: "Update"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 938,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 937,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 931,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 926,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 922,
		columnNumber: 5
	}, this);
};
_c25 = EditComposer;
const BranchPicker = ({ className, ...rest }) => {
	return /* @__PURE__ */ _jsxDEV(BranchPickerPrimitive.Root, {
		hideWhenSingleBranch: true,
		className: cn("aui-branch-picker-root text-muted-foreground -ms-2 me-2 inline-flex items-center text-xs", className),
		...rest,
		children: [
			/* @__PURE__ */ _jsxDEV(BranchPickerPrimitive.Previous, {
				asChild: true,
				children: /* @__PURE__ */ _jsxDEV(TooltipIconButton, {
					tooltip: "Previous",
					children: /* @__PURE__ */ _jsxDEV(ChevronLeftIcon, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 963,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 962,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 961,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("span", {
				className: "aui-branch-picker-state font-medium",
				children: [
					/* @__PURE__ */ _jsxDEV(BranchPickerPrimitive.Number, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 967,
						columnNumber: 9
					}, this),
					" / ",
					/* @__PURE__ */ _jsxDEV(BranchPickerPrimitive.Count, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 967,
						columnNumber: 44
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 966,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(BranchPickerPrimitive.Next, {
				asChild: true,
				children: /* @__PURE__ */ _jsxDEV(TooltipIconButton, {
					tooltip: "Next",
					children: /* @__PURE__ */ _jsxDEV(ChevronRightIcon, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 971,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 970,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 969,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 953,
		columnNumber: 5
	}, this);
};
_c26 = BranchPicker;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14, _c15, _c16, _c17, _c18, _c19, _c20, _c21, _c22, _c23, _c24, _c25, _c26;
$RefreshReg$(_c, "DefaultToolGroup");
$RefreshReg$(_c2, "ThreadComponentsContext");
$RefreshReg$(_c3, "ThreadHistorySkeleton");
$RefreshReg$(_c4, "Thread");
$RefreshReg$(_c5, "ThreadRoot");
$RefreshReg$(_c6, "ThreadMessage");
$RefreshReg$(_c7, "SpokenText");
$RefreshReg$(_c8, "SpokenMessage");
$RefreshReg$(_c9, "SpokenActionBar");
$RefreshReg$(_c10, "ThreadLoadEarlier");
$RefreshReg$(_c11, "ThreadScrollToBottom");
$RefreshReg$(_c12, "ThreadWelcome");
$RefreshReg$(_c13, "ThreadSuggestions");
$RefreshReg$(_c14, "ThreadSuggestionItem");
$RefreshReg$(_c15, "Composer");
$RefreshReg$(_c16, "ComposerAction");
$RefreshReg$(_c17, "MessageError");
$RefreshReg$(_c18, "AssistantMessage");
$RefreshReg$(_c19, "AssistantActionBar");
$RefreshReg$(_c20, "MessageFile");
$RefreshReg$(_c21, "UserFilePart");
$RefreshReg$(_c22, "UserImagePart");
$RefreshReg$(_c23, "UserMessage");
$RefreshReg$(_c24, "UserActionBar");
$RefreshReg$(_c25, "EditComposer");
$RefreshReg$(_c26, "BranchPicker");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/assistant-ui/elements/thread.aui.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/workspace/scratch/dc68edd00fe1/ui-study/w15/app/src/components/assistant-ui/elements/thread.aui.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/workspace/scratch/dc68edd00fe1/ui-study/w15/app/src/components/assistant-ui/elements/thread.aui.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/workspace/scratch/dc68edd00fe1/ui-study/w15/app/src/components/assistant-ui/elements/thread.aui.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUE7QUFFQSxTQUNFLHVCQUNBLHFCQUNBLDhCQUNLO0FBQ1AsU0FBUyxNQUFNLG1CQUFtQjtBQUNsQyxTQUFTLGlDQUFpQztBQUMxQyxTQUFTLGFBQWE7QUFDdEIsU0FBUyxvQkFBb0I7QUFDN0IsU0FDRSxXQUNBLGtCQUNBLGVBQ0EsZUFDQSx3QkFDSztBQUNQLFNBQVMsb0JBQW9CO0FBQzdCLFNBQ0Usa0JBQ0EsZUFDQSx3QkFDSztBQUNQLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMsY0FBYztBQUN2QixTQUFTLGdCQUFnQjtBQUN6QixTQUFTLFVBQVU7QUFDbkIsU0FDRSx3QkFDQSxvQkFDQSxPQUVBLHVCQUNBLG1CQUNBLGdCQUNBLGlCQUNBLGtCQUNBLHFCQUNBLGlCQUtBLG1CQUNLO0FBQ1AsU0FDRSxlQUNBLGFBQ0EsZ0JBQ0EsV0FDQSxpQkFDQSxrQkFDQSxVQUNBLGNBQ0EsU0FDQSxvQkFDQSxZQUNBLFdBQ0EsZUFDQSxZQUNBLFVBQ0EsZ0JBQ0Esb0JBQ0s7QUFDUCxTQUNFLGVBQ0EsWUFDQSxpQkFDQSxRQUNBLGdCQUlLOzs7O0FBSVAsTUFBTSxvQkFBdUUsRUFDM0UsT0FDQSxlQUNJOztDQUNKLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxLQUFLO0NBRXRDLE9BQ0Usd0JBQUMsZUFBRDtFQUNFLFNBQVE7RUFDUixNQUFNLFFBQVEsTUFBTSxPQUFPLGlCQUFpQjtFQUM1QyxjQUFjO1lBSGhCLENBS0Usd0JBQUMsa0JBQUQ7R0FDRSxPQUFPLE1BQU0sUUFBUTtHQUNyQixRQUFRLE1BQU0sT0FBTyxTQUFTO0VBQy9COzs7O1lBQ0Qsd0JBQUMsa0JBQUQsRUFBbUIsU0FBMkI7Ozs7VUFDakM7Ozs7OztBQUVuQjs7O0FBRUEsTUFBTSw0QkFBNEIsTUFDaEMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxhQUFhLEVBQUUsU0FBUyxTQUFTLFlBQVksRUFBRSxTQUFTO0FBRXJFLE1BQU0scUJBQXFCLFdBQ3pCLFFBQVEsZ0JBQWdCLFlBQ3BCLFlBQ0EsS0FBSyxPQUFPLE9BQU8sY0FBYyxPQUFPLGFBQWEsR0FBSTtBQTJCL0QsTUFBTSxpQkFBaUIsZ0JBQWdCO0NBQ3JDLFdBQVcsQ0FBQyx3QkFBd0IsaUJBQWlCO0NBQ3JELGFBQWEsQ0FBQyx3QkFBd0IsWUFBWTtDQUNsRCx3QkFBd0IsQ0FBQztBQUMzQixDQUFDO0FBUUQsTUFBTSxrQkFBNkMsQ0FDakQsd0JBQ0EsWUFDRjtBQUVBLE1BQU0sb0JBQ0osTUFDQSxZQUM4QjtDQUM5QixNQUFNLE9BQU8sZUFBZSxNQUFNLE9BQU87Q0FDekMsT0FBTyxLQUFLLFNBQVMsZUFDbkIsS0FBSyxhQUFhLGFBQ2xCLEtBQUssU0FBUyxLQUNkLENBQUMsU0FBUyxVQUFVLEtBQUssU0FBUyxFQUFFLFNBQ2xDLGtCQUNBO0FBQ047QUFPQSxNQUFNLG1CQUFxQyxDQUFDO0FBRTVDLE1BQU0sMEJBQ0osY0FBZ0MsZ0JBQWdCOzs7O0FBSWxELE1BQU0saUJBQWlCLE1BQ3JCLEVBQUUsT0FBTyxTQUFTLFdBQVcsTUFDNUIsQ0FBQyxFQUFFLE9BQU8sYUFBYSxFQUFFLFFBQVE7O0FBR3BDLE1BQU0sd0JBQXdCLE1BQzVCLEVBQUUsT0FBTyxTQUFTLFdBQVcsS0FDN0IsRUFBRSxPQUFPLGFBQ1QsQ0FBQyxFQUFFLE9BQU8sY0FDVixDQUFDLEVBQUUsUUFBUTtBQUViLE1BQU0sOEJBQ0osd0JBQUMsT0FBRDtDQUNFLGFBQVU7Q0FDVixNQUFLO0NBQ0wsV0FBVTtXQUhaO0VBS0Usd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFBVTtFQUEwQjs7Ozs7RUFDcEQsd0JBQUMsVUFBRCxFQUFVLFdBQVUsMERBQTJEOzs7OztFQUMvRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUseUNBQTBDOzs7OztJQUM5RCx3QkFBQyxVQUFELEVBQVUsV0FBVSx1Q0FBd0M7Ozs7O0lBQzVELHdCQUFDLFVBQUQsRUFBVSxXQUFVLHVDQUF3Qzs7Ozs7R0FDekQ7Ozs7OztFQUNMLHdCQUFDLFVBQUQsRUFBVSxXQUFVLDBEQUEyRDs7Ozs7RUFDL0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHlDQUEwQzs7OzthQUM5RCx3QkFBQyxVQUFELEVBQVUsV0FBVSx1Q0FBd0M7Ozs7V0FDekQ7Ozs7OztDQUNGOzs7Ozs7O0FBR1AsT0FBTyxNQUFNLFVBQTJCLEVBQ3RDLGFBQWEsa0JBQ2IsWUFBWSxXQUNSOztDQUNKLE1BQU0sVUFBVSxZQUFZLGFBQWE7Q0FFekMsT0FDRSx3QkFBQyx3QkFBd0IsVUFBekI7RUFBa0MsT0FBTztZQUN2Qyx3QkFBQyxZQUFEO0dBQXFCO0dBQW9CO0VBQVk7Ozs7O0NBQ3JCOzs7OztBQUV0Qzs7Ozs7QUFFQSxNQUFNLGNBQTRELEVBQ2hFLFNBQ0EsZ0JBQ0k7O0NBQ0osTUFBTSxFQUFFLFVBQVUsa0JBQWtCLFdBQVcsdUJBQXVCO0NBRXRFLE9BQ0Usd0JBQUMsZ0JBQWdCLE1BQWpCO0VBQ0UsV0FBVTtFQUNWLE9BQU87SUFDSix1QkFBaUM7SUFDakMsa0JBQ0M7SUFDRCxzQkFBZ0M7SUFDaEMsdUJBQWlDO0VBQ3BDO1lBRUEsd0JBQUMsZ0JBQWdCLFVBQWpCO0dBQ0UsWUFBVztHQUNYLGFBQVU7R0FDVixXQUFVO2FBRVYsd0JBQUMsT0FBRDtJQUNFLFdBQVcsR0FDVCw0RUFDQSxXQUFXLGdCQUNiO2NBSkY7S0FNRSx3QkFBQyxPQUFEO01BQU8sV0FBVztnQkFDaEIsd0JBQUMsU0FBRCxDQUFVOzs7OztLQUNMOzs7OztLQUNQLHdCQUFDLE9BQUQ7TUFBTyxXQUFXO2dCQUNoQix3QkFBQyx1QkFBRCxDQUF3Qjs7Ozs7S0FDbkI7Ozs7O0tBRVAsd0JBQUMsbUJBQUQsQ0FBb0I7Ozs7O0tBRXBCLHdCQUFDLE9BQUQ7TUFDRSxhQUFVO01BQ1YsV0FBVTtnQkFFVix3QkFBQyxnQkFBZ0IsVUFBakIsa0JBQ1Msd0JBQUMsZUFBRCxDQUFnQjs7OztlQUNDOzs7OztLQUN2Qjs7Ozs7S0FFTCx3QkFBQyxnQkFBZ0IsZ0JBQWpCO01BQ0UsV0FBVyxHQUNULDhGQUNBLENBQUMsV0FDQyx1REFDSjtnQkFMRjtPQU9FLHdCQUFDLHNCQUFELENBQXVCOzs7OztPQUN2Qix3QkFBQywyQkFBRCxDQUE0Qjs7Ozs7T0FDNUIsd0JBQUMsVUFBRCxFQUFxQixVQUFZOzs7OztPQUNqQyx3QkFBQyxPQUFEO1FBQU8sWUFBWSxNQUFNLGNBQWMsQ0FBQyxLQUFLLEVBQUUsU0FBUztrQkFDdEQsd0JBQUMsbUJBQUQsQ0FBb0I7Ozs7O09BQ2Y7Ozs7O01BQ3VCOzs7Ozs7SUFDN0I7Ozs7OztFQUNtQjs7Ozs7Q0FDTjs7Ozs7QUFFMUI7OztBQUVBLE1BQU0sc0JBQTBCOztDQUM5QixNQUFNLEVBQUUsa0JBQWtCLDRCQUE0QixxQkFDcEQsV0FBVyx1QkFBdUI7Q0FDcEMsTUFBTSxPQUFPLGFBQWEsTUFBTSxFQUFFLFFBQVEsSUFBSTtDQUM5QyxNQUFNLFlBQVksYUFBYSxNQUFNLEVBQUUsUUFBUSxTQUFTLFNBQVM7Q0FDakUsTUFBTSxXQUFXLGFBQWEsTUFBTSxFQUFFLFFBQVEsU0FBUyxhQUFhLE9BQU87Q0FFM0UsSUFBSSxXQUFXLE9BQU8sd0JBQUMsY0FBRCxDQUFlOzs7OztDQUNyQyxJQUFJLFVBQVUsT0FBTyx3QkFBQyxlQUFELENBQWdCOzs7OztDQUNyQyxJQUFJLFNBQVMsUUFBUSxPQUFPLHdCQUFDLGFBQUQsQ0FBYzs7Ozs7Q0FDMUMsT0FBTyx3QkFBQywyQkFBRCxDQUE0Qjs7Ozs7QUFDckM7Ozs7Ozs7OztBQUlBLE1BQU0sNEJBQ0o7O3FCQUFhLE1BQU07RUFDakIsTUFBTSxTQUNKLEVBQUUsT0FBTyxTQUFTLEVBQUUsUUFBUSxRQUFRLEVBQUUsRUFBRSxTQUFTLGFBQWE7RUFDaEUsTUFBTSxRQUNKLEVBQUUsT0FBTyxTQUFTLEVBQUUsUUFBUSxRQUFRLEVBQUUsRUFBRSxTQUFTLGFBQWE7RUFDaEUsSUFBSSxRQUFRLE9BQU8sUUFBUSxXQUFXO0VBQ3RDLE9BQU8sUUFBUSxVQUFVO0NBQzNCLENBQUM7Ozs7O0FBRUgsTUFBTSxjQUF3QyxFQUFFLFdBQzlDLHdCQUFDLEtBQUQ7Q0FBRyxXQUFVO1dBQStCO0FBQVE7Ozs7OztBQUd0RCxNQUFNLHNCQUEwQjs7Q0FDOUIsTUFBTSxPQUFPLGFBQWEsTUFBTSxFQUFFLFFBQVEsSUFBSTtDQUM5QyxNQUFNLFdBQVcsb0JBQW9CO0NBQ3JDLE1BQU0sYUFBYSxhQUNoQixNQUNDLEVBQUUsUUFBUSxTQUFTLGVBQWUsRUFBRSxRQUFRLFFBQVEsU0FBUyxTQUNqRTtDQUNBLE1BQU0sZ0JBQWdCLGFBQWEsV0FBVyxhQUFhO0NBRTNELE9BQ0Usd0JBQUMsaUJBQWlCLE1BQWxCO0VBQ0UsYUFBVTtFQUNWLGFBQVc7RUFDWCxrQkFBZ0I7RUFDaEIsV0FBVyxHQUNULGdIQUNBLGFBQWEsWUFBWSxtQkFDekIsYUFBYSxXQUFXLHFCQUN4QixhQUFhLFlBQVksU0FDekIsYUFBYSxTQUFTLHlCQUN4QjtZQVZGLENBWUcsaUJBQ0Msd0JBQUMsT0FBRDtHQUNFLGFBQVU7R0FDVixXQUFVO2FBRlosQ0FJRSx3QkFBQyxXQUFEO0lBQVcsV0FBVTtJQUFTO0dBQWE7Ozs7YUFDM0Msd0JBQUMsUUFBRCxZQUFNLHFCQUF3Qjs7OztXQUMzQjs7Ozs7WUFFUCx3QkFBQyxPQUFEO0dBQ0UsYUFBVTtHQUNWLFdBQVU7YUFGWjtJQUlFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO0tBQXNDO2VBQ25ELFNBQVMsU0FDUix3QkFBQyxTQUFELEVBQVMsV0FBVSxXQUFZOzs7O2dCQUUvQix3QkFBQyxnQkFBRCxFQUFnQixXQUFVLFdBQVk7Ozs7O0lBRXBDOzs7OztJQUNOLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQ2IsU0FBUyxTQUFTLGFBQWE7SUFDNUI7Ozs7O0lBQ04sd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLGlCQUFpQixPQUFsQixFQUF3QixZQUFZLEVBQUUsTUFBTSxXQUFXLEVBQUk7Ozs7ZUFDMUQsY0FDQyx3QkFBQyxRQUFEO01BQ0UsYUFBVTtNQUNWLE1BQUs7TUFDTCxXQUFVO01BQ1YsY0FBVztnQkFDWjtLQUVLOzs7O2FBRUw7Ozs7OztJQUNMLHdCQUFDLGlCQUFELENBQWtCOzs7OztHQUNmOzs7OztVQUNnQjs7Ozs7O0FBRTNCOzs7Ozs7Ozs7QUFFQSxNQUFNLHdCQUE0QjtDQUNoQyxPQUNFLHdCQUFDLG1CQUFtQixNQUFwQjtFQUNFO0VBQ0EsVUFBUztFQUNULFdBQVU7WUFFVix3QkFBQyxtQkFBbUIsTUFBcEI7R0FBeUI7YUFDdkIsd0JBQUMsbUJBQUQ7SUFBbUIsU0FBUTtJQUFPLFdBQVU7Y0FBNUMsQ0FDRSx3QkFBQyxPQUFEO0tBQU8sWUFBWSxNQUFNLEVBQUUsUUFBUTtlQUNqQyx3QkFBQyxXQUFELEVBQVcsV0FBVSxzREFBdUQ7Ozs7O0lBQ3ZFOzs7O2NBQ1Asd0JBQUMsT0FBRDtLQUFPLFlBQVksTUFBTSxDQUFDLEVBQUUsUUFBUTtlQUNsQyx3QkFBQyxVQUFELEVBQVUsV0FBVSw2Q0FBOEM7Ozs7O0lBQzdEOzs7O1lBQ1U7Ozs7OztFQUNJOzs7OztDQUNGOzs7OztBQUU3Qjs7QUFFQSxNQUFNLHFCQUNKO0FBRUYsTUFBTSxpQkFBaUIsVUFBbUI7Q0FDeEMsS0FDRSxJQUFJLFVBQVUsTUFBTSxvQkFDcEIsU0FDQSxVQUFVLFFBQVEsb0JBQ2xCO0VBQ0EsTUFBTSxTQUFTLFFBQVEsUUFBUSxrQkFBa0IsSUFDN0MsVUFDQSxRQUFRLGNBQWMsa0JBQWtCO0VBQzVDLElBQUksa0JBQWtCLGFBQWEsT0FBTztDQUM1QztDQUNBLE9BQU87QUFDVDtBQUVBLE1BQU0sMEJBQThCOztDQUNsQyxNQUFNLFVBQVUsYUFDYixNQUFNLEVBQUUsT0FBTyxjQUFjLEVBQUUsT0FBTyxnQkFDekM7Q0FDQSxNQUFNLFVBQVUsYUFBYSxNQUFNLEVBQUUsT0FBTyxnQkFBZ0I7Q0FDNUQsTUFBTSxVQUFVLE9BQXVCLElBQUk7Q0FDM0MsTUFBTSxhQUFhLE9BQXVCLElBQUk7OztDQUk5QyxzQkFBc0I7RUFDcEIsTUFBTSxVQUFVLFdBQVc7RUFDM0IsTUFBTSxPQUFPLFFBQVE7RUFDckIsSUFBSSxXQUFXLENBQUMsV0FBVyxRQUFRLGVBQWUsQ0FBQyxNQUFNO0VBQ3pELFdBQVcsVUFBVTtFQUNyQixNQUFNLFNBQVMsU0FBUztFQUN4QixJQUFJLFVBQVUsV0FBVyxTQUFTLE1BQU07RUFDeEMsY0FBYyxJQUFJLENBQUMsRUFBRSxNQUFNO0NBQzdCLEdBQUcsQ0FBQyxPQUFPLENBQUM7Q0FFWixPQUNFLHdCQUFDLE9BQUQ7RUFDRSxLQUFLO0VBQ0wsV0FBVTtFQUNWLFVBQVUsVUFBVTtHQUNsQixXQUFXLFVBQVUsTUFBTTtFQUM3QjtZQUxGLENBT0Usd0JBQUMsUUFBRDtHQUFNLE1BQUs7R0FBUyxXQUFVO2FBQzNCLFVBQVUsNkJBQTZCO0VBQ3BDOzs7O1lBQ0wsV0FDQyx3QkFBQyxnQkFBZ0IsYUFBakI7R0FBNkI7YUFDM0Isd0JBQUMsUUFBRDtJQUNFLFNBQVE7SUFDUixNQUFLO0lBQ0wsYUFBVTtJQUNWLFdBQVU7Y0FFVix3QkFBQyxRQUFEO0tBQ0UsV0FBVyxHQUFHLFdBQVcsb0NBQW9DO2VBRTVELFVBQVUsNkJBQTZCO0lBQ3BDOzs7OztHQUNBOzs7OztFQUNtQjs7OztVQUU1Qjs7Ozs7O0FBRVQ7Ozs7O0FBRUEsTUFBTSw2QkFBaUM7Q0FDckMsT0FDRSx3QkFBQyxnQkFBZ0IsZ0JBQWpCO0VBQWdDLFVBQVM7RUFBVTtZQUNqRCx3QkFBQyxtQkFBRDtHQUNFLFNBQVE7R0FDUixTQUFRO0dBQ1IsV0FBVTthQUVWLHdCQUFDLGVBQUQsQ0FBZ0I7Ozs7O0VBQ0M7Ozs7O0NBQ1c7Ozs7O0FBRXBDOztBQUVBLE1BQU0sc0JBQTBCO0NBQzlCLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxLQUFEO0dBQUcsV0FBVTthQUE2STtFQUV2Sjs7Ozs7Q0FDQTs7Ozs7QUFFVDs7QUFFQSxNQUFNLDBCQUE4QjtDQUNsQyxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsZ0JBQWdCLGFBQWpCLGtCQUNTLHdCQUFDLHNCQUFELENBQXVCOzs7O1dBQ0g7Ozs7O0NBQzFCOzs7OztBQUVUOztBQUVBLE1BQU0sNkJBQWlDO0NBQ3JDLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxvQkFBb0IsU0FBckI7R0FBNkI7R0FBSzthQUNoQyx3QkFBQyxVQUFEO0lBQ0UsTUFBSztJQUNMLFdBQVU7Y0FGWixDQUlFLHdCQUFDLFFBQUQ7S0FDRTtLQUNBLFdBQVU7ZUFFVDtJQUNHOzs7O2NBQ04sd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBaEI7TUFDRSx3QkFBQyxvQkFBb0IsT0FBckIsRUFBMkIsV0FBVSx1REFBd0Q7Ozs7O01BQUU7TUFDL0Ysd0JBQUMsb0JBQW9CLGFBQXJCLEVBQWlDLFdBQVUsMEVBQTJFOzs7OztLQUNsSDs7Ozs7WUFDQTs7Ozs7O0VBQ21COzs7OztDQUMxQjs7Ozs7QUFFVDs7QUFFQSxNQUFNLFlBQXdDLEVBQUUsZ0JBQWdCO0NBQzlELE9BQ0Usd0JBQUMsa0JBQWtCLE1BQW5CO0VBQXdCLFdBQVU7WUFDaEMsd0JBQUMsa0JBQWtCLG9CQUFuQjtHQUFzQzthQUNwQyx3QkFBQyxPQUFEO0lBQ0UsYUFBVTtJQUNWLFdBQVU7Y0FGWjtLQUlFLHdCQUFDLHFCQUFELENBQXNCOzs7OztLQUN0Qix3QkFBQyxrQkFBa0IsT0FBbkI7TUFDRSxhQUFZO01BQ1osV0FBVTtNQUNWLE1BQU07TUFDSztNQUNYLGNBQWE7TUFDYixjQUFXO0tBQ1o7Ozs7O0tBQ0Qsd0JBQUMsZ0JBQUQsQ0FBaUI7Ozs7O0lBQ2Q7Ozs7OztFQUMrQjs7Ozs7Q0FDaEI7Ozs7O0FBRTVCOztBQUVBLE1BQU0sdUJBQTJCOztDQUMvQixNQUFNLEVBQUUsa0JBQWtCLFdBQVcsdUJBQXVCOztDQUU1RCxNQUFNLFlBQVksYUFDZixNQUNDLEVBQUUsU0FBUyxlQUFlLGFBQzFCLEVBQUUsRUFBRSxPQUFPLGFBQWEsRUFBRSxPQUFPLGFBQWEsT0FDbEQ7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDRyxnQkFDQyx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsdUJBQUQsQ0FBd0I7Ozs7YUFDeEIsd0JBQUMsZUFBRCxDQUFnQjs7OztXQUNiOzs7OzthQUVMLHdCQUFDLHVCQUFELENBQXdCOzs7O1lBRTFCLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxPQUFEO0tBQU8sWUFBWSxNQUFNLEVBQUUsT0FBTyxhQUFhO2VBQS9DLENBQ0Usd0JBQUMsT0FBRDtNQUFPLFlBQVksTUFBTSxFQUFFLFNBQVMsYUFBYTtnQkFDL0Msd0JBQUMsa0JBQWtCLFNBQW5CO09BQTJCO2lCQUN6Qix3QkFBQyxtQkFBRDtRQUNFLFNBQVE7UUFDUixNQUFLO1FBQ0wsTUFBSztRQUNMLFNBQVE7UUFDUixNQUFLO1FBQ0wsV0FBVTtRQUNWLGNBQVc7a0JBRVgsd0JBQUMsU0FBRCxFQUFTLFdBQVUsbUNBQW9DOzs7OztPQUN0Qzs7Ozs7TUFDTTs7Ozs7S0FDdEI7Ozs7ZUFDUCx3QkFBQyxPQUFEO01BQU8sWUFBWSxNQUFNLEVBQUUsU0FBUyxhQUFhO2dCQUMvQyx3QkFBQyxrQkFBa0IsZUFBbkI7T0FBaUM7aUJBQy9CLHdCQUFDLG1CQUFEO1FBQ0UsU0FBUTtRQUNSLE1BQUs7UUFDTCxNQUFLO1FBQ0wsU0FBUTtRQUNSLE1BQUs7UUFDTCxXQUFVO1FBQ1YsY0FBVztrQkFFWCx3QkFBQyxZQUFELEVBQVksV0FBVSx1RUFBd0U7Ozs7O09BQzdFOzs7OztNQUNZOzs7OztLQUM1Qjs7OzthQUNGOzs7Ozs7SUFDUCx3QkFBQyxPQUFEO0tBQ0UsWUFBWSxPQUNULENBQUMsRUFBRSxTQUFTLGFBQ1YsRUFBRSxPQUFPLFVBQVUsYUFDbEIsRUFBRSxTQUFTLGVBQWUsY0FDOUIsQ0FBQyx5QkFBeUIsQ0FBQztlQUc3Qix3QkFBQyxrQkFBa0IsTUFBbkI7TUFBd0I7Z0JBQ3RCLHdCQUFDLG1CQUFEO09BQ0UsU0FBUTtPQUNSLE1BQUs7T0FDTCxNQUFLO09BQ0wsU0FBUTtPQUNSLE1BQUs7T0FDTCxXQUFVO09BQ1YsY0FBVztpQkFFWCx3QkFBQyxhQUFELEVBQWEsV0FBVSxnQ0FBaUM7Ozs7O01BQ3ZDOzs7OztLQUNHOzs7OztJQUNuQjs7Ozs7SUFDUCx3QkFBQyxPQUFEO0tBQU8sV0FBVztlQUNoQix3QkFBQyxrQkFBa0IsUUFBbkI7TUFBMEI7Z0JBQ3hCLHdCQUFDLG1CQUFEO09BQ0UsU0FBUTtPQUNSLE1BQUs7T0FDTCxNQUFLO09BQ0wsU0FBUTtPQUNSLE1BQUs7T0FDTCxXQUFVO09BQ1YsY0FBVztpQkFFWCx3QkFBQyxVQUFELEVBQVUsV0FBVSxrQ0FBbUM7Ozs7O01BQ3RDOzs7OztLQUNLOzs7OztJQUNyQjs7Ozs7SUFDUCx3QkFBQyxPQUFEO0tBQ0UsWUFBWSxNQUNWLEVBQUUsU0FBUyxjQUNWLEVBQUUsT0FBTyxVQUFVLGFBQ2xCLEVBQUUsU0FBUyxlQUFlO2VBRzlCLHdCQUFDLGtCQUFrQixRQUFuQjtNQUEwQjtnQkFDeEIsd0JBQUMsUUFBRDtPQUNFLE1BQUs7T0FDTCxTQUFRO09BQ1IsTUFBSztPQUNMLFdBQVU7T0FDVixjQUFZLFlBQVksbUJBQW1CO09BQzNDLGVBQWUsNEJBQTRCLFNBQVMsY0FBbUMscUJBQXFCLENBQUMsRUFBRSxNQUFNLENBQUM7aUJBRXRILHdCQUFDLFlBQUQsRUFBWSxXQUFVLGlEQUFrRDs7Ozs7TUFDbEU7Ozs7O0tBQ2dCOzs7OztJQUNyQjs7Ozs7R0FDSjs7Ozs7VUFDRjs7Ozs7O0FBRVQ7Ozs7O0FBRUEsTUFBTSxxQkFBeUI7Q0FDN0IsT0FDRSx3QkFBQyxpQkFBaUIsT0FBbEIsWUFDRSx3QkFBQyxlQUFlLE1BQWhCO0VBQXFCLE1BQUs7RUFBUSxXQUFVO1lBQzFDLHdCQUFDLGVBQWUsU0FBaEIsRUFBd0IsV0FBVSx5Q0FBMEM7Ozs7O0NBQ3pEOzs7O1VBQ0M7Ozs7O0FBRTVCOztBQUVBLE1BQU0seUJBQTZCOztDQUNqQyxNQUFNLEVBQ0osY0FBYyx3QkFBd0IsY0FDdEMsV0FDQSxnQkFDQSxXQUFXLHVCQUNULFdBQVcsdUJBQXVCO0NBQ3RDLE1BQU0sVUFBVSxxQkFBcUIsbUJBQW1CO0NBRXhELE1BQU0sZ0JBQWdCOztDQUV0QixNQUFNLG9CQUFvQixhQUFhO0NBRXZDLE9BQ0Usd0JBQUMsaUJBQWlCLE1BQWxCO0VBQ0UsYUFBVTtFQUNWLGFBQVU7RUFDVixXQUFVO1lBSFosQ0FLRSx3QkFBQyxPQUFEO0dBQ0UsYUFBVTtHQUNWLFdBQVU7YUFGWixDQUlFLHdCQUFDLGlCQUFpQixjQUFsQjtJQUF3QztlQUNwQyxFQUFFLE1BQU0sZUFBZTtLQUN2QixRQUFRLEtBQUssTUFBYjtNQUNFLEtBQUssd0JBQ0gsT0FBTyx3QkFBQyxPQUFEO09BQUssYUFBVTtPQUF3QjtNQUFjOzs7OztNQUM5RCxLQUFLLGNBQ0gsT0FBTyxxQkFDTCx3QkFBQyxvQkFBRCxFQUFvQixPQUFPLEtBQU87Ozs7aUJBQ2hDO01BQ04sS0FBSztPQUNILElBQUksV0FBVztRQUNiLE9BQU8sd0JBQUMsV0FBRDtTQUFXLE9BQU87U0FBTztRQUFvQjs7Ozs7T0FDdEQ7T0FDQSxPQUNFLHdCQUFDLGtCQUFEO1FBQWtCLE9BQU87UUFBTztPQUEyQjs7Ozs7TUFFL0QsS0FBSyxtQkFBbUI7T0FDdEIsSUFBSSxnQkFBZ0I7UUFDbEIsT0FDRSx3QkFBQyxnQkFBRDtTQUFnQixPQUFPO1NBQU87UUFBeUI7Ozs7O09BRTNEO09BQ0EsTUFBTSxVQUFVLEtBQUssT0FBTyxTQUFTO09BQ3JDLE9BQ0Usd0JBQUMsZUFBRDtRQUFlLFdBQVc7a0JBQTFCLENBQ0Usd0JBQUMsa0JBQUQ7U0FDRSxRQUFRO1NBQ1IsVUFBVSxrQkFBa0IsS0FBSyxNQUFNO1FBQ3hDOzs7O2tCQUNELHdCQUFDLGtCQUFEO1NBQWtCLGFBQVc7bUJBQzNCLHdCQUFDLGVBQUQsRUFBZ0IsU0FBd0I7Ozs7O1FBQ3hCOzs7O2dCQUNMOzs7Ozs7TUFFbkI7TUFDQSxLQUFLLFFBQ0gsT0FBTyx3QkFBQyxjQUFELENBQWU7Ozs7O01BQ3hCLEtBQUssYUFDSCxPQUFPLHdCQUFDLFdBQUQsRUFBVyxHQUFJLEtBQU87Ozs7O01BQy9CLEtBQUssYUFDSCxPQUFPLEtBQUssVUFBVSx3QkFBQyx1QkFBRCxFQUF1QixHQUFJLEtBQU87Ozs7O01BQzFELEtBQUssUUFDSCxPQUFPLEtBQUs7TUFDZCxLQUFLLFFBQ0gsT0FDRSx3QkFBQyxPQUFEO09BQUssYUFBVTtPQUE2QixXQUFVO2lCQUNwRCx3QkFBQyxhQUFELEVBQWEsR0FBSSxLQUFPOzs7OztNQUNyQjs7Ozs7TUFFVCxLQUFLLFNBQ0gsT0FDRSx3QkFBQyxPQUFEO09BQUssYUFBVTtPQUE4QixXQUFVO2lCQUNyRCx3QkFBQyxPQUFELEVBQU8sR0FBSSxLQUFPOzs7OztNQUNmOzs7OztNQUVULEtBQUssYUFDSCxPQUNFLHdCQUFDLFFBQUQ7T0FDRSxhQUFVO09BQ1YsV0FBVTtPQUNWLGNBQVc7aUJBRVY7TUFDRzs7Ozs7TUFFVixTQUNFLE9BQU87S0FDWDtJQUNGO0dBQzZCOzs7O2FBQy9CLHdCQUFDLGNBQUQsQ0FBZTs7OztXQUNaOzs7OztZQUVMLHdCQUFDLE9BQUQ7R0FDRSxhQUFVO0dBQ1YsV0FBVyxHQUFHLDBCQUEwQixpQkFBaUI7YUFGM0QsQ0FJRSx3QkFBQyxjQUFELENBQWU7Ozs7YUFDZix3QkFBQyxvQkFBRCxDQUFxQjs7OztXQUNsQjs7Ozs7VUFDZ0I7Ozs7OztBQUUzQjs7O0FBRUEsTUFBTSwyQkFBK0I7O0NBQ25DLE1BQU0sU0FBUyxhQUFhLE1BQU0sRUFBRSxRQUFRLFFBQVEsU0FBUyxnQkFBZ0IsRUFBRSxRQUFRLE9BQU8sV0FBVyxPQUFPO0NBQ2hILE9BQ0Usd0JBQUMsbUJBQW1CLE1BQXBCO0VBQ0U7RUFDQSxVQUFTO0VBQ1QsV0FBVTtZQUhaO0dBS0Usd0JBQUMsbUJBQW1CLE1BQXBCO0lBQXlCO2NBQ3ZCLHdCQUFDLG1CQUFEO0tBQW1CLFNBQVE7ZUFBM0IsQ0FDRSx3QkFBQyxPQUFEO01BQU8sWUFBWSxNQUFNLEVBQUUsUUFBUTtnQkFDakMsd0JBQUMsV0FBRCxFQUFXLFdBQVUsc0RBQXVEOzs7OztLQUN2RTs7OztlQUNQLHdCQUFDLE9BQUQ7TUFBTyxZQUFZLE1BQU0sQ0FBQyxFQUFFLFFBQVE7Z0JBQ2xDLHdCQUFDLFVBQUQsRUFBVSxXQUFVLDZDQUE4Qzs7Ozs7S0FDN0Q7Ozs7YUFDVTs7Ozs7O0dBQ0k7Ozs7O0dBQ3pCLHdCQUFDLE9BQUQ7SUFBTyxZQUFZLE1BQU0sRUFBRSxPQUFPLGFBQWE7Y0FBL0MsQ0FDRSx3QkFBQyxtQkFBbUIsa0JBQXBCO0tBQXFDO2VBQ25DLHdCQUFDLG1CQUFEO01BQ0UsU0FBUTtNQUNSLFdBQVU7Z0JBRVYsd0JBQUMsY0FBRCxDQUFlOzs7OztLQUNFOzs7OztJQUNnQjs7OztjQUNyQyx3QkFBQyxtQkFBbUIsa0JBQXBCO0tBQXFDO2VBQ25DLHdCQUFDLG1CQUFEO01BQ0UsU0FBUTtNQUNSLFdBQVU7Z0JBRVYsd0JBQUMsZ0JBQUQsQ0FBaUI7Ozs7O0tBQ0E7Ozs7O0lBQ2dCOzs7O1lBQ2hDOzs7Ozs7R0FDUCx3QkFBQyxtQkFBbUIsUUFBcEI7SUFBMkI7Y0FDekIsd0JBQUMsbUJBQUQ7S0FBbUIsU0FBUyxTQUFTLG1CQUFtQjtlQUN0RCx3QkFBQyxlQUFELENBQWdCOzs7OztJQUNDOzs7OztHQUNNOzs7OztHQUMzQix3QkFBQyx1QkFBdUIsTUFBeEIsYUFDRSx3QkFBQyx1QkFBdUIsU0FBeEI7SUFBZ0M7Y0FDOUIsd0JBQUMsbUJBQUQ7S0FDRSxTQUFRO0tBQ1IsV0FBVTtlQUVWLHdCQUFDLG9CQUFELENBQXFCOzs7OztJQUNKOzs7OztHQUNXOzs7O2FBQ2hDLHdCQUFDLHVCQUF1QixTQUF4QjtJQUNFLE1BQUs7SUFDTCxPQUFNO0lBQ04sWUFBWTtJQUNaLFdBQVU7Y0FFVix3QkFBQyxtQkFBbUIsZ0JBQXBCO0tBQW1DO2VBQ2pDLHdCQUFDLHVCQUF1QixNQUF4QjtNQUE2QixXQUFVO2dCQUF2QyxDQUNFLHdCQUFDLGNBQUQsRUFBYyxXQUFVLFNBQVU7Ozs7Z0JBQUMsb0JBRVI7Ozs7OztJQUNJOzs7OztHQUNMOzs7O1dBQ0w7Ozs7O0VBQ047Ozs7OztBQUU3Qjs7Ozs7QUFFQSxNQUFNLGVBQXlDLFNBQVM7Q0FDdEQsTUFBTSxRQUFRLEtBQUssU0FBUyxZQUFZLENBQUMsQ0FBQyxXQUFXLFFBQVEsSUFDekQsWUFBWSxLQUFLLE1BQU0sS0FBSyxVQUFVLEtBQUssVUFBVSxJQUNyRDtDQUNKLElBQUksQ0FBQyxPQUFPLE9BQU8sd0JBQUMsTUFBRCxFQUFNLEdBQUksS0FBTzs7Ozs7Q0FDcEMsT0FDRSx3QkFBQyxPQUFEO0VBQ0UsTUFBSztFQUNFO0VBQ1AsUUFBUSxLQUFLO0VBQ2IsR0FBSyxLQUFLLGFBQWEsYUFBYSxFQUFFLFVBQVUsS0FBSyxTQUFTO0NBQy9EOzs7OztBQUVMOztBQUVBLE1BQU0sZ0JBQTBDLFNBQzlDLHdCQUFDLE9BQUQ7Q0FBSyxhQUFVO0NBQXdCLFdBQVU7V0FDL0Msd0JBQUMsYUFBRCxFQUFhLEdBQUksS0FBTzs7Ozs7QUFDckI7Ozs7OztBQUdQLE1BQU0saUJBQTRDLFNBQ2hELHdCQUFDLE9BQUQ7Q0FBSyxhQUFVO0NBQXlCLFdBQVU7V0FDaEQsd0JBQUMsT0FBRCxFQUFPLEdBQUksS0FBTzs7Ozs7QUFDZjs7Ozs7O0FBR1AsTUFBTSxvQkFBd0I7Q0FDNUIsT0FDRSx3QkFBQyxpQkFBaUIsTUFBbEI7RUFDRSxhQUFVO0VBQ1YsV0FBVTtFQUNWLGFBQVU7WUFIWjtHQUtFLHdCQUFDLHdCQUFELENBQXlCOzs7OztHQUV6Qix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxpQkFBaUIsT0FBbEIsRUFDRSxZQUFZO01BQUUsTUFBTTtNQUFjLE9BQU87S0FBYyxFQUN4RDs7Ozs7SUFDRTs7OztjQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsZUFBRCxDQUFnQjs7Ozs7SUFDYjs7OztZQUNGOzs7Ozs7R0FFTCx3QkFBQyxjQUFEO0lBQ0UsYUFBVTtJQUNWLFdBQVU7R0FDWDs7Ozs7RUFDb0I7Ozs7OztBQUUzQjs7QUFFQSxNQUFNLHNCQUEwQjtDQUM5QixPQUNFLHdCQUFDLG1CQUFtQixNQUFwQjtFQUNFO0VBQ0EsVUFBUztFQUNULFdBQVU7WUFFVix3QkFBQyxtQkFBbUIsTUFBcEI7R0FBeUI7YUFDdkIsd0JBQUMsbUJBQUQ7SUFBbUIsU0FBUTtJQUFPLFdBQVU7Y0FDMUMsd0JBQUMsWUFBRCxDQUFhOzs7OztHQUNJOzs7OztFQUNJOzs7OztDQUNGOzs7OztBQUU3Qjs7QUFFQSxNQUFNLHFCQUF5QjtDQUM3QixPQUNFLHdCQUFDLGlCQUFpQixNQUFsQjtFQUNFLGFBQVU7RUFDVixXQUFVO1lBRVYsd0JBQUMsa0JBQWtCLE1BQW5CO0dBQXdCLFdBQVU7YUFBbEMsQ0FDRSx3QkFBQyxrQkFBa0IsT0FBbkI7SUFDRSxXQUFVO0lBQ1Y7R0FDRDs7OzthQUNELHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxrQkFBa0IsUUFBbkI7S0FBMEI7ZUFDeEIsd0JBQUMsUUFBRDtNQUFRLFNBQVE7TUFBUSxNQUFLO01BQUssV0FBVTtnQkFBVztLQUUvQzs7Ozs7SUFDZ0I7Ozs7Y0FDMUIsd0JBQUMsa0JBQWtCLE1BQW5CO0tBQXdCO2VBQ3RCLHdCQUFDLFFBQUQ7TUFBUSxNQUFLO01BQUssV0FBVTtnQkFBVztLQUUvQjs7Ozs7SUFDYzs7OztZQUNyQjs7Ozs7V0FDaUI7Ozs7OztDQUNIOzs7OztBQUUzQjs7QUFFQSxNQUFNLGdCQUFzRCxFQUMxRCxXQUNBLEdBQUcsV0FDQztDQUNKLE9BQ0Usd0JBQUMsc0JBQXNCLE1BQXZCO0VBQ0U7RUFDQSxXQUFXLEdBQ1QsNEZBQ0EsU0FDRjtFQUNBLEdBQUk7WUFOTjtHQVFFLHdCQUFDLHNCQUFzQixVQUF2QjtJQUFnQztjQUM5Qix3QkFBQyxtQkFBRDtLQUFtQixTQUFRO2VBQ3pCLHdCQUFDLGlCQUFELENBQWtCOzs7OztJQUNEOzs7OztHQUNXOzs7OztHQUNoQyx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFoQjtLQUNFLHdCQUFDLHNCQUFzQixRQUF2QixDQUErQjs7Ozs7S0FBQztLQUFHLHdCQUFDLHNCQUFzQixPQUF2QixDQUE4Qjs7Ozs7SUFDN0Q7Ozs7OztHQUNOLHdCQUFDLHNCQUFzQixNQUF2QjtJQUE0QjtjQUMxQix3QkFBQyxtQkFBRDtLQUFtQixTQUFRO2VBQ3pCLHdCQUFDLGtCQUFELENBQW1COzs7OztJQUNGOzs7OztHQUNPOzs7OztFQUNGOzs7Ozs7QUFFaEMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsidGhyZWFkLmF1aS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiXCJ1c2UgY2xpZW50XCI7XG5cbmltcG9ydCB7XG4gIENvbXBvc2VyQWRkQXR0YWNobWVudCxcbiAgQ29tcG9zZXJBdHRhY2htZW50cyxcbiAgVXNlck1lc3NhZ2VBdHRhY2htZW50cyxcbn0gZnJvbSBcIkAvY29tcG9uZW50cy9hc3Npc3RhbnQtdWkvZWxlbWVudHMvYXR0YWNobWVudC5hdWlcIjtcbmltcG9ydCB7IEZpbGUsIGdldEZpbGVIcmVmIH0gZnJvbSBcIkAvY29tcG9uZW50cy9hc3Npc3RhbnQtdWkvZWxlbWVudHMvZmlsZVwiO1xuaW1wb3J0IHsgVGhyZWFkRm9sbG93dXBTdWdnZXN0aW9ucyB9IGZyb20gXCJAL2NvbXBvbmVudHMvYXNzaXN0YW50LXVpL2VsZW1lbnRzL2ZvbGxvdy11cC1zdWdnZXN0aW9ucy5hdWlcIjtcbmltcG9ydCB7IEltYWdlIH0gZnJvbSBcIkAvY29tcG9uZW50cy9hc3Npc3RhbnQtdWkvZWxlbWVudHMvaW1hZ2VcIjtcbmltcG9ydCB7IE1hcmtkb3duVGV4dCB9IGZyb20gXCJAL2NvbXBvbmVudHMvYXNzaXN0YW50LXVpL2VsZW1lbnRzL21hcmtkb3duLXRleHRcIjtcbmltcG9ydCB7XG4gIFJlYXNvbmluZyxcbiAgUmVhc29uaW5nQ29udGVudCxcbiAgUmVhc29uaW5nUm9vdCxcbiAgUmVhc29uaW5nVGV4dCxcbiAgUmVhc29uaW5nVHJpZ2dlcixcbn0gZnJvbSBcIkAvY29tcG9uZW50cy9hc3Npc3RhbnQtdWkvZWxlbWVudHMvcmVhc29uaW5nLmF1aVwiO1xuaW1wb3J0IHsgVG9vbEZhbGxiYWNrIH0gZnJvbSBcIkAvY29tcG9uZW50cy9hc3Npc3RhbnQtdWkvZWxlbWVudHMvdG9vbC1mYWxsYmFjay5hdWlcIjtcbmltcG9ydCB7XG4gIFRvb2xHcm91cENvbnRlbnQsXG4gIFRvb2xHcm91cFJvb3QsXG4gIFRvb2xHcm91cFRyaWdnZXIsXG59IGZyb20gXCJAL2NvbXBvbmVudHMvYXNzaXN0YW50LXVpL2VsZW1lbnRzL3Rvb2wtZ3JvdXAuYXVpXCI7XG5pbXBvcnQgeyBUb29sdGlwSWNvbkJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvYXNzaXN0YW50LXVpL2VsZW1lbnRzL3Rvb2x0aXAtaWNvbi1idXR0b25cIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYnV0dG9uXCI7XG5pbXBvcnQgeyBTa2VsZXRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvc2tlbGV0b25cIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5pbXBvcnQge1xuICBBY3Rpb25CYXJNb3JlUHJpbWl0aXZlLFxuICBBY3Rpb25CYXJQcmltaXRpdmUsXG4gIEF1aUlmLFxuICB0eXBlIEFzc2lzdGFudFN0YXRlLFxuICBCcmFuY2hQaWNrZXJQcmltaXRpdmUsXG4gIENvbXBvc2VyUHJpbWl0aXZlLFxuICBFcnJvclByaW1pdGl2ZSxcbiAgZ3JvdXBQYXJ0QnlUeXBlLFxuICBNZXNzYWdlUHJpbWl0aXZlLFxuICBTdWdnZXN0aW9uUHJpbWl0aXZlLFxuICBUaHJlYWRQcmltaXRpdmUsXG4gIHR5cGUgRmlsZU1lc3NhZ2VQYXJ0Q29tcG9uZW50LFxuICB0eXBlIEltYWdlTWVzc2FnZVBhcnRDb21wb25lbnQsXG4gIHR5cGUgVGV4dE1lc3NhZ2VQYXJ0Q29tcG9uZW50LFxuICB0eXBlIFRvb2xDYWxsTWVzc2FnZVBhcnRDb21wb25lbnQsXG4gIHVzZUF1aVN0YXRlLFxufSBmcm9tIFwiQGFzc2lzdGFudC11aS9yZWFjdFwiO1xuaW1wb3J0IHtcbiAgQXJyb3dEb3duSWNvbixcbiAgQXJyb3dVcEljb24sXG4gIEF1ZGlvTGluZXNJY29uLFxuICBDaGVja0ljb24sXG4gIENoZXZyb25MZWZ0SWNvbixcbiAgQ2hldnJvblJpZ2h0SWNvbixcbiAgQ29weUljb24sXG4gIERvd25sb2FkSWNvbixcbiAgTWljSWNvbixcbiAgTW9yZUhvcml6b250YWxJY29uLFxuICBQZW5jaWxJY29uLFxuICBQaG9uZUljb24sXG4gIFJlZnJlc2hDd0ljb24sXG4gIFNxdWFyZUljb24sXG4gIFBsYXlJY29uLFxuICBUaHVtYnNEb3duSWNvbixcbiAgVGh1bWJzVXBJY29uLFxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQge1xuICBjcmVhdGVDb250ZXh0LFxuICB1c2VDb250ZXh0LFxuICB1c2VMYXlvdXRFZmZlY3QsXG4gIHVzZVJlZixcbiAgdXNlU3RhdGUsXG4gIHR5cGUgQ29tcG9uZW50VHlwZSxcbiAgdHlwZSBGQyxcbiAgdHlwZSBQcm9wc1dpdGhDaGlsZHJlbixcbn0gZnJvbSBcInJlYWN0XCI7XG5cbmV4cG9ydCB0eXBlIFRocmVhZEdyb3VwUGFydCA9IE1lc3NhZ2VQcmltaXRpdmUuR3JvdXBlZFBhcnRzLkdyb3VwUGFydDtcblxuY29uc3QgRGVmYXVsdFRvb2xHcm91cDogRkM8UHJvcHNXaXRoQ2hpbGRyZW48eyBncm91cDogVGhyZWFkR3JvdXBQYXJ0IH0+PiA9ICh7XG4gIGdyb3VwLFxuICBjaGlsZHJlbixcbn0pID0+IHtcbiAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIHJldHVybiAoXG4gICAgPFRvb2xHcm91cFJvb3RcbiAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXG4gICAgICBvcGVuPXtvcGVuIHx8IGdyb3VwLmNvdW50cy5yZXF1aXJlc0FjdGlvbiA+IDB9XG4gICAgICBvbk9wZW5DaGFuZ2U9e3NldE9wZW59XG4gICAgPlxuICAgICAgPFRvb2xHcm91cFRyaWdnZXJcbiAgICAgICAgY291bnQ9e2dyb3VwLmluZGljZXMubGVuZ3RofVxuICAgICAgICBhY3RpdmU9e2dyb3VwLnN0YXR1cy50eXBlID09PSBcInJ1bm5pbmdcIn1cbiAgICAgIC8+XG4gICAgICA8VG9vbEdyb3VwQ29udGVudD57Y2hpbGRyZW59PC9Ub29sR3JvdXBDb250ZW50PlxuICAgIDwvVG9vbEdyb3VwUm9vdD5cbiAgKTtcbn07XG5cbmNvbnN0IHNob3VsZFNob3dDb21wb3NlclJlc3VtZSA9IChzOiBBc3Npc3RhbnRTdGF0ZSkgPT5cbiAgISFzLnRocmVhZC5jYW5SZXN1bWUgJiYgcy5jb21wb3Nlci50eXBlID09PSBcInRocmVhZFwiICYmIHMuY29tcG9zZXIuaXNFbXB0eTtcblxuY29uc3QgcmVhc29uaW5nRHVyYXRpb24gPSAodGltaW5nOiBUaHJlYWRHcm91cFBhcnRbXCJ0aW1pbmdcIl0pID0+XG4gIHRpbWluZz8uY29tcGxldGVkQXQgPT09IHVuZGVmaW5lZFxuICAgID8gdW5kZWZpbmVkXG4gICAgOiBNYXRoLnJvdW5kKCh0aW1pbmcuY29tcGxldGVkQXQgLSB0aW1pbmcuc3RhcnRlZEF0KSAvIDEwMDApO1xuXG4vKipcbiAqIE9wdGlvbmFsIGNvbXBvbmVudCBvdmVycmlkZXMgZm9yIHRoZSB0aHJlYWQuIGBBc3Npc3RhbnRNZXNzYWdlYCBhbmRcbiAqIGBXZWxjb21lYCByZXBsYWNlIHdob2xlIHNlY3Rpb25zOyB0aGUgcmVtYWluaW5nIHNsb3RzIG92ZXJyaWRlIGhvdyB0aGVcbiAqIGFzc2lzdGFudCBtZXNzYWdlIHJlbmRlcnMgdG9vbCBjYWxscyBhbmQgcGFydCBncm91cHMuIFRvb2wgVUlzIHJlZ2lzdGVyZWRcbiAqIGJ5IG5hbWUgKHRvb2xraXQgYHJlbmRlcmAsIGB1c2VBc3Npc3RhbnREYXRhVUlgKSB0YWtlIHByZWNlZGVuY2Ugb3ZlclxuICogYFRvb2xGYWxsYmFja2AuIFdoZW4gYFRhc2tHcm91cGAgaXMgc2V0LCB0b29sIGNhbGxzIHRoYXQgY2FycnkgYSBuZXN0ZWRcbiAqIGNvbnZlcnNhdGlvbiBhbmQgaGF2ZSBubyByZWdpc3RlcmVkIFVJIHJlbmRlciB0aHJvdWdoIGl0IGluc3RlYWQgb2YgdGhlXG4gKiB0b29sIGdyb3VwOyB3aXRob3V0IGl0IHRoZXkgcmVuZGVyIGxpa2UgYW55IG90aGVyIHRvb2wgY2FsbC5cbiAqIGBDb21wb3NlckV4dHJhYCByZW5kZXJzIGluIHRoZSBjb21wb3NlcidzIGFjdGlvbiByb3cgYmVzaWRlIHRoZSBhdHRhY2hcbiAqIGJ1dHRvbi5cbiAqL1xuZXhwb3J0IHR5cGUgVGhyZWFkQ29tcG9uZW50cyA9IHtcbiAgQXNzaXN0YW50TWVzc2FnZT86IENvbXBvbmVudFR5cGUgfCB1bmRlZmluZWQ7XG4gIFdlbGNvbWU/OiBDb21wb25lbnRUeXBlIHwgdW5kZWZpbmVkO1xuICBUb29sRmFsbGJhY2s/OiBUb29sQ2FsbE1lc3NhZ2VQYXJ0Q29tcG9uZW50IHwgdW5kZWZpbmVkO1xuICBUb29sR3JvdXA/OlxuICAgIHwgQ29tcG9uZW50VHlwZTxQcm9wc1dpdGhDaGlsZHJlbjx7IGdyb3VwOiBUaHJlYWRHcm91cFBhcnQgfT4+XG4gICAgfCB1bmRlZmluZWQ7XG4gIFJlYXNvbmluZ0dyb3VwPzpcbiAgICB8IENvbXBvbmVudFR5cGU8UHJvcHNXaXRoQ2hpbGRyZW48eyBncm91cDogVGhyZWFkR3JvdXBQYXJ0IH0+PlxuICAgIHwgdW5kZWZpbmVkO1xuICBUYXNrR3JvdXA/OiBDb21wb25lbnRUeXBlPHsgZ3JvdXA6IFRocmVhZEdyb3VwUGFydCB9PiB8IHVuZGVmaW5lZDtcbiAgQ29tcG9zZXJFeHRyYT86IENvbXBvbmVudFR5cGUgfCB1bmRlZmluZWQ7XG59O1xuXG5jb25zdCBtZXNzYWdlR3JvdXBCeSA9IGdyb3VwUGFydEJ5VHlwZSh7XG4gIHJlYXNvbmluZzogW1wiZ3JvdXAtY2hhaW5PZlRob3VnaHRcIiwgXCJncm91cC1yZWFzb25pbmdcIl0sXG4gIFwidG9vbC1jYWxsXCI6IFtcImdyb3VwLWNoYWluT2ZUaG91Z2h0XCIsIFwiZ3JvdXAtdG9vbFwiXSxcbiAgXCJzdGFuZGFsb25lLXRvb2wtY2FsbFwiOiBbXSxcbn0pO1xuXG50eXBlIFRocmVhZEdyb3VwS2V5ID1cbiAgfCBcImdyb3VwLWNoYWluT2ZUaG91Z2h0XCJcbiAgfCBcImdyb3VwLXJlYXNvbmluZ1wiXG4gIHwgXCJncm91cC10b29sXCJcbiAgfCBcImdyb3VwLXRhc2tcIjtcblxuY29uc3QgVEFTS19HUk9VUF9QQVRIOiByZWFkb25seSBUaHJlYWRHcm91cEtleVtdID0gW1xuICBcImdyb3VwLWNoYWluT2ZUaG91Z2h0XCIsXG4gIFwiZ3JvdXAtdGFza1wiLFxuXTtcblxuY29uc3QgdGFza0F3YXJlR3JvdXBCeSA9IChcbiAgcGFydDogUGFyYW1ldGVyczx0eXBlb2YgbWVzc2FnZUdyb3VwQnk+WzBdLFxuICBjb250ZXh0PzogUGFyYW1ldGVyczx0eXBlb2YgbWVzc2FnZUdyb3VwQnk+WzFdLFxuKTogcmVhZG9ubHkgVGhyZWFkR3JvdXBLZXlbXSA9PiB7XG4gIGNvbnN0IHBhdGggPSBtZXNzYWdlR3JvdXBCeShwYXJ0LCBjb250ZXh0KTtcbiAgcmV0dXJuIHBhcnQudHlwZSA9PT0gXCJ0b29sLWNhbGxcIiAmJlxuICAgIHBhcnQubWVzc2FnZXMgIT09IHVuZGVmaW5lZCAmJlxuICAgIHBhdGgubGVuZ3RoID4gMCAmJlxuICAgICFjb250ZXh0Py50b29sVUlzPy5bcGFydC50b29sTmFtZV0/Lmxlbmd0aFxuICAgID8gVEFTS19HUk9VUF9QQVRIXG4gICAgOiBwYXRoO1xufTtcblxuZXhwb3J0IHR5cGUgVGhyZWFkUHJvcHMgPSB7XG4gIGNvbXBvbmVudHM/OiBUaHJlYWRDb21wb25lbnRzIHwgdW5kZWZpbmVkO1xuICBhdXRvRm9jdXM/OiBib29sZWFuIHwgdW5kZWZpbmVkO1xufTtcblxuY29uc3QgRU1QVFlfQ09NUE9ORU5UUzogVGhyZWFkQ29tcG9uZW50cyA9IHt9O1xuXG5jb25zdCBUaHJlYWRDb21wb25lbnRzQ29udGV4dCA9XG4gIGNyZWF0ZUNvbnRleHQ8VGhyZWFkQ29tcG9uZW50cz4oRU1QVFlfQ09NUE9ORU5UUyk7XG5cbi8vIFN0YXJ0dXAgZXhwb3NlcyBhIGxvYWRpbmcgcGxhY2Vob2xkZXIgdGhyZWFkOyB0cmVhdCBpdCBhcyBhIG5ldyBjaGF0IHNvXG4vLyB0aGUgY29tcG9zZXIgbW91bnRzIGNlbnRlcmVkLiBMb2FkcyBhZnRlciBzdGFydHVwIGtlZXAgdGhlIGRvY2tlZCBsYXlvdXQuXG5jb25zdCBpc05ld0NoYXRWaWV3ID0gKHM6IEFzc2lzdGFudFN0YXRlKSA9PlxuICBzLnRocmVhZC5tZXNzYWdlcy5sZW5ndGggPT09IDAgJiZcbiAgKCFzLnRocmVhZC5pc0xvYWRpbmcgfHwgcy50aHJlYWRzLmlzTG9hZGluZyk7XG5cbi8vIEEgc3dpdGNoZWQgdGhyZWFkIHRoYXQgaXMgc3RpbGwgZmV0Y2hpbmcgaXRzIGhpc3Rvcnk6IHNrZWxldG9uLCBub3Qgd2VsY29tZS5cbmNvbnN0IGlzSGlzdG9yeUxvYWRpbmdWaWV3ID0gKHM6IEFzc2lzdGFudFN0YXRlKSA9PlxuICBzLnRocmVhZC5tZXNzYWdlcy5sZW5ndGggPT09IDAgJiZcbiAgcy50aHJlYWQuaXNMb2FkaW5nICYmXG4gICFzLnRocmVhZC5pc0Rpc2FibGVkICYmXG4gICFzLnRocmVhZHMuaXNMb2FkaW5nO1xuXG5jb25zdCBUaHJlYWRIaXN0b3J5U2tlbGV0b246IEZDID0gKCkgPT4gKFxuICA8ZGl2XG4gICAgZGF0YS1zbG90PVwiYXVpX3RocmVhZC1oaXN0b3J5LXNrZWxldG9uXCJcbiAgICByb2xlPVwic3RhdHVzXCJcbiAgICBjbGFzc05hbWU9XCJhbmltYXRlLWluIGZhZGUtaW4gZmlsbC1tb2RlLWJvdGggZmxleCBmbGV4LWNvbCBnYXAteS02IFthbmltYXRpb24tZGVsYXk6MTUwbXNdIFthbmltYXRpb24tZHVyYXRpb246MjAwbXNdXCJcbiAgPlxuICAgIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5Mb2FkaW5nIGNvbnZlcnNhdGlvbjwvc3Bhbj5cbiAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwibWwtYXV0byBoLTkgdy0yLzUgcm91bmRlZC14bCBtb3Rpb24tcmVkdWNlOmFuaW1hdGUtbm9uZVwiIC8+XG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC15LTJcIj5cbiAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTQgdy0xMS8xMiBtb3Rpb24tcmVkdWNlOmFuaW1hdGUtbm9uZVwiIC8+XG4gICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC00IHctNC81IG1vdGlvbi1yZWR1Y2U6YW5pbWF0ZS1ub25lXCIgLz5cbiAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTQgdy0zLzUgbW90aW9uLXJlZHVjZTphbmltYXRlLW5vbmVcIiAvPlxuICAgIDwvZGl2PlxuICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJtbC1hdXRvIGgtOSB3LTEvMyByb3VuZGVkLXhsIG1vdGlvbi1yZWR1Y2U6YW5pbWF0ZS1ub25lXCIgLz5cbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLXktMlwiPlxuICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNCB3LTEwLzEyIG1vdGlvbi1yZWR1Y2U6YW5pbWF0ZS1ub25lXCIgLz5cbiAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTQgdy0yLzMgbW90aW9uLXJlZHVjZTphbmltYXRlLW5vbmVcIiAvPlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbik7XG5cbmV4cG9ydCBjb25zdCBUaHJlYWQ6IEZDPFRocmVhZFByb3BzPiA9ICh7XG4gIGNvbXBvbmVudHMgPSBFTVBUWV9DT01QT05FTlRTLFxuICBhdXRvRm9jdXMgPSB0cnVlLFxufSkgPT4ge1xuICBjb25zdCBpc0VtcHR5ID0gdXNlQXVpU3RhdGUoaXNOZXdDaGF0Vmlldyk7XG5cbiAgcmV0dXJuIChcbiAgICA8VGhyZWFkQ29tcG9uZW50c0NvbnRleHQuUHJvdmlkZXIgdmFsdWU9e2NvbXBvbmVudHN9PlxuICAgICAgPFRocmVhZFJvb3QgaXNFbXB0eT17aXNFbXB0eX0gYXV0b0ZvY3VzPXthdXRvRm9jdXN9IC8+XG4gICAgPC9UaHJlYWRDb21wb25lbnRzQ29udGV4dC5Qcm92aWRlcj5cbiAgKTtcbn07XG5cbmNvbnN0IFRocmVhZFJvb3Q6IEZDPHsgaXNFbXB0eTogYm9vbGVhbjsgYXV0b0ZvY3VzOiBib29sZWFuIH0+ID0gKHtcbiAgaXNFbXB0eSxcbiAgYXV0b0ZvY3VzLFxufSkgPT4ge1xuICBjb25zdCB7IFdlbGNvbWUgPSBUaHJlYWRXZWxjb21lIH0gPSB1c2VDb250ZXh0KFRocmVhZENvbXBvbmVudHNDb250ZXh0KTtcblxuICByZXR1cm4gKFxuICAgIDxUaHJlYWRQcmltaXRpdmUuUm9vdFxuICAgICAgY2xhc3NOYW1lPVwiYXVpLXJvb3QgYXVpLXRocmVhZC1yb290IGJnLWJhY2tncm91bmQgQGNvbnRhaW5lciBmbGV4IGgtZnVsbCBmbGV4LWNvbFwiXG4gICAgICBzdHlsZT17e1xuICAgICAgICBbXCItLXRocmVhZC1tYXgtd2lkdGhcIiBhcyBzdHJpbmddOiBcIjQ0cmVtXCIsXG4gICAgICAgIFtcIi0tY29tcG9zZXItYmdcIiBhcyBzdHJpbmddOlxuICAgICAgICAgIFwiY29sb3ItbWl4KGluIG9rbGFiLCB2YXIoLS1jb2xvci1tdXRlZCkgMzAlLCB0cmFuc3BhcmVudClcIixcbiAgICAgICAgW1wiLS1jb21wb3Nlci1yYWRpdXNcIiBhcyBzdHJpbmddOiBcIjFyZW1cIixcbiAgICAgICAgW1wiLS1jb21wb3Nlci1wYWRkaW5nXCIgYXMgc3RyaW5nXTogXCI4cHhcIixcbiAgICAgIH19XG4gICAgPlxuICAgICAgPFRocmVhZFByaW1pdGl2ZS5WaWV3cG9ydFxuICAgICAgICB0dXJuQW5jaG9yPVwiYm90dG9tXCJcbiAgICAgICAgZGF0YS1zbG90PVwiYXVpX3RocmVhZC12aWV3cG9ydFwiXG4gICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggZmxleC0xIGZsZXgtY29sIG92ZXJmbG93LXgtYXV0byBvdmVyZmxvdy15LXNjcm9sbCBzY3JvbGwtc21vb3RoXCJcbiAgICAgID5cbiAgICAgICAgPGRpdlxuICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICBcIm14LWF1dG8gZmxleCB3LWZ1bGwgbWF4LXctKC0tdGhyZWFkLW1heC13aWR0aCkgZmxleC0xIGZsZXgtY29sIHB4LTQgcHQtNFwiLFxuICAgICAgICAgICAgaXNFbXB0eSAmJiBcImp1c3RpZnktY2VudGVyXCIsXG4gICAgICAgICAgKX1cbiAgICAgICAgPlxuICAgICAgICAgIDxBdWlJZiBjb25kaXRpb249e2lzTmV3Q2hhdFZpZXd9PlxuICAgICAgICAgICAgPFdlbGNvbWUgLz5cbiAgICAgICAgICA8L0F1aUlmPlxuICAgICAgICAgIDxBdWlJZiBjb25kaXRpb249e2lzSGlzdG9yeUxvYWRpbmdWaWV3fT5cbiAgICAgICAgICAgIDxUaHJlYWRIaXN0b3J5U2tlbGV0b24gLz5cbiAgICAgICAgICA8L0F1aUlmPlxuXG4gICAgICAgICAgPFRocmVhZExvYWRFYXJsaWVyIC8+XG5cbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBkYXRhLXNsb3Q9XCJhdWlfbWVzc2FnZS1ncm91cFwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJtYi0xNCBmbGV4IGZsZXgtY29sIGdhcC15LTYgZW1wdHk6aGlkZGVuXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8VGhyZWFkUHJpbWl0aXZlLk1lc3NhZ2VzPlxuICAgICAgICAgICAgICB7KCkgPT4gPFRocmVhZE1lc3NhZ2UgLz59XG4gICAgICAgICAgICA8L1RocmVhZFByaW1pdGl2ZS5NZXNzYWdlcz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxUaHJlYWRQcmltaXRpdmUuVmlld3BvcnRGb290ZXJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgIFwiYXVpLXRocmVhZC12aWV3cG9ydC1mb290ZXIgYmctYmFja2dyb3VuZCBmbGV4IGZsZXgtY29sIGdhcC00IG92ZXJmbG93LXZpc2libGUgcGItNCBtZDpwYi02XCIsXG4gICAgICAgICAgICAgICFpc0VtcHR5ICYmXG4gICAgICAgICAgICAgICAgXCJzdGlja3kgYm90dG9tLTAgbXQtYXV0byByb3VuZGVkLXQtKC0tY29tcG9zZXItcmFkaXVzKVwiLFxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8VGhyZWFkU2Nyb2xsVG9Cb3R0b20gLz5cbiAgICAgICAgICAgIDxUaHJlYWRGb2xsb3d1cFN1Z2dlc3Rpb25zIC8+XG4gICAgICAgICAgICA8Q29tcG9zZXIgYXV0b0ZvY3VzPXthdXRvRm9jdXN9IC8+XG4gICAgICAgICAgICA8QXVpSWYgY29uZGl0aW9uPXsocykgPT4gaXNOZXdDaGF0VmlldyhzKSAmJiBzLmNvbXBvc2VyLmlzRW1wdHl9PlxuICAgICAgICAgICAgICA8VGhyZWFkU3VnZ2VzdGlvbnMgLz5cbiAgICAgICAgICAgIDwvQXVpSWY+XG4gICAgICAgICAgPC9UaHJlYWRQcmltaXRpdmUuVmlld3BvcnRGb290ZXI+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9UaHJlYWRQcmltaXRpdmUuVmlld3BvcnQ+XG4gICAgPC9UaHJlYWRQcmltaXRpdmUuUm9vdD5cbiAgKTtcbn07XG5cbmNvbnN0IFRocmVhZE1lc3NhZ2U6IEZDID0gKCkgPT4ge1xuICBjb25zdCB7IEFzc2lzdGFudE1lc3NhZ2U6IEFzc2lzdGFudE1lc3NhZ2VDb21wb25lbnQgPSBBc3Npc3RhbnRNZXNzYWdlIH0gPVxuICAgIHVzZUNvbnRleHQoVGhyZWFkQ29tcG9uZW50c0NvbnRleHQpO1xuICBjb25zdCByb2xlID0gdXNlQXVpU3RhdGUoKHMpID0+IHMubWVzc2FnZS5yb2xlKTtcbiAgY29uc3QgaXNFZGl0aW5nID0gdXNlQXVpU3RhdGUoKHMpID0+IHMubWVzc2FnZS5jb21wb3Nlci5pc0VkaXRpbmcpO1xuICBjb25zdCBpc1Nwb2tlbiA9IHVzZUF1aVN0YXRlKChzKSA9PiBzLm1lc3NhZ2UubWV0YWRhdGEubW9kYWxpdHkgPT09IFwidm9pY2VcIik7XG5cbiAgaWYgKGlzRWRpdGluZykgcmV0dXJuIDxFZGl0Q29tcG9zZXIgLz47XG4gIGlmIChpc1Nwb2tlbikgcmV0dXJuIDxTcG9rZW5NZXNzYWdlIC8+O1xuICBpZiAocm9sZSA9PT0gXCJ1c2VyXCIpIHJldHVybiA8VXNlck1lc3NhZ2UgLz47XG4gIHJldHVybiA8QXNzaXN0YW50TWVzc2FnZUNvbXBvbmVudCAvPjtcbn07XG5cbnR5cGUgVm9pY2VSdW5Qb3NpdGlvbiA9IFwic2luZ2xlXCIgfCBcInN0YXJ0XCIgfCBcIm1pZGRsZVwiIHwgXCJlbmRcIjtcblxuY29uc3QgdXNlVm9pY2VSdW5Qb3NpdGlvbiA9ICgpOiBWb2ljZVJ1blBvc2l0aW9uID0+XG4gIHVzZUF1aVN0YXRlKChzKSA9PiB7XG4gICAgY29uc3QgYmVmb3JlID1cbiAgICAgIHMudGhyZWFkLm1lc3NhZ2VzW3MubWVzc2FnZS5pbmRleCAtIDFdPy5tZXRhZGF0YS5tb2RhbGl0eSA9PT0gXCJ2b2ljZVwiO1xuICAgIGNvbnN0IGFmdGVyID1cbiAgICAgIHMudGhyZWFkLm1lc3NhZ2VzW3MubWVzc2FnZS5pbmRleCArIDFdPy5tZXRhZGF0YS5tb2RhbGl0eSA9PT0gXCJ2b2ljZVwiO1xuICAgIGlmIChiZWZvcmUpIHJldHVybiBhZnRlciA/IFwibWlkZGxlXCIgOiBcImVuZFwiO1xuICAgIHJldHVybiBhZnRlciA/IFwic3RhcnRcIiA6IFwic2luZ2xlXCI7XG4gIH0pO1xuXG5jb25zdCBTcG9rZW5UZXh0OiBUZXh0TWVzc2FnZVBhcnRDb21wb25lbnQgPSAoeyB0ZXh0IH0pID0+IChcbiAgPHAgY2xhc3NOYW1lPVwiYXVpLXNwb2tlbi1tZXNzYWdlLXRleHQgbS0wXCI+e3RleHR9PC9wPlxuKTtcblxuY29uc3QgU3Bva2VuTWVzc2FnZTogRkMgPSAoKSA9PiB7XG4gIGNvbnN0IHJvbGUgPSB1c2VBdWlTdGF0ZSgocykgPT4gcy5tZXNzYWdlLnJvbGUpO1xuICBjb25zdCBwb3NpdGlvbiA9IHVzZVZvaWNlUnVuUG9zaXRpb24oKTtcbiAgY29uc3QgaXNTcGVha2luZyA9IHVzZUF1aVN0YXRlKFxuICAgIChzKSA9PlxuICAgICAgcy5tZXNzYWdlLnJvbGUgPT09IFwiYXNzaXN0YW50XCIgJiYgcy5tZXNzYWdlLnN0YXR1cz8udHlwZSA9PT0gXCJydW5uaW5nXCIsXG4gICk7XG4gIGNvbnN0IG9wZW5zRXhjaGFuZ2UgPSBwb3NpdGlvbiA9PT0gXCJzdGFydFwiIHx8IHBvc2l0aW9uID09PSBcInNpbmdsZVwiO1xuXG4gIHJldHVybiAoXG4gICAgPE1lc3NhZ2VQcmltaXRpdmUuUm9vdFxuICAgICAgZGF0YS1zbG90PVwiYXVpX3Nwb2tlbi1tZXNzYWdlLXJvb3RcIlxuICAgICAgZGF0YS1yb2xlPXtyb2xlfVxuICAgICAgZGF0YS12b2ljZS1ydW49e3Bvc2l0aW9ufVxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJhdWktc3Bva2VuLW1lc3NhZ2UgYmctbXV0ZWQvNDAgbXgtMiBweC0zIHB5LTEuNSBbY29udGFpbi1pbnRyaW5zaWMtc2l6ZTphdXRvXzQ4cHhdIFtjb250ZW50LXZpc2liaWxpdHk6YXV0b11cIixcbiAgICAgICAgcG9zaXRpb24gPT09IFwic2luZ2xlXCIgJiYgXCJyb3VuZGVkLXhsIHB5LTJcIixcbiAgICAgICAgcG9zaXRpb24gPT09IFwic3RhcnRcIiAmJiBcInJvdW5kZWQtdC14bCBwdC0yXCIsXG4gICAgICAgIHBvc2l0aW9uID09PSBcIm1pZGRsZVwiICYmIFwiLW10LTZcIixcbiAgICAgICAgcG9zaXRpb24gPT09IFwiZW5kXCIgJiYgXCItbXQtNiByb3VuZGVkLWIteGwgcGItMlwiLFxuICAgICAgKX1cbiAgICA+XG4gICAgICB7b3BlbnNFeGNoYW5nZSAmJiAoXG4gICAgICAgIDxkaXZcbiAgICAgICAgICBkYXRhLXNsb3Q9XCJhdWlfc3Bva2VuLWV4Y2hhbmdlLWhlYWRlclwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kIG1iLTEuNSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHNcIlxuICAgICAgICA+XG4gICAgICAgICAgPFBob25lSWNvbiBjbGFzc05hbWU9XCJzaXplLTNcIiBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgIDxzcGFuPlZvaWNlIGNvbnZlcnNhdGlvbjwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgICAgPGRpdlxuICAgICAgICBkYXRhLXNsb3Q9XCJhdWlfc3Bva2VuLW1lc3NhZ2UtY29udGVudFwiXG4gICAgICAgIGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZCBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yIHRleHQtc20gbGVhZGluZy1yZWxheGVkXCJcbiAgICAgID5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kIG10LTEgc2hyaW5rLTBcIiBhcmlhLWhpZGRlbj5cbiAgICAgICAgICB7cm9sZSA9PT0gXCJ1c2VyXCIgPyAoXG4gICAgICAgICAgICA8TWljSWNvbiBjbGFzc05hbWU9XCJzaXplLTMuNVwiIC8+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxBdWRpb0xpbmVzSWNvbiBjbGFzc05hbWU9XCJzaXplLTMuNVwiIC8+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9zcGFuPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+XG4gICAgICAgICAge3JvbGUgPT09IFwidXNlclwiID8gXCJZb3Ugc2FpZFwiIDogXCJBc3Npc3RhbnQgc2FpZFwifVxuICAgICAgICA8L3NwYW4+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTEgd3JhcC1icmVhay13b3JkXCI+XG4gICAgICAgICAgPE1lc3NhZ2VQcmltaXRpdmUuUGFydHMgY29tcG9uZW50cz17eyBUZXh0OiBTcG9rZW5UZXh0IH19IC8+XG4gICAgICAgICAge2lzU3BlYWtpbmcgJiYgKFxuICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgZGF0YS1zbG90PVwiYXVpX3Nwb2tlbi1tZXNzYWdlLWluZGljYXRvclwiXG4gICAgICAgICAgICAgIHJvbGU9XCJzdGF0dXNcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkLWZvcmVncm91bmQgbXMtMSBhbmltYXRlLXB1bHNlIGZvbnQtc2Fuc1wiXG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJBc3Npc3RhbnQgaXMgc3BlYWtpbmdcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICDil49cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPFNwb2tlbkFjdGlvbkJhciAvPlxuICAgICAgPC9kaXY+XG4gICAgPC9NZXNzYWdlUHJpbWl0aXZlLlJvb3Q+XG4gICk7XG59O1xuXG5jb25zdCBTcG9rZW5BY3Rpb25CYXI6IEZDID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxBY3Rpb25CYXJQcmltaXRpdmUuUm9vdFxuICAgICAgaGlkZVdoZW5SdW5uaW5nXG4gICAgICBhdXRvaGlkZT1cImFsd2F5c1wiXG4gICAgICBjbGFzc05hbWU9XCJhdWktc3Bva2VuLWFjdGlvbi1iYXIgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGZsZXggc2hyaW5rLTAgZ2FwLTFcIlxuICAgID5cbiAgICAgIDxBY3Rpb25CYXJQcmltaXRpdmUuQ29weSBhc0NoaWxkPlxuICAgICAgICA8VG9vbHRpcEljb25CdXR0b24gdG9vbHRpcD1cIkNvcHlcIiBjbGFzc05hbWU9XCJzaXplLTZcIj5cbiAgICAgICAgICA8QXVpSWYgY29uZGl0aW9uPXsocykgPT4gcy5tZXNzYWdlLmlzQ29waWVkfT5cbiAgICAgICAgICAgIDxDaGVja0ljb24gY2xhc3NOYW1lPVwiYW5pbWF0ZS1pbiB6b29tLWluLTUwIGZhZGUtaW4gZHVyYXRpb24tMjAwIGVhc2Utb3V0XCIgLz5cbiAgICAgICAgICA8L0F1aUlmPlxuICAgICAgICAgIDxBdWlJZiBjb25kaXRpb249eyhzKSA9PiAhcy5tZXNzYWdlLmlzQ29waWVkfT5cbiAgICAgICAgICAgIDxDb3B5SWNvbiBjbGFzc05hbWU9XCJhbmltYXRlLWluIHpvb20taW4tNzUgZmFkZS1pbiBkdXJhdGlvbi0xNTBcIiAvPlxuICAgICAgICAgIDwvQXVpSWY+XG4gICAgICAgIDwvVG9vbHRpcEljb25CdXR0b24+XG4gICAgICA8L0FjdGlvbkJhclByaW1pdGl2ZS5Db3B5PlxuICAgIDwvQWN0aW9uQmFyUHJpbWl0aXZlLlJvb3Q+XG4gICk7XG59O1xuXG5jb25zdCBGT0NVU0FCTEVfU0VMRUNUT1IgPVxuICBcImFbaHJlZl0sIGJ1dHRvbjpub3QoW2Rpc2FibGVkXSksIGlucHV0Om5vdChbZGlzYWJsZWRdKSwgdGV4dGFyZWE6bm90KFtkaXNhYmxlZF0pLCBbdGFiaW5kZXhdOm5vdChbdGFiaW5kZXg9Jy0xJ10pOm5vdChbZGlzYWJsZWRdKVwiO1xuXG5jb25zdCBuZXh0Rm9jdXNhYmxlID0gKHN0YXJ0OiBFbGVtZW50KSA9PiB7XG4gIGZvciAoXG4gICAgbGV0IGVsZW1lbnQgPSBzdGFydC5uZXh0RWxlbWVudFNpYmxpbmc7XG4gICAgZWxlbWVudDtcbiAgICBlbGVtZW50ID0gZWxlbWVudC5uZXh0RWxlbWVudFNpYmxpbmdcbiAgKSB7XG4gICAgY29uc3QgdGFyZ2V0ID0gZWxlbWVudC5tYXRjaGVzKEZPQ1VTQUJMRV9TRUxFQ1RPUilcbiAgICAgID8gZWxlbWVudFxuICAgICAgOiBlbGVtZW50LnF1ZXJ5U2VsZWN0b3IoRk9DVVNBQkxFX1NFTEVDVE9SKTtcbiAgICBpZiAodGFyZ2V0IGluc3RhbmNlb2YgSFRNTEVsZW1lbnQpIHJldHVybiB0YXJnZXQ7XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59O1xuXG5jb25zdCBUaHJlYWRMb2FkRWFybGllcjogRkMgPSAoKSA9PiB7XG4gIGNvbnN0IHZpc2libGUgPSB1c2VBdWlTdGF0ZShcbiAgICAocykgPT4gcy50aHJlYWQuaGFzRWFybGllciB8fCBzLnRocmVhZC5pc0xvYWRpbmdFYXJsaWVyLFxuICApO1xuICBjb25zdCBsb2FkaW5nID0gdXNlQXVpU3RhdGUoKHMpID0+IHMudGhyZWFkLmlzTG9hZGluZ0VhcmxpZXIpO1xuICBjb25zdCBzbG90UmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcbiAgY29uc3QgZm9jdXNlZFJlZiA9IHVzZVJlZjxFbGVtZW50IHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gVGhlIGxhc3QgcGFnZSByZW1vdmVzIHRoZSBidXR0b247IGEga2V5Ym9hcmQgdXNlciBvbiBpdCBjb250aW51ZXMgZnJvbSB0aGVcbiAgLy8gbmV4dCBjb250cm9sIGluIHRhYiBvcmRlciByYXRoZXIgdGhhbiBmcm9tIHRoZSBkb2N1bWVudCBib2R5LlxuICB1c2VMYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGZvY3VzZWQgPSBmb2N1c2VkUmVmLmN1cnJlbnQ7XG4gICAgY29uc3Qgc2xvdCA9IHNsb3RSZWYuY3VycmVudDtcbiAgICBpZiAodmlzaWJsZSB8fCAhZm9jdXNlZCB8fCBmb2N1c2VkLmlzQ29ubmVjdGVkIHx8ICFzbG90KSByZXR1cm47XG4gICAgZm9jdXNlZFJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICBjb25zdCBhY3RpdmUgPSBkb2N1bWVudC5hY3RpdmVFbGVtZW50O1xuICAgIGlmIChhY3RpdmUgJiYgYWN0aXZlICE9PSBkb2N1bWVudC5ib2R5KSByZXR1cm47XG4gICAgbmV4dEZvY3VzYWJsZShzbG90KT8uZm9jdXMoKTtcbiAgfSwgW3Zpc2libGVdKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIHJlZj17c2xvdFJlZn1cbiAgICAgIGNsYXNzTmFtZT1cImNvbnRlbnRzXCJcbiAgICAgIG9uRm9jdXM9eyhldmVudCkgPT4ge1xuICAgICAgICBmb2N1c2VkUmVmLmN1cnJlbnQgPSBldmVudC50YXJnZXQ7XG4gICAgICB9fVxuICAgID5cbiAgICAgIDxzcGFuIHJvbGU9XCJzdGF0dXNcIiBjbGFzc05hbWU9XCJzci1vbmx5XCI+XG4gICAgICAgIHtsb2FkaW5nID8gXCJMb2FkaW5nIGVhcmxpZXIgbWVzc2FnZXNcIiA6IFwiXCJ9XG4gICAgICA8L3NwYW4+XG4gICAgICB7dmlzaWJsZSAmJiAoXG4gICAgICAgIDxUaHJlYWRQcmltaXRpdmUuTG9hZEVhcmxpZXIgYXNDaGlsZD5cbiAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxuICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgIGRhdGEtc2xvdD1cImF1aV90aHJlYWQtbG9hZC1lYXJsaWVyXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImF1aS10aHJlYWQtbG9hZC1lYXJsaWVyIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBtYi02IHNlbGYtY2VudGVyIHJvdW5kZWQtZnVsbFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihsb2FkaW5nICYmIFwic2hpbW1lciBtb3Rpb24tcmVkdWNlOmFuaW1hdGUtbm9uZVwiKX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge2xvYWRpbmcgPyBcIkxvYWRpbmcgZWFybGllciBtZXNzYWdlc1wiIDogXCJMb2FkIGVhcmxpZXIgbWVzc2FnZXNcIn1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9UaHJlYWRQcmltaXRpdmUuTG9hZEVhcmxpZXI+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufTtcblxuY29uc3QgVGhyZWFkU2Nyb2xsVG9Cb3R0b206IEZDID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxUaHJlYWRQcmltaXRpdmUuU2Nyb2xsVG9Cb3R0b20gYmVoYXZpb3I9XCJpbnN0YW50XCIgYXNDaGlsZD5cbiAgICAgIDxUb29sdGlwSWNvbkJ1dHRvblxuICAgICAgICB0b29sdGlwPVwiU2Nyb2xsIHRvIGJvdHRvbVwiXG4gICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgY2xhc3NOYW1lPVwiYXVpLXRocmVhZC1zY3JvbGwtdG8tYm90dG9tIGRhcms6Ym9yZGVyLWJvcmRlciBkYXJrOmJnLWJhY2tncm91bmQgZGFyazpob3ZlcjpiZy1hY2NlbnQgYWJzb2x1dGUgLXRvcC0xMiB6LTEwIHNlbGYtY2VudGVyIHJvdW5kZWQtZnVsbCBwLTQgZGlzYWJsZWQ6aW52aXNpYmxlXCJcbiAgICAgID5cbiAgICAgICAgPEFycm93RG93bkljb24gLz5cbiAgICAgIDwvVG9vbHRpcEljb25CdXR0b24+XG4gICAgPC9UaHJlYWRQcmltaXRpdmUuU2Nyb2xsVG9Cb3R0b20+XG4gICk7XG59O1xuXG5jb25zdCBUaHJlYWRXZWxjb21lOiBGQyA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImF1aS10aHJlYWQtd2VsY29tZS1yb290IG1iLTYgZmxleCBmbGV4LWNvbCBweC0yXCI+XG4gICAgICA8cCBjbGFzc05hbWU9XCJhdWktdGhyZWFkLXdlbGNvbWUtbWVzc2FnZS1pbm5lciBmYWRlLWluIHNsaWRlLWluLWZyb20tYm90dG9tLTEgYW5pbWF0ZS1pbiBmaWxsLW1vZGUtYm90aCB0ZXh0LTJ4bCBmb250LW1lZGl1bSB0cmFja2luZy10aWdodCBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgSG93IGNhbiBJIGhlbHAgeW91IHRvZGF5P1xuICAgICAgPC9wPlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuY29uc3QgVGhyZWFkU3VnZ2VzdGlvbnM6IEZDID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYXVpLXRocmVhZC13ZWxjb21lLXN1Z2dlc3Rpb25zIGZsZXggdy1mdWxsIGZsZXgtY29sXCI+XG4gICAgICA8VGhyZWFkUHJpbWl0aXZlLlN1Z2dlc3Rpb25zPlxuICAgICAgICB7KCkgPT4gPFRocmVhZFN1Z2dlc3Rpb25JdGVtIC8+fVxuICAgICAgPC9UaHJlYWRQcmltaXRpdmUuU3VnZ2VzdGlvbnM+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5jb25zdCBUaHJlYWRTdWdnZXN0aW9uSXRlbTogRkMgPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJhdWktdGhyZWFkLXdlbGNvbWUtc3VnZ2VzdGlvbi1kaXNwbGF5IGZhZGUtaW4gc2xpZGUtaW4tZnJvbS1ib3R0b20tMiBhbmltYXRlLWluIGZpbGwtbW9kZS1ib3RoIGR1cmF0aW9uLTIwMFwiPlxuICAgICAgPFN1Z2dlc3Rpb25QcmltaXRpdmUuVHJpZ2dlciBzZW5kIGFzQ2hpbGQ+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJhdWktdGhyZWFkLXdlbGNvbWUtc3VnZ2VzdGlvbiBncm91cCBob3ZlcjpiZy1mb3JlZ3JvdW5kL1swLjAzXSBmb2N1cy12aXNpYmxlOnJpbmctcmluZy81MCBmbGV4IHctZnVsbCBpdGVtcy1iYXNlbGluZSBnYXAtMi41IHJvdW5kZWQtbWQgcHgtMiBweS0yIHRleHQtc3RhcnQgdGV4dC1zbSB0cmFuc2l0aW9uLWNvbG9ycyBvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTEgbW90aW9uLXJlZHVjZTp0cmFuc2l0aW9uLW5vbmVcIlxuICAgICAgICA+XG4gICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgIGFyaWEtaGlkZGVuXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkLWZvcmVncm91bmQvNjAgZ3JvdXAtaG92ZXI6dGV4dC1mb3JlZ3JvdW5kIGZvbnQtbW9ubyB0ZXh0LXhzIHRyYW5zaXRpb24tY29sb3JzIG1vdGlvbi1yZWR1Y2U6dHJhbnNpdGlvbi1ub25lXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICB7XCI+XCJ9XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xIHRydW5jYXRlXCI+XG4gICAgICAgICAgICA8U3VnZ2VzdGlvblByaW1pdGl2ZS5UaXRsZSBjbGFzc05hbWU9XCJhdWktdGhyZWFkLXdlbGNvbWUtc3VnZ2VzdGlvbi10ZXh0LTEgdGV4dC1mb3JlZ3JvdW5kXCIgLz57XCIgXCJ9XG4gICAgICAgICAgICA8U3VnZ2VzdGlvblByaW1pdGl2ZS5EZXNjcmlwdGlvbiBjbGFzc05hbWU9XCJhdWktdGhyZWFkLXdlbGNvbWUtc3VnZ2VzdGlvbi10ZXh0LTIgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGVtcHR5OmhpZGRlblwiIC8+XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvU3VnZ2VzdGlvblByaW1pdGl2ZS5UcmlnZ2VyPlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuY29uc3QgQ29tcG9zZXI6IEZDPHsgYXV0b0ZvY3VzOiBib29sZWFuIH0+ID0gKHsgYXV0b0ZvY3VzIH0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8Q29tcG9zZXJQcmltaXRpdmUuUm9vdCBjbGFzc05hbWU9XCJhdWktY29tcG9zZXItcm9vdCByZWxhdGl2ZSBmbGV4IHctZnVsbCBmbGV4LWNvbFwiPlxuICAgICAgPENvbXBvc2VyUHJpbWl0aXZlLkF0dGFjaG1lbnREcm9wem9uZSBhc0NoaWxkPlxuICAgICAgICA8ZGl2XG4gICAgICAgICAgZGF0YS1zbG90PVwiYXVpX2NvbXBvc2VyLXNoZWxsXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItZm9yZWdyb3VuZC8xMCBmb2N1cy13aXRoaW46Ym9yZGVyLWZvcmVncm91bmQvMjUgZGF0YS1bZHJhZ2dpbmc9dHJ1ZV06Ym9yZGVyLXJpbmcgZmxleCB3LWZ1bGwgY3Vyc29yLXRleHQgZmxleC1jb2wgZ2FwLTIgcm91bmRlZC0oLS1jb21wb3Nlci1yYWRpdXMpIGJvcmRlciBiZy0oLS1jb21wb3Nlci1iZykgcC0oLS1jb21wb3Nlci1wYWRkaW5nKSB0cmFuc2l0aW9uLVtib3JkZXItY29sb3JdIGRhdGEtW2RyYWdnaW5nPXRydWVdOmJvcmRlci1kYXNoZWQgZGF0YS1bZHJhZ2dpbmc9dHJ1ZV06YmctW2NvbG9yLW1peChpbl9va2xhYix2YXIoLS1jb2xvci1hY2NlbnQpXzUwJSx2YXIoLS1jb2xvci1iYWNrZ3JvdW5kKSldXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxDb21wb3NlckF0dGFjaG1lbnRzIC8+XG4gICAgICAgICAgPENvbXBvc2VyUHJpbWl0aXZlLklucHV0XG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbmQgYSBtZXNzYWdlLi4uXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImF1aS1jb21wb3Nlci1pbnB1dCBjYXJldC1wcmltYXJ5IHBsYWNlaG9sZGVyOnRleHQtbXV0ZWQtZm9yZWdyb3VuZC82MCBtYXgtaC00OCBtaW4taC0xMCB3LWZ1bGwgcmVzaXplLW5vbmUgYmctdHJhbnNwYXJlbnQgcHgtMi41IHB5LTEgdGV4dC1iYXNlIGxlYWRpbmctNiBvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgcm93cz17MX1cbiAgICAgICAgICAgIGF1dG9Gb2N1cz17YXV0b0ZvY3VzfVxuICAgICAgICAgICAgZW50ZXJLZXlIaW50PVwic2VuZFwiXG4gICAgICAgICAgICBhcmlhLWxhYmVsPVwiTWVzc2FnZSBpbnB1dFwiXG4gICAgICAgICAgLz5cbiAgICAgICAgICA8Q29tcG9zZXJBY3Rpb24gLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L0NvbXBvc2VyUHJpbWl0aXZlLkF0dGFjaG1lbnREcm9wem9uZT5cbiAgICA8L0NvbXBvc2VyUHJpbWl0aXZlLlJvb3Q+XG4gICk7XG59O1xuXG5jb25zdCBDb21wb3NlckFjdGlvbjogRkMgPSAoKSA9PiB7XG4gIGNvbnN0IHsgQ29tcG9zZXJFeHRyYSB9ID0gdXNlQ29udGV4dChUaHJlYWRDb21wb25lbnRzQ29udGV4dCk7XG4gIC8vIFRoZSBzdG9wIGNvbnRyb2wgb25seSBjYW5jZWxzIHRoZSBzZW5kIHdoaWxlIG5vIHJ1biBpdCBjb3VsZCBzdG9wIGlzIGdvaW5nLlxuICBjb25zdCBpc1NlbmRpbmcgPSB1c2VBdWlTdGF0ZShcbiAgICAocykgPT5cbiAgICAgIHMuY29tcG9zZXIuc3VibWlzc2lvbiAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAhKHMudGhyZWFkLmlzUnVubmluZyAmJiBzLnRocmVhZC5jYXBhYmlsaXRpZXMuY2FuY2VsKSxcbiAgKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYXVpLWNvbXBvc2VyLWFjdGlvbi13cmFwcGVyIHJlbGF0aXZlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAge0NvbXBvc2VyRXh0cmEgPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXVpLWNvbXBvc2VyLWFjdGlvbi1zdGFydCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgPENvbXBvc2VyQWRkQXR0YWNobWVudCAvPlxuICAgICAgICAgIDxDb21wb3NlckV4dHJhIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IChcbiAgICAgICAgPENvbXBvc2VyQWRkQXR0YWNobWVudCAvPlxuICAgICAgKX1cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICA8QXVpSWYgY29uZGl0aW9uPXsocykgPT4gcy50aHJlYWQuY2FwYWJpbGl0aWVzLmRpY3RhdGlvbn0+XG4gICAgICAgICAgPEF1aUlmIGNvbmRpdGlvbj17KHMpID0+IHMuY29tcG9zZXIuZGljdGF0aW9uID09IG51bGx9PlxuICAgICAgICAgICAgPENvbXBvc2VyUHJpbWl0aXZlLkRpY3RhdGUgYXNDaGlsZD5cbiAgICAgICAgICAgICAgPFRvb2x0aXBJY29uQnV0dG9uXG4gICAgICAgICAgICAgICAgdG9vbHRpcD1cIlZvaWNlIGlucHV0XCJcbiAgICAgICAgICAgICAgICBzaWRlPVwiYm90dG9tXCJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxuICAgICAgICAgICAgICAgIHNpemU9XCJpY29uXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhdWktY29tcG9zZXItZGljdGF0ZSB0ZXh0LW11dGVkLWZvcmVncm91bmQgaG92ZXI6dGV4dC1mb3JlZ3JvdW5kIHNpemUtNyByb3VuZGVkLWZ1bGxcIlxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJTdGFydCB2b2ljZSBpbnB1dFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8TWljSWNvbiBjbGFzc05hbWU9XCJhdWktY29tcG9zZXItZGljdGF0ZS1pY29uIHNpemUtNFwiIC8+XG4gICAgICAgICAgICAgIDwvVG9vbHRpcEljb25CdXR0b24+XG4gICAgICAgICAgICA8L0NvbXBvc2VyUHJpbWl0aXZlLkRpY3RhdGU+XG4gICAgICAgICAgPC9BdWlJZj5cbiAgICAgICAgICA8QXVpSWYgY29uZGl0aW9uPXsocykgPT4gcy5jb21wb3Nlci5kaWN0YXRpb24gIT0gbnVsbH0+XG4gICAgICAgICAgICA8Q29tcG9zZXJQcmltaXRpdmUuU3RvcERpY3RhdGlvbiBhc0NoaWxkPlxuICAgICAgICAgICAgICA8VG9vbHRpcEljb25CdXR0b25cbiAgICAgICAgICAgICAgICB0b29sdGlwPVwiU3RvcCBkaWN0YXRpb25cIlxuICAgICAgICAgICAgICAgIHNpZGU9XCJib3R0b21cIlxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXG4gICAgICAgICAgICAgICAgc2l6ZT1cImljb25cIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImF1aS1jb21wb3Nlci1zdG9wLWRpY3RhdGlvbiB0ZXh0LWRlc3RydWN0aXZlIHNpemUtNyByb3VuZGVkLWZ1bGxcIlxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJTdG9wIHZvaWNlIGlucHV0XCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxTcXVhcmVJY29uIGNsYXNzTmFtZT1cImF1aS1jb21wb3Nlci1zdG9wLWRpY3RhdGlvbi1pY29uIHNpemUtMy41IGFuaW1hdGUtcHVsc2UgZmlsbC1jdXJyZW50XCIgLz5cbiAgICAgICAgICAgICAgPC9Ub29sdGlwSWNvbkJ1dHRvbj5cbiAgICAgICAgICAgIDwvQ29tcG9zZXJQcmltaXRpdmUuU3RvcERpY3RhdGlvbj5cbiAgICAgICAgICA8L0F1aUlmPlxuICAgICAgICA8L0F1aUlmPlxuICAgICAgICA8QXVpSWZcbiAgICAgICAgICBjb25kaXRpb249eyhzKSA9PlxuICAgICAgICAgICAgKCFzLmNvbXBvc2VyLmNhbkNhbmNlbCB8fFxuICAgICAgICAgICAgICAocy50aHJlYWQudm9pY2UgIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAgICAgICAgIHMuY29tcG9zZXIuc3VibWlzc2lvbiA9PT0gdW5kZWZpbmVkKSkgJiZcbiAgICAgICAgICAgICFzaG91bGRTaG93Q29tcG9zZXJSZXN1bWUocylcbiAgICAgICAgICB9XG4gICAgICAgID5cbiAgICAgICAgICA8Q29tcG9zZXJQcmltaXRpdmUuU2VuZCBhc0NoaWxkPlxuICAgICAgICAgICAgPFRvb2x0aXBJY29uQnV0dG9uXG4gICAgICAgICAgICAgIHRvb2x0aXA9XCJTZW5kIG1lc3NhZ2VcIlxuICAgICAgICAgICAgICBzaWRlPVwiYm90dG9tXCJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIHZhcmlhbnQ9XCJkZWZhdWx0XCJcbiAgICAgICAgICAgICAgc2l6ZT1cImljb25cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhdWktY29tcG9zZXItc2VuZCBzaXplLTcgcm91bmRlZC1mdWxsXCJcbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlNlbmQgbWVzc2FnZVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxBcnJvd1VwSWNvbiBjbGFzc05hbWU9XCJhdWktY29tcG9zZXItc2VuZC1pY29uIHNpemUtNFwiIC8+XG4gICAgICAgICAgICA8L1Rvb2x0aXBJY29uQnV0dG9uPlxuICAgICAgICAgIDwvQ29tcG9zZXJQcmltaXRpdmUuU2VuZD5cbiAgICAgICAgPC9BdWlJZj5cbiAgICAgICAgPEF1aUlmIGNvbmRpdGlvbj17c2hvdWxkU2hvd0NvbXBvc2VyUmVzdW1lfT5cbiAgICAgICAgICA8Q29tcG9zZXJQcmltaXRpdmUuUmVzdW1lIGFzQ2hpbGQ+XG4gICAgICAgICAgICA8VG9vbHRpcEljb25CdXR0b25cbiAgICAgICAgICAgICAgdG9vbHRpcD1cIlJlc3VtZSBnZW5lcmF0aW5nXCJcbiAgICAgICAgICAgICAgc2lkZT1cImJvdHRvbVwiXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICB2YXJpYW50PVwiZGVmYXVsdFwiXG4gICAgICAgICAgICAgIHNpemU9XCJpY29uXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXVpLWNvbXBvc2VyLXJlc3VtZSBzaXplLTcgcm91bmRlZC1mdWxsXCJcbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlJlc3VtZSBnZW5lcmF0aW5nXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFBsYXlJY29uIGNsYXNzTmFtZT1cImF1aS1jb21wb3Nlci1yZXN1bWUtaWNvbiBzaXplLTRcIiAvPlxuICAgICAgICAgICAgPC9Ub29sdGlwSWNvbkJ1dHRvbj5cbiAgICAgICAgICA8L0NvbXBvc2VyUHJpbWl0aXZlLlJlc3VtZT5cbiAgICAgICAgPC9BdWlJZj5cbiAgICAgICAgPEF1aUlmXG4gICAgICAgICAgY29uZGl0aW9uPXsocykgPT5cbiAgICAgICAgICAgIHMuY29tcG9zZXIuY2FuQ2FuY2VsICYmXG4gICAgICAgICAgICAocy50aHJlYWQudm9pY2UgPT09IHVuZGVmaW5lZCB8fFxuICAgICAgICAgICAgICBzLmNvbXBvc2VyLnN1Ym1pc3Npb24gIT09IHVuZGVmaW5lZClcbiAgICAgICAgICB9XG4gICAgICAgID5cbiAgICAgICAgICA8Q29tcG9zZXJQcmltaXRpdmUuQ2FuY2VsIGFzQ2hpbGQ+XG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICB2YXJpYW50PVwiZGVmYXVsdFwiXG4gICAgICAgICAgICAgIHNpemU9XCJpY29uXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXVpLWNvbXBvc2VyLWNhbmNlbCBzaXplLTcgcm91bmRlZC1mdWxsXCJcbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD17aXNTZW5kaW5nID8gXCJDYW5jZWwgc2VuZGluZ1wiIDogXCJTdG9wIGdlbmVyYXRpbmdcIn1cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3I8SFRNTFRleHRBcmVhRWxlbWVudD4oXCIuYXVpLWNvbXBvc2VyLWlucHV0XCIpPy5mb2N1cygpKX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFNxdWFyZUljb24gY2xhc3NOYW1lPVwiYXVpLWNvbXBvc2VyLWNhbmNlbC1pY29uIHNpemUtMy41IGZpbGwtY3VycmVudFwiIC8+XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8L0NvbXBvc2VyUHJpbWl0aXZlLkNhbmNlbD5cbiAgICAgICAgPC9BdWlJZj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuY29uc3QgTWVzc2FnZUVycm9yOiBGQyA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8TWVzc2FnZVByaW1pdGl2ZS5FcnJvcj5cbiAgICAgIDxFcnJvclByaW1pdGl2ZS5Sb290IHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cImF1aS1tZXNzYWdlLWVycm9yLXJvb3QgYm9yZGVyLWRlc3RydWN0aXZlIGJnLWRlc3RydWN0aXZlLzEwIHRleHQtZGVzdHJ1Y3RpdmUgZGFyazpiZy1kZXN0cnVjdGl2ZS81IG10LTIgcm91bmRlZC1tZCBib3JkZXIgcC0zIHRleHQtc20gZGFyazp0ZXh0LXJlZC0yMDBcIj5cbiAgICAgICAgPEVycm9yUHJpbWl0aXZlLk1lc3NhZ2UgY2xhc3NOYW1lPVwiYXVpLW1lc3NhZ2UtZXJyb3ItbWVzc2FnZSBsaW5lLWNsYW1wLTJcIiAvPlxuICAgICAgPC9FcnJvclByaW1pdGl2ZS5Sb290PlxuICAgIDwvTWVzc2FnZVByaW1pdGl2ZS5FcnJvcj5cbiAgKTtcbn07XG5cbmNvbnN0IEFzc2lzdGFudE1lc3NhZ2U6IEZDID0gKCkgPT4ge1xuICBjb25zdCB7XG4gICAgVG9vbEZhbGxiYWNrOiBUb29sRmFsbGJhY2tDb21wb25lbnQgPSBUb29sRmFsbGJhY2ssXG4gICAgVG9vbEdyb3VwLFxuICAgIFJlYXNvbmluZ0dyb3VwLFxuICAgIFRhc2tHcm91cDogVGFza0dyb3VwQ29tcG9uZW50LFxuICB9ID0gdXNlQ29udGV4dChUaHJlYWRDb21wb25lbnRzQ29udGV4dCk7XG4gIGNvbnN0IGdyb3VwQnkgPSBUYXNrR3JvdXBDb21wb25lbnQgPyB0YXNrQXdhcmVHcm91cEJ5IDogbWVzc2FnZUdyb3VwQnk7XG5cbiAgY29uc3QgQUNUSU9OX0JBUl9QVCA9IFwicHQtMS41XCI7XG4gIC8vIEtlZXAgdGhlIGFjdGlvbiBiYXIgaW5zaWRlIHRoZSBjb250YWluZWQgcm9vdCdzIHBhaW50IGJveCwgdGhlbiBjYW5jZWwgaXRzIHJlc2VydmVkIHNwYWNlIGluIGZsb3cuXG4gIGNvbnN0IEFDVElPTl9CQVJfSEVJR0hUID0gYG1pbi1oLTcuNSAke0FDVElPTl9CQVJfUFR9YDtcblxuICByZXR1cm4gKFxuICAgIDxNZXNzYWdlUHJpbWl0aXZlLlJvb3RcbiAgICAgIGRhdGEtc2xvdD1cImF1aV9hc3Npc3RhbnQtbWVzc2FnZS1yb290XCJcbiAgICAgIGRhdGEtcm9sZT1cImFzc2lzdGFudFwiXG4gICAgICBjbGFzc05hbWU9XCJmYWRlLWluIHNsaWRlLWluLWZyb20tYm90dG9tLTEgYW5pbWF0ZS1pbiByZWxhdGl2ZSAtbWItNy41IHBiLTcuNSBkdXJhdGlvbi0xNTAgW2NvbnRhaW4taW50cmluc2ljLXNpemU6YXV0b18yMDBweF0gW2NvbnRlbnQtdmlzaWJpbGl0eTphdXRvXVwiXG4gICAgPlxuICAgICAgPGRpdlxuICAgICAgICBkYXRhLXNsb3Q9XCJhdWlfYXNzaXN0YW50LW1lc3NhZ2UtY29udGVudFwiXG4gICAgICAgIGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZCBweC0yIGxlYWRpbmctcmVsYXhlZCB3cmFwLWJyZWFrLXdvcmRcIlxuICAgICAgPlxuICAgICAgICA8TWVzc2FnZVByaW1pdGl2ZS5Hcm91cGVkUGFydHMgZ3JvdXBCeT17Z3JvdXBCeX0+XG4gICAgICAgICAgeyh7IHBhcnQsIGNoaWxkcmVuIH0pID0+IHtcbiAgICAgICAgICAgIHN3aXRjaCAocGFydC50eXBlKSB7XG4gICAgICAgICAgICAgIGNhc2UgXCJncm91cC1jaGFpbk9mVGhvdWdodFwiOlxuICAgICAgICAgICAgICAgIHJldHVybiA8ZGl2IGRhdGEtc2xvdD1cImF1aV9jaGFpbi1vZi10aG91Z2h0XCI+e2NoaWxkcmVufTwvZGl2PjtcbiAgICAgICAgICAgICAgY2FzZSBcImdyb3VwLXRhc2tcIjpcbiAgICAgICAgICAgICAgICByZXR1cm4gVGFza0dyb3VwQ29tcG9uZW50ID8gKFxuICAgICAgICAgICAgICAgICAgPFRhc2tHcm91cENvbXBvbmVudCBncm91cD17cGFydH0gLz5cbiAgICAgICAgICAgICAgICApIDogbnVsbDtcbiAgICAgICAgICAgICAgY2FzZSBcImdyb3VwLXRvb2xcIjpcbiAgICAgICAgICAgICAgICBpZiAoVG9vbEdyb3VwKSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gPFRvb2xHcm91cCBncm91cD17cGFydH0+e2NoaWxkcmVufTwvVG9vbEdyb3VwPjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgIDxEZWZhdWx0VG9vbEdyb3VwIGdyb3VwPXtwYXJ0fT57Y2hpbGRyZW59PC9EZWZhdWx0VG9vbEdyb3VwPlxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgIGNhc2UgXCJncm91cC1yZWFzb25pbmdcIjoge1xuICAgICAgICAgICAgICAgIGlmIChSZWFzb25pbmdHcm91cCkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgPFJlYXNvbmluZ0dyb3VwIGdyb3VwPXtwYXJ0fT57Y2hpbGRyZW59PC9SZWFzb25pbmdHcm91cD5cbiAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IHJ1bm5pbmcgPSBwYXJ0LnN0YXR1cy50eXBlID09PSBcInJ1bm5pbmdcIjtcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgPFJlYXNvbmluZ1Jvb3Qgc3RyZWFtaW5nPXtydW5uaW5nfT5cbiAgICAgICAgICAgICAgICAgICAgPFJlYXNvbmluZ1RyaWdnZXJcbiAgICAgICAgICAgICAgICAgICAgICBhY3RpdmU9e3J1bm5pbmd9XG4gICAgICAgICAgICAgICAgICAgICAgZHVyYXRpb249e3JlYXNvbmluZ0R1cmF0aW9uKHBhcnQudGltaW5nKX1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPFJlYXNvbmluZ0NvbnRlbnQgYXJpYS1idXN5PXtydW5uaW5nfT5cbiAgICAgICAgICAgICAgICAgICAgICA8UmVhc29uaW5nVGV4dD57Y2hpbGRyZW59PC9SZWFzb25pbmdUZXh0PlxuICAgICAgICAgICAgICAgICAgICA8L1JlYXNvbmluZ0NvbnRlbnQ+XG4gICAgICAgICAgICAgICAgICA8L1JlYXNvbmluZ1Jvb3Q+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBjYXNlIFwidGV4dFwiOlxuICAgICAgICAgICAgICAgIHJldHVybiA8TWFya2Rvd25UZXh0IC8+O1xuICAgICAgICAgICAgICBjYXNlIFwicmVhc29uaW5nXCI6XG4gICAgICAgICAgICAgICAgcmV0dXJuIDxSZWFzb25pbmcgey4uLnBhcnR9IC8+O1xuICAgICAgICAgICAgICBjYXNlIFwidG9vbC1jYWxsXCI6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHBhcnQudG9vbFVJID8/IDxUb29sRmFsbGJhY2tDb21wb25lbnQgey4uLnBhcnR9IC8+O1xuICAgICAgICAgICAgICBjYXNlIFwiZGF0YVwiOlxuICAgICAgICAgICAgICAgIHJldHVybiBwYXJ0LmRhdGFSZW5kZXJlclVJO1xuICAgICAgICAgICAgICBjYXNlIFwiZmlsZVwiOlxuICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGRhdGEtc2xvdD1cImF1aV9hc3Npc3RhbnQtbWVzc2FnZS1maWxlXCIgY2xhc3NOYW1lPVwicHktMVwiPlxuICAgICAgICAgICAgICAgICAgICA8TWVzc2FnZUZpbGUgey4uLnBhcnR9IC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICBjYXNlIFwiaW1hZ2VcIjpcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgPGRpdiBkYXRhLXNsb3Q9XCJhdWlfYXNzaXN0YW50LW1lc3NhZ2UtaW1hZ2VcIiBjbGFzc05hbWU9XCJweS0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxJbWFnZSB7Li4ucGFydH0gLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgIGNhc2UgXCJpbmRpY2F0b3JcIjpcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgZGF0YS1zbG90PVwiYXVpX2Fzc2lzdGFudC1tZXNzYWdlLWluZGljYXRvclwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFuaW1hdGUtcHVsc2UgZm9udC1zYW5zXCJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkFzc2lzdGFudCBpcyB3b3JraW5nXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge1wi4pePXCJ9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9fVxuICAgICAgICA8L01lc3NhZ2VQcmltaXRpdmUuR3JvdXBlZFBhcnRzPlxuICAgICAgICA8TWVzc2FnZUVycm9yIC8+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdlxuICAgICAgICBkYXRhLXNsb3Q9XCJhdWlfYXNzaXN0YW50LW1lc3NhZ2UtZm9vdGVyXCJcbiAgICAgICAgY2xhc3NOYW1lPXtjbihcIm1zLTIgZmxleCBpdGVtcy1jZW50ZXJcIiwgQUNUSU9OX0JBUl9IRUlHSFQpfVxuICAgICAgPlxuICAgICAgICA8QnJhbmNoUGlja2VyIC8+XG4gICAgICAgIDxBc3Npc3RhbnRBY3Rpb25CYXIgLz5cbiAgICAgIDwvZGl2PlxuICAgIDwvTWVzc2FnZVByaW1pdGl2ZS5Sb290PlxuICApO1xufTtcblxuY29uc3QgQXNzaXN0YW50QWN0aW9uQmFyOiBGQyA9ICgpID0+IHtcbiAgY29uc3QgZmFpbGVkID0gdXNlQXVpU3RhdGUoKHMpID0+IHMubWVzc2FnZS5zdGF0dXM/LnR5cGUgPT09IFwiaW5jb21wbGV0ZVwiICYmIHMubWVzc2FnZS5zdGF0dXMucmVhc29uID09PSBcImVycm9yXCIpO1xuICByZXR1cm4gKFxuICAgIDxBY3Rpb25CYXJQcmltaXRpdmUuUm9vdFxuICAgICAgaGlkZVdoZW5SdW5uaW5nXG4gICAgICBhdXRvaGlkZT1cIm5vdC1sYXN0XCJcbiAgICAgIGNsYXNzTmFtZT1cImF1aS1hc3Npc3RhbnQtYWN0aW9uLWJhci1yb290IHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBhbmltYXRlLWluIGZhZGUtaW4gY29sLXN0YXJ0LTMgcm93LXN0YXJ0LTIgLW1zLTEgZmxleCBnYXAtMSBkdXJhdGlvbi0yMDBcIlxuICAgID5cbiAgICAgIDxBY3Rpb25CYXJQcmltaXRpdmUuQ29weSBhc0NoaWxkPlxuICAgICAgICA8VG9vbHRpcEljb25CdXR0b24gdG9vbHRpcD1cIkNvcHlcIj5cbiAgICAgICAgICA8QXVpSWYgY29uZGl0aW9uPXsocykgPT4gcy5tZXNzYWdlLmlzQ29waWVkfT5cbiAgICAgICAgICAgIDxDaGVja0ljb24gY2xhc3NOYW1lPVwiYW5pbWF0ZS1pbiB6b29tLWluLTUwIGZhZGUtaW4gZHVyYXRpb24tMjAwIGVhc2Utb3V0XCIgLz5cbiAgICAgICAgICA8L0F1aUlmPlxuICAgICAgICAgIDxBdWlJZiBjb25kaXRpb249eyhzKSA9PiAhcy5tZXNzYWdlLmlzQ29waWVkfT5cbiAgICAgICAgICAgIDxDb3B5SWNvbiBjbGFzc05hbWU9XCJhbmltYXRlLWluIHpvb20taW4tNzUgZmFkZS1pbiBkdXJhdGlvbi0xNTBcIiAvPlxuICAgICAgICAgIDwvQXVpSWY+XG4gICAgICAgIDwvVG9vbHRpcEljb25CdXR0b24+XG4gICAgICA8L0FjdGlvbkJhclByaW1pdGl2ZS5Db3B5PlxuICAgICAgPEF1aUlmIGNvbmRpdGlvbj17KHMpID0+IHMudGhyZWFkLmNhcGFiaWxpdGllcy5mZWVkYmFja30+XG4gICAgICAgIDxBY3Rpb25CYXJQcmltaXRpdmUuRmVlZGJhY2tQb3NpdGl2ZSBhc0NoaWxkPlxuICAgICAgICAgIDxUb29sdGlwSWNvbkJ1dHRvblxuICAgICAgICAgICAgdG9vbHRpcD1cIkhlbHBmdWxcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZGF0YS1bc3VibWl0dGVkPXRydWVdOmJnLWFjY2VudCBkYXRhLVtzdWJtaXR0ZWQ9dHJ1ZV06dGV4dC1hY2NlbnQtZm9yZWdyb3VuZFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFRodW1ic1VwSWNvbiAvPlxuICAgICAgICAgIDwvVG9vbHRpcEljb25CdXR0b24+XG4gICAgICAgIDwvQWN0aW9uQmFyUHJpbWl0aXZlLkZlZWRiYWNrUG9zaXRpdmU+XG4gICAgICAgIDxBY3Rpb25CYXJQcmltaXRpdmUuRmVlZGJhY2tOZWdhdGl2ZSBhc0NoaWxkPlxuICAgICAgICAgIDxUb29sdGlwSWNvbkJ1dHRvblxuICAgICAgICAgICAgdG9vbHRpcD1cIk5vdCBoZWxwZnVsXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImRhdGEtW3N1Ym1pdHRlZD10cnVlXTpiZy1hY2NlbnQgZGF0YS1bc3VibWl0dGVkPXRydWVdOnRleHQtYWNjZW50LWZvcmVncm91bmRcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxUaHVtYnNEb3duSWNvbiAvPlxuICAgICAgICAgIDwvVG9vbHRpcEljb25CdXR0b24+XG4gICAgICAgIDwvQWN0aW9uQmFyUHJpbWl0aXZlLkZlZWRiYWNrTmVnYXRpdmU+XG4gICAgICA8L0F1aUlmPlxuICAgICAgPEFjdGlvbkJhclByaW1pdGl2ZS5SZWxvYWQgYXNDaGlsZD5cbiAgICAgICAgPFRvb2x0aXBJY29uQnV0dG9uIHRvb2x0aXA9e2ZhaWxlZCA/IFwiUmV0cnkgcmVzcG9uc2VcIiA6IFwiUmVmcmVzaFwifT5cbiAgICAgICAgICA8UmVmcmVzaEN3SWNvbiAvPlxuICAgICAgICA8L1Rvb2x0aXBJY29uQnV0dG9uPlxuICAgICAgPC9BY3Rpb25CYXJQcmltaXRpdmUuUmVsb2FkPlxuICAgICAgPEFjdGlvbkJhck1vcmVQcmltaXRpdmUuUm9vdD5cbiAgICAgICAgPEFjdGlvbkJhck1vcmVQcmltaXRpdmUuVHJpZ2dlciBhc0NoaWxkPlxuICAgICAgICAgIDxUb29sdGlwSWNvbkJ1dHRvblxuICAgICAgICAgICAgdG9vbHRpcD1cIk1vcmVcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZGF0YS1bc3RhdGU9b3Blbl06YmctYWNjZW50XCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8TW9yZUhvcml6b250YWxJY29uIC8+XG4gICAgICAgICAgPC9Ub29sdGlwSWNvbkJ1dHRvbj5cbiAgICAgICAgPC9BY3Rpb25CYXJNb3JlUHJpbWl0aXZlLlRyaWdnZXI+XG4gICAgICAgIDxBY3Rpb25CYXJNb3JlUHJpbWl0aXZlLkNvbnRlbnRcbiAgICAgICAgICBzaWRlPVwiYm90dG9tXCJcbiAgICAgICAgICBhbGlnbj1cInN0YXJ0XCJcbiAgICAgICAgICBzaWRlT2Zmc2V0PXs2fVxuICAgICAgICAgIGNsYXNzTmFtZT1cImF1aS1hY3Rpb24tYmFyLW1vcmUtY29udGVudCBiZy1wb3BvdmVyIHRleHQtcG9wb3Zlci1mb3JlZ3JvdW5kIGRhdGEtW3N0YXRlPW9wZW5dOmZhZGUtaW4tMCBkYXRhLVtzdGF0ZT1vcGVuXTp6b29tLWluLTk1IGRhdGEtW3N0YXRlPW9wZW5dOmFuaW1hdGUtaW4gZGF0YS1bc3RhdGU9Y2xvc2VkXTpmYWRlLW91dC0wIGRhdGEtW3N0YXRlPWNsb3NlZF06em9vbS1vdXQtOTUgZGF0YS1bc3RhdGU9Y2xvc2VkXTphbmltYXRlLW91dCBkYXRhLVtzaWRlPWJvdHRvbV06c2xpZGUtaW4tZnJvbS10b3AtMiBkYXRhLVtzaWRlPWxlZnRdOnNsaWRlLWluLWZyb20tcmlnaHQtMiBkYXRhLVtzaWRlPXJpZ2h0XTpzbGlkZS1pbi1mcm9tLWxlZnQtMiBkYXRhLVtzaWRlPXRvcF06c2xpZGUtaW4tZnJvbS1ib3R0b20tMiB6LTUwIG1pbi13LVs4cmVtXSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBib3JkZXIgcC0xLjVcIlxuICAgICAgICA+XG4gICAgICAgICAgPEFjdGlvbkJhclByaW1pdGl2ZS5FeHBvcnRNYXJrZG93biBhc0NoaWxkPlxuICAgICAgICAgICAgPEFjdGlvbkJhck1vcmVQcmltaXRpdmUuSXRlbSBjbGFzc05hbWU9XCJhdWktYWN0aW9uLWJhci1tb3JlLWl0ZW0gaG92ZXI6YmctYWNjZW50IGhvdmVyOnRleHQtYWNjZW50LWZvcmVncm91bmQgZm9jdXM6YmctYWNjZW50IGZvY3VzOnRleHQtYWNjZW50LWZvcmVncm91bmQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc20gb3V0bGluZS1ub25lIHNlbGVjdC1ub25lXCI+XG4gICAgICAgICAgICAgIDxEb3dubG9hZEljb24gY2xhc3NOYW1lPVwic2l6ZS00XCIgLz5cbiAgICAgICAgICAgICAgRXhwb3J0IGFzIE1hcmtkb3duXG4gICAgICAgICAgICA8L0FjdGlvbkJhck1vcmVQcmltaXRpdmUuSXRlbT5cbiAgICAgICAgICA8L0FjdGlvbkJhclByaW1pdGl2ZS5FeHBvcnRNYXJrZG93bj5cbiAgICAgICAgPC9BY3Rpb25CYXJNb3JlUHJpbWl0aXZlLkNvbnRlbnQ+XG4gICAgICA8L0FjdGlvbkJhck1vcmVQcmltaXRpdmUuUm9vdD5cbiAgICA8L0FjdGlvbkJhclByaW1pdGl2ZS5Sb290PlxuICApO1xufTtcblxuY29uc3QgTWVzc2FnZUZpbGU6IEZpbGVNZXNzYWdlUGFydENvbXBvbmVudCA9IChwYXJ0KSA9PiB7XG4gIGNvbnN0IGltYWdlID0gcGFydC5taW1lVHlwZS50b0xvd2VyQ2FzZSgpLnN0YXJ0c1dpdGgoXCJpbWFnZS9cIilcbiAgICA/IGdldEZpbGVIcmVmKHBhcnQuZGF0YSwgcGFydC5taW1lVHlwZSwgcGFydC5zb3VyY2VUeXBlKVxuICAgIDogbnVsbDtcbiAgaWYgKCFpbWFnZSkgcmV0dXJuIDxGaWxlIHsuLi5wYXJ0fSAvPjtcbiAgcmV0dXJuIChcbiAgICA8SW1hZ2VcbiAgICAgIHR5cGU9XCJpbWFnZVwiXG4gICAgICBpbWFnZT17aW1hZ2V9XG4gICAgICBzdGF0dXM9e3BhcnQuc3RhdHVzfVxuICAgICAgey4uLihwYXJ0LmZpbGVuYW1lICE9PSB1bmRlZmluZWQgJiYgeyBmaWxlbmFtZTogcGFydC5maWxlbmFtZSB9KX1cbiAgICAvPlxuICApO1xufTtcblxuY29uc3QgVXNlckZpbGVQYXJ0OiBGaWxlTWVzc2FnZVBhcnRDb21wb25lbnQgPSAocGFydCkgPT4gKFxuICA8ZGl2IGRhdGEtc2xvdD1cImF1aV91c2VyLW1lc3NhZ2UtZmlsZVwiIGNsYXNzTmFtZT1cInB5LTFcIj5cbiAgICA8TWVzc2FnZUZpbGUgey4uLnBhcnR9IC8+XG4gIDwvZGl2PlxuKTtcblxuY29uc3QgVXNlckltYWdlUGFydDogSW1hZ2VNZXNzYWdlUGFydENvbXBvbmVudCA9IChwYXJ0KSA9PiAoXG4gIDxkaXYgZGF0YS1zbG90PVwiYXVpX3VzZXItbWVzc2FnZS1pbWFnZVwiIGNsYXNzTmFtZT1cInB5LTFcIj5cbiAgICA8SW1hZ2Ugey4uLnBhcnR9IC8+XG4gIDwvZGl2PlxuKTtcblxuY29uc3QgVXNlck1lc3NhZ2U6IEZDID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxNZXNzYWdlUHJpbWl0aXZlLlJvb3RcbiAgICAgIGRhdGEtc2xvdD1cImF1aV91c2VyLW1lc3NhZ2Utcm9vdFwiXG4gICAgICBjbGFzc05hbWU9XCJmYWRlLWluIHNsaWRlLWluLWZyb20tYm90dG9tLTEgYW5pbWF0ZS1pbiBncmlkIGF1dG8tcm93cy1hdXRvIGdyaWQtY29scy1bbWlubWF4KDcycHgsMWZyKV9hdXRvXSBjb250ZW50LXN0YXJ0IGdhcC15LTIgcHgtMiBkdXJhdGlvbi0xNTAgW2NvbnRhaW4taW50cmluc2ljLXNpemU6YXV0b18yMDBweF0gW2NvbnRlbnQtdmlzaWJpbGl0eTphdXRvXSBbJjp3aGVyZSg+KildOmNvbC1zdGFydC0yXCJcbiAgICAgIGRhdGEtcm9sZT1cInVzZXJcIlxuICAgID5cbiAgICAgIDxVc2VyTWVzc2FnZUF0dGFjaG1lbnRzIC8+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXVpLXVzZXItbWVzc2FnZS1jb250ZW50LXdyYXBwZXIgcmVsYXRpdmUgY29sLXN0YXJ0LTIgbWluLXctMFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1aS11c2VyLW1lc3NhZ2UtY29udGVudCBwZWVyIGJnLW11dGVkIHRleHQtZm9yZWdyb3VuZCByb3VuZGVkLSgtLWNvbXBvc2VyLXJhZGl1cykgcHgtNCBweS0yIHdyYXAtYnJlYWstd29yZCBlbXB0eTpoaWRkZW5cIj5cbiAgICAgICAgICA8TWVzc2FnZVByaW1pdGl2ZS5QYXJ0c1xuICAgICAgICAgICAgY29tcG9uZW50cz17eyBGaWxlOiBVc2VyRmlsZVBhcnQsIEltYWdlOiBVc2VySW1hZ2VQYXJ0IH19XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXVpLXVzZXItYWN0aW9uLWJhci13cmFwcGVyIGFic29sdXRlIHN0YXJ0LTAgdG9wLTEvMiAtdHJhbnNsYXRlLXgtZnVsbCAtdHJhbnNsYXRlLXktMS8yIHBlLTIgcGVlci1lbXB0eTpoaWRkZW4gcnRsOnRyYW5zbGF0ZS14LWZ1bGxcIj5cbiAgICAgICAgICA8VXNlckFjdGlvbkJhciAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8QnJhbmNoUGlja2VyXG4gICAgICAgIGRhdGEtc2xvdD1cImF1aV91c2VyLWJyYW5jaC1waWNrZXJcIlxuICAgICAgICBjbGFzc05hbWU9XCJjb2wtc3Bhbi1mdWxsIGNvbC1zdGFydC0xIC1tZS0xIGp1c3RpZnktZW5kXCJcbiAgICAgIC8+XG4gICAgPC9NZXNzYWdlUHJpbWl0aXZlLlJvb3Q+XG4gICk7XG59O1xuXG5jb25zdCBVc2VyQWN0aW9uQmFyOiBGQyA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8QWN0aW9uQmFyUHJpbWl0aXZlLlJvb3RcbiAgICAgIGhpZGVXaGVuUnVubmluZ1xuICAgICAgYXV0b2hpZGU9XCJub3QtbGFzdFwiXG4gICAgICBjbGFzc05hbWU9XCJhdWktdXNlci1hY3Rpb24tYmFyLXJvb3QgZmxleCBmbGV4LWNvbCBpdGVtcy1lbmRcIlxuICAgID5cbiAgICAgIDxBY3Rpb25CYXJQcmltaXRpdmUuRWRpdCBhc0NoaWxkPlxuICAgICAgICA8VG9vbHRpcEljb25CdXR0b24gdG9vbHRpcD1cIkVkaXRcIiBjbGFzc05hbWU9XCJhdWktdXNlci1hY3Rpb24tZWRpdFwiPlxuICAgICAgICAgIDxQZW5jaWxJY29uIC8+XG4gICAgICAgIDwvVG9vbHRpcEljb25CdXR0b24+XG4gICAgICA8L0FjdGlvbkJhclByaW1pdGl2ZS5FZGl0PlxuICAgIDwvQWN0aW9uQmFyUHJpbWl0aXZlLlJvb3Q+XG4gICk7XG59O1xuXG5jb25zdCBFZGl0Q29tcG9zZXI6IEZDID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxNZXNzYWdlUHJpbWl0aXZlLlJvb3RcbiAgICAgIGRhdGEtc2xvdD1cImF1aV9lZGl0LWNvbXBvc2VyLXdyYXBwZXJcIlxuICAgICAgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBweC0yIFtjb250YWluLWludHJpbnNpYy1zaXplOmF1dG9fMjAwcHhdIFtjb250ZW50LXZpc2liaWxpdHk6YXV0b11cIlxuICAgID5cbiAgICAgIDxDb21wb3NlclByaW1pdGl2ZS5Sb290IGNsYXNzTmFtZT1cImF1aS1lZGl0LWNvbXBvc2VyLXJvb3QgYm9yZGVyLWZvcmVncm91bmQvMTAgZm9jdXMtd2l0aGluOmJvcmRlci1mb3JlZ3JvdW5kLzI1IG1zLWF1dG8gZmxleCB3LWZ1bGwgbWF4LXctWzg1JV0gY3Vyc29yLXRleHQgZmxleC1jb2wgcm91bmRlZC0oLS1jb21wb3Nlci1yYWRpdXMpIGJvcmRlciBiZy0oLS1jb21wb3Nlci1iZykgdHJhbnNpdGlvbi1bYm9yZGVyLWNvbG9yXVwiPlxuICAgICAgICA8Q29tcG9zZXJQcmltaXRpdmUuSW5wdXRcbiAgICAgICAgICBjbGFzc05hbWU9XCJhdWktZWRpdC1jb21wb3Nlci1pbnB1dCB0ZXh0LWZvcmVncm91bmQgbWluLWgtMTQgdy1mdWxsIHJlc2l6ZS1ub25lIGJnLXRyYW5zcGFyZW50IHB4LTQgcHQtMyBwYi0xIHRleHQtYmFzZSBvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgIGF1dG9Gb2N1c1xuICAgICAgICAvPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1aS1lZGl0LWNvbXBvc2VyLWZvb3RlciBteC0yLjUgbWItMi41IGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgc2VsZi1lbmRcIj5cbiAgICAgICAgICA8Q29tcG9zZXJQcmltaXRpdmUuQ2FuY2VsIGFzQ2hpbGQ+XG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIHNpemU9XCJzbVwiIGNsYXNzTmFtZT1cImgtOCBweC0zXCI+XG4gICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPC9Db21wb3NlclByaW1pdGl2ZS5DYW5jZWw+XG4gICAgICAgICAgPENvbXBvc2VyUHJpbWl0aXZlLlNlbmQgYXNDaGlsZD5cbiAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgY2xhc3NOYW1lPVwiaC04IHB4LTNcIj5cbiAgICAgICAgICAgICAgVXBkYXRlXG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8L0NvbXBvc2VyUHJpbWl0aXZlLlNlbmQ+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9Db21wb3NlclByaW1pdGl2ZS5Sb290PlxuICAgIDwvTWVzc2FnZVByaW1pdGl2ZS5Sb290PlxuICApO1xufTtcblxuY29uc3QgQnJhbmNoUGlja2VyOiBGQzxCcmFuY2hQaWNrZXJQcmltaXRpdmUuUm9vdC5Qcm9wcz4gPSAoe1xuICBjbGFzc05hbWUsXG4gIC4uLnJlc3Rcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8QnJhbmNoUGlja2VyUHJpbWl0aXZlLlJvb3RcbiAgICAgIGhpZGVXaGVuU2luZ2xlQnJhbmNoXG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcImF1aS1icmFuY2gtcGlja2VyLXJvb3QgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIC1tcy0yIG1lLTIgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHRleHQteHNcIixcbiAgICAgICAgY2xhc3NOYW1lLFxuICAgICAgKX1cbiAgICAgIHsuLi5yZXN0fVxuICAgID5cbiAgICAgIDxCcmFuY2hQaWNrZXJQcmltaXRpdmUuUHJldmlvdXMgYXNDaGlsZD5cbiAgICAgICAgPFRvb2x0aXBJY29uQnV0dG9uIHRvb2x0aXA9XCJQcmV2aW91c1wiPlxuICAgICAgICAgIDxDaGV2cm9uTGVmdEljb24gLz5cbiAgICAgICAgPC9Ub29sdGlwSWNvbkJ1dHRvbj5cbiAgICAgIDwvQnJhbmNoUGlja2VyUHJpbWl0aXZlLlByZXZpb3VzPlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYXVpLWJyYW5jaC1waWNrZXItc3RhdGUgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgPEJyYW5jaFBpY2tlclByaW1pdGl2ZS5OdW1iZXIgLz4gLyA8QnJhbmNoUGlja2VyUHJpbWl0aXZlLkNvdW50IC8+XG4gICAgICA8L3NwYW4+XG4gICAgICA8QnJhbmNoUGlja2VyUHJpbWl0aXZlLk5leHQgYXNDaGlsZD5cbiAgICAgICAgPFRvb2x0aXBJY29uQnV0dG9uIHRvb2x0aXA9XCJOZXh0XCI+XG4gICAgICAgICAgPENoZXZyb25SaWdodEljb24gLz5cbiAgICAgICAgPC9Ub29sdGlwSWNvbkJ1dHRvbj5cbiAgICAgIDwvQnJhbmNoUGlja2VyUHJpbWl0aXZlLk5leHQ+XG4gICAgPC9CcmFuY2hQaWNrZXJQcmltaXRpdmUuUm9vdD5cbiAgKTtcbn07XG4iXX0=