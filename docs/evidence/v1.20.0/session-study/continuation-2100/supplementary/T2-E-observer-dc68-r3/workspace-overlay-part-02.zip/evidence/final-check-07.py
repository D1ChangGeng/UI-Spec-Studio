from playwright.sync_api import sync_playwright
from pathlib import Path
import subprocess,time,signal,json
r=Path('/workspace/scratch/dc68edd00fe1/ui-study/w15');o=r/'evidence/final-07';o.mkdir(exist_ok=True)
server=subprocess.Popen(['npm','run','dev','--','--host','127.0.0.1','--port','4415'],cwd=r/'app',stdout=(o/'server.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True);time.sleep(1.5)
logs=[]
files=[{'name':'notes.txt','mimeType':'text/plain','buffer':b''},{'name':'城市出行访谈摘要_2026-10-31_final-revised-notes.txt','mimeType':'text/plain','buffer':b''},{'name':'accessibility-research-interviews-synthesis-final-version.txt','mimeType':'text/plain','buffer':b''}]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 for w,h in [(1440,900),(1280,600),(390,844)]:
  for theme,lang in [('light','en'),('dark','zh')]:
   page=b.new_page(viewport={'width':w,'height':h});page.set_default_timeout(5000);errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
   page.goto(f'http://127.0.0.1:4415/?theme={theme}&lang={lang}');page.wait_for_timeout(300);page.evaluate('document.fonts.ready');name=f'{w}x{h}-{theme}-{lang}'
   page.screenshot(path=str(o/f'{name}-initial.png'))
   inp=page.get_by_role('textbox',name='Message input',exact=True);inp.fill('Question one\n第二行：研究资料\nCompare evidence and interpretation\n第四行：阅读连续性\nKeep filenames visible\nSixth line')
   with page.expect_file_chooser() as fc:page.get_by_role('button',name='Add Attachment',exact=True).click()
   fc.value.set_files(files);page.wait_for_timeout(250);page.screenshot(path=str(o/f'{name}-expanded.png'))
   chip=page.locator('.aui-composer-attachments [tabindex="0"]').nth(1);page.keyboard.press('Tab');chip.focus();page.wait_for_timeout(500)
   disclosure=page.get_by_role('tooltip');assert disclosure.is_visible();assert files[1]['name'] in disclosure.inner_text()
   page.screenshot(path=str(o/f'{name}-disclosure.png'))
   page.get_by_role('button',name='Remove notes.txt',exact=True).click();page.wait_for_timeout(100)
   assert page.locator('.aui-composer-attachments [tabindex="0"]').count()==2
   assert inp.evaluate('(e)=>e===document.activeElement')
   boxes={'composer':page.locator('[data-slot=aui_composer-shell]').bounding_box(),'input':inp.bounding_box(),'viewport':page.locator('[data-slot=aui_thread-viewport]').bounding_box()}
   assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
   logs.append({'condition':name,'fullNameKeyboardDisclosure':True,'removeExactItem':True,'removeReturnsFocus':True,'noDocumentHorizontalOverflow':True,'boxes':boxes,'pageErrors':errs})
   page.close()
 # Full deterministic fail/retry, stop, continued input and duplicate filename identity.
 page=b.new_page(viewport={'width':1280,'height':600});page.set_default_timeout(6000);page.goto('http://127.0.0.1:4415/?theme=light&lang=en');page.wait_for_timeout(300)
 inp=page.get_by_role('textbox',name='Message input',exact=True)
 inp.fill('[fail] verify recovery');page.get_by_role('button',name='Send message',exact=True).click();page.locator('.aui-message-error-message').wait_for();page.screenshot(path=str(o/'failure.png'))
 page.get_by_role('button',name='Retry response',exact=True).last.click();page.get_by_role('button',name='Stop generating',exact=True).wait_for();page.wait_for_timeout(300);page.get_by_role('button',name='Stop generating',exact=True).click();page.wait_for_timeout(150)
 assert inp.evaluate('(e)=>e===document.activeElement');text=page.locator('[data-role=assistant]').last.inner_text();page.wait_for_timeout(350);assert text==page.locator('[data-role=assistant]').last.inner_text();assert page.locator('.aui-message-error-message').count()==0
 inp.fill('Continue after stopping');page.get_by_role('button',name='Send message',exact=True).click();page.get_by_role('button',name='Stop generating',exact=True).wait_for();page.wait_for_timeout(250);page.get_by_role('button',name='Stop generating',exact=True).click()
 page.screenshot(path=str(o/'continued-after-stop.png'))
 logs.append({'failureAppeared':True,'retryStarted':True,'retryClearedError':True,'stopTextStable':True,'continuedQuestionStarted':True})
 with page.expect_file_chooser() as fc:page.get_by_role('button',name='Add Attachment',exact=True).click()
 fc.value.set_files([files[0],files[0]]);page.wait_for_timeout(200);assert page.locator('.aui-composer-attachments [tabindex="0"]').count()==2
 page.get_by_role('button',name='Remove notes.txt',exact=True).first.click();assert page.locator('.aui-composer-attachments [tabindex="0"]').count()==1
 logs.append({'duplicateFilenameRemovalByRuntimeContext':True})
 b.close()
(o/'checks.json').write_text(json.dumps(logs,ensure_ascii=False,indent=2));print(json.dumps(logs,ensure_ascii=False,indent=2))
os.killpg(server.pid,signal.SIGTERM)
