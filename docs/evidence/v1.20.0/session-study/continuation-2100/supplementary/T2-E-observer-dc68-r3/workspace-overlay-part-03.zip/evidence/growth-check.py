from pathlib import Path
from playwright.sync_api import sync_playwright
import subprocess,time,json,os,signal
r=Path('/workspace/scratch/dc68edd00fe1/ui-study/w15');o=r/'evidence/final-growth';o.mkdir(exist_ok=True)
s=subprocess.Popen(['npm','run','dev','--','--host','127.0.0.1','--port','55116','--strictPort'],cwd=r/'app',stdout=(o/'server.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True);time.sleep(1.3)
logs=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox']);page=b.new_page(viewport={'width':1280,'height':600});page.goto('http://127.0.0.1:55116/?theme=dark&lang=zh');inp=page.get_by_role('textbox',name='Message input',exact=True);vp=page.locator('[data-slot=aui_thread-viewport]');inp.fill('请比较研究记录');page.get_by_role('button',name='Send message',exact=True).click();page.wait_for_timeout(300);vp.hover();page.mouse.wheel(0,-1500);page.wait_for_timeout(150)
 def snap(n):
  page.screenshot(path=str(o/f'{n}.png'));logs.append({'name':n,'monotonic':time.monotonic(),'scrollTop':vp.evaluate('(e)=>e.scrollTop'),'composer':page.locator('[data-slot=aui_composer-shell]').bounding_box(),'focus':page.evaluate('document.activeElement.getAttribute("aria-label")')});(o/'log.json').write_text(json.dumps(logs,indent=2))
 snap('01-away');inp.fill('\n'.join('Draft研究资料 '+str(i) for i in range(6)));snap('02-six-lines')
 with page.expect_file_chooser() as fc:page.get_by_role('button',name='Add Attachment',exact=True).click()
 fc.value.set_files([{'name':f'城市访谈_{i}_final-revised-notes.txt','mimeType':'text/plain','buffer':b''} for i in range(5)]);page.wait_for_timeout(150);snap('03-five-files')
 page.get_by_role('button',name='Stop generating',exact=True).click();page.wait_for_timeout(150);snap('04-stop-away');page.wait_for_timeout(250);snap('05-stop-hold')
 assert max(v['scrollTop'] for v in logs)-min(v['scrollTop'] for v in logs)<2
 assert logs[3]['focus']=='Message input'
 b.close()
os.killpg(s.pid,signal.SIGTERM);print(json.dumps(logs,indent=2))
