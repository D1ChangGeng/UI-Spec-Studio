import os,subprocess,time,json,hashlib,pathlib,traceback
from playwright.sync_api import sync_playwright
root=pathlib.Path.cwd(); ev=root/'evidence/observer'; env=os.environ.copy(); env['FONTCONFIG_FILE']='/tmp/ui-spec-fonts/fonts.conf'
log=[]
serverlog=open(ev/'vite.log','w'); server=subprocess.Popen(['npm','run','dev','--','--host','127.0.0.1','--port','4515','--strictPort'],cwd=root/'app',env=env,stdout=serverlog,stderr=subprocess.STDOUT)
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,env=env,args=['--no-sandbox'])
  page=browser.new_page(viewport={'width':1280,'height':600},device_scale_factor=1,locale='zh-CN',color_scheme='dark')
  for i in range(50):
   try: page.goto('http://127.0.0.1:4515/?theme=dark&lang=zh',timeout=2000); break
   except: time.sleep(.2)
  page.wait_for_timeout(1200); page.evaluate('document.fonts.ready')
  def snap(name):
   before=time.time(); state=page.evaluate('''() => {let v=document.querySelector('[data-slot="aui_thread-viewport"]'),a=document.activeElement,t=document.querySelector('textarea'),c=document.querySelector('.aui-composer-root'); let r=e=>e?Object.fromEntries(['x','y','width','height'].map(k=>[k,e.getBoundingClientRect()[k]])):null;return {scrollTop:v.scrollTop,scrollHeight:v.scrollHeight,clientHeight:v.clientHeight,active:{tag:a.tagName,label:a.getAttribute('aria-label'),class:a.className},textarea:r(t),composer:r(c),assistantText:[...document.querySelectorAll('[data-role="assistant"]')].map(e=>e.innerText.length),buttons:[...document.querySelectorAll('button')].filter(e=>e.getBoundingClientRect().width).map(e=>({name:e.getAttribute('aria-label')||e.innerText,disabled:e.disabled}))}}''');page.screenshot(path=str(ev/(name+'.png'))); log.append({'name':name,'captureStart':before,'captureEnd':time.time(),'state':state}); print(name,json.dumps(state,ensure_ascii=False),flush=True)
  snap('01-initial')
  t=page.locator('textarea').last; t.fill('请解释如何保持阅读位置。');t.press('Enter');page.wait_for_timeout(1300);snap('02-stream-top')
  page.locator('[data-slot="aui_thread-viewport"]').hover();page.mouse.wheel(0,-550);page.wait_for_timeout(450);snap('03-scroll-away');page.wait_for_timeout(1800);snap('04-scroll-away-growth')
  # Return control uses upstream accessible name.
  names=page.get_by_role('button',name='Scroll to bottom',exact=True)
  if names.count():names.click();page.wait_for_timeout(700);snap('05-return-latest')
  else:print('RETURN BUTTON MISSING',flush=True)
  stop=page.get_by_role('button',name='Stop generating',exact=True)
  if stop.count():stop.click();page.wait_for_timeout(250);snap('06-stopped');page.wait_for_timeout(900);snap('07-stopped-hold')
  t.fill('请解释如何保持阅读位置。');t.press('Enter');page.wait_for_timeout(800);snap('08-repeat-question');
  stop=page.get_by_role('button',name='Stop generating',exact=True)
  if stop.count():stop.click()
  t.fill('测试失败恢复 [fail]');t.press('Enter');page.wait_for_timeout(2800);snap('09-failed')
  ref=page.get_by_role('button',name='Refresh',exact=True).last
  ref.click();page.wait_for_timeout(1000);snap('10-retry');
  stop=page.get_by_role('button',name='Stop generating',exact=True)
  if stop.count():stop.click()
  # Return to a prior reading paragraph before draft expansion.
  page.locator('[data-slot="aui_thread-viewport"]').hover();page.mouse.wheel(0,-450);page.wait_for_timeout(500);snap('11-reading-before-expand')
  t.fill('第一行研究问题\n第二行关于城市交通\n第三行 mixed language question\n第四行保持阅读位置\n第五行附件和输入\n第六行补充说明');page.wait_for_timeout(400);snap('12-six-line')
  files=[{'name':'notes.txt','mimeType':'text/plain','buffer':b'fixture'}]+[{'name':f'城市出行访谈摘要_2026-10-31_final-revised-notes-{i}.txt','mimeType':'text/plain','buffer':b'fixture'} for i in range(4)]
  with page.expect_file_chooser() as fc:page.get_by_role('button',name='Add Attachment',exact=False).click()
  fc.value.set_files(files);page.wait_for_timeout(600);snap('13-attachments')
  # Full-name disclosure on hover.
  chip=page.get_by_text('城市出行访谈摘要_2026-10-31_final-revised-notes-0.txt',exact=False).first
  if chip.count():chip.hover();page.wait_for_timeout(700);snap('14-tooltip')
  t.focus(); t.fill('短问题');page.wait_for_timeout(400);snap('15-collapse')
  browser.close()
except Exception:
 traceback.print_exc()
finally:
 (ev/'states.json').write_text(json.dumps(log,ensure_ascii=False,indent=2))
 (ev/'source-digests.json').write_text(json.dumps({str(x.relative_to(root)):hashlib.sha256(x.read_bytes()).hexdigest() for x in (root/'app/src').rglob('*') if x.is_file()},indent=2))
 server.terminate()
 try: server.wait(timeout=5)
 except:server.kill()
 serverlog.close()
