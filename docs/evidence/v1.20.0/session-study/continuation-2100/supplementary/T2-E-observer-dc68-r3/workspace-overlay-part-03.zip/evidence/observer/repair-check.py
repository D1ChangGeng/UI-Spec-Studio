import os,subprocess,time,json,hashlib,pathlib,traceback
from playwright.sync_api import sync_playwright
root=pathlib.Path.cwd(); ev=root/'evidence/observer'; env=os.environ.copy(); env['FONTCONFIG_FILE']='/tmp/ui-spec-fonts/fonts.conf'
log=[]
serverlog=open(ev/'vite.log','w'); server=subprocess.Popen(['npm','run','dev','--','--host','127.0.0.1','--port','4515','--strictPort'],cwd=root/'app',env=env,stdout=serverlog,stderr=subprocess.STDOUT)
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,env=env,args=['--no-sandbox'])
  page=browser.new_page(viewport={'width':1280,'height':600},device_scale_factor=1,locale='zh-CN',color_scheme='dark')
  for i in range(50):
   try: page.goto('http://127.0.0.1:4515/?theme=dark&lang=zh',timeout=2000); break
   except: time.sleep(.2)
  page.wait_for_timeout(1200); page.evaluate('document.fonts.ready')
  def snap(name):
   before=time.time(); state=page.evaluate('''() => {let v=document.querySelector('[data-slot="aui_thread-viewport"]'),a=document.activeElement,t=document.querySelector('textarea'),c=document.querySelector('.aui-composer-root'); let r=e=>e?Object.fromEntries(['x','y','width','height'].map(k=>[k,e.getBoundingClientRect()[k]])):null;return {scrollTop:v.scrollTop,scrollHeight:v.scrollHeight,clientHeight:v.clientHeight,active:{tag:a.tagName,label:a.getAttribute('aria-label'),class:a.className},textarea:r(t),composer:r(c),assistantText:[...document.querySelectorAll('[data-role="assistant"]')].map(e=>e.innerText.length),buttons:[...document.querySelectorAll('button')].filter(e=>e.getBoundingClientRect().width).map(e=>({name:e.getAttribute('aria-label')||e.innerText,disabled:e.disabled}))}}''');page.screenshot(path=str(ev/(name+'.png'))); log.append({'name':name,'captureStart':before,'captureEnd':time.time(),'state':state}); print(name,json.dumps(state,ensure_ascii=False),flush=True)
  t=page.get_by_role('textbox',name='Message input',exact=True)
  t.fill('停止键盘测试');t.press('Enter');page.wait_for_timeout(350);snap('23-before-stop-repair')
  stop=page.get_by_role('button',name='Stop generating',exact=True);stop.focus();stop.press('Enter');page.wait_for_timeout(250);snap('24-stop-repair');page.wait_for_timeout(900);snap('25-stop-repair-hold')
  browser.close()
except Exception:
 traceback.print_exc()
finally:
 (ev/'states-repair.json').write_text(json.dumps(log,ensure_ascii=False,indent=2))
 (ev/'source-digests-repair.json').write_text(json.dumps({str(x.relative_to(root)):hashlib.sha256(x.read_bytes()).hexdigest() for x in (root/'app/src').rglob('*') if x.is_file()},indent=2))
 server.terminate()
 try: server.wait(timeout=5)
 except:server.kill()
 serverlog.close()
