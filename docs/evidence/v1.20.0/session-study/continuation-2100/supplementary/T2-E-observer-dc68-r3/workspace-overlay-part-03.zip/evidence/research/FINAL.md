# Composer and reading continuity — research report

Research scope: the coupled growing composer, file identity, streaming answer and reader-controlled position in Meridian. Product code was not changed. The complete eight common UI Spec references were read; sourcing, perceptual, temporal, evidence-map and gap-to-action guidance informed the inquiry.

## Decision-useful finding

A same-family attachment chip implementation exists at the starter's **exact pinned revision** `ff654d8156680b839774296ef644b57ab1078425`, MIT. This materially reduces the need to replace the mature composer or import a second system. Adoptable source and an original demo were acquired; the unchanged upstream demo was rendered locally and its progress, settled and removal frames were personally viewed.

The relevant exports are `ComposerAttachments` and `ComposerAttachmentChip` in:

- Original: `packages/ui/src/components/react/assistant-ui/elements/composer.tsx`
- Exact source: https://github.com/assistant-ui/assistant-ui/blob/ff654d8156680b839774296ef644b57ab1078425/packages/ui/src/components/react/assistant-ui/elements/composer.tsx
- Retained plain text: `evidence/research/composer-source.tsx`
- Original demonstration: `apps/docs/components/demo/elements/composer-attachments.tsx`; retained `composer-demo.tsx`
- Coordinated surface tokens: `packages/ui/src/components/react/assistant-ui/elements/surfaces.tsx`; retained `surface-source.tsx`
- Source API exports and paths corroborated by `github-tree.json`; exact original GitHub responses in `composer-source.json`, `composer-demo.json`, `surface-source.json`.

## Actual visual relationships

**Baseline, 1440×900 light/English:** personally viewed `baseline-initial.png`. The conversation has a bounded reading measure, quiet sidebar and header, strong answer text and a broad restrained input near the bottom. The input's attach action is visually secondary; the circular send action is separated at the right. This mature whole is a good preservation target. I did not independently operate its entire streaming journey; the parent owns baseline interaction evidence.

**Original same-family chip demo, local render, 1440×900:** personally viewed `chip-demo-progress.png`, `chip-demo-done.png`, `chip-demo-removed.png`. The demo was rendered with unchanged upstream component and demo files, using current project stylesheet and dependency tree. It occupies its source max-w-lg width at the upper left; surrounding documentation-stage centering was not reproduced. This is a source-demo render, not integrated Meridian evidence.

The chip visibly groups a 32 px icon square, filename and smaller metadata with a trailing action. Two distinct filenames can be recognized without opening a tooltip. During the sampled progress state, the image chip shows a spinner and thin blue lower progress line; trace.log already has its remove action. In the settled frame, both chips show metadata and remove actions. Operating “Remove trace.log” removes that item and leaves screenshot.png. The source attachment container wraps at the next row rather than shrinking files to squares.

This supplies visual completeness for the **attachment chip family**, not for the whole runtime composer. Its filename is `max-w-36 truncate`; therefore it improves immediate differentiation but does **not** itself guarantee full long-name disclosure. Keep the existing tooltip or another already-supported disclosure and test keyboard/touch. Metadata must reflect Meridian's filename-only adapter; do not transplant “uploading” or actual file-size claims when no such service exists.

The source's standalone `ComposerInput` is a single-line HTML input. Replacing the current runtime textarea with it would lose the requested multiline behavior. The useful adoption scope is the attachment chip/container, retaining the current runtime composer, dropzone, textarea, send/cancel and reading viewport.

## Reading mechanism and alternatives

| Source | What evidence actually establishes | Useful adoption relationship / limit |
|---|---|---|
| Existing assistant-ui Thread | Source uses `turnAnchor="top"`, sticky `ViewportFooter`, current runtime `ComposerPrimitive.Input`, and `ScrollToBottom`. Official current docs describe top anchoring and long-question clamp. | Prefer source-supported configuration before replacing scroll ownership. Verify installed pinned API. New run can intentionally reposition; manual reading during a run is a separate condition. |
| assistant-ui chip source at pinned revision | Exact code acquired; original demo locally rendered, progress/settled/removal frames viewed; remove operated. | Lowest integration and visual-family cost for visible filename identity. Full-name disclosure and wrapped-row height remain contextual trial questions. |
| Vercel AI Elements Attachments / Conversation | Official docs retrieved, including grid/inline/list variants, hover previews, media detection and use-stick-to-bottom style conversation behavior. Public render failed in this executor. | Materially different reuse scope: inline badges or metadata rows with a separate conversation mechanism. More state and dependency integration; not visually validated here. Also official site now announces migration to shadcn/ui and deprecation at end of November 2026. |
| Ant Design X Attachments / Sender | Official docs retrieved for wrap/scrollX/scrollY overflow and Sender.Header composition. Public render failed. | Explicit separate disclosure/header and overflow choices are useful counterexamples. Importing Ant's visual/token ecosystem would require a much larger composition trial; no adoption recommendation from unseen rendering. |
| stackblitz-labs/use-stick-to-bottom | Original repository found; published description explains resize-aware bottom following and exposing isAtBottom / explicit return. Not rendered here. | Behavior foundation only, not a replacement mature composer visual. Adding a second scroll owner would create avoidable integration uncertainty unless existing runtime proves inadequate. |

Official assistant-ui documentation (current, not proof of every pinned runtime detail): https://www.assistant-ui.com/docs/primitives/thread . It says top anchoring defaults autoScroll=false; new user message stays near top while reply grows below; `topAnchorMessageClamp` bounds unusually tall questions. A return button is distinct from forcing every chunk to scroll. The current source already uses this family. This reframed the research from “add an auto-scroll hook” to “preserve the existing reading policy and test it under growth.”

Further useful primary-source links:
- https://www.assistant-ui.com/elements/composer-attachments
- https://www.assistant-ui.com/elements/attachment
- https://elements.ai-sdk.dev/components/attachments
- https://elements.ai-sdk.dev/components/conversation
- https://ant-design-x.antgroup.com/components/attachments
- https://github.com/stackblitz-labs/use-stick-to-bottom

## Practical adoption path for the parent to assess

Copy/extract the exact upstream chip exports with their actual surface dependencies and notice. Retain icon size, filename/metadata hierarchy, padding, trailing slot and theme surface relationship. Map runtime attachment identity/status/removal to chip props at the runtime boundary; use stable attachment IDs rather than filenames as React/removal identity when duplicates are possible. Keep existing dialog/tooltip disclosure where needed, and retain current image behavior unless the product explicitly changes it. Integrate only after a short contextual trial with several long Chinese/English filenames.

Source `ComposerAttachments` wraps. At compact height, several rows plus a max-height textarea can consume substantial answer space. Trial the actual coupled height; a source-preserving bounded attachment region or existing overflow pattern can be considered if wrapping demonstrably crowds reading. Neither the demo nor source acquisition settles that choice.

## Evidence maturity and remaining limits

- Retained original tool returns: `web-001.json` to `web-003.json`, GitHub JSON responses and command capture folders.
- Failed public browser attempts: `observe-command-001/` and the first observation export. Successful isolated local baseline plus failed public accesses: `observe-command-002/`, `observe-initial.json`. Failures establish access limits, not absent quality.
- Local source-demo run: `chip-command-001/`; no page errors. Runnable investigation files in `local-demo/`; this is research scaffolding, not product code.
- Personally viewed images and full view_image responses: `view-*.json`.
- Temporal claim is limited to a controlled timed sampled sequence plus a real removal operation. No natural-time playback was inspected; these samples do not establish smooth animation or frame-rate quality.
- No final product design decision, formal SPEC modification, original-construction authorization or acceptance claim is made.
- Parent's integrated trial must still establish compact height, dark/Chinese and mobile fit; long/full filename disclosure; manual scroll-away during streaming; return-to-latest focus; send/stop; failure/retry; repeat-question continuity.

