import asyncio,subprocess,json,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).parent
async def main():
 s=subprocess.Popen(['node',str(ROOT.parent.parent/'app/node_modules/vite/bin/vite.js'),'--host','127.0.0.1','--port','4114'],cwd=ROOT/'local-demo',stdout=(ROOT/'chip-server.txt').open('w'),stderr=subprocess.STDOUT)
 try:
  async with async_playwright() as p:
   b=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
   page=await b.new_page(viewport={'width':1440,'height':900})
   await asyncio.sleep(1)
   errors=[]
   page.on('pageerror',lambda e:errors.append(str(e)))
   await page.goto('http://127.0.0.1:4114/',wait_until='networkidle')
   await page.wait_for_timeout(1000)
   await page.screenshot(path=str(ROOT/'chip-demo-progress.png'))
   await page.wait_for_timeout(2400)
   await page.screenshot(path=str(ROOT/'chip-demo-done.png'))
   await page.get_by_role('button',name='Remove trace.log').click()
   await page.screenshot(path=str(ROOT/'chip-demo-removed.png'))
   print(json.dumps({'errors':errors,'body':await page.locator('body').inner_text()}))
   await b.close()
 finally:s.terminate()
asyncio.run(main())
