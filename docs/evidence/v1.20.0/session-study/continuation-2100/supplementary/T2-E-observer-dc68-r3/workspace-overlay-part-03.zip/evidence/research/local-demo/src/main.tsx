import React from 'react';
import {createRoot} from 'react-dom/client';
import {ComposerAttachmentsDemo} from './Demo';
import './styles.css';
createRoot(document.getElementById('root')!).render(<ComposerAttachmentsDemo/>);
