import asyncio,json,time,os,subprocess
from pathlib import Path
from playwright.async_api import async_playwright

ROOT=Path(__file__).parent
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
  server=subprocess.Popen(['python3','-m','http.server','4113','--bind','127.0.0.1','--directory',str(ROOT.parent.parent/'app/dist')],stdout=(ROOT/'server.txt').open('w'),stderr=subprocess.STDOUT)
  await asyncio.sleep(0.8)
  async with async_playwright() as p:
    browser=await p.chromium.launch(executable_path=BROWSER,headless=True,args=['--no-sandbox'])
    page=await browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
    events=[]
    for key,url in [('baseline','http://127.0.0.1:4113/?theme=light&lang=en'),('aui-chips','https://www.assistant-ui.com/elements/composer-attachments'),('ai-elements-attachments','https://elements.ai-sdk.dev/components/attachments'),('ant-sender','https://ant-design-x.antgroup.com/components/sender')]:
      try:
        start=time.time()
        response=await page.goto(url,wait_until='domcontentloaded',timeout=30000)
        await page.wait_for_timeout(3500)
        await page.screenshot(path=str(ROOT/f'{key}-initial.png'))
        (ROOT/f'{key}-page.txt').write_text(await page.locator('body').inner_text())
        (ROOT/f'{key}-page.html').write_text(await page.content())
        events.append({'key':key,'url':url,'status':response.status if response else None,'finalUrl':page.url,'elapsed':time.time()-start,'buttons':await page.get_by_role('button').all_text_contents()})
      except Exception as e:
        events.append({'key':key,'url':url,'error':str(e)})
    (ROOT/'observe-initial.json').write_text(json.dumps(events,ensure_ascii=False,indent=2))
    print(json.dumps(events,ensure_ascii=False,indent=2))
    await browser.close()
  server.terminate()
asyncio.run(main())
