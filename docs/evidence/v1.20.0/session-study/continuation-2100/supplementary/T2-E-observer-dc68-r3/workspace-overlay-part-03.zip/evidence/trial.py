from playwright.sync_api import sync_playwright
from pathlib import Path
import json,time,subprocess
server=subprocess.Popen(["npm","run","dev","--","--host","127.0.0.1","--port","4415"],cwd="/workspace/scratch/dc68edd00fe1/ui-study/w15/app",stdout=open("/workspace/scratch/dc68edd00fe1/ui-study/w15/evidence/trial-server.log","w"),stderr=subprocess.STDOUT)
time.sleep(2)
out=Path('/workspace/scratch/dc68edd00fe1/ui-study/w15/evidence/trial');out.mkdir(exist_ok=True)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1280,'height':600},device_scale_factor=1)
 page.goto('http://127.0.0.1:4415/?theme=light&lang=en');page.wait_for_timeout(700);page.screenshot(path=str(out/'compact-initial.png'))
 page.locator('textarea[aria-label="Message input"]').fill('First question\nSecond line\n第三行：混合语言研究材料\nFourth line\nFifth line\nSixth line')
 with page.expect_file_chooser() as fc:
  page.get_by_role('button',name='Add Attachment',exact=True).click()
 fc.value.set_files([{'name':'notes.txt','mimeType':'text/plain','buffer':b''},{'name':'城市出行访谈摘要_2026-10-31_final-revised-notes.txt','mimeType':'text/plain','buffer':b''},{'name':'accessibility-research-interviews-synthesis-final-version.txt','mimeType':'text/plain','buffer':b''}])
 page.wait_for_timeout(500);page.screenshot(path=str(out/'compact-attachments.png'))
 (out/'dom.json').write_text(json.dumps({'text':page.locator('body').inner_text(),'textarea':page.locator('textarea[aria-label="Message input"]').bounding_box(),'composer':page.locator('[data-slot=aui_composer-shell]').bounding_box()},ensure_ascii=False,indent=2))
 b.close()

server.terminate()
