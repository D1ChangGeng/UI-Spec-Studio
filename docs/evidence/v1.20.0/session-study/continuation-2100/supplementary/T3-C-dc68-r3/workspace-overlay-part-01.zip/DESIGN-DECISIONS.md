# Fieldnotes current design model

## Goal and active increment
The complete goal remains an expressive editorial research studio with reliable native reading, linked navigation, editing, saving and return. One coherent SPEC owns the whole-theme relationship between note sheet, utility rail, typography, editor, themes and narrow conditions. It is implemented and inspected within the stated evidence boundary; user preference/approval is not claimed.

L0: bilingual research team and durable notes. L1: interview→ledger→return→edit→save→reload, plus cancel and keyboard search. L2: native story river/sidebar/search/tags/control panel. L3–L4: Paper's linked sheet, serif/sans/mono roles, warm surfaces, red margin, capped measure, native controls, ruled editor, day/night states. L5: complete adopted theme plus upstream TiddlyWiki5.4.1/tiddlyweb/filesystem. No W1–W3 exception or replacement product model.

## DDU1 — Whole-workspace direction
Question: can a mature source carry distinctive composition and type through actual populated work rather than a decorative entry view or palette swap?

Evidence: native baseline read and viewed; external original Paper and Notebook demos both genuinely rendered/viewed; equivalent supplied-content trials at1440×900,1280×640,390×844. Important actual image-view responses and source outputs are preserved. `evidence/research/REPORT.md` and `SOURCES.json` identify source/revision/rights and final v5 trials. Main designer independently opened important source/trial pixels.

Choice: Paper0.10.0, MIT, revision031a78d4d4187128c632f8a647fa05408eddc700. Its720px sheet, warm desk/cream-paper contrast, red margin rule and serif reading are recognisable across work; sans utilities and ruled mono input distinguish tasks. Notebook1.4.1 challenged the early preference with denser centered sans sheets and a persistent top/mobile utility bar. It fits more text but provides less reading/editing role contrast. Starlight was source-inspected only, and is not represented as a rendered alternative.

Implementation: whole local theme folder with supported exact theme/palette selections. Numbered stylesheet ordering and all55 source files retained. Three narrow source repairs and their exact diff are in `SOURCE-ADOPTION.md`, `evidence/source-diff.patch`, `source-comparison.json`. Native toolbaralways=yes improves pencil discoverability. No new asset/font download or animation engine.

## DDU2 — Bilingual work and authoritative persistence
The native editor/draft/story/search mechanisms remain responsible. Verified server identity (owned Node cwd/argv/source/wiki plus unique HTTP instance marker) precedes final assertions on55111. `evidence/commands/017` and `evidence/verified-final/behavior.json` establish native link navigation, exact-title file writes, English+Chinese changes surviving reload, restored original interview text, confirmed cancel leaving the note and exiting the editor, keyboard search/Enter to editor, both palettes and all3 viewports, localized Chinese UI and no browser errors. Initial and final live draft inventories were empty.

The authored meaning and length of all8 notes remain. Interview body matches the seed exactly after restoration. Three tables retain all original rows/cells but now use Paper's existing keyboard-focusable scroll wrapper because the5.4.1 parser lacks the newer wrapper expected by this source. The existing wrapper's appearance and scrolling mechanism are adopted, not invented. `commands/018` proves row preservation; `commands/020` proves keyboard scrolling to the final column, native day/night palette selection and no page-wide narrow overflow.

## DDU3 — Quiet state and bounded cost
Research found the layout's reduced-motion1ms rule overridden by a later global150ms!important rule. A one-line specificity repair retains the source's documented instant-layout intent. Owned55112 run in `commands/020` records normal0.4s and reduced0.001s computed duration, scalar progression and actual sampled-frame times. Viewed ordered frames establish sampled states, not natural-speed quality. Runtime resources were local native wiki endpoints; no added imagery, fonts, engines or remote services. Theme source is text and uses host fonts.

## Assurance and remaining scope
All12 final reading/editor viewport/theme PNGs were personally opened. `VISUAL-REVIEW.md` records whole/detail observations, original-versus-product comparison, normal/reduced sampled episodes and limits. `npm run build` passed in commands/021; actual offline export was rendered/viewed in commands/022 and reports8 notes/zero drafts.

Early failed source activation, selectors, stale test-draft and server-identity attempts remain in the archive. Cross-call deleted files reappeared with old mtimes; no cause was proven and no unowned process was stopped. Complete originals were retained before redundant records were overwritten as inert unique system records. Final owned-process/HTTP identity and fresh8-note/zero-draft inventories replace earlier uncertain identity assertions. This executor's cross-process deletion behavior remains a limitation, distinct from successful live-store cancellation.

No natural-speed video playback, user study, exhaustive assistive-technology testing, physical mobile keyboard testing or broad plugin compatibility claim. Date metadata remains low emphasis. Owner acceptance is pending. The original initial model is preserved in `evidence/initial-design-model.md`; this record is the current choice.
