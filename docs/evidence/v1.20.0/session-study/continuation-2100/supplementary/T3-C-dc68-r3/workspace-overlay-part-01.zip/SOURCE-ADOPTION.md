# Source adoption and exact adaptation

Selected source: **Vanilla Paper 0.10.0**, Simon Huber, MIT 2026; https://github.com/BurningTreeC/vanilla-paper at `031a78d4d4187128c632f8a647fa05408eddc700`. Acquired archive SHA256 `8c7fe37648f0c2c55a38616633c58e3787e083168813f35630a540187b496127`. Complete original source, actual API/archive results, source hashes and original-demo capture are retained in `evidence/research/`; see `SOURCES.json` and `REPORT.md` there. License: `app/wiki/licenses/VanillaPaper-LICENSE.txt`. Existing complete TiddlyWiki5.4.1 distribution remains untouched and retains its license and provenance.

## Actual adoption boundary
The complete 55-file theme directory is installed in `app/wiki/themes/vanilla-paper/`. Local wiki themes are an upstream-supported package extension point. It is standalone, so `app/wiki/tiddlywiki.info` no longer lists Vanilla/Snow White. `$:/theme` selects the exact Paper title; `$:/palette` selects its Day palette. No dependency or online asset fetch is needed at runtime. The typography stacks, sheet proportions, margin rule, warm ground/sheet relationship, capped reading measure, sans navigation, ruled mono editor, native controls and CSS sidebar mechanism are retained together. No W1–W3 exception or original substitute was used.

The initial exact-source copy is proven in `evidence/commands/004`. Three original source files then received narrow repairs, with original identities unchanged:

1. `1-layout.tid`: `transition-duration: 1ms;` becomes `transition-duration: 1ms !important;` inside the existing reduced-motion layout branch. The later source surface wildcard otherwise overrides it to150ms. This restores the source's documented instant-layout intent; it adds no new mechanism.
2. `VanillaPaperDay.tid`: `tiddler-controls-foreground` changes from `#b5afa2` to the source's existing `sidebar-foreground` value `#6b6558`.
3. `VanillaPaperNight.tid`: same control role changes from `#5e594e` to the source's existing `sidebar-foreground` value `#a49e90`.

The latter two preserve the warm palette but make the native pencil/checkmark and navigation controls more discernible. Supported configuration `options/toolbaralways=yes` keeps them visible at rest. All other theme files remain byte-identical to acquired source. `evidence/source-diff.patch` and `evidence/source-comparison.json` provide actual diffs/hashes.

## Why this source, and the challenger
Original Paper and Notebook demos were both rendered and personally opened, separately from current-content trials. Paper turns the material into a reading studio: a measured serif column, sans utility rail and ruled working input maintain identity after the first action. Notebook1.4.1 (MIT, Nicolas Petton; revision465c832c885894ee3c97be76449cc524e1252eb0) is a substantive challenger, with a centered sans sheet, fixed search bar and mobile bottom bar. It reveals more content per frame, but expresses less distinction between reading and writing. It was compared, not adopted. Starlight's source supplies a global font and image texture over Snow White and labels itself a placeholder; it was source-inspected but not represented as a rendered competitor.

## Product and maintenance ownership
TiddlyWiki's native story/search/tags/drafts/editor/toolbar remain the interaction model. Browser saves use its upstream tiddlyweb adaptor, Node store and filesystem plugin. All eight supplied note bodies are preserved, including long Chinese passages, table data, cross-links, synthetic-material disclosures and unfinished status. Temporary English/Chinese wording changes were saved, observed in the exact-title filesystem record, reloaded, then restored through native controls.

The host's Chinese font fixture is not a newly adopted font asset. Paper uses system stacks; no downloaded font or imagery is redistributed. Future Paper updates require reapplying/rechecking the three small repairs, the core-compatible Vanilla-namespace shims, focus, tables and editing. An original source demo uses a different TW core revision, so compatibility claims rely on this package's actual5.4.1 trials.

## Table composition compatibility repair
Paper supplies `.tc-table-wrapper` with scoped horizontal scrolling. The5.4.1 parser emits a bare table, so the three supplied table blocks are now composed inside that exact mature wrapper with a keyboard-focusable named region. No CSS or table data was invented. Original complete note files are retained in `evidence/table-originals/`; commands/018 proves every table row was preserved and commands/020 proves keyboard scrolling reaches the final column in both palettes.
