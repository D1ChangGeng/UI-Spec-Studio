# Fieldnotes

Run the genuine native client–server application from the app directory:

```sh
PORT=55111 ./start.sh
```

Open http://127.0.0.1:55111/. Use the pencil to edit and checkmark to confirm. The Node wiki and filesystem plugin own the stored notes in `wiki/tiddlers/`. Stop this server before editing those files directly.

Control Panel → Appearance → Palette contains **Vanilla Paper Day** and **Vanilla Paper Night**. Both were tested with the long bilingual interview, native editor, search and keyboard navigation. Tables have focusable local horizontal scrolling on narrow screens.

`npm run build` exports `wiki/output/index.html`. This is a native offline rendition; the server is the authoritative persistence path for the study.

Whole theme: Vanilla Paper0.10.0, MIT, Simon Huber. Full notice is in `licenses/VanillaPaper-LICENSE.txt`. Source identity, configuration, source-preserving patches and verification evidence are documented in the work package's `SOURCE-ADOPTION.md`, `DESIGN-DECISIONS.md`, and `VISUAL-REVIEW.md`.
