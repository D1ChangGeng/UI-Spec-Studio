from pathlib import Path
import json,shutil,hashlib
r=Path(__file__).resolve().parent.parent
source=r/'evidence/research/vanilla-paper-main/themes/BurningTreeC/vanilla-paper'
target=r/'app/wiki/themes/vanilla-paper'
shutil.copytree(source,target)
shutil.copy(r/'evidence/research/vanilla-paper-main/LICENSE',target/'LICENSE')
info=r/'app/wiki/tiddlywiki.info';data=json.loads(info.read_text());data['themes']=[];info.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def put(name,title,text):
 p=r/'app/wiki/tiddlers'/name;p.write_text('title: '+title+'\n\n'+text)
put('fieldnotes-theme.tid','$:/theme','$:/themes/BurningTreeC/vanilla-paper')
put('config-04.tid','$:/palette','$:/palettes/VanillaPaperDay')
put('fieldnotes-visible-controls.tid','$:/themes/BurningTreeC/vanilla-paper/options/toolbaralways','yes')
# Keep the upstream's optional motion mechanisms; all honor reduced-motion.
print(json.dumps({'theme':json.loads((target/'plugin.info').read_text()),'copied_source_files':len(list(source.iterdir())),'unmodified_source':all((target/f.name).read_bytes()==f.read_bytes() for f in source.iterdir() if f.is_file()),'configuration':{'palette':'VanillaPaperDay','toolbaralways':'yes'},'source_commit':'031a78d4d4187128c632f8a647fa05408eddc700'},indent=2))
