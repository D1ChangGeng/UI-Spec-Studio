import asyncio,json,os,time,subprocess
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).parent
SERVER=subprocess.Popen(["node","vendor/tiddlywiki/tiddlywiki.js","wiki","--listen","host=127.0.0.1","port=4412"],cwd=ROOT.parent/"app",stdout=open(ROOT/"server-capture.log","w"),stderr=subprocess.STDOUT)
time.sleep(2)
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
  page=await browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
  await page.goto('http://127.0.0.1:4412/');await page.wait_for_timeout(1800)
  await page.screenshot(path=str(ROOT/'baseline-1440.png'))
  print(json.dumps({'title':await page.title(),'buttons':await page.locator('button').evaluate_all('(xs)=>xs.map(x=>({text:x.innerText,title:x.title,aria:x.getAttribute("aria-label")}))'),'tiddlers':await page.locator('.tc-tiddler-frame').evaluate_all('(xs)=>xs.map(x=>({title:x.getAttribute("data-tiddler-title"),height:x.offsetHeight}))')},ensure_ascii=False,indent=2))
  await browser.close()
try: asyncio.run(main())
finally: SERVER.terminate();SERVER.wait()
