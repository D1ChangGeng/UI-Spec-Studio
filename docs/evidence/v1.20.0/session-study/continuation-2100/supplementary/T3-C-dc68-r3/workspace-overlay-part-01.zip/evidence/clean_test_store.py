from pathlib import Path
import shutil,json
r=Path(__file__).resolve().parent.parent;d=r/'app/wiki/tiddlers';o=r/'evidence/pre-final-store';o.mkdir(exist_ok=True)
for p in list(d.glob('*.tid')):
 text=p.read_text();header=text.split('\n\n',1)[0]
 if 'draft.of:' in header or p.name=='$__StoryList.tid' or p.name=='note-04.tid':
  shutil.copy(p,o/p.name);p.unlink();print('Removed retained test artifact',p.name)
# One authoritative interview remains, with the source body restored.
canonical=d/'访谈笔记 — 傍晚通勤.tid';assert canonical.exists()
body=canonical.read_text().split('\n\n',1)[1];seed=(o/'note-04.tid').read_text().split('\n\n',1)[1];assert body==seed
(d/'fieldnotes-story.tid').write_text('title: $:/StoryList\nlist: [[Fieldnotes — project index]] [[访谈笔记 — 傍晚通勤]]\n\n')
p=r/'app/wiki/themes/vanilla-paper/1-layout.tid';text=p.read_text();assert text.count('transition-duration: 1ms;')==1;p.write_text(text.replace('transition-duration: 1ms;','transition-duration: 1ms !important;'))
print('Body preservation pass. Reduced-motion specificity repair applied to original 1-layout identity.')
