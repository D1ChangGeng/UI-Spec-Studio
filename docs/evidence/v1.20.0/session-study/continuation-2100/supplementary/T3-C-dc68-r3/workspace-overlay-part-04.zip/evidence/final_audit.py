from pathlib import Path
import json,hashlib,datetime
r=Path(__file__).resolve().parent.parent
v=json.loads((r/'PROVENANCE.json').read_text());bad=[]
for name,expected in v['upstream_vendor_files'].items():
 p=r/'app/vendor/tiddlywiki'/name
 if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=expected:bad.append(name)
assert not bad,bad
store={};drafts=[]
for p in (r/'app/wiki/tiddlers').glob('*.tid'):
 text=p.read_text();h=text.split('\n\n',1)[0];f=dict(x.split(': ',1) for x in h.splitlines() if ': ' in x);t=f.get('title');store.setdefault(t,[]).append(str(p.relative_to(r)))
 if f.get('draft.of'):drafts.append(t)
assert not drafts,drafts
assert all(len(ps)==1 for ps in store.values()),{k:ps for k,ps in store.items() if len(ps)>1}
notes=[t for t in store if t and not t.startswith('$:/')];assert len(notes)==8
for name in ['day-reading-1440','day-reading-1280','day-reading-390','night-reading-1440','night-reading-1280','night-reading-390','day-editing-1440','day-editing-1280','day-editing-390','night-editing-1440','night-editing-1280','night-editing-390']:
 assert (r/f'evidence/verified-final/{name}.png').exists();assert (r/f'evidence/view-verified-{name}.json').exists()
report={'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'upstream_vendor_files_verified':len(v['upstream_vendor_files']),'upstream_revision':v['revision'],'vendor_mismatches':bad,'authoritative_note_count':len(notes),'draft_count':len(drafts),'duplicate_titles':False,'offline_bytes':(r/'app/wiki/output/index.html').stat().st_size,'final_matrix_images_and_actual_views':12,'source_changes':[k for k,x in json.loads((r/'evidence/source-comparison.json').read_text()).items() if not x['identical']]}
(r/'evidence/final-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
