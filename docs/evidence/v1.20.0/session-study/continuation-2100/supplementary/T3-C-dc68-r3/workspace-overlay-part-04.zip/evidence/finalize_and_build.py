from pathlib import Path
import json,hashlib,subprocess
r=Path(__file__).resolve().parent.parent;d=r/'app/wiki/tiddlers'
records={}
for p in d.glob('*.tid'):
 s=p.read_text();h=s.split('\n\n',1)[0];f=dict(x.split(': ',1) for x in h.splitlines() if ': ' in x)
 title=f.get('title');records.setdefault(title,[]).append(p)
 assert 'draft.of' not in f,(p,'Unremoved draft')
 if title=='$:/StoryList':p.write_text('title: $:/StoryList\nlist: [[Fieldnotes — project index]] [[访谈笔记 — 傍晚通勤]]\n\n')
 if title=='$:/palette':p.write_text('title: $:/palette\n\n$:/palettes/VanillaPaperDay')
 if title=='$:/language':p.write_text('title: $:/language\n\n$:/languages/en-GB')
# Inert archive records preserve cross-exec deletion anomalies without becoming notes.
assert all(len(x)==1 for x in records.values()),{k:[p.name for p in v] for k,v in records.items() if len(v)>1}
notes={k:v[0] for k,v in records.items() if k and not k.startswith('$:/')};assert len(notes)==8,notes
seed=r/'evidence/pre-final-store/note-04.tid';body=notes['访谈笔记 — 傍晚通勤'].read_text().split('\n\n',1)[1];assert body==seed.read_text().split('\n\n',1)[1]
print(json.dumps({'final_note_count':len(notes),'draft_count':0,'unique_titles':True,'interview_body_matches_seed':True,'note_files':{k:str(p.relative_to(r)) for k,p in notes.items()}},ensure_ascii=False))
result=subprocess.run(['npm','run','build'],cwd=r/'app',check=False);raise SystemExit(result.returncode)
