# Fieldnotes current design model

## Overall goal and active SPEC
One cohesive increment: retain the native linked-note workspace and complete edit/save/return loop while giving populated reading, navigation and editing an editorial studio identity. English/Chinese content, long interview, evidence tables, unfinished notes and authoritative filesystem persistence remain intact. No W1–W3 exception is authorized or used.

L0: small bilingual research team; durable notes are the primary objects. L1: read interview → inspect ledger → return → edit and save → reload; cancel and search/keyboard are necessary continuations. L2–L4: whole-theme composition, role-specific typography, material and day/night states must work together. L5: upstream TiddlyWiki server/tiddlyweb/filesystem own data; theme/configuration own presentation.

## Current evidence and open choice
Baseline personally viewed at 1440×900: broad white story cards, subdued blue headings, grey sidebar and pale pencil controls. Its task foundation is complete but the reading measure is very wide and the visual identity mostly generic. Actual capture: evidence/baseline-1440.png; runtime/DOM: evidence/commands/003.

Independent research is comparing adoptable whole-workspace themes, especially Vanilla Paper and Notebook. Paper is provisionally promising for editorial composition and day/night treatment; it is not selected until the defining populated reading/editor/narrow states and rights are inspected. Native Starlight was source-inspected: its own source labels it a placeholder and globally assigns Arvo + a texture, so it is a weaker whole-product candidate despite its material character. Native Seamless/Heavier/Flexoki are a supported fallback, not a claim that a palette alone fulfills the expressive goal.

## Evidence plan and boundary
Read full long interview, follow ledger and return. Test English and Chinese edits via native pencil/checkmark, inspect server filesystem writes and reload, restore source text through the same controls. Start/cancel an edit. Search with keyboard and reach editor. Capture day/night reading and editing at 1440×900, 1280×640, 390×844, reduced motion, and Simplified Chinese UI. Inspect final PNG pixels personally. Static capture is not natural-time motion viewing or user preference evidence.

## Runtime discovery
Cross-command localhost is isolated by executor network namespaces. Initial attempts 001/002 failed with connection refused. Successful attempt 003 starts Node and Playwright in the same subprocess. Subsequent checks use that reproducible route; no claim of connected user-browser access is made.
