import asyncio,json,time,subprocess,os
from pathlib import Path
from playwright.async_api import async_playwright
R=Path(__file__).resolve().parent.parent;O=R/'evidence/verified-extra';O.mkdir(exist_ok=True)
async def main():
 server=subprocess.Popen(['node','../evidence/owned-launcher.cjs','wiki','--listen','host=127.0.0.1','port=55112'],cwd=R/'app',stdout=open(O/'server.log','w'),stderr=subprocess.STDOUT)
 try:
  await asyncio.sleep(2)
  async with async_playwright() as p:
   browser=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
   page=await browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1);page.on('dialog',lambda d:d.accept())
   await page.goto('http://127.0.0.1:55112/');await page.wait_for_timeout(1200)
   identity=json.loads((R/'evidence/owned-server-identity.json').read_text());print('OWNED_SERVER',json.dumps(identity))
   assert identity['cwd']==str(R/'app') and identity['wiki']==str(R/'app/wiki')
   assert await page.evaluate('$tw.wiki.getTiddlerText("$:/config/FieldnotesRunIdentity")')=='w11-verified-port55111-paper-031a78d'
   assert await page.evaluate('$tw.wiki.filterTiddlers("[has[draft.of]]").length')==0
   print('FRESH_STORE',await page.evaluate('$tw.wiki.filterTiddlers("[!is[system]]")'))
   # Use the native settings pane to select the day/night palettes once.
   await page.get_by_role('button',name='control panel',exact=True).click();await page.wait_for_timeout(1200)
   panel=page.locator('.tc-tiddler-frame[data-tiddler-title="$:/ControlPanel"]')
   print('CONTROL PANEL',await panel.inner_text());print('BUTTONS',await panel.locator('button').all_text_contents());await page.screenshot(path=str(O/'control-panel-initial.png'))
   await panel.locator('button').filter(has_text='Appearance').first.click();await page.wait_for_timeout(300)
   await panel.locator('button').filter(has_text='Palette').first.click();await page.wait_for_timeout(300)
   print('PALETTE CONTROLS',await panel.locator('input,select,button').evaluate_all('(xs)=>xs.map(x=>({tag:x.tagName,text:x.innerText,type:x.type,value:x.value,title:x.title})).filter(x=>x.text?.includes("Vanilla Paper")||x.type==="radio")'))
   await panel.locator('.tc-chooser a').filter(has_text='Vanilla Paper Night').first.click();await page.wait_for_timeout(300)
   assert await page.evaluate('$tw.wiki.getTiddlerText("$:/palette")')=='$:/palettes/VanillaPaperNight'
   await panel.locator('.tc-chooser a').filter(has_text='Vanilla Paper Day').first.click();await page.wait_for_timeout(300)
   assert await page.evaluate('$tw.wiki.getTiddlerText("$:/palette")')=='$:/palettes/VanillaPaperDay'
   print('NATIVE_PALETTE_SWITCH day-night-day pass')
   await page.screenshot(path=str(O/'native-palette-controls.png'))
   # Cross-linked table at narrow size; whole page must not overflow.
   await panel.get_by_role('button',name='close',exact=True).first.click();await page.wait_for_timeout(300)
   await page.locator('a.tc-tiddlylink-resolves').filter(has_text='Evidence ledger').first.click();await page.wait_for_timeout(500)
   for theme,palette in [('day','$:/palettes/VanillaPaperDay'),('night','$:/palettes/VanillaPaperNight')]:
    await page.evaluate('(p)=>$tw.wiki.addTiddler({title:"$:/palette",text:p})',palette)
    await page.set_viewport_size({'width':390,'height':844});await page.wait_for_timeout(300)
    ledger=page.locator('.tc-tiddler-frame[data-tiddler-title="Evidence ledger"]');await ledger.evaluate("e=>e.scrollIntoView({block:'start'})")
    await page.screenshot(path=str(O/f'{theme}-ledger-390.png'))
    wrapper=ledger.locator('.tc-table-wrapper');await wrapper.focus();await page.keyboard.press('ArrowRight');await page.wait_for_timeout(200)
    assert await wrapper.evaluate('e=>e.scrollLeft')>0
    await wrapper.evaluate('e=>e.scrollLeft=e.scrollWidth');await page.screenshot(path=str(O/f'{theme}-ledger-390-right.png'))
    print('TABLE_KEYBOARD_SCROLL',theme,await wrapper.evaluate('e=>({left:e.scrollLeft,width:e.clientWidth,full:e.scrollWidth})'))
    print(json.dumps({'check':'narrow-ledger','theme':theme,'bounds':await page.evaluate('({viewport:innerWidth,scroll:document.documentElement.scrollWidth})')}))
   await page.set_viewport_size({'width':1440,'height':900});await page.evaluate('$tw.wiki.addTiddler({title:"$:/palette",text:"$:/palettes/VanillaPaperDay"})');await page.wait_for_timeout(300)
   await page.locator('.tc-sidebar-lists a').filter(has_text='访谈笔记 — 傍晚通勤').first.click();await page.wait_for_timeout(500)
   for pref in ['no-preference','reduce']:
    await page.emulate_media(reduced_motion=pref);await page.wait_for_timeout(100)
    start=time.monotonic();await page.get_by_role('button',name='hide sidebar',exact=True).click()
    for delay in [0,70,130,250,450]:
     if delay: await page.wait_for_timeout(delay)
     actual=time.monotonic()-start
     await page.screenshot(path=str(O/f'sidebar-{pref}-{delay}.png'))
     print(json.dumps({'episode':'sidebar-hide','preference':pref,'capture_after_previous_delay_ms':delay,'elapsed_seconds':actual,'openScalar':await page.locator('.tc-page-container').evaluate('(e)=>getComputedStyle(e).getPropertyValue("--btc-open")'),'transition':await page.locator('.tc-page-container').evaluate('(e)=>getComputedStyle(e).transitionDuration')}))
    await page.get_by_role('button',name='show sidebar',exact=True).click();await page.wait_for_timeout(700)
   print(json.dumps({'resources':await page.evaluate('performance.getEntriesByType("resource").map(x=>({name:x.name,bytes:x.transferSize,duration:x.duration}))'),'styleCount':await page.locator('style').count(),'drafts':await page.evaluate('$tw.wiki.filterTiddlers("[has[draft.of]]")')}))
   await browser.close()
 finally:server.terminate();server.wait()
asyncio.run(main())
