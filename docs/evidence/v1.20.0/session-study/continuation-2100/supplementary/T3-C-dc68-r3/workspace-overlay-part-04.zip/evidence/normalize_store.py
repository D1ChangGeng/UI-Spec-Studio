from pathlib import Path
import json,shutil,hashlib
r=Path(__file__).resolve().parent.parent;d=r/'app/wiki/tiddlers';o=r/'evidence/normalization-originals';o.mkdir(exist_ok=True)
by={}
for p in d.glob('*.tid'):
 text=p.read_text();h=text.split('\n\n',1)[0];fields=dict(x.split(': ',1) for x in h.splitlines() if ': ' in x);title=fields.get('title')
 if fields.get('draft.of'):
  (o/p.name).write_text(text);p.write_text('title: $:/state/FieldnotesArchivedSource/'+p.stem.replace('/','-')+'\n\n');print('inert draft archive',p.name);continue
 by.setdefault(title,[]).append(p)
for title,ps in by.items():
 if len(ps)>1:
  keep=max(ps,key=lambda p:p.stat().st_mtime)
  for p in ps:
   if p!=keep:
    (o/p.name).write_text(p.read_text());p.write_text('title: $:/state/FieldnotesArchivedSource/'+p.stem.replace('/','-')+'\n\n');print('inert duplicate archive',p.name)
# Set desired initial presentation through the authoritative system records.
for title,text in [('$:/palette','$:/palettes/VanillaPaperDay'),('$:/language','$:/languages/en-GB')]:
 for p in d.glob('*.tid'):
  if 'title: '+title in p.read_text().split('\n\n',1)[0].splitlines():p.write_text('title: '+title+'\n\n'+text)
print('No draft.of remains in source:',all('draft.of:' not in p.read_text().split('\n\n',1)[0] for p in d.glob('*.tid')))
