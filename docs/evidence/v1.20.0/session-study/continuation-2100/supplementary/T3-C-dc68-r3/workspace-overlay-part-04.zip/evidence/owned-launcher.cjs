const fs=require('fs');const path=require('path');
const source=path.resolve('vendor/tiddlywiki/tiddlywiki.js');
fs.writeFileSync(path.resolve('../evidence/owned-server-identity.json'),JSON.stringify({pid:process.pid,cwd:process.cwd(),argv:process.argv,source:fs.realpathSync(source),wiki:fs.realpathSync(path.resolve('wiki')),startedAt:new Date().toISOString()},null,2));
require(source);
