from pathlib import Path
import json,shutil,hashlib
r=Path(__file__).resolve().parent.parent;d=r/'app/wiki/tiddlers';o=r/'evidence/pre-verified-store';o.mkdir(exist_ok=True)
by={}
for p in d.glob('*.tid'):
 text=p.read_text();h=text.split('\n\n',1)[0];fields=dict(x.split(': ',1) for x in h.splitlines() if ': ' in x);title=fields.get('title')
 if fields.get('draft.of') or title=='$:/StoryList':shutil.copy(p,o/p.name);p.unlink();continue
 by.setdefault(title,[]).append(p)
for title,ps in by.items():
 if len(ps)>1:
  keep=max(ps,key=lambda p:p.stat().st_mtime)
  for p in ps:
   if p!=keep:shutil.copy(p,o/p.name);p.unlink();print('duplicate archived',str(p))
(d/'fieldnotes-story.tid').write_text('title: $:/StoryList\nlist: [[Fieldnotes — project index]] [[访谈笔记 — 傍晚通勤]]\n\n')
(d/'fieldnotes-run-identity.tid').write_text('title: $:/config/FieldnotesRunIdentity\n\nw11-verified-port55111-paper-031a78d')
(r/'app/wiki/licenses').mkdir(exist_ok=True)
p=r/'app/wiki/themes/vanilla-paper/LICENSE'
if p.exists():shutil.move(p,r/'app/wiki/licenses/VanillaPaper-LICENSE.txt')
print(json.dumps({'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.glob('*.tid')}},ensure_ascii=False))
