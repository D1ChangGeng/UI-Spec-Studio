from pathlib import Path
r=Path(__file__).resolve().parent.parent
for name,old,new in [('VanillaPaperDay.tid','#b5afa2','#6b6558'),('VanillaPaperNight.tid','#5e594e','#a49e90')]:
 p=r/'app/wiki/themes/vanilla-paper'/name;s=p.read_text();needle='tiddler-controls-foreground: '+old;assert needle in s;p.write_text(s.replace(needle,'tiddler-controls-foreground: '+new));print(name,needle,'→',new,'(existing sidebar-foreground token)')
# Retain original theme source; only these copied source fields change.
