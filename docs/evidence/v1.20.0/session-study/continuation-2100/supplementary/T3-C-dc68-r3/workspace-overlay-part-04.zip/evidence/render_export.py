import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
r=Path(__file__).resolve().parent.parent
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
  page=await b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1);await page.goto((r/'app/wiki/output/index.html').as_uri());await page.wait_for_timeout(1000)
  await page.screenshot(path=str(r/'evidence/export-build.png'))
  print(json.dumps({'export_title':await page.title(),'theme':await page.evaluate('$tw.wiki.getTiddlerText("$:/theme")'),'notes':await page.evaluate('$tw.wiki.filterTiddlers("[!is[system]]")'),'drafts':await page.evaluate('$tw.wiki.filterTiddlers("[has[draft.of]]")'),'output_bytes':(r/'app/wiki/output/index.html').stat().st_size},ensure_ascii=False))
  await b.close()
asyncio.run(main())
