# Research visual review

Personally viewed with view_image, actual responses saved at call site:

- Paper original demo: normal desktop whole; serif titles/prose, red margin and warm sheet align closely with the populated Paper trial.
- Paper v2 day whole and interview: 720px sheet and right sidebar form a clear two-region composition. V3/v5 settled editor: dense mixed-language source text stays on ruled lines, with compact sans controls and visible focus. Night: warm reading values carry the same composition. V5 narrow: title, English quote and Chinese paragraph wrap within the viewport.
- Notebook original demo: centered sans sheet and fixed horizontal tools are coherent. Corrected v4/v5 populated trial retains that composition; compact editing displays more lines. V5 dark and narrow are readable and keep the mobile bottom controls.
- Initial Paper unstyled and initial Notebook oversized controls were actual trial configuration failures; never treated as valid source comparisons. Intermediate editor capture at 250ms is an incomplete native transition, not a settled state.
- Static captures only. Edit/cancel were operated and sampled after settling; there was no natural-speed playback inspection. Reduced-motion computed styles reveal the Paper 150ms override, but do not establish experienced pacing.

