import asyncio,json,os,time
from pathlib import Path
from playwright.async_api import async_playwright
R=Path(__file__).resolve().parent
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'],env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
  for name in ['paper','notebook']:
   page=await b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
   await page.goto((R/(name+'-demo.html')).as_uri());await page.wait_for_timeout(1500);await page.evaluate('document.fonts.ready')
   await page.screenshot(path=str(R/(name+'-original-demo-1440.png')))
   print(json.dumps({'name':name,'title':await page.title(),'theme':await page.evaluate('$tw.wiki.getTiddlerText("$:/theme")'),'palette':await page.evaluate('$tw.wiki.getTiddlerText("$:/palette")'),'version':await page.evaluate('$tw.version'),'sourceTheme':await page.evaluate('$tw.wiki.getTiddler($tw.wiki.getTiddlerText("$:/theme")).fields.version')},ensure_ascii=False))
   await page.close()
  await b.close()
asyncio.run(main())
