import asyncio, json, os, shutil, subprocess, time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent
PKG=ROOT.parent.parent
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
def field(wiki,title,text):
 for f in (wiki/'tiddlers').glob('*.tid'):
  if ('title: '+title+'\n') in f.read_text(): f.unlink()
 name=title.replace('$:/','').replace('/','-')
 (wiki/'tiddlers'/(name+'.tid')).write_text('title: '+title+'\n\n'+text)
def prepare(name):
 wiki=ROOT/(name+'-wiki')
 if wiki.exists(): shutil.rmtree(wiki)
 shutil.copytree(PKG/'app/wiki',wiki)
 for f in (wiki/'tiddlers').glob('*.tid'):
  if '\ndraft.of:' in f.read_text(): f.unlink()
 field(wiki,'$:/StoryList','')
 (wiki/'tiddlers/StoryList.tid').write_text('title: $:/StoryList\nlist: [[Fieldnotes — project index]] [[访谈笔记 — 傍晚通勤]]\n\n')
 if (wiki/'plugins').exists(): shutil.rmtree(wiki/'plugins')
 (wiki/'plugins').mkdir(exist_ok=True)
 if name=='paper':
  shutil.copytree(ROOT/'vanilla-paper-main/themes/BurningTreeC/vanilla-paper',wiki/'plugins/paper')
  info=json.loads((wiki/'tiddlywiki.info').read_text());info['themes']=[];(wiki/'tiddlywiki.info').write_text(json.dumps(info))
  field(wiki,'$:/theme','$:/themes/BurningTreeC/vanilla-paper')
  field(wiki,'$:/palette','$:/palettes/VanillaPaperDay')
 else:
  info=json.loads((wiki/'tiddlywiki.info').read_text());info['themes']=['tiddlywiki/vanilla','tiddlywiki/snowwhite'];(wiki/'tiddlywiki.info').write_text(json.dumps(info))
  shutil.copytree(ROOT/'Notebook-master/themes/notebook',wiki/'plugins/notebook')
  shutil.copytree(ROOT/'Notebook-master/plugins/notebook-mobile',wiki/'plugins/notebook-mobile')
  field(wiki,'$:/theme','$:/themes/nico/notebook')
  field(wiki,'$:/palette','$:/themes/nico/notebook/palettes/palette-beige')
 return wiki
async def inspect(name,wiki,port):
 server=subprocess.Popen(['node',str(PKG/'app/vendor/tiddlywiki/tiddlywiki.js'),str(wiki),'--listen','host=127.0.0.1',f'port={port}'],stdout=open(ROOT/(name+'-server.log'),'w'),stderr=subprocess.STDOUT)
 try:
  await asyncio.sleep(2)
  async with async_playwright() as p:
   browser=await p.chromium.launch(executable_path=BROWSER,args=['--no-sandbox'],env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
   page=await browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
   page.on('dialog',lambda dialog: asyncio.create_task(dialog.accept()))
   await page.goto(f'http://127.0.0.1:{port}/');await page.wait_for_timeout(1000);await page.evaluate('document.fonts.ready')
   await page.screenshot(path=str(ROOT/(name+'-v5-1440-day.png')))
   print(json.dumps({'candidate':name,'theme':await page.evaluate('$tw.wiki.getTiddlerText("$:/theme")'),'palette':await page.evaluate('$tw.wiki.getTiddlerText("$:/palette")'),'frames':await page.locator('.tc-tiddler-frame').evaluate_all('(xs)=>xs.map(x=>({title:x.getAttribute("data-tiddler-title"),w:x.offsetWidth,h:x.offsetHeight}))'),'buttons':await page.locator('button').evaluate_all('(xs)=>xs.slice(0,35).map(x=>({title:x.title,aria:x.getAttribute("aria-label")}))')},ensure_ascii=False))
   note=page.locator('.tc-tiddler-frame').filter(has=page.locator('[data-tiddler-title]'))
   target=page.locator('.tc-tiddler-frame[data-tiddler-title="访谈笔记 — 傍晚通勤"]')
   await target.evaluate('(e)=>e.scrollIntoView({block:"start"})');await page.screenshot(path=str(ROOT/(name+'-v5-interview-day.png')))
   await target.get_by_role('button',name='Edit this tiddler',exact=True).click();await page.wait_for_timeout(1200)
   await page.screenshot(path=str(ROOT/(name+'-v5-editor-day.png')))
   print('EDITOR_BUTTONS',await page.locator('.tc-tiddler-edit-frame button').evaluate_all('(xs)=>xs.map(x=>({title:x.title,aria:x.getAttribute("aria-label")}))'))
   await page.locator('.tc-tiddler-edit-frame .tc-tiddler-controls button').nth(1).click();await page.wait_for_timeout(1200)
   assert await page.locator('.tc-tiddler-edit-frame').count()==0
   night='$:/palettes/VanillaPaperNight' if name=='paper' else '$:/themes/nico/notebook/palettes/palette-dark'
   await page.evaluate('(p)=>$tw.wiki.addTiddler({title:"$:/palette",text:p})',night);await page.wait_for_timeout(250)
   await target.evaluate('(e)=>e.scrollIntoView({block:"start"})');await page.screenshot(path=str(ROOT/(name+'-v5-interview-night.png')))
   await page.set_viewport_size({'width':390,'height':844});await page.wait_for_timeout(250)
   await target.evaluate('(e)=>e.scrollIntoView({block:"start"})');await page.screenshot(path=str(ROOT/(name+'-v5-390-night.png')))
   await page.set_viewport_size({'width':1280,'height':640});await page.wait_for_timeout(250)
   await target.evaluate('(e)=>e.scrollIntoView({block:"start"})');await page.screenshot(path=str(ROOT/(name+'-v5-1280-night.png')))
   await page.emulate_media(reduced_motion='reduce');await page.wait_for_timeout(100)
   print(json.dumps({'candidate':name,'reducedTransition':await page.locator('.tc-page-container').evaluate('(e)=>getComputedStyle(e).transitionDuration'),'overflow':await page.evaluate('({doc:document.documentElement.scrollWidth,viewport:innerWidth})')}))
   await browser.close()
 finally:
  server.terminate();server.wait()
async def main():
 for n,p in [('paper',4471),('notebook',4472)]:
  try: await inspect(n,prepare(n),p)
  except Exception as e: print(json.dumps({'candidate':n,'error':str(e)}));raise
asyncio.run(main())
