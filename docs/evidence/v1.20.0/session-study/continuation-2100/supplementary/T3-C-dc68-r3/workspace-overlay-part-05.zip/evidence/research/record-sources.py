import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parent
paper=json.loads((R/'commands/005/stdout.txt').read_text())
notebook=json.loads((R/'notebook-commit.json').read_text())
out=[]
for name,archive,folder,revision,url in [('Paper','paper-source.tar.gz','vanilla-paper-main',paper['sha'],'https://github.com/BurningTreeC/vanilla-paper'),('Notebook','notebook-source.tar.gz','Notebook-master',notebook['sha'],'https://github.com/NicolasPetton/Notebook')]:
 files={str(f.relative_to(R/folder)):hashlib.sha256(f.read_bytes()).hexdigest() for f in (R/folder).rglob('*') if f.is_file()}
 out.append({'name':name,'repository':url,'resolved_revision':revision,'archive':archive,'archive_sha256':hashlib.sha256((R/archive).read_bytes()).hexdigest(),'files_sha256':files})
plugin=R/'vanilla-paper-main/themes/BurningTreeC/vanilla-paper/plugin.info';d=plugin.read_bytes();actual=hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()
expected=next(f['sha'] for f in paper['files'] if f['filename'].endswith('plugin.info'))
assert actual==expected
out[0]['plugin_git_blob_sha1_match']={'actual':actual,'expected':expected,'matches':True}
(R/'SOURCES.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'source_records':len(out),'paper_revision':paper['sha'],'notebook_revision':notebook['sha'],'paper_plugin_blob_matches_api':actual==expected},indent=2))
