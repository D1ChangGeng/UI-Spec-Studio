import asyncio,json,time,subprocess,os,hashlib
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'evidence'/'final4';OUT.mkdir(exist_ok=True)
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
TITLE='访谈笔记 — 傍晚通勤'
logs=[]
def log(event,**kw):
 x={'event':event,'time':time.time(),**kw};logs.append(x);print(json.dumps(x,ensure_ascii=False),flush=True)
async def capture(page,name):
 if 'edit' in name:
  drafts=page.locator('.tc-tiddler-frame').filter(has=page.locator('input.tc-titlebar'))
  if await drafts.count():await drafts.first.evaluate("e=>e.scrollIntoView({block:'start'})")
 await page.screenshot(path=str(OUT/f'{name}.png'));log('capture',name=name,viewport=page.viewport_size,scroll=await page.evaluate('scrollY'))
async def setconfig(page,title,text):
 await page.evaluate('([title,text])=>$tw.wiki.addTiddler({title,text})',[title,text]);await page.wait_for_timeout(650)
async def waitsave(page,title,expected):
 for _ in range(60):
  paths=list((ROOT/'app/wiki/tiddlers').glob('*.tid'))
  found=[p for p in paths if ('title: '+title) in p.read_text().split('\n\n',1)[0].splitlines() and expected in p.read_text()]
  if found:log('filesystem-write-confirmed',title=title,path=str(found[0]),sha256=hashlib.sha256(found[0].read_bytes()).hexdigest());return
  await page.wait_for_timeout(200)
 raise AssertionError('filesystem did not persist expected text')
async def frame(page,title=TITLE):
 return page.locator('.tc-tiddler-frame').filter(has=page.locator('.tc-title',has_text=title)).first
async def openNote(page,title):
 # Use native internal link where present; index provides all supplied notes.
 link=page.locator('a.tc-tiddlylink-resolves').filter(has_text=title).first
 await link.click();await page.wait_for_timeout(500)
 return page.locator('.tc-tiddler-frame').filter(has=page.locator('.tc-title',has_text=title)).first
async def editor(page,f):
 await f.get_by_role('button',name='Edit this tiddler',exact=True).click();await page.wait_for_timeout(1100)
 d=page.locator('.tc-tiddler-frame').filter(has=page.locator('input.tc-titlebar')).first
 # Framed native editor has the actual textarea in an iframe.
 if await d.locator('iframe.tc-edit-texteditor').count():return d,d.frame_locator('iframe.tc-edit-texteditor').locator('textarea')
 return d,d.locator('textarea.tc-edit-texteditor').last
async def main():
 server=subprocess.Popen(['node','vendor/tiddlywiki/tiddlywiki.js','wiki','--listen','host=127.0.0.1','port=4412'],cwd=ROOT/'app',stdout=open(OUT/'server.log','w'),stderr=subprocess.STDOUT)
 try:
  await asyncio.sleep(2)
  async with async_playwright() as p:
   browser=await p.chromium.launch(executable_path=CHROME,args=['--no-sandbox'])
   ctx=await browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1,record_video_dir=str(OUT/'video'),record_video_size={'width':1440,'height':900})
   page=await ctx.new_page();page.on('dialog',lambda d: d.accept());errors=[];page.on('pageerror',lambda e: errors.append(str(e)))
   await page.goto('http://127.0.0.1:4412/');await page.wait_for_timeout(1500)
   await capture(page,'day-index-1440')
   f=await openNote(page,TITLE);await capture(page,'day-interview-1440')
   # Complete long reading, then follow the actual cross-link to ledger and return.
   await f.get_by_text('如果标志必须很少',exact=False).scroll_into_view_if_needed();await capture(page,'day-interview-end')
   await f.get_by_role('link',name='Evidence ledger',exact=True).click();await page.wait_for_timeout(500)
   ledger=page.locator('.tc-tiddler-frame').filter(has=page.locator('.tc-title',has_text='Evidence ledger')).first
   await capture(page,'day-ledger');await ledger.get_by_role('link',name=TITLE,exact=True).click();await page.wait_for_timeout(500)
   log('journey-read-ledger-return',pass_=True)
   f=await frame(page);d,ta=await editor(page,f);original=await ta.input_value()
   changed=original.replace('represents a real person.','represents an actual person.').replace('下一轮访谈应当分别追问','下一轮访谈需要分别追问')
   assert changed!=original
   await ta.fill(changed);await capture(page,'day-edit-1440')
   print(json.dumps({'draftbuttons':await d.locator('button').evaluate_all('(xs)=>xs.map(x=>({text:x.innerText,title:x.title,aria:x.getAttribute("aria-label")}))')},ensure_ascii=False))
   await d.get_by_role('button',name='Confirm changes to this tiddler',exact=True).click();await waitsave(page,TITLE,'represents an actual person.')
   await page.reload();await page.wait_for_timeout(1000)
   text=await page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',TITLE);assert text==changed;log('reload-persisted-English-and-Chinese',pass_=True)
   # Restore source words using native edit/save and verify again.
   f=await frame(page);await f.scroll_into_view_if_needed();d,ta=await editor(page,f);await ta.fill(original)
   await d.get_by_role('button',name='Confirm changes to this tiddler',exact=True).click();await waitsave(page,TITLE,'represents a real person.')
   # Cancel leaves the saved note untouched.
   f=await frame(page);d,ta=await editor(page,f);await ta.fill(original+'\nDiscard this unsaved probe.')
   await d.get_by_role('button',name='Discard changes to this tiddler',exact=True).click();await page.wait_for_timeout(1100)
   assert await page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',TITLE)==original
   assert await page.locator('input.tc-titlebar').count()==0
   log('cancel-preserves-note-and-exits-editor',pass_=True)
   await capture(page,'cancelled-note-preserved')
   # Matrix uses supported native palette/configuration values, with native UI editing.
   for theme,palette in [('day','$:/palettes/VanillaPaperDay'),('night','$:/palettes/VanillaPaperNight')]:
    await setconfig(page,'$:/palette',palette)
    for width,height in [(1440,900),(1280,640),(390,844)]:
     await page.set_viewport_size({'width':width,'height':height});await page.wait_for_timeout(450)
     f=await frame(page);await f.evaluate("e=>e.scrollIntoView({block:'start'})");await page.wait_for_timeout(250);await capture(page,f'{theme}-reading-{width}')
     bounds=await page.evaluate('({viewport:innerWidth,scroll:document.documentElement.scrollWidth})');log('page-width',theme=theme,**bounds)
     d,ta=await editor(page,f);await capture(page,f'{theme}-editing-{width}')
     await d.get_by_role('button',name='Discard changes to this tiddler',exact=True).click();await page.wait_for_timeout(200)
   await page.set_viewport_size({'width':1440,'height':900})
   await page.emulate_media(reduced_motion='reduce');await setconfig(page,'$:/palette','$:/palettes/VanillaPaperDay')
   f=await frame(page);await f.locator('.tc-title').scroll_into_view_if_needed();await capture(page,'reduced-motion-day')
   # Native search entered by keyboard, followed by keyboard-activated editor.
   await page.get_by_role('button',name='hide sidebar',exact=True).click();await page.wait_for_timeout(250)
   await page.get_by_role('button',name='show sidebar',exact=True).click();await page.wait_for_timeout(250)
   search=page.locator('.tc-search input').first;await search.focus();await page.keyboard.type('Next field session');await page.wait_for_timeout(700)
   print(json.dumps({'searchhtml':await page.locator('.tc-search').inner_html()},ensure_ascii=False))
   result=page.locator('.tc-search-results a').filter(has_text='Next field session').first
   await result.focus();await page.keyboard.press('Enter');await page.wait_for_timeout(500)
   nf=page.locator('.tc-tiddler-frame').filter(has=page.locator('.tc-title',has_text='Next field session')).first
   button=nf.get_by_role('button',name='Edit this tiddler',exact=True);await button.focus();await page.keyboard.press('Enter');await page.wait_for_timeout(1100)
   await capture(page,'keyboard-search-editor');log('keyboard-search-editor',pass_=True)
   d=page.locator('.tc-tiddler-frame').filter(has=page.locator('input.tc-titlebar')).first;await d.get_by_role('button',name='Discard changes to this tiddler',exact=True).click()
   await setconfig(page,'$:/language','$:/languages/zh-Hans');await capture(page,'chinese-ui-day')
   await setconfig(page,'$:/language','$:/languages/en-GB');await setconfig(page,'$:/palette','$:/palettes/VanillaPaperDay')
   log('console-errors',errors=errors);assert not errors
   await ctx.close();await browser.close()
 finally:
  server.terminate();server.wait();(OUT/'behavior.json').write_text(json.dumps(logs,ensure_ascii=False,indent=2))
asyncio.run(main())
