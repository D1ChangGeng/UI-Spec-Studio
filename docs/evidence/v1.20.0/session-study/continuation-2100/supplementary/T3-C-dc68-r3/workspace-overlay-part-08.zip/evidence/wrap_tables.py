from pathlib import Path
import json,shutil
r=Path(__file__).resolve().parent.parent;d=r/'app/wiki/tiddlers';o=r/'evidence/table-originals';o.mkdir(exist_ok=True)
for p in d.glob('*.tid'):
 s=p.read_text();parts=s.split('\n\n',1)
 if len(parts)<2:continue
 h,body=parts
 if not h.startswith('title:') and '\ntitle:' not in h:continue
 title=next((x[7:] for x in h.splitlines() if x.startswith('title: ')),'')
 if title.startswith('$:/') or not any(line.startswith('|') for line in body.splitlines()):continue
 if 'tc-table-wrapper' in body:continue
 (o/p.name).write_text(s)
 lines=body.splitlines();out=[];inside=False
 for line in lines:
  if line.startswith('|') and not inside:
   out.extend(['<div class="tc-table-wrapper" tabindex="0" role="region" aria-label="'+title+' table">','']);inside=True
  if not line.startswith('|') and inside:out.extend(['','</div>']);inside=False
  out.append(line)
 if inside:out.extend(['','</div>'])
 p.write_text(h+'\n\n'+'\n'.join(out))
 print(json.dumps({'note':title,'native_scroll_wrapper':True,'table_rows_preserved':[x for x in body.splitlines() if x.startswith('|')]==[x for x in out if x.startswith('|')]},ensure_ascii=False))
