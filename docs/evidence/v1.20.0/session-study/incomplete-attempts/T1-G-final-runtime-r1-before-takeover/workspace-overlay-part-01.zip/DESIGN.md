# Fieldnotes settings — current design model

## Goal and increment
One coherent, working browser-local settings journey: edit identity, notification and privacy preferences; understand validation, pending, failure and retry; cancel or return to persisted settings. Retain Tabler's mature settings page, navigation, card surfaces, typography, form controls, theme tokens and license. No original visual construction is authorized or planned.

## Evidence and decisions

### D1 — retain the page foundation
The supplied 1.7.1 source and settings snapshot carry the entire shell, two-column settings card, list-group navigation, heading scale, avatar, buttons and form/switch family. The primary designer viewed the original snapshot locally and the starter at 1440×900, plus Chinese/dark at 1280×600 (evidence/tools/view-source.json, view-baseline.json, view-compact.json). The original and starter share stable proportions and calm surfaces. The starter's detached fixture buttons inside the profile/avatar row compete with profile identity, and the short three-column fields hide representative organization content. Supported composition will move fixture buttons to the page-header action row, retain the avatar and settings card, widen text-bearing fields, and reuse Tabler textareas where wrapping is useful. No alternate visual family is needed for this explicitly mature-system task.

### D2 — truthful, associated feedback
The source controller reports only a general status above the form. The store is authoritative and remains unchanged. Use Tabler's is-invalid/invalid-feedback presentation, linked via aria-describedby and aria-invalid, with focus on the first invalid field after submit. Native form submission supports keyboard operation; novalidate lets the existing store's exact rules remain authoritative. The footer owns save status and recovery, close to Save. Existing Tabler alert, spinner/button and sticky-bottom utilities are the candidate composition; a local render will determine whether sticky action placement remains usable at 600px and narrow width.

### D3 — submitted snapshot and live draft
The store captures a snapshot before its 750ms wait. Preserve live edits during pending; disable duplicate Save and Cancel until completion. Success updates the saved baseline without overwriting later edits, and explicitly states when newer changes remain unsaved. Failure preserves both live draft and old persisted value. Language/theme switching updates presentation and URL without navigation. Cancel reloads the real saved value and clears validation. These are state/authority adapters, not replacement visual components.

## Alternatives considered
Retaining a top-only status would be a smaller change but leaves feedback outside the saving viewport at compact height. A transient toast has an upstream source but would make a recoverable error easy to lose; use persistent footer feedback. Disabling all inputs during pending avoids draft races but needlessly prevents editing; retain editable inputs and report snapshot completion accurately. Broader theme or navigation replacement has no task basis and is excluded.

## Sources
Exact selected source: SOURCE-MANIFEST.json; @tabler/core 1.7.1 tag 07f60c07da13d8ff957a370434b7ef5c86f5ab94; app/dist unchanged, app/LICENSE retained. Existing SettingsLayout.astro, Check.astro, Alert.astro and official-settings-snapshot.html are directly inspected source references. Modern form guidance was retrieved in commands/001–002; its semantic labels, input/error association, keyboard submission and delayed validation recommendations apply. Its server fallback/security examples do not describe this intentionally local-only service. Public Tabler documentation lookups are retained in tools/web-001.json and web-002.json.

## Verification plan and limits
Inspect English and Simplified Chinese, both themes, 1440×900 and 1280×600, plus 390×844. Exercise short and specified long content; validation for all four fields, failure/retry, edits during pending, Cancel, language/theme continuity, keyboard focus, reload and return. Capture original command output and controlled episode frames. Actual pixel viewing and static composition judgments are separate from runtime assertions; natural-time motion and screen-reader testing are not established by screenshots.

## Trial findings and revision
The main designer viewed the first integrated desktop, compact Chinese/dark, and narrow English/light captures (tools/view-trial-*.json). The inherited surfaces, heading scale, blue selection and switch family remain coherent. Footer feedback remains in the saving viewport, but the upstream floating customization button overlaps Save at 390px; it now uses Tabler's responsive visibility utility below md. The long representative text needs three native textarea rows at narrow width; the adapter uses the system's md breakpoint to change rows without replacing the form-control treatment. A focus-in adapter centers any input that would otherwise sit behind the sticky footer. These are specific responsive/focus repairs, to be rechecked in the final keyboard path.

The independent challenger reproduced the same baseline defects and an additional Cancel-during-pending race. Its original report and captures are under evidence/challenger/. The primary designer also opened its invalid-state image. Cancel is disabled during the store's non-cancellable interval; the final tests will check that persistence and live edits remain distinct.

### Final correction — document scrolling and explicit error reveal
The 002 run executed 132 checks before a real narrow keyboard-recovery failure: email was focused while below the visible area. The primary designer opened that failed capture. The sticky action footer also visibly covered part of the notification switch in the 900px overview. That candidate did not retain the desired complete-control relationship. The final implementation restores the original non-sticky, transparent card footer and document scrolling. Validation focuses and centers the first invalid field on the next animation frame after error layout is applied. Native Tabler w-auto/flex utilities now let the existing narrow navigation wrap; the page-header grid gives the title and appearance actions separate mobile rows. Historical captures and the failed 002 report remain unmodified. Final revision evidence is the 003 run.

The earlier viewport attempt ended after 55 checks because the captured preview server reached its explicit 600-second timeout. It is infrastructure evidence, not a product failure. Its command and captures remain available; the server restart is separately captured.

### Focus timing correction
Run 003 reached 134 checks but its Save hit-test failed after success. Personally viewed captures also showed validation focus while the source's smooth scroll was still progressing. The distributed CSS explicitly contains scroll-behavior:smooth. The final behavior adapter uses native instant scrolling for error reveal and section navigation, and restores focus to Save after pending only when the submit button originally had focus and the user has not focused another control. This also reveals the action after feedback grows. Run 004 adds an explicit viewport-bounds assertion for the invalid field. No distribution styles or store rules changed.
