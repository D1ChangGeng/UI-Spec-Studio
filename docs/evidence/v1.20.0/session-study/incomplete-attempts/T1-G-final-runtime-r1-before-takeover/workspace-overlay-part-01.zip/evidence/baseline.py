from pathlib import Path
from playwright.sync_api import sync_playwright
import json, time, re

ROOT=Path(__file__).resolve().parents[1]
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=BROWSER,headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
    logs=[]
    page.on('pageerror',lambda error:logs.append(str(error)))
    for theme,lang,w,h in [('light','en',1440,900),('dark','zh',1280,600),('light','en',390,844)]:
        page.set_viewport_size({'width':w,'height':h})
        page.goto(f'http://127.0.0.1:4404/?theme={theme}&lang={lang}',wait_until='networkidle')
        page.evaluate('document.fonts.ready')
        page.screenshot(path=str(ROOT/f'evidence/screenshots/baseline-{theme}-{lang}-{w}x{h}.png'))
        logs.append({'subject':'baseline','theme':theme,'lang':lang,'viewport':[w,h],'body':page.locator('#content').inner_text(),'scrollWidth':page.evaluate('document.documentElement.scrollWidth')})
    page.set_viewport_size({'width':1440,'height':900})
    original=(ROOT/'sources/official-settings-snapshot.html').read_text()
    original=original.replace('<head>','<head><base href="http://127.0.0.1:4404/">')
    page.set_content(original,wait_until='networkidle')
    page.evaluate("document.documentElement.setAttribute('data-bs-theme','light')")
    page.screenshot(path=str(ROOT/'evidence/screenshots/source-settings-local-1440x900.png'))
    (ROOT/'evidence/baseline-observations.json').write_text(json.dumps(logs,indent=2,ensure_ascii=False))
    browser.close()
print(json.dumps({'captures':4,'browser':BROWSER,'evidence':'evidence/baseline-observations.json'}))
