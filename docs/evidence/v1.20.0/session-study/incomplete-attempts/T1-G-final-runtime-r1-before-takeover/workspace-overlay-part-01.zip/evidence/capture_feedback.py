from pathlib import Path
from playwright.sync_api import sync_playwright
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence/feedback-final';OUT.mkdir(exist_ok=True)
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
log={'subject':'Final feedback views; separate fresh-context episodes without edits while pending','source_sha256':hashlib.sha256((ROOT/'app/settings-controller.js').read_bytes()).hexdigest(),'frames':[]}
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=BROWSER,headless=True,args=['--no-sandbox'])
 for theme in ['light','dark']:
  for lang in ['en','zh']:
   page=b.new_page(viewport={'width':1280,'height':600},device_scale_factor=1)
   page.goto(f'http://127.0.0.1:4404/?theme={theme}&lang={lang}&fail=once',wait_until='networkidle')
   page.locator('#business-name').fill('Mei')
   page.locator('#save-settings').click()
   for state in ['pending','error']:
    page.wait_for_function('(s)=>document.querySelector("#save-status").dataset.state===s',arg=state)
    before=page.evaluate('performance.now()')
    name=f'{theme}-{lang}-{state}'
    page.screenshot(path=str(OUT/(name+'.png')))
    log['frames'].append({'name':name,'before_ms':before,'after_ms':page.evaluate('performance.now()'),'status':page.locator('#save-status').inner_text(),'scrollY':page.evaluate('scrollY'),'focus':page.evaluate('document.activeElement.id')})
   page.locator('#save-settings').click()
   page.wait_for_function('document.querySelector("#save-status").dataset.state==="success"')
   name=f'{theme}-{lang}-success'
   before=page.evaluate('performance.now()')
   page.screenshot(path=str(OUT/(name+'.png')))
   log['frames'].append({'name':name,'before_ms':before,'after_ms':page.evaluate('performance.now()'),'status':page.locator('#save-status').inner_text(),'scrollY':page.evaluate('scrollY'),'focus':page.evaluate('document.activeElement.id')})
   page.close()
 b.close()
(ROOT/'evidence/feedback-final.json').write_text(json.dumps(log,ensure_ascii=False,indent=2))
print(json.dumps({'frames':len(log['frames']),'source_sha256':log['source_sha256']}))
