# Settings boundary challenge

## Scope and evidence

Read-only inquiry into the current settings controller/store and the planned source-preserving repair. No product files changed and no acceptance judgment made. The Tabler 1.7.1 family remains the appropriate boundary; these findings call for state wiring, supported validation/status components and content repair.

Executed isolated Chrome 143 at 1280×600 with FONTCONFIG_FILE=/tmp/ui-spec-fonts/fonts.conf against http://127.0.0.1:4404. Fresh browser contexts isolated storage. Source identities and raw browser observations are in browser-observations.json. Controller SHA-256 at capture: e60170f1f3bdd6b9495c20bd08dc8e5870287dda877266c58c5184ca6942a952. The main agent may be changing this source; these observations describe that captured baseline.

Personally opened all three PNGs with view_image; full tool responses are retained in view-01.json through view-03.json. These are static views and controlled action/state observations, not natural-time playback or whole-product acceptance.

## Concrete findings

1. **Cancel can contradict the eventual persisted result.** In the pending state Save was disabled and Cancel remained enabled. Cancel restored the old persisted values, but the request subsequently saved its captured snapshot and reported success while the fields still showed the old values. Disabling Cancel for the pending interval is justified; do not represent it as request cancellation because the store offers no abort contract.

2. **Success currently overstates what was saved.** Submitting “Submitted snapshot A”, then editing to “Later draft B” and changing weekly digest left B visible while storage contained A and the old digest. The status still said “Changes saved in this browser.” Keep the confirmed saved snapshot separate from the live draft; derive whether newer changes remain from all six field values. Success must not write the submitted snapshot back into fields when newer edits exist. The recorded intermediate sample named “during” had already reached success after the UI action sequence, so it does not establish every action occurred inside the 750 ms interval.

3. **Language switching destroys drafts and can reverse theme changes.** Switching language after the preceding case replaced B with persisted A and restored the original digest. A dark theme toggle also reverted to light because the URL still contained theme=light and locale switching navigated. In-place localization must retain the actual inputs, selection/focus where feasible, field errors, dirty state and pending operation. Keep URL and current theme preference coherent. Reloading also re-arms ?fail=once, so navigation-based locale changes can accidentally turn one failure into repeated failures.

4. **Authoritative errors currently lack usable field presentation.** Empty name, 181-character organization, 101-character location and malformed email produced only a generic status. All four inputs lacked aria-invalid, aria-describedby and invalid classes. Focus stayed on Save. In 01-invalid.png, the status is above the visible viewport after Save, while the invalid fields carry no error explanation. Bind the store's fieldErrors into Tabler invalid feedback and field association; arrange recovery so the person reaches the first invalid field and perceives the summary at compact height.

5. **Failure/retry already preserves an important behavior.** The zh/dark fail-once case retained the newer draft and previous persistence after failure, then saved the latest draft successfully on retry. Preserve this property. In 03-failed-newer-draft-zh-dark.png, the top status is outside the visible viewport, so useful failure feedback still needs a reachable placement or deliberate focus/announcement behavior.

## High-value verification cases for the repair

- **Snapshot versus live draft:** submit A; inside the actual 750 ms interval edit text and both switches to B; switch language and theme; confirm only submit/Cancel are disabled. On success storage equals A, controls equal B, and localized feedback says newer edits remain. A second save must commit B.
- **Values, not merely “was edited”:** after submitting A, change a field to B and back to A before resolution. Final equal values should not be reported as unsaved merely because an input event occurred.
- **Failure and retry:** start from a non-default saved value; fail a valid submission while editing further; confirm saved value remains untouched and the newest draft survives. Retry through keyboard submission; verify the newest draft, then reload and Cancel.
- **Cancel source:** after a completed save and later edits, Cancel must reload persistence, including all switches; it must clear stale errors/status consistently. An unreadable-storage error must preserve the current draft rather than load initial defaults as though restoration succeeded.
- **Authoritative validation:** blank and whitespace-only name; exact 100/101 name and location lengths; 180/181 organization; malformed email; simultaneous errors; correcting one field; changing locale while errors remain. Preserve String.length and the store's email syntax/normalization behavior. Adding a semantic form must not let native constraints bypass the authoritative error path; avoid silently truncating entered values.
- **Duplicate actions:** rapid clicks, Enter, and Enter immediately after a click must produce a single pending UI request. Saving and Cancel are disabled while pending; text, checkboxes, language, theme and section navigation remain usable.
- **Compact recovery:** keyboard-only invalid submit, focus reveal, correction, service failure and retry at 1280×600 and 390×844, with both locales/themes. Check actual visible focus and the error/status position after scrolling; a top status alone is insufficient evidence.
- **No semantics drift:** toggling public profile must never imply email disclosure; weekly digest and visibility state labels must follow the live checkbox and localize without changing values.

## Sources and remaining uncertainty

Authoritative local sources: INPUT.md, app/settings-store.js, app/settings-controller.js and app/index.html. Current forms guidance search/retrieve outputs are captured under guidance-search-001 and guidance-retrieve-001. Applicable points include semantic submission, associated errors, live announcements and duplicate-submit prevention. Generic native-constraint and styling examples must not override this project's store authority or Tabler family. The CLI reported a newer skill revision; no installed skill was changed.

No 390×844, 1440×900, full keyboard journey, screen-reader output, post-repair behavior or temporal smoothness was verified by this inquiry. Main agent retains implementation, final source/visual decisions and integrated verification.

