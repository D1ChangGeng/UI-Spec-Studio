**The planned state repair is warranted; the observed problems can be addressed while preserving Tabler 1.7.1.** I made no product edits and no acceptance judgment.

### Observed boundary failures

- **Cancel during pending creates conflicting state.** Cancel restored old persisted values while the outstanding request continued. After 750 ms, storage contained the submitted snapshot, the form displayed the old values, and feedback announced success. Disable Cancel for that interval; the store has no cancellation contract.
- **Success currently overstates what was saved.** After submitting A and editing to B, storage contained A and the controls retained B, but feedback said “Changes saved in this browser.” Track the confirmed snapshot separately from the live draft and report when newer edits remain.
- **Language changes lose drafts and can reverse theme changes.** Locale switching restored the saved snapshot and discarded later text/switch edits. A dark toggle also reverted to light because the URL retained `theme=light` and language switching navigated. Preserve state through in-place localization and keep theme/URL preferences coherent.
- **Authoritative field errors have no field association.** Four simultaneous invalid inputs produced only generic feedback, with no `aria-invalid`, associated descriptions or invalid styling. Focus remained on Save. At 1280×600, the generic status was above the visible viewport after submission, leaving no visible explanation beside the invalid controls.
- **Failure/retry already preserves valuable behavior.** In Chinese/dark mode, a failed save retained the newest draft and previous persistence; retry saved that latest draft. Preserve this while repairing feedback visibility.

These observations describe the captured baseline, controller SHA beginning `e60170f1`. The parent’s subsequent edits require fresh verification.

### Most useful verification cases

1. **Submit A, edit to B during the actual 750 ms interval, then switch locale/theme.** Confirm only Save and Cancel are disabled. Completion must leave storage=A, controls=B and accurate localized feedback; the next save commits B.
2. **Edit A→B→A while pending.** Determine unsaved state from actual values across all six fields, rather than an input-event flag.
3. **Fail while further editing, then retry by keyboard.** Confirm persistence stays unchanged after failure, the newest draft survives, and retry saves it.
4. **Cancel after success and later edits.** Restore actual persistence, including switches, and clear stale error state. If reading storage fails, retain the draft and expose that failure.
5. **Validate through the authoritative store.** Cover blank/whitespace name, exact 100/101 and 180/181 boundaries, malformed email, simultaneous errors and localization while errors remain. A new semantic form must not let browser constraints bypass the store’s error path or silently truncate entered values.
6. **Exercise duplicate submission and compact recovery.** Rapid clicks and Enter must produce one UI request. Verify field editing, checkboxes and appearance controls remain usable during pending; inspect focus and reachable feedback at 1280×600 and 390×844.

### Evidence and limits

The [REPORT.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w04/evidence/challenger/REPORT.md) contains the complete findings and verification recommendations. [browser-observations.json](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w04/evidence/challenger/browser-observations.json) preserves raw states and source digests. Three screenshots, their actual `view_image` responses, and current forms-guidance captures are retained in the same directory.

I personally inspected all three screenshots. This inquiry did **not** verify the repaired version, narrow layout, a complete keyboard journey, screen-reader output or natural-time smoothness. The intermediate sample labelled “during” in one scenario had already reached success, so it does not establish that every appearance-control action occurred within the pending interval.
