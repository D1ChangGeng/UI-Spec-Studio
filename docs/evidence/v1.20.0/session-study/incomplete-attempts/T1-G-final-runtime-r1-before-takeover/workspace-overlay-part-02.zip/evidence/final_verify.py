from pathlib import Path
from playwright.sync_api import sync_playwright
import hashlib,json,time,traceback,sys

ROOT=Path(__file__).resolve().parents[1]
RUN=sys.argv[1] if len(sys.argv)>1 else '002'
OUT=ROOT/f'evidence/final-captures-{RUN}'
OUT.mkdir(exist_ok=True)
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
LONG='跨城市田野研究协作小组 — Longitudinal everyday-mobility research programme'
record={'browser':BROWSER,'fontconfig':'/tmp/ui-spec-fonts/fonts.conf','deviceScaleFactor':1,'source':{},'checks':[],'captures':[],'page_errors':[]}
for name in ['index.html','settings-controller.js','settings-store.js','dist/css/tabler.min.css']:
 record['source'][name]=hashlib.sha256((ROOT/'app'/name).read_bytes()).hexdigest()

def check(label,value,detail=None):
 record['checks'].append({'check':label,'pass':bool(value),'detail':detail})
 if not value: raise AssertionError(label+' '+str(detail))

def observe(page):
 return page.evaluate('''()=>({time:performance.now(),state:document.querySelector('#save-status').dataset.state,status:document.querySelector('#save-status').textContent,draft:window.fieldnotes.draft(),saved:window.fieldnotes.readSettings(),storage:localStorage.getItem('fieldnotes-settings-v1'),focus:document.activeElement.id,theme:document.documentElement.dataset.bsTheme,lang:document.documentElement.lang,scrollY,scrollWidth:document.documentElement.scrollWidth,url:location.href})''')

def snap(page,name):
 before=observe(page)
 page.screenshot(path=str(OUT/(name+'.png')))
 after=observe(page)
 record['captures'].append({'name':name,'viewport':page.viewport_size,'before':before,'after':after,'clock':'browser performance.now; brackets include screenshot overhead'})

def ready(page,theme,lang,fail=False):
 page.on('pageerror',lambda e:record['page_errors'].append(str(e)))
 page.goto(f'http://127.0.0.1:4404/?theme={theme}&lang={lang}'+('&fail=once' if fail else ''),wait_until='networkidle')
 page.evaluate('document.fonts.ready')
 page.wait_for_function('!!window.fieldnotes')

def wait_state(page,state):
 page.wait_for_function('(state)=>document.querySelector("#save-status").dataset.state===state',arg=state)

def tab_to(page,identifier):
 for _ in range(70):
  if page.evaluate('document.activeElement.id')==identifier: return
  page.keyboard.press('Tab')
 raise AssertionError('Keyboard could not reach '+identifier)

try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path=BROWSER,headless=True,args=['--no-sandbox'])
  # Same content and conditions across the complete requested primary-state matrix.
  for w,h in [(1440,900),(1280,600),(390,844)]:
   for theme in ['light','dark']:
    for lang in ['en','zh']:
     page=browser.new_page(viewport={'width':w,'height':h},device_scale_factor=1)
     ready(page,theme,lang)
     label=f'{theme}-{lang}-{w}x{h}'
     page.locator('#business-name').fill('Mei')
     page.evaluate('scrollTo({top:0,behavior:"instant"})')
     snap(page,label+'-top-short')
     page.locator('#business-name').fill(LONG)
     page.locator('#business-id').fill(LONG)
     page.locator('#profile-heading').scroll_into_view_if_needed()
     snap(page,label+'-profile-long')
     fit=page.locator('#business-name').evaluate('(e)=>({client:e.clientHeight,scroll:e.scrollHeight})')
     check(label+' long name fully visible',fit['scroll']<=fit['client']+1,fit)
     check(label+' no horizontal page overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
     page.locator('#settings-nav a[href="#privacy-heading"]').click()
     snap(page,label+'-privacy')
     check(label+' section navigation focus',page.evaluate('document.activeElement.id')=='privacy-heading')
     check(label+' privacy draft retained',page.locator('#business-name').input_value()==LONG)
     page.locator('#settings-nav a[href="#profile-heading"]').click()
     check(label+' return to profile',page.evaluate('document.activeElement.id')=='profile-heading')
     page.close()
  # Real 750 ms pending/failure/retry path, every language/theme pair at compact height.
  for theme in ['light','dark']:
   for lang in ['en','zh']:
    page=browser.new_page(viewport={'width':1280,'height':600},device_scale_factor=1)
    ready(page,theme,lang,True)
    label=f'episode-{theme}-{lang}'
    page.locator('#business-name').fill('Submitted A')
    page.locator('#weekly-digest').uncheck()
    page.locator('#public-profile').check()
    snap(page,label+'-before')
    page.locator('#save-settings').click()
    check(label+' pending buttons',page.locator('#save-settings').is_disabled() and page.locator('#cancel-settings').is_disabled())
    check(label+' inputs remain editable',page.locator('#business-name').is_editable())
    page.locator('#business-name').fill('Newer B')
    check(label+' edited during real pending',observe(page)['state']=='pending')
    snap(page,label+'-pending-edited')
    wait_state(page,'error')
    snap(page,label+'-error')
    check(label+' failure preserves persistence',observe(page)['storage'] is None)
    check(label+' failure preserves newest draft',page.locator('#business-name').input_value()=='Newer B')
    page.locator('#save-settings').click()
    snap(page,label+'-retry-pending')
    wait_state(page,'success')
    snap(page,label+'-success')
    check(label+' retry committed newest draft',observe(page)['saved']['displayName']=='Newer B')
    page.reload(wait_until='networkidle')
    check(label+' reload persistence',page.locator('#business-name').input_value()=='Newer B' and page.locator('#public-profile').is_checked() and not page.locator('#weekly-digest').is_checked())
    page.locator('#business-name').fill('Discarded')
    page.locator('#public-profile').uncheck()
    page.locator('#cancel-settings').click()
    check(label+' cancel restores real persistence',page.locator('#business-name').input_value()=='Newer B' and page.locator('#public-profile').is_checked())
    page.locator('#business-name').fill('   ')
    page.locator('#business-id').fill('o'*181)
    page.locator('#location').fill('l'*101)
    page.locator('#email').fill('bad')
    page.locator('#save-settings').click()
    wait_state(page,'invalid')
    snap(page,label+'-invalid')
    check(label+' four authoritative associated errors',page.locator('#settings-form [aria-invalid="true"]').count()==4)
    check(label+' invalid focus',page.evaluate('document.activeElement.id')=='business-name')
    check(label+' invalid persistence unchanged',observe(page)['saved']['displayName']=='Newer B')
    association=page.locator('#settings-form [aria-invalid="true"]').evaluate_all('(els)=>els.every(e=>e.getAttribute("aria-describedby").split(" ").some(id=>document.getElementById(id)?.classList.contains("invalid-feedback")&&document.getElementById(id).textContent.length))')
    check(label+' error descriptions resolve',association)
    page.locator('#language-toggle').click()
    check(label+' locale preserves invalid fields',page.locator('#settings-form [aria-invalid="true"]').count()==4 and page.locator('#business-id').input_value()=='o'*181)
    page.locator('#business-name').fill('n'*100)
    page.locator('#business-id').fill('o'*180)
    page.locator('#location').fill('l'*100)
    page.locator('#email').fill('valid@example.invalid')
    page.locator('#save-settings').click()
    wait_state(page,'error') # Reload of ?fail=once intentionally re-arms the explicit fixture.
    page.locator('#save-settings').click()
    wait_state(page,'success')
    check(label+' exact length boundaries accepted',len(observe(page)['saved']['displayName'])==100 and len(observe(page)['saved']['organization'])==180 and len(observe(page)['saved']['location'])==100)
    page.locator('#business-name').fill('n'*101)
    page.locator('#save-settings').click()
    wait_state(page,'invalid')
    check(label+' 101 name rejected',page.locator('#business-name').get_attribute('aria-invalid')=='true')
    page.close()
  # Snapshot success, appearance continuity, duplicate request and value equality.
  page=browser.new_page(viewport={'width':1280,'height':600},device_scale_factor=1)
  ready(page,'light','en')
  page.evaluate('async()=>{window.storeEvents=[];const s=await import("/settings-store.js");s.subscribeSettings(e=>storeEvents.push({status:e.status,id:e.operationId,t:performance.now()}))}')
  page.locator('#business-name').fill('Snapshot A')
  page.locator('#save-settings').focus()
  page.keyboard.press('Enter')
  page.keyboard.press('Enter')
  page.keyboard.press('Enter')
  page.locator('#business-name').fill('Draft B')
  # DOM click invokes real visible appearance-control handlers immediately, keeping this exact race inside 750 ms.
  page.evaluate('()=>{document.querySelector("#language-toggle").click();document.querySelector("#theme-toggle").click();document.querySelector("#weekly-digest").click();document.querySelector("#public-profile").click()}')
  check('snapshot controls changed during real pending',observe(page)['state']=='pending')
  snap(page,'snapshot-pending-zh-dark')
  wait_state(page,'success')
  snap(page,'snapshot-success-newer-zh-dark')
  observed=observe(page)
  check('snapshot saved A while controls retain B',observed['saved']['displayName']=='Snapshot A' and observed['draft']['displayName']=='Draft B',observed)
  check('newer edits announced in Chinese','仍未保存' in observed['status'])
  check('theme and locale survive and URL agrees',observed['theme']=='dark' and observed['lang']=='zh-CN' and 'theme=dark' in observed['url'] and 'lang=zh' in observed['url'])
  events=page.evaluate('storeEvents')
  check('duplicate Enter produces one save',len([e for e in events if e['status']=='pending'])==1,events)
  page.locator('#save-settings').click(); wait_state(page,'success')
  check('second save commits later edits',observe(page)['saved']==observe(page)['draft'])
  page.locator('#business-name').fill('Final A')
  page.locator('#save-settings').click()
  page.locator('#business-name').fill('Temporary B')
  page.locator('#business-name').fill('Final A')
  check('A B A edits inside pending',observe(page)['state']=='pending')
  wait_state(page,'success')
  check('actual equality removes unsaved claim','仍未保存' not in observe(page)['status'])
  page.locator('#business-name').fill('Draft before unreadable storage')
  page.evaluate('localStorage.setItem("fieldnotes-settings-v1","broken")')
  page.locator('#cancel-settings').click()
  check('failed Cancel read preserves live draft',page.locator('#business-name').input_value()=='Draft before unreadable storage')
  check('unreadable persistence is not overwritten',page.evaluate('localStorage.getItem("fieldnotes-settings-v1")')=='broken' and page.locator('#save-settings').is_disabled())
  page.close()
  # Complete keyboard-only narrow path from the source skip link through failure/retry.
  page=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
  ready(page,'light','en',True)
  page.keyboard.press('Tab'); page.keyboard.press('Enter')
  tab_to(page,'business-name')
  page.keyboard.press('Control+a');page.keyboard.insert_text(LONG)
  snap(page,'keyboard-narrow-name-focus')
  page.keyboard.press('Tab');page.keyboard.press('Control+a');page.keyboard.insert_text(LONG)
  page.keyboard.press('Tab');page.keyboard.press('Control+a');page.keyboard.insert_text('Singapore / 新加坡')
  page.keyboard.press('Tab');page.keyboard.press('Control+a');page.keyboard.insert_text('bad')
  page.keyboard.press('Tab');page.keyboard.press('Space')
  page.keyboard.press('Tab');page.keyboard.press('Space')
  page.keyboard.press('Tab');page.keyboard.press('Tab');page.keyboard.press('Enter')
  wait_state(page,'invalid')
  snap(page,'keyboard-narrow-email-invalid-focus')
  check('keyboard invalid focuses email',page.evaluate('document.activeElement.id')=='email')
  box=page.locator('#email').bounding_box();foot=page.locator('#settings-form .card-footer').bounding_box()
  check('keyboard error field is within viewport',box['y']>=0 and box['y']+box['height']<=844,box)
  check('keyboard focused field clears action footer',box['y']+box['height']<=foot['y'],{'field':box,'footer':foot})
  page.keyboard.press('Control+a');page.keyboard.insert_text('keyboard@example.invalid')
  tab_to(page,'save-settings');page.keyboard.press('Enter')
  wait_state(page,'error');snap(page,'keyboard-narrow-failed')
  tab_to(page,'save-settings');page.keyboard.press('Enter')
  wait_state(page,'success');snap(page,'keyboard-narrow-success')
  check('keyboard retry saved real values',observe(page)['saved']['email']=='keyboard@example.invalid' and observe(page)['saved']['displayName']==LONG)
  hit=page.locator('#save-settings').evaluate('(e)=>{const r=e.getBoundingClientRect();return e.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}')
  check('narrow Save is not covered by floating demo button',hit)
  page.reload(wait_until='networkidle')
  check('keyboard result persists after reload',page.locator('#email').input_value()=='keyboard@example.invalid')
  page.close();browser.close()
 check('no JavaScript page errors',not record['page_errors'],record['page_errors'])
 record['completed']=True
except Exception as error:
 record['completed']=False;record['failure']=str(error);record['traceback']=traceback.format_exc()
 print(record['traceback'])
finally:
 (ROOT/f'evidence/final-verification-{RUN}.json').write_text(json.dumps(record,ensure_ascii=False,indent=2))
 print(json.dumps({'completed':record['completed'],'checks':len(record['checks']),'captures':len(record['captures']),'failure':record.get('failure')},ensure_ascii=False))
 if not record['completed']: raise SystemExit(1)
