from pathlib import Path
from playwright.sync_api import sync_playwright
import json,time
ROOT=Path(__file__).resolve().parents[1]
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
LONG='跨城市田野研究协作小组 — Longitudinal everyday-mobility research programme'
logs=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=BROWSER,headless=True,args=['--no-sandbox'])
 for theme,lang,w,h in [('light','en',1440,900),('dark','zh',1280,600),('light','en',390,844)]:
  page=b.new_page(viewport={'width':w,'height':h},device_scale_factor=1)
  page.on('pageerror',lambda error:logs.append({'pageerror':str(error)}))
  page.goto(f'http://127.0.0.1:4404/?theme={theme}&lang={lang}',wait_until='networkidle')
  page.evaluate('document.fonts.ready')
  page.screenshot(path=str(ROOT/f'evidence/screenshots/trial-{theme}-{lang}-{w}x{h}-top.png'))
  page.locator('#business-name').fill(LONG)
  page.locator('#business-id').fill(LONG)
  page.locator('#email').scroll_into_view_if_needed()
  page.screenshot(path=str(ROOT/f'evidence/screenshots/trial-{theme}-{lang}-{w}x{h}-fields.png'))
  page.locator('#privacy-heading').scroll_into_view_if_needed()
  page.screenshot(path=str(ROOT/f'evidence/screenshots/trial-{theme}-{lang}-{w}x{h}-bottom.png'))
  logs.append({'viewport':[w,h],'theme':theme,'lang':lang,'scrollWidth':page.evaluate('document.documentElement.scrollWidth'),'controls':page.locator('#settings-form').count(),'textarea':page.locator('#business-name').evaluate('(e)=>({height:e.clientHeight,scrollHeight:e.scrollHeight})'),'text':page.locator('#settings-form').inner_text()})
  page.close()
 b.close()
(ROOT/'evidence/trial-observations.json').write_text(json.dumps(logs,ensure_ascii=False,indent=2))
print(json.dumps(logs,ensure_ascii=False))
