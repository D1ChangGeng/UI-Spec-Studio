import { INITIAL_SETTINGS, readSettings, saveSettings, subscribeSettings, setFailureMode } from './settings-store.js';

const ids = {displayName:'business-name',organization:'business-id',location:'location',email:'email',weeklyDigest:'weekly-digest',publicProfile:'public-profile'};
const fields = Object.fromEntries(Object.entries(ids).map(([key,id]) => [key,document.getElementById(id)]));
const form = document.getElementById('settings-form');
const status = document.getElementById('save-status');
const save = document.getElementById('save-settings');
const cancel = document.getElementById('cancel-settings');
let lang = new URLSearchParams(location.search).get('lang') === 'zh' ? 'zh' : 'en';
let saved, submitted, state='idle', fieldErrors={}, readFailed=false, activeOperation=null;

const messages = {
  en: {
    pageTitle:'Account settings', accountNav:'Account settings', myAccount:'My account', profileDetails:'Profile details',
    displayName:'Display name', organization:'Organization', location:'Location', email:'Email',
    nameHint:'Required. Up to 100 characters.', localHint:'Your settings are saved only in this browser.',
    emailHint:'Used for workspace notifications. Your email always stays private.',
    notifications:'Notifications', digestHint:'Receive a weekly digest of research notes shared with your workspace.',
    digestOn:'Weekly digest is on', digestOff:'Weekly digest is off', privacy:'Privacy', publicProfile:'Public profile',
    privacyHint:'Let other workspace members find your profile. Your email stays private.',
    profileOn:'Profile visibility: on', profileOff:'Profile visibility: off', plans:'Plans', billing:'Billing & invoices',
    experience:'Experience', feedback:'Give feedback', cancel:'Cancel', save:'Save changes', retry:'Try again',
    lightTheme:'Use light theme', darkTheme:'Use dark theme', idle:'No unsaved changes.', dirty:'You have unsaved changes.',
    pending:'Saving your submitted changes…', pendingEdited:'Saving submitted changes. Newer edits remain unsaved.',
    success:'Changes saved in this browser.', successEdited:'Submitted changes saved. Your newer edits are still unsaved.',
    error:'Save did not complete. Your latest draft is still here. Try again.',
    invalid:'Check the highlighted fields, then save again.', cancelled:'Saved settings restored. Unsaved changes were discarded.',
    readError:'Saved settings could not be read. Existing data is unchanged. Reload to try again.',
    errors:{'Add a display name.':'Add a display name.','Use 100 characters or fewer.':'Use 100 characters or fewer.','Use 180 characters or fewer.':'Use 180 characters or fewer.','Enter a complete email address.':'Enter a complete email address.'}
  },
  zh: {
    pageTitle:'账户设置', accountNav:'账户设置', myAccount:'我的账户', profileDetails:'个人资料',
    displayName:'显示名称', organization:'机构', location:'地点', email:'电子邮箱',
    nameHint:'必填，最多 100 个字符。', localHint:'你的设置仅保存在当前浏览器中。',
    emailHint:'用于接收工作区通知。电子邮箱始终保持私密。',
    notifications:'通知', digestHint:'每周接收工作区共享研究笔记的摘要。',
    digestOn:'每周摘要已开启', digestOff:'每周摘要已关闭', privacy:'隐私', publicProfile:'公开个人资料',
    privacyHint:'允许其他工作区成员找到你的个人资料。电子邮箱仍保持私密。',
    profileOn:'个人资料可见性：已开启', profileOff:'个人资料可见性：已关闭', plans:'方案', billing:'账单与发票',
    experience:'使用体验', feedback:'提供反馈', cancel:'取消', save:'保存更改', retry:'重试',
    lightTheme:'使用浅色主题', darkTheme:'使用深色主题', idle:'没有未保存的更改。', dirty:'你有尚未保存的更改。',
    pending:'正在保存已提交的更改…', pendingEdited:'正在保存已提交的更改。之后的编辑尚未保存。',
    success:'更改已保存到当前浏览器。', successEdited:'已提交的更改已保存。之后的编辑仍未保存。',
    error:'保存未完成。最新草稿仍然保留，请重试。', invalid:'请检查标出的字段，然后重新保存。',
    cancelled:'已恢复保存的设置，未保存的更改已丢弃。', readError:'无法读取已保存的设置。原有数据未更改，请重新加载后重试。',
    errors:{'Add a display name.':'请输入显示名称。','Use 100 characters or fewer.':'请使用 100 个字符以内的内容。','Use 180 characters or fewer.':'请使用 180 个字符以内的内容。','Enter a complete email address.':'请输入完整的电子邮箱地址。'}
  }
};
const text=key=>messages[lang][key];
function draft() { return Object.fromEntries(Object.entries(fields).map(([key,el])=>[key,el.type==='checkbox'?el.checked:el.value])); }
function equal(a,b) { return !!a && !!b && Object.keys(ids).every(key=>a[key]===b[key]); }
function fill(data) { for(const [key,el] of Object.entries(fields)) { if(el.type==='checkbox') el.checked=data[key]; else el.value=data[key]; } }
function renderErrors() {
  for(const [key,el] of Object.entries(fields)) {
    const error=document.getElementById(`${key}-error`);
    if(!error) continue;
    const message=fieldErrors[key];
    el.classList.toggle('is-invalid',!!message);
    if(message) el.setAttribute('aria-invalid','true'); else el.removeAttribute('aria-invalid');
    error.textContent=message ? messages[lang].errors[message] || message : '';
  }
}
function renderStatus() {
  const pending=state==='pending';
  let key=state;
  if(pending && !equal(draft(),submitted)) key='pendingEdited';
  if(state==='success' && !equal(draft(),saved)) key='successEdited';
  if(readFailed) key='readError';
  status.textContent=text(key);
  status.dataset.state=state;
  status.className=(state==='error'||state==='invalid'||readFailed) ? 'alert alert-danger mb-3' : state==='success' ? 'alert alert-success mb-3' : 'text-secondary mb-3';
  save.disabled=pending||readFailed;
  cancel.disabled=pending;
  save.classList.toggle('btn-loading',pending);
  save.setAttribute('aria-busy',String(pending));
  save.textContent=text(pending?'pending':state==='error'?'retry':'save');
  form.dataset.state=state;
}
function renderTheme() {
  const dark=document.documentElement.getAttribute('data-bs-theme')==='dark';
  document.getElementById('theme-toggle').textContent=text(dark?'lightTheme':'darkTheme');
}
function renderLanguage() {
  document.documentElement.lang=lang==='zh'?'zh-CN':'en';
  document.title=lang==='zh'?'Fieldnotes — 账户设置':'Fieldnotes — Account settings';
  document.querySelectorAll('[data-i18n]').forEach(el=>el.textContent=text(el.dataset.i18n));
  document.getElementById('settings-nav').setAttribute('aria-label',text('accountNav'));
  const toggle=document.getElementById('language-toggle');
  toggle.textContent=lang==='zh'?'English':'简体中文';
  toggle.lang=lang==='zh'?'en':'zh-CN';
  renderErrors(); renderTheme(); renderStatus();
}
function updateURL(key,value) {
  const url=new URL(location.href); url.searchParams.set(key,value); history.replaceState(null,'',url);
}
function load() {
  saved=readSettings(); readFailed=false; fill(saved); fieldErrors={};
  const name=String(saved.displayName).trim();
  document.getElementById('profile-avatar').textContent=name.split(/\s+/).slice(0,2).map(part=>Array.from(part)[0]).join('').toUpperCase();
}
subscribeSettings(event=>{
  if(event.status==='invalid') { fieldErrors=event.fieldErrors; state='invalid'; renderErrors(); renderStatus(); fields[Object.keys(fieldErrors)[0]]?.focus(); return; }
  if(event.status==='pending') { activeOperation=event.operationId; submitted=event.snapshot; state='pending'; }
  if(event.status!=='pending' && activeOperation!==event.operationId) return;
  if(event.status==='success') { saved=event.settings; state='success'; activeOperation=null; }
  if(event.status==='error') { state='error'; activeOperation=null; }
  renderStatus();
});
form.addEventListener('submit',async event=>{
  event.preventDefault(); if(state==='pending'||readFailed) return;
  fieldErrors={}; renderErrors();
  try { await saveSettings(draft()); } catch { /* The store event supplies the authoritative error. */ }
});
for(const [key,el] of Object.entries(fields)) {
  el.addEventListener('input',()=>{
    delete fieldErrors[key]; renderErrors();
    if(state!=='pending' && state!=='error') state=Object.keys(fieldErrors).length?'invalid':equal(draft(),saved)?'idle':'dirty';
    renderStatus();
  });
}
cancel.addEventListener('click',()=>{
  if(state==='pending') return;
  try { load(); state='cancelled'; } catch { readFailed=true; }
  renderErrors(); renderStatus();
});
document.getElementById('language-toggle').addEventListener('click',()=>{
  lang=lang==='zh'?'en':'zh'; updateURL('lang',lang); renderLanguage();
});
function setTheme(theme) {
  document.documentElement.setAttribute('data-bs-theme',theme);
  try { localStorage.setItem('tabler-theme',theme); } catch { /* Theme still works in this page. */ }
  updateURL('theme',theme); renderTheme();
}
document.getElementById('theme-toggle').addEventListener('click',()=>setTheme(document.documentElement.getAttribute('data-bs-theme')==='dark'?'light':'dark'));
document.querySelectorAll('a[href="?theme=dark"],a[href="?theme=light"]').forEach(link=>link.addEventListener('click',event=>{
  event.preventDefault(); setTheme(new URL(link.href).searchParams.get('theme'));
}));
document.querySelectorAll('#settings-nav a[href^="#"]').forEach(link=>{
  if(link.hash.length<2) return;
  link.addEventListener('click',event=>{
    event.preventDefault();
    document.querySelectorAll('#settings-nav a').forEach(item=>{item.classList.remove('active');item.removeAttribute('aria-current');});
    link.classList.add('active');link.setAttribute('aria-current','location');
    const target=document.querySelector(link.hash);target.focus({preventScroll:true});target.scrollIntoView({block:'start'});
    const url=new URL(location.href);url.hash=link.hash;history.replaceState(null,'',url);
  });
});
try { load(); } catch { readFailed=true;fill(INITIAL_SETTINGS); }
renderLanguage();
window.fieldnotes={readSettings,saveSettings,setFailureMode,draft};
