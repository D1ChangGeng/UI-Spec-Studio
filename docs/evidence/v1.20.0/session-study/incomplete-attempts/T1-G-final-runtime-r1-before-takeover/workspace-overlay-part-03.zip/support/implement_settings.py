from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=ROOT/'app/index.html'
s=p.read_text()
(ROOT/'evidence/starter-index.html').write_text(s)
(ROOT/'evidence/starter-controller.js').write_text((ROOT/'app/settings-controller.js').read_text())
s=s.replace('<h1 class="page-title">Account Settings</h1>', '''<h1 class="page-title" data-i18n="pageTitle">Account settings</h1>
                </div>
                <div class="col-auto ms-auto">
                  <div class="btn-list">
                    <button type="button" class="btn" id="language-toggle" lang="zh-CN">简体中文</button>
                    <button type="button" class="btn" id="theme-toggle">Use dark theme</button>
                  </div>''')
start=s.index('                  <!-- BEGIN SETTINGS NAV -->',s.index('<!-- BEGIN PAGE BODY -->'))
end=s.index('\n                </div>\n              </div>',start)
s=s[:start]+'''                  <!-- BEGIN SETTINGS NAV -->
                  <div class="col-12 col-md-3 border-end">
                    <div class="card-body">
                      <h2 class="subheader" data-i18n="accountNav">Account settings</h2>
                      <nav id="settings-nav" aria-label="Account settings" class="list-group list-group-transparent flex-row flex-wrap flex-md-column">
                        <a href="#profile-heading" class="list-group-item list-group-item-action active d-flex align-items-center" aria-current="location" data-i18n="myAccount">My account</a>
                        <a href="#notifications-heading" class="list-group-item list-group-item-action d-flex align-items-center" data-i18n="notifications">Notifications</a>
                        <a href="#privacy-heading" class="list-group-item list-group-item-action d-flex align-items-center" data-i18n="privacy">Privacy</a>
                        <a href="./settings-plan.html" class="list-group-item list-group-item-action d-flex align-items-center" data-i18n="plans">Plans</a>
                        <a href="#" class="list-group-item list-group-item-action d-flex align-items-center" data-i18n="billing">Billing &amp; invoices</a>
                      </nav>
                      <h2 class="subheader mt-4" data-i18n="experience">Experience</h2>
                      <nav aria-label="Experience" class="list-group list-group-transparent">
                        <a href="#" class="list-group-item list-group-item-action" data-i18n="feedback">Give feedback</a>
                      </nav>
                    </div>
                  </div>
                  <!-- END SETTINGS NAV -->
                  <form id="settings-form" class="col-12 col-md-9 d-flex flex-column" novalidate>
                    <div class="card-body">
                      <h2 class="mb-2" id="profile-heading" tabindex="-1" data-i18n="myAccount">My account</h2>
                      <p class="text-secondary mb-4" data-i18n="localHint">Your settings are saved only in this browser.</p>
                      <div class="row align-items-center mb-3">
                        <div class="col-auto"><span class="avatar" id="profile-avatar" aria-hidden="true">ML</span></div>
                        <div class="col"><h3 class="card-title mb-0" data-i18n="profileDetails">Profile details</h3></div>
                      </div>
                      <div class="row g-3">
                        <div class="col-12">
                          <label class="form-label required" for="business-name" data-i18n="displayName">Display name</label>
                          <textarea class="form-control" id="business-name" name="displayName" autocomplete="name" rows="2" required aria-describedby="displayName-hint displayName-error"></textarea>
                          <div class="invalid-feedback" id="displayName-error"></div>
                          <div class="form-hint" id="displayName-hint" data-i18n="nameHint">Required. Up to 100 characters.</div>
                        </div>
                        <div class="col-md-8">
                          <label class="form-label" for="business-id" data-i18n="organization">Organization</label>
                          <textarea class="form-control" id="business-id" name="organization" autocomplete="organization" rows="2" aria-describedby="organization-error"></textarea>
                          <div class="invalid-feedback" id="organization-error"></div>
                        </div>
                        <div class="col-md-4">
                          <label class="form-label" for="location" data-i18n="location">Location</label>
                          <input type="text" class="form-control" id="location" name="location" autocomplete="address-level2" aria-describedby="location-error" />
                          <div class="invalid-feedback" id="location-error"></div>
                        </div>
                      </div>
                      <div class="mt-4">
                        <label class="form-label required" for="email" data-i18n="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" autocomplete="email" inputmode="email" autocapitalize="off" spellcheck="false" required aria-describedby="email-hint email-error" />
                        <div class="invalid-feedback" id="email-error"></div>
                        <div class="form-hint" id="email-hint" data-i18n="emailHint">Used for workspace notifications. Your email always stays private.</div>
                      </div>
                      <h3 class="card-title mt-4" id="notifications-heading" tabindex="-1" data-i18n="notifications">Notifications</h3>
                      <p class="card-subtitle" id="digest-hint" data-i18n="digestHint">Receive a weekly digest of research notes shared with your workspace.</p>
                      <label class="form-check form-switch form-switch-lg">
                        <input class="form-check-input" type="checkbox" id="weekly-digest" name="weeklyDigest" aria-describedby="digest-hint" />
                        <span class="form-check-label form-check-label-on" data-i18n="digestOn">Weekly digest is on</span>
                        <span class="form-check-label form-check-label-off" data-i18n="digestOff">Weekly digest is off</span>
                      </label>
                      <h3 class="card-title mt-4" id="privacy-heading" tabindex="-1" data-i18n="publicProfile">Public profile</h3>
                      <p class="card-subtitle" id="privacy-hint" data-i18n="privacyHint">Let other workspace members find your profile. Your email stays private.</p>
                      <label class="form-check form-switch form-switch-lg mb-0">
                        <input class="form-check-input" type="checkbox" id="public-profile" name="publicProfile" aria-describedby="privacy-hint" />
                        <span class="form-check-label form-check-label-on" data-i18n="profileOn">Profile visibility: on</span>
                        <span class="form-check-label form-check-label-off" data-i18n="profileOff">Profile visibility: off</span>
                      </label>
                    </div>
                    <div class="card-footer bg-body mt-auto sticky-bottom">
                      <div id="save-status" class="text-secondary mb-3" role="status" aria-live="polite" aria-atomic="true"></div>
                      <div class="btn-list justify-content-end">
                        <button type="button" class="btn" id="cancel-settings" data-i18n="cancel">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="save-settings">Save changes</button>
                      </div>
                    </div>
                  </form>'''+s[end:]
s=s.replace('content="Premium and Open Source dashboard template with responsive and high quality UI."','content="Fieldnotes profile, notification and privacy settings."')
p.write_text(s)
(ROOT/'app/settings-controller.js').write_text((ROOT/'support/controller-next.js').read_text())
print('Updated the settings region and controller using Tabler 1.7.1 classes. Starter code retained in evidence/.')
