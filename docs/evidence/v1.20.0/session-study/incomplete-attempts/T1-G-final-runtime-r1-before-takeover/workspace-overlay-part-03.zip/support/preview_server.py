from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
import os
root=Path(__file__).resolve().parents[1]
(root/'evidence/preview-server-02.pid').write_text(str(os.getpid()))
os.chdir(root/'app')
server=ThreadingHTTPServer(('127.0.0.1',4404),SimpleHTTPRequestHandler)
print('Serving assigned Fieldnotes application on http://127.0.0.1:4404/',flush=True)
try: server.serve_forever()
finally: server.server_close()
