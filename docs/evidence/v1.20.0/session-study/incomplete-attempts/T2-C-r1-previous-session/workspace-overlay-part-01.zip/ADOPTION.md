# Source adoption and decisions

## Provenance

The complete assistant-ui cloud-template family remains the product foundation: repository https://github.com/assistant-ui/assistant-ui, revision ff654d8156680b839774296ef644b57ab1078425, MIT. SOURCE-MANIFEST.json identifies original paths/digests; app/LICENSE retains the notice. FONT-SOURCES.json and OFL notices remain intact. The adoption audit compares all 35 copied source files: exactly three upstream components changed, with one new local label helper. No dependency was added.

## Acquired, observed, adopted

| Resource | Acquisition and observation | Product disposition |
| --- | --- | --- |
| Supplied thread, composer, sidebar, Markdown, File and Dialog | Exact source already supplied; baseline and final application viewed; File public demo viewed | Retained mature family. File and Dialog composed for metadata disclosure; source scroll/renderer options configured |
| assistant-ui File and Thread documentation | Primary web response retained in evidence/source-verification-web.json | Supports published component/API contract, supplemented by actual local behavior tests |
| AI Elements inline/list attachment demos | Research browser captures, source retrieval; compact inline and taller list inspected | Comparison only; no source imported |
| AI Elements full chatbot | Six-line draft, busy and completed mock-response samples viewed | Complete-surface reference only; its extra suggestion rail does not solve Meridian's compact reading budget |
| Zola public product and repository | Empty composer and settled six-line mixed-language draft viewed; attachment population sign-in gated | Independent product reference for upward growth/stable lower actions; no copied implementation |

The research report documents public URLs, licenses where established, failed transfers and temporal limits. Public material provides evidence, not permission to invent a replacement visual system.

## Source-to-product integration

- app/src/components/assistant-ui/elements/attachment.aui.tsx composes the existing File small variant and Dialog around actual filename metadata. The source horizontal composer strip remains bounded; sent files wrap. Focus is explicitly restored after disclosure/removal.
- app/src/components/assistant-ui/elements/thread.aui.tsx retains source layout and controls. It bounds input growth with min(12rem,20dvh), uses bottom anchoring/autoScroll, removes competing CSS smooth behavior, localizes primary task labels, and restores composer focus for keyboard Stop.
- app/src/components/assistant-ui/elements/markdown-text.tsx uses the existing smooth option to settle incomplete messages after cancellation/failure.
- app/src/lib/locale.ts reads the pre-existing document language to select English/Chinese labels.

The supplied synthetic adapter is unedited: local 72-character chunks, approximately 60ms, preserved [fail] recovery, filename-only metadata and no external service. Lockfile and license are unedited. Current protected-file hashes are recorded; the audit honestly distinguishes source-manifest comparisons from files lacking an independently captured before hash.

## Evidence and accepted tradeoffs

evidence/product-changes.patch is the complete diff against saved original component copies plus the locale helper. evidence/adoption-digests.json maps original/current digests. commands/018-adoption-audit captures the actual comparison.

The card row reveals file identity while conserving height, but similar truncated prefixes require disclosure and multiple cards scroll horizontally. The compact textarea shows about five of six lines at 600px height; all text remains reachable internally. Bottom anchoring changes the original new-turn emphasis to continuing latest output while preserving manual scroll-away. These decisions were accepted against the coupled task, not simply for visual novelty.

Failed attempts remain under evidence/commands: top anchor/autoScroll, inherited smooth return, dialog focus, and post-cancel smoothing. Final corrected behavior is supported by commands 015–017 and personally viewed captures; unresolved coverage is explicit in VISUAL-REVIEW.md.

