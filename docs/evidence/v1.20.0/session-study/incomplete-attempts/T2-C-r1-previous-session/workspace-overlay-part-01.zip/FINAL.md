# Meridian conversation workspace — completed

The rebuilt application now connects growing drafts, visible filename identity and user-controlled reading position while retaining the supplied assistant-ui workspace. Source, lockfile, rebuilt `app/dist`, actual test captures and the formal [SPEC.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/SPEC.md) are retained in this work package.

## What changed

**The composer preserves more reading space.** Its existing autosized input now has an available-height ceiling and internal scrolling. At 1280×600, a six-line draft with three files uses **228px instead of 270px**, returning **42px** to the conversation. The one-line input remains 40px, and send/stop/add controls remain visible. The same-family typography, contour, desktop message measure, sidebar and lower action hierarchy remain.

**Attachments identify themselves before opening.** Compact source File rows show the real filename and “Filename only.” A deliberate keyboard/touch action opens the complete wrapping filename in the supplied Dialog. Escape returns to the originating trigger; removing a draft file focuses the composer. Sent filenames wrap within the user message and retain disclosure. The bounded horizontal draft row preserves conversation space; similar truncated names still require opening the full-name dialog.

**Manual reading and explicit return now work together.** The source viewport uses bottom anchoring and autoScroll, with competing smooth-scroll behavior removed. The runtime continues to own scroll intention. Manual scroll-away held its position through further answer chunks and draft growth; “Return to latest” reached the bottom and resumed following subsequent output.

**Interruption settles visibly.** Testing exposed buffered Markdown continuing to appear after cancellation even though the adapter had stopped producing chunks. The source renderer now settles already-received text when a message becomes incomplete. Keyboard Stop returns focus to the input. Failure/retry, repeat question and edit/update remain supported through the original runtime.

Primary composer, attachment, return and retry labels follow English/Chinese mode. The fixed local response content, 72-character/~60ms delivery, [fail] behavior, metadata-only files and in-memory state remain intact.

## What was verified

| Verification | Result |
| --- | --- |
| Build | Passed; rebuilt dist retained |
| 1440×900, 1280×600, 390×844 | Checked in light/en and dark/zh |
| One line, six lines, long mixed-language draft | Growth, internal scrolling and onscreen actions passed |
| Full filename, Escape return, removal focus | Passed in all six viewport/theme/locale conditions |
| Failure → Retry, repeat question, keyboard Stop | Passed in English and Chinese |
| Sent files, edit → Update, edit → Escape | Passed at desktop light/en and narrow dark/zh |
| Page JavaScript errors and horizontal body overflow | None in the checked final matrix |

The [final check results](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/final-015/final-checks.json) contain the measured geometry and outcomes. The separate [attachment/edit journey](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/attachment-017/checks.json) verifies sent-file disclosure and actual updated questions.

The [coupled reading trace](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/settled-episode.json) records scrollTop staying at 387 while response height grew and the draft composer rose from 94px to 174px. Two samples after return were at the current bottom. Stopped and held output both contained 5728 rendered characters with identical geometry. These are actual controlled execution samples, not continuous playback evidence.

I personally inspected the final screenshots. Representative captures include the [compact dark/Chinese draft](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/final-015/final-expanded-1280-dark-zh.png), [narrow full-name disclosure](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/final-015/final-disclosure-390-light-en.png), [returned streaming answer](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/settled-episode-return-growth.png), and [sent filenames at narrow width](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/attachment-017/sent-390-zh.png). [VISUAL-REVIEW.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/VISUAL-REVIEW.md) distinguishes viewed pixels, measurements, transitions and limits.

## Source decisions and evidence

The independent research compared assistant-ui File, AI Elements attachment and complete-chat surfaces, and Zola's public multiline composer. The selected implementation composes resources already present in the supplied family. No alternate visual system or new dependency was introduced.

The audit identifies **three modified upstream components and one new locale helper**. Original source revision, MIT notice and font provenance remain. [ADOPTION.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/ADOPTION.md), the [exact change diff](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/product-changes.patch), and [source digest comparison](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/adoption-digests.json) explain the integration. The [research report](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/research/RESEARCH-REPORT.md), actual child notification and coordination request are retained. Failed trials—including top anchoring, smooth return, disclosure focus and post-cancel buffering—remain alongside the corrected checks.

## Run the delivered build

From the work package:

```bash
cd /workspace/scratch/708e8b7f118e/ui-study/worksets/w07/app
python3 -m http.server 4407 --bind 127.0.0.1 --directory dist
```

Open [light/English](http://127.0.0.1:4407/?theme=light&lang=en) or [dark/Chinese](http://127.0.0.1:4407/?theme=dark&lang=zh) in a browser on the same host. Use `npm run build` after source changes. The preview server used for verification has been stopped as required.

## Remaining limits

No material defect remains in the checked synthetic scope. Continuous natural-time playback, physical mobile keyboards, a comprehensive screen-reader audit and other browser engines were not tested. The detailed scroll-away plus draft-growth episode was light/en; the other theme/language checks do not independently repeat that entire episode. Some upstream secondary labels remain English. The inherited build emits a large-chunk warning. Remote model output, file-content upload and durable history remain outside the supplied product boundary.

