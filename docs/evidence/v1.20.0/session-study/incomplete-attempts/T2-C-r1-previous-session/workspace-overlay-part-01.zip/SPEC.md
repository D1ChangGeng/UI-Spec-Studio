# Meridian — SPEC 01: compose and keep your place

## Overview

The complete product goal is a researcher’s continuing conversation: compose a question, identify attached local filenames, read a long synthetic answer, revisit earlier text while it grows, return to the latest content, stop or recover, and ask again. This is one formal increment because composer height, attachment height, footer geometry and scroll intention share the same reading area. The delivered boundary remains the supplied deterministic local adapter; this work does not introduce a model service, file upload or durable history.

The current product is the supplied assistant-ui cloud-template composition at `ff654d8156680b839774296ef644b57ab1078425`. The shell, message measure, Inter/IBM Plex Mono, semantic theme tokens, composer contour, action row, Markdown rendering and native runtime remain the foundation. `SOURCE-MANIFEST.json`, `FONT-SOURCES.json`, and `app/LICENSE` retain original provenance.

Research studies full conversation products and independently authored implementations. Primary implementation stays in the existing composer, attachment presentation and source-supported viewport options. Regression includes reading text, sidebar, message actions, keyboard focus, narrow width, light/English and dark/Chinese conditions.

## Quality commitments and evidence plan

| Relationship | Required result | Evidence |
|---|---|---|
| Draft growth → reading space | One line grows naturally; six lines and long mixed text remain editable; compact view retains a useful reading area and stable actions | Baseline/final viewport captures and measured composer/input bounds |
| File identity → disclosure | Multiple filenames are distinguishable without hover; full long name is available by keyboard/touch; remove retains a useful focus target | Same-family File composition trial, dialog/return/removal episode |
| Response growth → reader intention | Existing reading point stays stable after manual scroll-away; explicit return reaches latest content | Controlled real-time scroll and streaming episode, metrics plus viewed ordered frames |
| Submit/stop/failure → continuation | Enter/Shift+Enter, stop, first-failure/retry and repeat question work through the source runtime | Actual controls and checked text/status/focus outcomes |
| Theme/locale/viewport → retained craft | 1440×900 and 1280×600 in light/en and dark/zh; supplementary 390×844; meaningful text, no offscreen primary action | Actual PNG views with font readiness and capture conditions |

## Current design decisions

### D1 — Retain the complete assistant-ui family

Baseline source and rendered observations establish the template’s restrained, legible message measure, inset composer and stable bottom action row. There is no reason to import a replacement shell. Baseline captures: `evidence/baseline-expanded-1280-dark-zh.png` and `evidence/baseline-expanded-390-light-en.png`; actual view exports `evidence/view-002.json` and `evidence/view-003.json`. The initial 1440 screenshot catches the upstream entry fade and is not a settled contrast reference.

### D2 — Adopt labeled metadata attachments using the existing File component

The baseline’s 56px tiles show identical document icons; filenames are in tooltip/accessibility text. The adopted composition uses the existing `File.Root/Icon/Name` compact variant with the supplied Dialog, TooltipIconButton and AttachmentPrimitive. Cards show a document icon, real filename, and “Filename only” / “仅文件名.” Source border, radius, type hierarchy and semantics remain. The composer retains one horizontal row; sent files wrap. Cards measure 46px high. A keyboard/touch disclosure opens the full, wrapping filename with a truthful statement that contents are neither read nor transmitted. Escape returns focus to its initiating trigger through the source finalFocus API; removing a file focuses the composer. Final keyboard, sent-file and narrow-width checks passed.

The 256px card width trades simultaneous visibility of full names for a bounded composer footprint. Keyboard focus reveals offscreen cards; a partially visible next card signals overflow. Similar truncated prefixes still require disclosure. File size, downloadable content and previews are not invented for the metadata-only adapter.

### D3 — Constrain growth by available height, preserve runtime ownership

The baseline six-line input plus three files uses 270px at 1280×600, leaving only 242px above its composer after the 64px header. The accepted input ceiling is `min(12rem, 20dvh)`, with internal scrolling. Existing react-textarea-autosize and the source action row remain. No competing field-sizing mechanism was added. Current guidance is retained under `evidence/commands/001-guidance-search` and `002-guidance-retrieve`.

At 1280×600 the final six-line draft with three files uses 228px, returning 42px to the reading area. Its input is 120px high and scrolls its 152px content. At 1440×900 and 390×844 the same state uses 260px and the input displays 152px. One line remains 40px; long mixed-language text scrolls internally and primary controls stay onscreen.

### D4 — Respect manual reading and explicit return through the source runtime

Use the supplied Viewport with `turnAnchor="bottom"` and `autoScroll`, remove inherited CSS `scroll-smooth`, and request `behavior="auto"` on ScrollToBottom. No custom scrolling loop is added. “Return to latest” / “回到最新内容” describes the explicit control. Top anchoring plus autoScroll failed to resume following during a run in an actual trial; bottom anchoring with smooth scrolling still chased growing output. The accepted source configuration resolves both observed issues.

In the final controlled 1280×600 light/en episode, manual scroll-away held scrollTop=387 while scrollHeight grew from 1615 to 2417 and the draft composer grew from 94px to 174px. After explicit return, two samples satisfy scrollTop + clientHeight = scrollHeight. Source footer registration and runtime intention handling remain authoritative.

### D5 — Settle interrupted rendering and keyboard focus

The adapter already aborted future chunks, but an actual failed check exposed Markdown smoothing draining buffered text after Stop. Set the supplied renderer’s `smooth` flag false only when message status is incomplete, settling already-received text on cancellation/failure. Normal streaming and completion keep source smoothing and deferred rendering. Partial content stays readable. Keyboard Stop focuses the existing composer before cancellation swaps the button. The final episode retained 5728 characters and identical geometry in stop/held samples; separate English/Chinese checks verified stable rendered text over 600ms and input focus. The toolbar action now says “Retry response” / “重试回答.”

## Research and adoption decision

Independent research compared the supplied File demo, AI Elements inline attachments versus taller metadata lists, the AI Elements complete chatbot, and Zola’s public composer. The primary designer viewed consequential returned captures. Compact filename identity and stable lower actions are useful cross-product observations. The alternative chatbot’s persistent suggestion rail spends additional vertical space; Zola’s conversation/attachment states required access not used here. Those surfaces remain design references only. No alternate-family code was imported. The source File/Dialog composition was already available and retained the stronger compatibility and visual continuity. See `ADOPTION.md` and `evidence/research/RESEARCH-REPORT.md`.

## State and content contracts

Enter submits; Shift+Enter adds a line. Draft files clear on send and sent filenames remain operable. [fail] produces the preserved first-attempt partial error, and Retry succeeds. Editing/Update creates another run; Escape returns to the main input. Primary composer, attachment, return and retry labels follow the existing locale query. Other upstream shell/edit labels remain English. Reload intentionally resets to the seeded thread. No synthetic adapter, lockfile, license or font source was changed.

## Verification and revision record

The final build and passing matrix are in commands 014–015. Commands 016–017 cover the coupled reading episode and sent-file/edit journey. Earlier failures remain: top/smooth scroll trials, disclosure-focus attempt, and stop-buffer check. `evidence/adoption-digests.json` compares all 35 supplied component digests and identifies exactly three modified upstream components; `evidence/product-changes.patch` records those edits and the new locale helper.

The final matrix covers light/en and dark/zh at 1440×900, 1280×600 and 390×844 with real text, no checked body overflow or page errors. It exercises one/six/long drafts, filenames, disclosure/Escape, removal focus, failure/retry, repeat question and keyboard Stop. A separate reduced-motion journey verifies sent-file disclosure and actual edit/update/Escape at desktop light/en and narrow dark/zh.

## Constraints and unresolved questions

Original UI construction was not used. The research child changed no product code; the primary designer made all final choices and inspected the assembled result. `VISUAL-REVIEW.md` records actual viewed states separately from measurements and published contracts. No continuous natural-time playback was inspected; ordered frames do not establish animation quality between samples. The detailed scroll-away/draft-growth episode was light/en, not independently repeated in Chinese. Real mobile keyboards, screen-reader comprehension and other browser engines were not tested. The preserved synthetic service and filename-only boundary are the delivered product scope.
