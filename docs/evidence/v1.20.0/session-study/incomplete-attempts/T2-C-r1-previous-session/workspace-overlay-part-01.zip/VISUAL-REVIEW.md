# Final visual review

Primary designer review, 2026-10-31. Final app served on owned localhost:4407 from rebuilt app/dist. Chromium headless shell 143.0.7499.4; every browser process used FONTCONFIG_FILE=/tmp/ui-spec-fonts/fonts.conf. Chinese text renders as actual glyphs. Captures wait for fonts and normal settling except the specifically identified transition samples below.

## Personally viewed final output

Actual view_image call arguments and returned images are preserved in evidence/view-NNN.json. Creating a PNG alone is not counted as viewing.

| Views | Conditions actually opened | Observed result |
| --- | --- | --- |
| 015–020 | Resting application at 1440×900, 1280×600 and 390×844, light/en and dark/zh | Source sidebar/header, message type hierarchy and desktop measure retained; narrow sidebar collapses; composer/actions fit |
| 013, 021–025 | Six-line draft plus three files across both themes and all sizes | Compact 46px labeled file rows integrate with the existing composer outline; draft growth remains upward; lower actions stay visible; 600px input scrolls internally |
| 014, 026–027 | Full-name disclosures, including narrow light/en and dark/zh | Long Chinese/English filename wraps within the source dialog; metadata-only explanation visible; source close/focus treatment retained |
| 028–029 | Actual partial error in English and Chinese | Source error panel follows partial answer and Retry remains nearby |
| 030–031 | Recovery/edit-return samples | Resulting controls and content present; source message entry fade is caught, so these are not settled text-contrast evidence |
| 037–039 | Manual reading with growing draft; returned/following output; stopped/held output at 1280×600 light/en | Reader context remains above growing composer; latest response and stop control visible after return; stopped text and normal composer/action state retained |
| 040–041 | Sent attachments at 390×844 dark/zh and 1280×600 light/en | File cards wrap in user-message area, real filenames remain visible, no page-width overflow; main input stays available |

Views 032–036 were exported in a call whose aggregate output exceeded context. They are not relied on as personally seen; views 037–039 re-open the consequential frames. Views 001 and 007 contain early source transitions and are not settled visual references. The research image zola-six-lines.jpg is an early typing sample; the settled zola-draft-unobstructed-20261031.jpg was separately opened.

## Coupled behavior evidence

evidence/final-015/final-checks.json records the six viewport/theme/locale checks. At 1280×600, six lines plus three files measure 228px, versus baseline 270px: 42px more conversation space. Input one-line height stays 40px; long mixed text is internally reachable. Actual keyboard Enter/Escape disclosure, removal focus, failure/retry, repeated question and Stop checks passed; no page JavaScript errors or checked horizontal body overflow occurred.

evidence/settled-episode.json is a timestamped, controlled, real-time synthetic run. ScrollTop stayed 387 while the response grew and the draft composer rose by 80px. Explicit return reached the latest position, and a later sample continued following. Stopped and held text both measured 5728 characters with identical scroll geometry. The screenshots provide ordered state evidence. I did not inspect uninterrupted natural-time playback and do not claim perceived motion quality between samples.

evidence/attachment-017/checks.json adds actual sent-file disclosure and edit/update/Escape in desktop English and narrow Chinese with reduced motion. The separate final matrix exercises failure/retry and interruption in both languages.

## Research comparison reviewed

I opened the same-family File demo, AI Elements inline attachment and complete-chat draft/final samples, and Zola's settled multiline composer. The references support labeled identity and persistent lower controls. Their independent renderings were not treated as proof of Meridian runtime behavior. The alternate products' authentication, long-stream and keyboard gaps remain in the research report.

## Limits and remaining risks

No material defect remains in the checked synthetic scope. Mobile checks use a resized desktop Chromium viewport, not a physical phone or virtual keyboard. There was no comprehensive screen-reader audit or second browser engine. The detailed scroll-away plus draft-growth episode was only light/en. Some upstream secondary labels remain English in Chinese mode. Natural-time continuous playback was not reviewed. The inherited build warns about a large JavaScript chunk; bundle optimization was outside this bounded UI increment. Remote model output, upload and durable history remain intentionally absent.

Source render/animation states can show transient faded text during remount. Failed attempts and their original outputs remain; final acceptance relies on passing corrected checks and the viewed final states above.

