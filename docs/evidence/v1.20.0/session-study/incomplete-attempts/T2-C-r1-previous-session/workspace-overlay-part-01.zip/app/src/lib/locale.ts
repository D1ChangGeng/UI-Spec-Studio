// The existing query-string locale is the owner; reload intentionally resets state.
export const label = (en: string, zh: string) =>
  document.documentElement.lang.startsWith("zh") ? zh : en;
