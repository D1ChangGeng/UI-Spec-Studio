import asyncio,json,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent/'attachment-017';ROOT.mkdir(exist_ok=True)
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=BROWSER,headless=True)
  rows=[]
  for width,height,theme,lang in [(1280,600,'light','en'),(390,844,'dark','zh')]:
   page=await browser.new_page(viewport={'width':width,'height':height},reduced_motion='reduce')
   await page.goto(f'http://127.0.0.1:4407/?theme={theme}&lang={lang}');await page.wait_for_timeout(350)
   field=page.locator('.aui-composer-input')
   await field.fill('Compare these local filenames. 请比较文件名。')
   names=['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','interview-accessibility-reading-continuity-notes.txt']
   async with page.expect_file_chooser() as info:await page.locator('.aui-composer-add-attachment').click()
   await (await info.value).set_files([{'name':n,'mimeType':'text/plain','buffer':b''} for n in names])
   await field.press('Enter');await page.wait_for_timeout(350)
   await page.locator('.aui-composer-cancel').click();await page.wait_for_timeout(250)
   user=page.locator('[data-role="user"]').last
   await user.scroll_into_view_if_needed()
   assert await user.locator('[data-slot="file-name"]').count()==3
   assert await page.locator('.aui-composer-attachments [data-slot="file-name"]').count()==0
   assert await page.evaluate('document.body.scrollWidth===innerWidth')
   await page.screenshot(path=str(ROOT/f'sent-{width}-{lang}.png'))
   details=user.locator('[data-slot="dialog-trigger"]').nth(1)
   await details.click();await page.get_by_role('dialog').wait_for();await page.wait_for_timeout(200)
   assert names[1] in await page.get_by_role('dialog').inner_text()
   await page.keyboard.press('Escape');await page.wait_for_timeout(250)
   await user.hover();await page.locator('.aui-user-action-edit').last.click()
   edit=page.locator('.aui-edit-composer-input')
   await edit.wait_for();assert 'Compare these local filenames.' in await edit.input_value()
   await edit.fill('An edited question. 修订后的问题。')
   await page.get_by_role('button',name='Update',exact=True).click();await page.wait_for_timeout(350)
   await page.locator('.aui-composer-cancel').click();await page.wait_for_timeout(200)
   assert 'An edited question.' in await page.locator('[data-role="user"]').last.inner_text()
   await page.locator('[data-role="user"]').last.hover();await page.locator('.aui-user-action-edit').last.click()
   await page.locator('.aui-edit-composer-input').wait_for();await page.keyboard.press('Escape');await page.wait_for_timeout(100)
   assert await field.evaluate('(e)=>document.activeElement===e')
   rows.append({'viewport':[width,height],'theme':theme,'lang':lang,'reducedMotion':True,'sentNames':3,'sentDisclosure':True,'editUpdate':True,'editEscapeFocus':True,'time':time.time()})
   await page.close()
  (ROOT/'checks.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));print(json.dumps(rows,ensure_ascii=False))
  await browser.close()
asyncio.run(main())
