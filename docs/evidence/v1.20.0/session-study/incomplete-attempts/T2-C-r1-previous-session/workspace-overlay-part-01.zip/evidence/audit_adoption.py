from pathlib import Path
import hashlib, json, difflib

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / 'SOURCE-MANIFEST.json').read_text())
entries = []
for item in manifest['source_files']:
    p = root / 'app' / item['app_path']
    actual = hashlib.sha256(p.read_bytes()).hexdigest()
    entries.append({**item, 'current_sha256': actual, 'unchanged': actual == item['sha256']})
patch = []
for before in sorted((root / 'evidence/source-before').glob('*')):
    current = root / 'app/src/components/assistant-ui/elements' / before.name
    patch.extend(difflib.unified_diff(before.read_text().splitlines(True), current.read_text().splitlines(True), fromfile='upstream/' + before.name, tofile='app/src/components/assistant-ui/elements/' + before.name))
new = root / 'app/src/lib/locale.ts'
patch.extend(difflib.unified_diff([], new.read_text().splitlines(True), fromfile='/dev/null', tofile='app/src/lib/locale.ts'))
(root / 'evidence/product-changes.patch').write_text(''.join(patch))
protected = {}
for rel in ['app/src/synthetic.ts','app/package-lock.json','app/LICENSE','SOURCE-MANIFEST.json','FONT-SOURCES.json']:
    protected[rel] = hashlib.sha256((root / rel).read_bytes()).hexdigest()
result = {'original_repository': manifest['repository'], 'original_revision': manifest['revision'], 'source_files': entries, 'protected_current_sha256': protected, 'note': 'Manifest comparisons establish changed upstream components. Protected hashes record current files; no before hash was independently captured for synthetic.ts or lockfile. Their non-modification is supported by the retained edit diff and work history.'}
(root / 'evidence/adoption-digests.json').write_text(json.dumps(result, indent=2))
print(json.dumps({'source_files': len(entries), 'modified_upstream_components': [e['app_path'] for e in entries if not e['unchanged']], 'patch_lines': len(patch), 'protected_current_sha256': protected}, indent=2))
