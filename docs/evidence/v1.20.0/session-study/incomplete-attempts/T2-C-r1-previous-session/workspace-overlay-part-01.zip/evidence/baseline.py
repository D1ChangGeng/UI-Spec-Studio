import asyncio, json, time
from pathlib import Path
from playwright.async_api import async_playwright

ROOT = Path(__file__).resolve().parent
BROWSER = '/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(executable_path=BROWSER, headless=True)
        rows=[]
        for width,height,theme,lang in [(1440,900,'light','en'),(1280,600,'dark','zh'),(390,844,'light','en')]:
            page=await browser.new_page(viewport={'width':width,'height':height},device_scale_factor=1)
            await page.goto(f'http://127.0.0.1:4407/?theme={theme}&lang={lang}')
            await page.evaluate('document.fonts.ready')
            await page.screenshot(path=str(ROOT/f'baseline-{width}-{theme}-{lang}.png'))
            field=page.locator('.aui-composer-input')
            await field.fill('Compare the evidence.\nKeep the original context.\n请保留事实和解释。\nReview the interviews.\nIdentify uncertainty.\nSuggest next questions.')
            async with page.expect_file_chooser() as info:
                await page.get_by_role('button',name='Add Attachment',exact=True).click()
            await (await info.value).set_files([{'name':n,'mimeType':'text/plain','buffer':b''} for n in ['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','accessibility_research_interview-round-two_final_notes.txt']])
            await page.wait_for_timeout(300)
            await page.screenshot(path=str(ROOT/f'baseline-expanded-{width}-{theme}-{lang}.png'))
            rows.append({'viewport':[width,height],'theme':theme,'lang':lang,'time':time.time(),'metrics':await page.evaluate('''() => {const v=document.querySelector('[data-slot="aui_thread-viewport"]'),c=document.querySelector('.aui-composer-root'),i=document.querySelector('.aui-composer-input');return {viewport:v.getBoundingClientRect().toJSON(),composer:c.getBoundingClientRect().toJSON(),input:i.getBoundingClientRect().toJSON(),scrollHeight:v.scrollHeight,scrollTop:v.scrollTop,bodyWidth:document.body.scrollWidth,buttons:[...document.querySelectorAll('button')].map(x=>x.getAttribute('aria-label')||x.textContent)}}''')})
            await page.close()
        (ROOT/'baseline-metrics.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
        print(json.dumps(rows,ensure_ascii=False))
        await browser.close()
asyncio.run(main())
