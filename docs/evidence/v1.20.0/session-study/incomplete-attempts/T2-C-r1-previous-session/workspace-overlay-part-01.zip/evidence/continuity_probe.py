import asyncio,json,time,sys
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent
TAG=sys.argv[1] if len(sys.argv)>1 else 'baseline'
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=BROWSER,headless=True)
  page=await browser.new_page(viewport={'width':1280,'height':600})
  await page.goto('http://127.0.0.1:4407/?theme=light&lang=en')
  await page.evaluate('document.fonts.ready'); await page.wait_for_timeout(400)
  rows=[]
  async def capture(label):
   before=time.time()
   metrics=await page.evaluate('''() => {const v=document.querySelector('[data-slot="aui_thread-viewport"]'),c=document.querySelector('.aui-composer-root');return {scrollTop:v.scrollTop,scrollHeight:v.scrollHeight,clientHeight:v.clientHeight,composer:c.getBoundingClientRect().toJSON(),text:[...document.querySelectorAll('[data-role="assistant"]')].at(-1).textContent.length,active:document.activeElement?.getAttribute('aria-label')}}''')
   await page.screenshot(path=str(ROOT/f'{TAG}-episode-{label}.png'))
   rows.append({'label':label,'start':before,'end':time.time(),**metrics})
  await page.locator('.aui-composer-input').fill('Compare these findings and preserve reading continuity.')
  await page.locator('.aui-composer-input').press('Enter')
  await page.wait_for_timeout(1300); await capture('stream')
  await page.mouse.move(740,220); await page.mouse.wheel(0,-550)
  await page.wait_for_timeout(350); await capture('away')
  await page.wait_for_timeout(1100); await capture('away-growth')
  await page.locator('.aui-composer-input').fill('Reading earlier text.\nKeep this position.\n保留当前位置。\nCompare sources.\nFollow the context.\nContinue the question.')
  await page.wait_for_timeout(200); await capture('away-draft-growth')
  await page.locator('.aui-composer-input').fill('')
  await page.locator('.aui-thread-scroll-to-bottom').click()
  await page.wait_for_timeout(600); await capture('return')
  await page.wait_for_timeout(800); await capture('return-growth')
  if await page.locator('.aui-composer-cancel').count():
   await page.locator('.aui-composer-cancel').focus(); await page.keyboard.press('Enter')
  await page.wait_for_timeout(350); await capture('stop')
  await page.wait_for_timeout(400); await capture('stop-held')
  (ROOT/f'{TAG}-episode.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows))
  await browser.close()
asyncio.run(main())
