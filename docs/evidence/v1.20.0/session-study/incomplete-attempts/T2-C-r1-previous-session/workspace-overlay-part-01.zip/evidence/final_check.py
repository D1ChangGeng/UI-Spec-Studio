import asyncio,json,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent/'final-015'
ROOT.mkdir(exist_ok=True)
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
NAMES=['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','accessibility_research_interview-round-two_final_notes.txt']
SIX='Compare the evidence.\nKeep the original context.\n请保留事实和解释。\nReview the interviews.\nIdentify uncertainty.\nSuggest next questions.'
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=BROWSER,headless=True)
  rows=[]; errors=[]
  for width,height,theme,lang in [(1440,900,'light','en'),(1440,900,'dark','zh'),(1280,600,'light','en'),(1280,600,'dark','zh'),(390,844,'light','en'),(390,844,'dark','zh')]:
   page=await browser.new_page(viewport={'width':width,'height':height},device_scale_factor=1)
   page.on('pageerror',lambda error:errors.append(str(error)))
   key=f'{width}-{theme}-{lang}'
   await page.goto(f'http://127.0.0.1:4407/?theme={theme}&lang={lang}')
   await page.evaluate('document.fonts.ready'); await page.wait_for_timeout(450)
   await page.screenshot(path=str(ROOT/f'final-{key}.png'))
   field=page.locator('.aui-composer-input')
   await field.fill('One line question.'); one=await field.bounding_box()
   await field.press('Shift+Enter'); assert '\n' in await field.input_value()
   await field.fill(SIX)
   async with page.expect_file_chooser() as info:
    await page.locator('.aui-composer-add-attachment').click()
   await (await info.value).set_files([{'name':n,'mimeType':'text/plain','buffer':b''} for n in NAMES])
   await page.wait_for_timeout(250)
   await page.screenshot(path=str(ROOT/f'final-expanded-{key}.png'))
   metrics=await page.evaluate('''() => {const v=document.querySelector('[data-slot="aui_thread-viewport"]'),c=document.querySelector('.aui-composer-root'),i=document.querySelector('.aui-composer-input'),a=document.querySelector('.aui-composer-attachments');return {composer:c.getBoundingClientRect().toJSON(),input:i.getBoundingClientRect().toJSON(),inputScrollHeight:i.scrollHeight,attachmentHeight:a.clientHeight,attachmentOverflow:a.scrollWidth>a.clientWidth,bodyWidth:document.body.scrollWidth,viewportWidth:innerWidth,visibleNames:[...a.querySelectorAll('[data-slot="file-name"]')].map(x=>x.textContent)}}''')
   assert metrics['bodyWidth']==width
   assert metrics['composer']['bottom']<=height
   assert metrics['input']['height']>one['height']
   details=page.locator('.aui-composer-attachments [data-slot="dialog-trigger"]').nth(1)
   await details.focus(); await page.keyboard.press('Enter')
   await page.get_by_role('dialog').wait_for()
   await page.wait_for_timeout(250)
   assert NAMES[1] in await page.get_by_role('dialog').inner_text()
   await page.screenshot(path=str(ROOT/f'final-disclosure-{key}.png'))
   await page.keyboard.press('Escape'); await page.wait_for_timeout(350)
   focus_return=await details.evaluate('(e)=>document.activeElement===e')
   assert focus_return
   remove=page.locator('.aui-composer-attachments').get_by_role('button',name=('移除 ' if lang=='zh' else 'Remove ')+NAMES[1],exact=True)
   await remove.focus(); await page.keyboard.press('Enter'); await page.wait_for_timeout(100)
   assert await field.evaluate('(e)=>document.activeElement===e')
   assert await page.locator('.aui-composer-attachments [data-slot="file-name"]').count()==2
   await field.fill((SIX+'\nLong mixed-language question 长问题，请核对每个来源。 ')*8)
   await field.press('Control+End'); await page.wait_for_timeout(100)
   long_metrics=await field.evaluate('(e)=>({height:e.clientHeight,scrollHeight:e.scrollHeight,scrollTop:e.scrollTop})')
   assert long_metrics['scrollHeight']>long_metrics['height']
   rows.append({'condition':key,'time':time.time(),'oneLineHeight':one['height'],'expanded':metrics,'dialogFocusReturn':focus_return,'longDraft':long_metrics})
   (ROOT/'final-checks.json').write_text(json.dumps({'checks':rows,'pageErrors':errors},ensure_ascii=False,indent=2))
   await page.close()
  # Exercise actual failure, retry, editing, repeated questions and stopping in both locales.
  for theme,lang in [('light','en'),('dark','zh')]:
   page=await browser.new_page(viewport={'width':1280,'height':600})
   page.on('pageerror',lambda error:errors.append(str(error)))
   await page.goto(f'http://127.0.0.1:4407/?theme={theme}&lang={lang}');await page.wait_for_timeout(350)
   field=page.locator('.aui-composer-input')
   await field.fill('[fail] Check the recovery path.');await field.press('Enter')
   await page.locator('.aui-message-error-root').wait_for()
   await page.wait_for_timeout(250); await page.screenshot(path=str(ROOT/f'final-failure-{lang}.png'))
   await page.get_by_role('button',name='重试回答' if lang=='zh' else 'Retry response',exact=True).last.click()
   await page.locator('.aui-composer-cancel').wait_for(state='visible')
   await page.locator('.aui-composer-cancel').wait_for(state='detached',timeout=16000)
   assert await page.locator('.aui-message-error-root').count()==0
   assert ('观察主题 7' if lang=='zh' else 'Observation theme 7') in await page.locator('[data-role="assistant"]').last.inner_text()
   await field.fill('Repeat-question continuity.');await field.press('Enter');await page.wait_for_timeout(700)
   await page.locator('.aui-composer-cancel').focus();await page.keyboard.press('Enter');await page.wait_for_timeout(350)
   stopped=await page.locator('[data-slot="aui_assistant-message-content"]').last.inner_text()
   stop_focus=await field.evaluate('(e)=>document.activeElement===e')
   await page.wait_for_timeout(600)
   assert stopped==await page.locator('[data-slot="aui_assistant-message-content"]').last.inner_text()
   assert await page.locator('.aui-composer-cancel').count()==0
   assert stop_focus
   await page.locator('[data-role="user"]').last.hover()
   await page.locator('.aui-user-action-edit').last.click()
   editing=page.locator('.aui-edit-composer-input')
   if await editing.count():
    await editing.fill('Edited question continuity.');await editing.press('Escape')
   await page.screenshot(path=str(ROOT/f'final-recovery-{lang}.png'))
   rows.append({'condition':f'journey-{lang}','failureRetry':True,'repeatQuestion':True,'stopHeld':True,'keyboardStopFocus':stop_focus,'editOpened':True})
   await page.close()
  assert not errors,errors
  (ROOT/'final-checks.json').write_text(json.dumps({'checks':rows,'pageErrors':errors},ensure_ascii=False,indent=2))
  print(json.dumps({'checks':rows,'pageErrors':errors},ensure_ascii=False))
  await browser.close()
asyncio.run(main())
