# Meridian UI research: identity, growth, and reading continuity

Research date: 2026-10-31. Scope: workset w07 and public sources only. No product code, UI SPEC, or final product decisions changed by this researcher.

## Decision-useful findings

The strongest adoption path is the supplied assistant-ui family, using its existing File components to make filename identity visible. Independent attachment demos distinguish compact inline identity from full metadata lists; the latter consume much more vertical space. This supports a trial of compact labeled attachments, with a deliberate full-name disclosure for long or similar names. It does not establish the final dimensions or interaction contract; the main agent owns that choice and validation.

The baseline already coordinates composer alignment and upward growth. Its consequential weakness is the shared vertical budget: at 1280×600, six lines plus four files produce a 270px-high composer, versus 94px initially. Generic, identical file icons spend 56px of height without showing which file is which. This makes visible identity a stronger inquiry than a wholesale composer redesign.

Source documentation is useful for identifying supported configurations, but it does not prove runtime continuity. The parent reports that top anchoring plus explicit autoScroll still held following during a run; bottom anchoring with inherited smooth scrolling removed behaved correctly in its local trials. Those are parent observations, not independently replicated by this researcher. The report therefore does not recommend top anchoring as a verified fix.

## What was actually inspected

The full UI Spec Studio method and all eight common references were read, plus evidence-map and evidence-actions. The supplied role, TASK, INPUT, and RUN-CONTROL governed this work. Search began with mature attachment and composer implementations, then narrowed to a practical question: how to disclose trustworthy filename identity without taking additional space from an established conversation.

The unchanged supplied dist was served separately on localhost:4177. A controlled local browser sequence captured initial conversation, six-line mixed Chinese/English draft, four metadata-only attachments, programmatic attachment focus, and narrow reflow. Original command, stdout/stderr, timestamps, exit status, geometry, and captures are retained. This is a rapid state sequence, not natural-speed playback.

Public research used authoritative web retrieval for source facts, then genuine browser viewing for layout. The assistant-ui File demo, AI Elements inline/list attachment demos, AI Elements complete chatbot demo, and Zola public composer were viewed. Zola was reached through the open-source prompt-kit ecosystem. An attachment action exposed a sign-in requirement; no account operation was attempted. Search access to prompt-kit.com itself returned 403; that does not establish bot detection or product unavailability.

## Baseline relationships

| Observed state | Composer height | Input height | Consequential relationship |
| --- | ---: | ---: | --- |
| 1280×600 initial | 94px | 40px | 672px-wide composer aligns with message column; lower edge remains at y576. |
| Six-line draft | 206px | 152px | Growth moves the upper edge from y482 to y370 while actions remain below input. |
| Six lines + four files | 270px | 152px | A 56px attachment strip plus spacing moves upper edge to y306, substantially reducing visible conversation area. |
| Same draft/files at 390×844 | 270px | 152px | Composer fits at 356px wide; four generic tiles remain visually indistinguishable. |

Evidence: `baseline-observation.json`, `commands/003-baseline-probe/`, and `captures/baseline-compact-initial.png`, `baseline-compact-six-lines-attachments.png`, `baseline-narrow-attachments.png`.

The chosen file names include a short English name, a long English transcript name, and two similar long Chinese names. The baseline exposes full names in accessibility labels, but the idle visual shows identical document icons. The capture named `baseline-attachment-keyboard-disclosure.png` used programmatic focus, not actual Tab navigation. No visible tooltip appeared in that sample; it must not be cited as proof of keyboard inaccessibility.

## Materially different candidates

| Candidate and acquisition path | Genuine observation | Reuse and limits |
| --- | --- | --- |
| [assistant-ui File](https://www.assistant-ui.com/elements/file), already supplied in `app/src/components/assistant-ui/elements/file.tsx` | Outline and muted compact file cards put icon, filename, optional metadata, and action in one row; size variants preserve that hierarchy. | Highest compatibility. Supplied revision ff654d8156680b839774296ef644b57ab1078425, MIT per INPUT. File.Root, File.Icon, File.Name support composition; size=sm is available. File.Name truncates, so it does not solve full identity alone. |
| [AI Elements Attachments](https://elements.ai-sdk.dev/components/attachments), inline variant | Four small labeled chips occupy two rows in the demo. Identity is continuously visible and scanning is faster than repeatedly opening generic icons. | Reference for compact identity; no need to import a second family. Long similar names and touch disclosure were not tested. |
| Same page, list variant | Five vertical rows show filename and a second MIME-type line, with preview/icon at left and remove at right. The block is substantially taller than inline chips. | A useful counterexample for a short chat viewport. Metadata rows could suit a file manager or dedicated disclosure, but spend too much composer height when all files remain expanded. No dimension was measured from the public DOM. |
| [AI Elements complete chatbot](https://elements.ai-sdk.dev/examples/chatbot), [repository](https://github.com/vercel/ai-elements) | Bounded conversation pane, persistent suggestion rail, and separate composer. Six-line draft expands upward within the preview. Submission clears the draft; a busy endpoint and completed user/mock-answer endpoint were viewed. | A complete implementation reference, not equivalent proof for this runtime. Public demo source uses local mockResponses with timed word updates. No cancel, retry, scroll-away, keyboard, or narrow-width episode was established. Repository currently announces migration to shadcn and deprecation at the end of November 2026, making wholesale new adoption unattractive without further maintenance review. |
| [Zola public product](https://www.zola.chat/), [repository](https://github.com/ibelick/zola) | Empty-state title, broad composer, bottom action row, and suggestions form one centered group. Six-line Chinese/English draft increases composer height while retaining the lower actions. | Independent product-level comparison; Apache-2.0 repository with prompt-kit, shadcn, Tailwind, Next.js/Supabase. Attachment population requires login. Established conversation, streaming, narrow layout, and dark mode were not tested; the product describes itself as beta. |

For the supplied metadata-only adapter, file size, downloadable content, content preview, and processing status must not be invented. Using only the existing File icon and name, plus the supplied Dialog primitive for full-name disclosure, has a concrete same-family route. Retain a distinct removal action and test focus return. Whether the main agent chooses that exact composition remains outside this role.

## Complete-surface comparison and temporal limits

Zola captures: `captures/zola-empty.jpg` → `captures/zola-draft-unobstructed-20261031.jpg`. The latter is the useful settled draft capture. `zola-six-lines.jpg` contains an early typing sample, and `zola-draft-final-20261031.jpg` includes a closing popover transition; neither should substitute for the settled view. The centered empty state differs materially from Meridian's established conversation, so it supports composer/action hierarchy only.

AI Elements captures: `captures/ai-elements-chat-initial.jpg` → `ai-elements-chat-six-lines.jpg` → `ai-elements-chat-run-start.jpg` → `ai-elements-final-observed.jpg`. The final view shows the synthetic user draft and a short mock assistant response. The suggestion rail remains between conversation and composer, using extra vertical space. This makes it a meaningful alternative composition, but its screenshot does not justify rebuilding Meridian around that layout.

These are ordered samples with no continuous recording. They establish visible states and relationships, not perceived animation quality, exact duration, cancellation, or scroll stability between samples. Some browser file transfers failed to synchronize; only paths listed above were verified nonempty before handoff. All important candidates have retained viewed captures.

## Supported implementation paths and unresolved checks

Official [Thread primitives documentation](https://www.assistant-ui.com/docs/primitives/thread) states that autoScroll defaults differently for top and bottom anchoring, that manual scrolling pauses following, that ScrollToBottom can resume it, and that ViewportFooter registers composer height. These are published contracts. The supplied app and installed package must be tested as a coupled system; the parent is doing that.

Current web guidance was searched and retrieved through the prescribed tool, with original outputs in `commands/001-guidance-search/` and `002-guidance-retrieve/`. It supports bounded growing text fields but flags browser-coverage limits for newer CSS sizing/scroll primitives. It does not justify replacing the existing runtime with a CSS experiment.

High-impact checks still belong to the main implementation:

- Long draft plus attachments in the 600px-high viewport: typing remains usable while message context stays visible.
- Long similar filenames: visible distinction, full disclosure, independent removal, Escape/close, and focus return.
- Actual streaming: scroll away, remain still through further chunks, return, and follow subsequent chunks.
- Stop and failure/retry: content settles promptly, controls match state, and partial content remains readable.
- Narrow, light/en, dark/zh, and real keyboard paths after composition.

The parent reports discovering delayed Markdown smoothing after cancellation and trialing smooth=false for incomplete status. That observation reinforces the need to inspect completed temporal episodes rather than infer behavior from a successful click.

## Evidence index and handoff

Original web responses: `sources/001-discovery-search.json`, `003-source-verification.json`, `007-independent-products.json`, `008-episode-contracts.json`. Browser AX outputs are retained where synchronization succeeded; source facts and rendered observations are kept distinct above.

Most useful visual comparisons: `captures/assistant-ui-file-demo.jpg`, `ai-elements-inline-list.jpg`, `ai-elements-full-list-20261031.jpg`, the settled Zola draft, and AI Elements draft/final endpoints. Original local view_image outputs for the key comparison images are retained in `views/`.

This research supports preserving the mature foundation and testing same-family composition. It does not constitute final UI acceptance.

