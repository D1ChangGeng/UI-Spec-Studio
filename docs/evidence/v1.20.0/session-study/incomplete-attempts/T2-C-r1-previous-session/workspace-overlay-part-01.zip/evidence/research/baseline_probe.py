import asyncio, json, time, os, hashlib
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent
shots=ROOT/"captures"
log=[]
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path="/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell",headless=True)
  page=await browser.new_page(viewport={"width":1280,"height":600},device_scale_factor=1)
  await page.goto("http://127.0.0.1:4177/?theme=light&lang=en",wait_until="networkidle")
  await page.evaluate("document.fonts.ready")
  async def snap(name):
   before=time.monotonic()
   geometry=await page.evaluate("""() => { const box=s=>{let e=document.querySelector(s);if(!e)return null;let r=e.getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height,scrollTop:e.scrollTop,scrollHeight:e.scrollHeight,clientHeight:e.clientHeight}};return {viewport:[innerWidth,innerHeight],composer:box('.aui-composer-root'),input:box('textarea'),thread:box('[data-slot=aui_thread-viewport]'),attachments:box('.aui-composer-attachments'),attachmentNames:[...document.querySelectorAll('.aui-attachment-tile')].map(e=>e.getAttribute('aria-label')),active:document.activeElement?.outerHTML.slice(0,600)}}""")
   await page.screenshot(path=str(shots/name))
   log.append({"name":name,"before_monotonic":before,"after_monotonic":time.monotonic(),"geometry":geometry})
  await snap("baseline-compact-initial.png")
  await page.get_by_role("textbox",name="Message input").fill("Summarize the findings.\n请保留中文采访记录。\nCompare the conflicting views.\nKeep the limitations explicit.\nList follow-up questions.\nSuggest a useful next step.")
  await snap("baseline-compact-six-lines.png")
  names=["notes.txt","城市出行访谈摘要_2026-10-31_final-revised-notes.txt","interview-participant-research-transcript-mobility-study-final-v3.txt","城市出行访谈摘要_2026-10-31_final-revised-notes-第二版.txt"]
  async with page.expect_file_chooser() as fc:
   await page.get_by_role("button",name="Add Attachment",exact=True).click()
  chooser=await fc.value
  await chooser.set_files([{"name":n,"mimeType":"text/plain","buffer":b"research fixture metadata only"} for n in names])
  await page.wait_for_timeout(250)
  await snap("baseline-compact-six-lines-attachments.png")
  tile=page.locator(".aui-attachment-tile").nth(1)
  await tile.focus()
  await page.wait_for_timeout(700)
  await snap("baseline-attachment-keyboard-disclosure.png")
  await page.set_viewport_size({"width":390,"height":844})
  await snap("baseline-narrow-attachments.png")
  await page.goto("http://127.0.0.1:4177/?theme=dark&lang=zh",wait_until="networkidle")
  await snap("baseline-narrow-dark-zh.png")
  await browser.close()
 print(json.dumps(log,ensure_ascii=False,indent=2))
 (ROOT/"baseline-observation.json").write_text(json.dumps(log,ensure_ascii=False,indent=2))
asyncio.run(main())

