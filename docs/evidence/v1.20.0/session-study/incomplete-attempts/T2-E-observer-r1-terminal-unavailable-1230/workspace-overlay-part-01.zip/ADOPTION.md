# Source adoption and design decisions

## Decision

Retain the supplied assistant-ui cloud workspace and runtime. Adopt the named attachment hierarchy from assistant-ui's `ComposerAttachmentChip`, using the existing native Dialog for complete filename disclosure. Configure the existing Thread viewport and return action for explicit bottom following. Keep the source typography, spacing, tokens, sidebar, message measure, composer contour, input sizing, and action hierarchy.

The reason is observable: the initial attachment tiles gave four different filenames the same visible document icon, while the mature source chip already supplies an icon/name/metadata/removal hierarchy compatible with this family. The initial `turnAnchor="top"` default also did not resume following after return; the supported bottom anchor and instant return resolved that behavior without a second scroll owner.

## References and usable implementations

| Candidate | Provenance and evidence | Decision and cost |
|---|---|---|
| Supplied assistant-ui cloud template | `SOURCE-MANIFEST.json`; complete source at `ff654d8156680b839774296ef644b57ab1078425`; baseline captures genuinely viewed | Retained. Existing runtime, tokens, fonts, source hierarchy and responsive shell already fit the reading task. |
| assistant-ui `ComposerAttachmentChip` | Exact same revision, `packages/ui/src/components/react/assistant-ui/elements/composer.tsx`; acquired in `sources/adoptable/composer.tsx`; original demo and hook acquired and locally rendered | Adopted visual structure through a focused adapter. Existing `AttachmentPrimitive` owns removal/state; existing Base UI Dialog owns disclosure/focus. No second composer runtime. |
| Vercel AI Elements Prompt Input / Attachments | Official documents in `evidence/sources-001.json`, researcher public demo observations and `evidence/research/web-*.json` | Reference only. Unified growing prompt and stable footer are relevant, but old site announces a migration to shadcn/ui. No new old-latest installer or unpinned replacement imported. |
| Ant Design X 2.10.0 Sender.Header + Attachments | Researcher operated public original demo; report and official web exports in `evidence/research/` | Reference only. Separate attachment disclosure is a meaningful alternative, but the isolated close leaves input at the same vertical position; it does not prove reclaimed reading area. Additional component/token/state family and unverified source revision/rights did not justify adoption. |
| Ant Ultramodern complete workspace | Researcher viewed original public entry composition at 1363×936 | Context reference only. Broad central entry composer differs from this sustained-reading task; populated response and return behavior were not established. |
| LibreChat composer | Official documentation opened in `evidence/sources-001.json` | Documentation-only context for staged attachments and draft during generation. Queue/steer/interrupt behavior was not adopted or claimed visually observed. |

## Exact adopted source and rights

Repository: https://github.com/assistant-ui/assistant-ui . Revision: `ff654d8156680b839774296ef644b57ab1078425`. License: MIT, retained in `app/LICENSE`; source inventory remains unchanged in `SOURCE-MANIFEST.json`.

Additional acquisition URLs use `https://raw.githubusercontent.com/assistant-ui/assistant-ui/ff654d8156680b839774296ef644b57ab1078425/` plus:

- `packages/ui/src/components/react/assistant-ui/elements/composer.tsx`
- `apps/docs/components/demo/elements/composer-attachments.tsx`
- `apps/docs/components/demo/hooks/use-demo.ts`
- `packages/ui/src/components/react/assistant-ui/utils/range.ts`

The downloaded originals are retained in `sources/adoptable/`. Original command stdout/stderr and the failed `.tsx` hook lookup followed by the successful `.ts` lookup remain under `evidence/commands/006-*`, `009-*` through `013-*`.

The source demo is locally mounted at `/reference.html` using copied source with import-path adaptation and a neutral page wrapper. This is a local rendering of original source, not a claim that the live public page was inspected by the primary. The first mount lacked newly discovered Tailwind classes and was rejected; the corrected source rendering is captured in `evidence/local-source-demo-corrected/` and personally viewed in `view-005.json`. The default production entry remains the application.

## Adaptation boundaries

`filename-attachment.tsx` preserves the source chip's field surface, 14px outer / 10px icon radii, 32px document icon block, compact spacing, 12px medium filename and 11px metadata. The source upload-size metadata is replaced by truthful “Filename only” / “仅文件名”. Clicking or keyboard-activating the filename opens the existing Dialog with the full wrapped name and a plain statement that file contents are neither read nor sent. Removal remains the source attachment action.

The source attachment container wraps and is bounded to 112px with internal vertical scrolling. At 390px this shows two full chips and part of the next; keyboard focus scrolls the final chip into view. This is a deliberate capacity tradeoff, not a claim that all four filenames remain simultaneously visible on narrow screens. At 1280×600 the four names occupy two rows; with a six-line draft the composer is 311px high and leaves about 201px between the header and its top. The baseline tile version was shorter, but lacked visible identity.

The existing autosizing textarea retains its 192px cap, line height, Enter/Shift+Enter and composition handling. The source runtime remains the sole conversation/scroll owner. `turnAnchor="bottom"` enables supported following; `ScrollToBottom behavior="instant"` avoids repeated smooth targets lagging behind fast synthetic chunks. Manual scroll-away continues to pause following. A small focus repair returns focus to the existing input after stop or attachment removal; it neither recreates composer state nor scrolls the viewport.

Core composer, attachment and retry labels are localized. Source shell and some secondary action labels remain English in the Chinese condition, as allowed by the starting package. This is not a complete localization pass.

## Rejected trials and evidence limits

Primary external subprocess navigation failed TLS trust checks; no certificate or sandbox bypass was used. Those failed captures and original errors remain in `evidence/commands/007-*`. The researcher later used the authorized cloud browser to inspect public originals; external screenshots are in its tool transcript, with no documented local PNG export. They are not represented as local artifacts. The primary personally inspected local original-source and assembled-product captures and read the full independent report; it did not personally replay the researcher's external browser episode.

Bottom anchoring with the source's smooth return still chased a moving target in the controlled trial (`021-*`). The final instant action reached bottom distance 0 and continued following (`022-*` and final checks). No natural-speed animation-quality claim follows from sampled frames.

`evidence/source-audit-final.json` compares supplied source hashes: 32 copied source files remain byte-identical; only Thread, attachment and MarkdownText source files changed, with new focused filename/locale modules. Dependency versions and lockfile are retained. No synthetic response shortening, model connection, upload or persistence was introduced.

## Independent observation changed the cancellation decision

The observer found that, with normal motion, inherited smooth text reveal can continue draining already-received text after Stop has returned the composer to Send (`observer/run-005/stop-detail.json`). This is consistent with the installed source `useSmooth` implementation, which calls animator.start for settled states; it is not evidence that the unchanged synthetic adapter emitted after abort. The primary chose a focused supported configuration: `MarkdownTextPrimitive smooth={false}` only while the message has status `incomplete/cancelled`. Received text becomes visible at cancellation and subsequent reveal stops, while ordinary streaming smoothing and reduced-motion behavior retain their source implementation. This repair is in the existing MarkdownText integration; no animator or model logic was replaced. A new independent stop probe validates the affected path and preserves the earlier observation.
