# SPEC 01 — Composer and reading continuity

## Outcome and boundary

Meridian's researcher can grow a question, recognize selected filenames, disclose a complete long name, send, read a long synthetic response, hold an earlier reading position during generation, and explicitly return to latest. Composer height, attachments, focus and the reading viewport remain one coupled design increment.

The supplied assistant-ui cloud application at `ff654d8156680b839774296ef644b57ab1078425` remains the foundation. The deterministic synthetic adapter and filename-only adapter are unchanged. No model service, file-content upload, persistence or new visual identity is included. The primary owns source selection, code changes, and final product inspection; the two sequential children supply independent evidence.

## Formal scope and evidence

| Scale | Owned relationship | Final disposition |
|---|---|---|
| L0 | Calm research conversation and truthful local state | Source shell and reading hierarchy retained; explicit synthetic and filename-only disclosures remain. |
| L1 | Draft → attach → send → read → scroll away → return → stop/retry → next question | Primary controlled episodes and independent cross-component inquiry; original failures and corrected checks retained. |
| L2 | Readable message column above a growing sticky composer | Source 44rem measure and responsive shell retained; all six required viewport/theme combinations captured and personally viewed in representative final expanded states. |
| L3 | Filename identity, complete disclosure, removal, bounded input, return/stop | Mature source chip adapted; native Dialog; 112px attachment region; source textarea 192px cap; supported bottom-follow configuration; focus repair. |
| L4 | Inter/CJK body, muted contour, source icons and round primary action | Source proportions/tokens retained. Compact and narrow tradeoffs explicitly inspected. |
| L5 | Pinned source → local adaptation → real output | `ADOPTION.md`, `SOURCE-MANIFEST.json`, source originals, hash audit, original command outputs, PNGs and actual image-tool exports. |

## Final decisions

### D1 — Retain the complete family

The baseline's message measure, readable type hierarchy, quiet contour and stable action row were coherent at desktop and compact sizes. Independent comparison did not establish a replacement with a better verified full reading episode. Retain the source visual and behavior family rather than mixing a second runtime or shell.

### D2 — Make filename identity visible and complete

Four identical 56px document tiles were a recognition failure in this metadata-only context. The same pinned source's named chip supplies a compatible hierarchy. Adopt that hierarchy and native Dialog disclosure; preserve full underlying names and source removal semantics. Bound/wrap attachment growth. At 390px, internal scrolling is required to reach remaining chips; keyboard reachability is tested. At compact height, six lines plus four names yield a 311px composer with roughly 201px reading area above it. That density tradeoff is accepted for visible identity, while keeping input/actions available.

### D3 — Respect voluntary reading position and explicit return

Baseline top anchoring kept an earlier reading point but failed to resume following after return. Bottom anchoring alone still chased rapidly growing text through CSS smooth scrolling. The source-supported instant return plus bottom anchoring reaches the latest content and resumes following. Manual wheel scroll-away leaves scrollTop unchanged while response height grows. No custom follower or forced-scroll loop was added.

### D4 — Repair focus at disappearing controls

Stopping a response or removing a filename can remove the focused button. A scoped requestAnimationFrame focuses the existing composer input with preventScroll. Draft text remains in the source runtime. Dialog Escape returns to the filename trigger. An independent normal-motion episode also exposed the inherited buffered text reveal after cancellation. The primary configures the existing MarkdownText smooth option off only for incomplete/cancelled messages, so already-received text settles when Stop is acknowledged. Existing source IME and textarea autosize behavior is retained; synthetic composition-event testing does not establish real OS IME compatibility.

## Verification and completion boundary

Primary matrix: 1440×900, 1280×600, 390×844, each light/English and dark/Chinese. One line, six lines, twenty mixed-language lines, four filenames, full-name dialog, Escape, removal, IME-event guard, Shift+Enter, no document overflow, no file reads/no application network mutation, and no uncaught page errors were exercised. Both language streaming episodes cover manual position, explicit return, keyboard stop/draft preservation, deliberate failure, same-question retry and repeated questions.

The broad runner records 66 passed checks and 2 edit-probe failures, preserved as failures. Source inspection established that the edit action is absent until its user message is hovered. A focused corrected trigger/update run passes in English (`025-edit-corrected`); no unexecuted Chinese edit success is claimed. This secondary action retains upstream hover disclosure and is not part of the new keyboard attachment flow.

The independent observer investigates the consequential combined stream/scroll/attach/draft/dialog/removal/return/stop/next-question episode; its report and original observations, including the cancellation-buffer refinement and successful focused rerun, are retained under `evidence/observer/`. Final primary visual acceptance and limitations are recorded in `VISUAL-REVIEW.md` and `FINAL.md`.

## Constraints and unresolved assurance

Source/right provenance and external observation limits are in `ADOPTION.md`. Sparse controlled frames and geometry do not establish natural-time smoothness, screen-reader usability, real device keyboard behavior or a user study. Some shell/action labels remain English. The large upstream bundle warning is retained; no performance optimization claim is made. Native backend identities, tokens and billed costs are unavailable. Initial child capacity, server expiry, TLS access and test-attempt failures remain in evidence rather than being erased. Work uses normal sandboxed Chromium and approved local/network execution without TLS/proxy/sandbox bypass.
