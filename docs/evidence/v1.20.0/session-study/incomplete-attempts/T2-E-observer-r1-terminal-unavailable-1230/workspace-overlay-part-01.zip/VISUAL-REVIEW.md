# Primary visual review

Reviewed by the primary product agent on 2026-11-01. All listed local images were opened with `view_image`; full actual returned objects were saved in `evidence/view-*.json` at the call site. Screenshots were produced by the real application/source demo in Chromium with Noto CJK configuration, device scale 1. Evidence is static frames and controlled ordered episodes, not natural-speed playback.

## Source and baseline

- `view-001` / `view-002`: baseline desktop/light and compact/dark expanded composer. Source reading measure, line rhythm, composer contour and stable bottom actions are coherent; four identical document tiles conceal filename identity.
- `view-003`: baseline growth while scrolled away; return arrow and stop coexist with earlier reading.
- `view-004`: first isolated source mount, rejected because Tailwind had not discovered new source classes. This was a broken rendering, not the intended source quality.
- `view-005`: corrected original assistant-ui attachment demo. Named compact chips preserve recognizable icon/name/metadata hierarchy within the unified composer; this is the adopted visual source.
- `view-006`: local narrow trial; bounded chips and action row fit.

## Final assembled product

| Actual viewed export | Capture | Observed quality and limits |
|---|---|---|
| `view-007` | `final/1440x900-light-en-expanded.png` | All four names distinguishable across two rows; source 44rem measure, quiet contour and bottom actions retained. |
| `view-008` | `final/1280x600-dark-zh-expanded.png` | Compact density is substantial but composed: all chips and six lines fit; clear CJK, about 201px reading area above composer. |
| `view-009` | `final/390x844-dark-zh-filename-dialog.png` | Complete mixed-script name wraps inside the narrow dialog; content boundary is truthful and localized; close remains accessible. |
| `view-010` | `final/1440x900-dark-zh-expanded.png` | Source dark palette and hierarchy remain consistent; English shell labels persist as a localization limit. |
| `view-011` | `final/1280x600-light-en-expanded.png` | Named rows increase composer height versus baseline; readable input and send/attach remain inside the viewport. |
| `view-013` | `final/390x844-light-en-expanded.png` | Narrow source shell collapses appropriately; two full filename chips plus part of the next signal overflow. Bounded region requires scrolling; actions remain separated from text. |
| `view-014` | `final/390x844-dark-zh-expanded.png` | Same narrow geometry with legible mixed script and quiet dark surfaces. |
| `view-015` | `final/episode-dark-zh-growth-away.png` | Earlier theme/paragraph stays visible while stop and return remain available; geometry log proves unchanged sampled scrollTop. |
| `view-016` | `final/episode-dark-zh-returned.png` | Latest growing paragraph is reached; return arrow is in its settling/disabled transition in this sample. Subsequent logged bottom distance is zero. |
| `view-017` | `final/episode-light-en-failure.png` | Partial response remains visible with explicit synthetic error and source retry action; composer stays available. |
| `view-018` | `final/1280x600-dark-zh-long-input.png` | Textarea is internally scrollable at 192px; attachment region and action row remain bounded. The screenshot shows later lines because fill leaves caret at the end. |
| `view-019` | `research/meridian-scroll-away.png` | Independently captured current app: earlier paragraphs, return arrow, and stop coexist. Primary personally inspected this returned evidence. |
| `view-020` | `edit-corrected/edited.png` | Corrected source-hover edit flow produces an updated mixed-language question and branch indicator in the existing conversation. |

`view-012` was an attempted narrow-image display whose tool output exceeded available model context; it is not counted as reviewed. The same PNG was explicitly reopened and genuinely inspected in `view-013`.

## Behavior evidence that changes interpretation

`evidence/final/checks.json` contains the original six-condition and two-language records. The broad runner has 66 successful checks and two failed edit probes. It preserved both failures; the source action requires its message hover trigger, and the focused corrected English probe in `025-edit-corrected` succeeds. It does not retroactively turn the failed probes into passes.

Baseline top-anchor return stopped following further growth. A bottom-anchor/smooth-return trial still lagged behind repeated targets. Final instant return records bottom distance zero and ongoing following; manual scroll-away remains exactly stable in the sampled intervals. Keyboard stop preserves the draft and restores input focus. Filename removal does likewise; Escape restores disclosure-trigger focus. Metadata-only checks observed no Blob/FileReader reads or non-GET application request during fixture selection. These observations support the local adapter boundary, not a general security audit.

The independent observer's coupled episode is a separate inquiry, with its own captures, original command outputs, trace and report under `evidence/observer/`. Its observations support primary acceptance but do not replace these personal visual inspections.

## Acceptance and remaining limits

The accepted result is a focused source-supported improvement of the supplied workspace: filenames become identifiable, complete disclosure works beyond hover, constrained height stays usable, and explicit return follows new content while manual reading remains voluntary. Visual acceptance applies to the displayed source and product states listed above, with the documented compact/narrow tradeoffs.

No claim is made for natural-speed motion quality, screen-reader testing, a real OS IME session, physical mobile keyboard/viewport changes, touch-device testing, live model behavior, upload, remote persistence, or a complete Chinese localization. External public screenshots viewed by the researcher are retained in its tool transcript but are not locally exported; primary external subprocess attempts were TLS-blocked without bypass. Vite's large-chunk warning remains visible in final build logs.

## Independent cancellation refinement

The first independent normal-motion stop probe observed source smoothing draining text after the generation control had changed to Send. Primary reduced-motion checks did not expose this distinction. The source animator confirms this drain behavior; the observation does not establish continued adapter emission. The primary added a supported MarkdownText `smooth` configuration keyed only to incomplete/cancelled message status, then requested a focused independent rerun. Original pre-fix captures and text samples remain under `observer/run-004/` and `observer/run-005/`. Final post-fix findings are appended below after actual inspection.

### Final cancellation acceptance

Primary personally opened `observer/run-007-repaired-stop/04-after-stop.png` in `view-021.json`: Send is visible, the working indicator is gone, all four named chips/two rows and six-line draft remain inside the source boundary. `view-022.json` opens the independent live-stream full-name dialog from `observer/run-004/06-full-name-dialog.png`: the complete mixed-script name wraps cleanly and disclosure remains distinct over the stable underlying composer.

The repaired stop probe reports lengths 457 at ~4ms while Stop is still present, then 694 at ~100ms, ~479ms and ~1184ms with Stop absent. Text is identical in all three acknowledged-stop samples. Focus remains on 消息输入 and four chips plus the exact draft remain. This supports settling received text at acknowledged cancellation; it does not claim a zero-latency browser update. The pre-fix samples and the final source hash are retained in the observer record. Final build `027-cancellation-build` succeeds with the existing large-chunk warning.
