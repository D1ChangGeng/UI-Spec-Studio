"use client";

// Named-chip visual structure extracted and adapted from assistant-ui's
// ComposerAttachmentChip at ff654d8156680b839774296ef644b57ab1078425 (MIT).
// The source's field material, 14/10px radii, icon/name/meta hierarchy and
// compact spacing remain. Base UI Dialog supplies keyboard/touch disclosure.
import { AttachmentPrimitive } from "@assistant-ui/react";
import { FileTextIcon, Loader2Icon, XIcon } from "lucide-react";
import { Dialog, DialogTrigger, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { TooltipIconButton } from "./tooltip-icon-button";
import { useAttachmentState } from "./attachment-state";
import { field } from "./surfaces";
import { cn } from "@/lib/utils";
import { localized } from "@/lib/locale";

export function FilenameAttachment() {
  const { name, isComposer, isUploading, isError, errorMessage } = useAttachmentState();
  return (
    <AttachmentPrimitive.Root className="aui-attachment-root max-w-full">
      <Dialog>
        <div className={cn(field, "aui-filename-chip relative flex max-w-full items-center gap-2.5 overflow-hidden rounded-[14px] py-1.5 ps-1.5 pe-2.5")}>
          <DialogTrigger
            className="flex min-w-0 items-center gap-2.5 text-start outline-none focus-visible:ring-1 focus-visible:ring-ring/50"
            aria-label={localized(`View filename: ${name}`, `查看文件名：${name}`)}
            title={name}
          >
            <span className="bg-background text-muted-foreground flex size-8 shrink-0 items-center justify-center rounded-[10px] dark:bg-white/10">
              <FileTextIcon className="size-4" aria-hidden />
            </span>
            <span className="flex min-w-0 flex-col">
              <span className="max-w-36 truncate text-xs font-medium">{name}</span>
              <span className={cn("text-[11px]", isError ? "text-destructive" : "text-muted-foreground")}>
                {isError ? localized("Could not attach", "无法添加") : localized("Filename only", "仅文件名")}
              </span>
            </span>
          </DialogTrigger>
          {isUploading ? (
            <Loader2Icon className="text-muted-foreground size-3.5 shrink-0 animate-spin motion-reduce:animate-none" aria-label={localized("Preparing attachment", "正在准备附件")} />
          ) : isComposer ? (
            <AttachmentPrimitive.Remove
              render={<TooltipIconButton tooltip={localized(`Remove ${name}`, `移除 ${name}`)} className="ms-1 size-6 shrink-0 rounded-full" />}
              onClick={(event) => {
                const input = event.currentTarget.closest("[data-aui-composer-type]")?.querySelector<HTMLTextAreaElement>(".aui-composer-input");
                requestAnimationFrame(() => input?.focus({ preventScroll: true }));
              }}
            >
              <XIcon className="size-3" />
            </AttachmentPrimitive.Remove>
          ) : null}
        </div>
        <DialogContent>
          <DialogTitle className="pr-6 leading-relaxed break-all">{name}</DialogTitle>
          <DialogDescription>
            {localized("This conversation keeps the filename only. File contents are not read or sent.", "此对话仅保留文件名，不读取或发送文件内容。")}
            {errorMessage && ` ${errorMessage}`}
          </DialogDescription>
        </DialogContent>
      </Dialog>
    </AttachmentPrimitive.Root>
  );
}
