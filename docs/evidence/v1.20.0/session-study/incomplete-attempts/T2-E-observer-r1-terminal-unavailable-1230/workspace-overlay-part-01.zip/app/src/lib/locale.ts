// The local preview's existing URL contract owns locale selection.
export const isChinese = new URLSearchParams(location.search).get("lang") === "zh";
export const localized = (en: string, zh: string) => isChinese ? zh : en;
