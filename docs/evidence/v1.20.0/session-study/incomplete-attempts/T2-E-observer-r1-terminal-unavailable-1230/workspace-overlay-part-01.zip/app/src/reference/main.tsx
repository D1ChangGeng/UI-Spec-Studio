import { createRoot } from 'react-dom/client';
import { ComposerAttachmentsDemo } from './composer-attachments-demo';
import '../styles.css';
import '../fonts.css';
document.documentElement.classList.toggle('dark',new URLSearchParams(location.search).get('theme')==='dark');
// Neutral observation mount; authored component and its demo content are intact.
createRoot(document.getElementById('root')!).render(<main style={{padding:32}}><ComposerAttachmentsDemo /></main>);
