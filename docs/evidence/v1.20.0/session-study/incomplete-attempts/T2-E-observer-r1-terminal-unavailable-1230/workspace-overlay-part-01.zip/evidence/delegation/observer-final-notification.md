# Cross-component continuity observation

**The coupled desktop episode preserved the earlier reading point, composer boundary, filename identity, and focus. One temporal mismatch was found after Stop; the primary agent applied a supported configuration repair, and the focused recheck confirmed stable text after the cancellation update.** Final product acceptance remains with the primary designer.

## Observed conditions

Actual Meridian app at http://127.0.0.1:4415/?theme=dark&lang=zh, Chromium 143.0.7499.4, 1280×600 CSS pixels, device scale 1, dark theme, Chinese content, configured Noto CJK fonts. The mature source family is assistant-ui revision ff654d8156680b839774296ef644b57ab1078425. The application uses synthetic responses and filename-only attachments. No product source was edited by this observer.

The episode used the visible 添加本地文件名 button and the browser's actual file-chooser event, selecting four local fixture files. The native operating-system picker was not visually inspected. Input used Playwright fill and keyboard events, not real IME composition.

## Findings

- **Reading continuity:** In attempt 003, scrollTop remained exactly 26 px through attachment addition, six-line draft growth, keyboard dialog opening, Escape, and chip removal. The original reading heading stayed at y=142 px and its paragraph at y=182 px. Attempt 004 repeated this at scrollTop=39 px; attempt 005 repeated it at scrollTop=0. Content height continued growing during these operations.
- **Composer and action relationship:** Adding four chips increased the composer from 94 to 199 px high; the six-line draft increased it to 311 px. Its bottom remained at y=576 px. The four chips occupied two rows; their compact labels and “仅文件名” metadata remained distinguishable. The expanded composer left about 201 px between the header and its top, so less text was visible, while the selected reading landmark remained fixed. Removing one chip collapsed the chips to one row and reduced composer height to approximately 258.5 px. The actual viewed frames retained a clear source boundary and reachable add/stop/send controls.
- **Filename and focus:** From the textarea, Shift+Tab twice reached the last truncated filename trigger. Enter opened its native Dialog. The full mixed-language filename wrapped across two lines without clipping, accompanied by the metadata-only explanation. Escape returned focus to that same chip, with a visible focus outline. Removing another chip returned focus to the textarea and retained the entire six-line draft.
- **Explicit return and continuation:** 回到最新内容 moved the viewport to its current bottom. After Stop, sending the next question succeeded, moved the three retained filenames into the user message, and reset the composer to its 94 px height. This next-question frame was actually viewed.
- **Narrow follow-up:** The viewed 390×844 frame showed readable Chinese response text and a six-line mixed-language draft within the source composer; Add and Send remained visible. This was a resized desktop browser after the filenames had been sent. It does not establish touch interaction, four-chip mobile composition, or device-keyboard behavior.

## Stop finding and focused repair verification

Before repair, Stop changed the control back to Send, but the displayed assistant text kept revealing buffered content. Attempt 005 sampled assistant text lengths of 1420, 1464, 1505, and 1531 after Stop while the Stop control was absent. Source inspection established that MarkdownText defaults to smoothing and continues its animator after the underlying state stops running. These observations did **not** prove that the synthetic adapter emitted new chunks after abort.

The primary designer configured smoothing off specifically for incomplete/cancelled messages. In the focused post-repair probe, with four unsent filenames and the six-line draft, the immediate sample at approximately 4 ms still reflected the prior render. At approximately 100, 479, and 1184 ms after the click, assistant text was identical at 694 characters and Stop was absent. Draft, four chips, and input focus persisted. The final repaired frame was actually viewed: Send was present, the working dot was absent, and the source composer remained intelligible. This verifies the sampled cancellation outcome; it is not an input-latency measurement.

## Evidence and reproduction

All paths are relative to evidence/observer/.

- **Attempt 003:** root-level 01–12 PNGs, episode.json, trace.zip, episode-attempt-003.py, and command-003/. Its stream completed before the attempted Stop; retain that limitation.
- **Attempts 004–005:** distinct run-004/ and run-005/ directories, original scripts, command captures, and run-005/stop-detail.json. They preserve the pre-repair temporal finding.
- **Source explanation:** command-006-source/ contains exact captured excerpts.
- **Repaired Stop:** stop-recheck.py, command-007-repaired-stop/, and run-007-repaired-stop/ contain the original command, sampled text, result, screenshots, source hashes, and browser version.
- **Actual visual review:** VISUAL-REVIEW.md enumerates the nine images opened. Each corresponding view-*.json preserves the original image-tool result.
- **Failed setup attempts:** command-001/ retains the runuser permission failure; command-002/ retains the overly broad textarea selector failure. These were observation-tool setup failures, not product defects.

Reproduce the full episode with episode-attempt-003.py or episode.py using the supplied Python/Chromium configuration and capture wrapper; use a new output directory to preserve prior evidence. Start a question, wheel upward, select all four files through Add, fill the six-line draft, Shift+Tab twice, Enter, Escape, remove one chip, return to latest, stop, and send another question.

These are automated GUI episodes, ordered screenshots, source inspection, and sampled geometry/focus/text evidence. Natural-speed motion was not viewed; recorded traces were not played back. No real IME, assistive-technology, native mobile, or device-keyboard coverage is claimed. No further consequential continuity gap was identified within this scoped observation; the primary retains the final design judgment.
