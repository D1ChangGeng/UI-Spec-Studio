# Conversation continuity research

Researcher report, 2026-11-01. Saved at [FINAL.md](sandbox:/workspace/scratch/e1cfe6e447ee/ui-study/active-worksets/w15/evidence/research/FINAL.md). This is decision support, not a product design decision or acceptance. **No product code was changed.**

## Most useful finding

The existing assistant-ui family remains a credible foundation for the coupled composer/reading task. The consequential alternatives concern attachment disclosure and how much vertical space a growing prompt consumes; the public examples do not justify replacing the current runtime. A complete external workspace also exposes why inspecting a composer alone is insufficient: its placement can change substantially between an empty entry state and a populated conversation.

## Actual observations

### Current Meridian — local assembled UI

Observed the running app at `http://127.0.0.1:4415/?theme=light&lang=en`, 1280×600, device scale 1, using the supplied sandboxed Chromium and required Chinese font configuration.

- With six lines of mixed-language text, the textarea measured **654×152 CSS px**. In the viewed capture, the enclosing composer occupies roughly the lower third of the compact viewport, retains the reading-column width, and keeps attach/send actions on one bottom row. The six lines remain legible, including the Chinese text.
- During a synthetic response, a wheel scroll into older material produced a visible **return-to-latest arrow above the composer**, while the stop control remained reachable. The sampled view shows older paragraphs and continuing generation controls together.
- These are ordered, controlled samples, not natural-time playback or proof of a stable anchor throughout every intervening frame.
- The first attachment probe looked for an already-present file input. This app creates it on demand, so the probe did not attach files. **No attachment success claim follows from that run.** The independent observer should use the visible “Add local filename” control and the real file chooser.

Genuinely viewed and retained:

- [Six-line composer](sandbox:/workspace/scratch/e1cfe6e447ee/ui-study/active-worksets/w15/evidence/research/meridian-compact-six-line.png)
- [Scrolled away during generation](sandbox:/workspace/scratch/e1cfe6e447ee/ui-study/active-worksets/w15/evidence/research/meridian-scroll-away.png)

Additional captures, not individually reviewed, are `meridian-compact-empty.png` and `meridian-streaming.png`. Full actual image-tool responses are retained in the `view-*.json` files. Executed actions and timestamped stdout are in `observe_current.py` and `command-003/`.

### Ant Design X 2.10.0 — disclosure and full-workspace alternatives

Viewed the original public [attachment examples](https://x.ant.design/components/attachments) and [standalone Sender.Header demonstration](https://x.ant.design/~demos/attachments-demo-with-sender).

The expanded state has a distinct “Attachments” header, close control, centered drop area, then a separate input/action row. Closing the header removes the attachment region; **the input row remains at the same vertical position in this isolated demo**. This establishes deliberate disclosure and stable actions. It does **not** demonstrate that a conversation reclaims the vacated space: the example leaves blank space above the row. A local thread composition trial is required for that claim.

The documented attachment overflow choices are `wrap`, `scrollX`, and `scrollY`. These offer materially different ways to manage many files, but their availability does not establish long-filename usability in Meridian. The page exposes original source links to `packages/x/components/attachments/demo/with-sender.tsx` and `packages/x/components/attachments` in `ant-design/x`. genui{"citation":{"ref":"turn58view1"}}

Also viewed the complete [Ultramodern example](https://x.ant.design/docs/playground/ultramodern) and its [standalone workspace](https://x.ant.design/~demos/docs-playground-ultramodern-demo-ultramodern).

At the cloud browser’s 1363×936 capture size, it has a 280px sidebar, a centered assistant title, a very wide input beneath it, a contextual inline “X SDK” token, a lower-left “Deep Think” action, and a strong blue send action at the far right. The input is the central entry object. This differs materially from Meridian’s narrow reading column and bottom composer.

Selecting an existing-looking history item did not produce a populated conversation in the observed sample. It therefore supplies an **entry-state reference**, not verified long-answer or return behavior.

**Practical adoption path:** use the exact Sender.Header/Attachments implementations and their supported composition if this disclosure model proves useful. Installing Ant Design X would introduce its component and token family into a currently coherent assistant-ui/shadcn application; assess styling, focus and state ownership before considering that cost. No Ant implementation was acquired or trialed here. GitHub source/license fetches returned `DisabledError`; exact source revision and rights remain to be checked before adoption.

### Vercel AI Elements — unified prompt alternative and a maintenance change

Viewed and edited the original [Prompt Input demo](https://elements.ai-sdk.dev/components/prompt-input).

The prompt’s text field and lower toolbar share one rounded boundary. Six mixed-language lines grow above the toolbar; attachment/menu actions remain left and submit remains right. The focus treatment strengthens the entire input boundary. In the viewed example, this makes the prompt read as one object with a stable action row. Its implementation documentation composes attachment content into a `PromptInputHeader` above the body and footer.

A consequential new fact appears in both the rendered page and retrieved text: **AI Elements announces migration to shadcn/ui and deprecation at the end of November 2026.** genui{"citation":{"ref":"turn58view0"}}

The verified [shadcn/ui destination](https://ui.shadcn.com/docs/ai-elements) says existing copied components keep working; new work should use current shadcn/ui compositions. It maps old `attachments.tsx` to Attachment, `conversation.tsx` to Chat, and `prompt-input.tsx` to Prompt Input. This supports preserving an existing pinned source rather than treating an old “latest” installer as a stable adoption path. genui{"citation":{"ref":"turn60view2"}}

The old [Conversation page](https://elements.ai-sdk.dev/components/conversation) documents a return-to-bottom control and a `StickToBottom` context. This is a documented API, not a streaming episode inspected here. genui{"citation":{"ref":"turn59view2"}}

**Practical adoption path:** inspect the current shadcn/ui Prompt Input, Attachment and Message Scroller exact variants before any new acquisition. This is likely a closer token/style fit to Meridian than importing Ant’s whole family, but that is an integration inference. The new replacement variants were textually researched, not visually trialed. No replacement-runtime recommendation is warranted by this evidence.

## Practical comparison

| Candidate | Useful observed relationship | Tradeoff or evidence limit |
|---|---|---|
| Current assistant-ui composition | Narrow readable answer measure; growing input; stable bottom action row; return-to-latest and stop visible after scroll-away | Compact height makes composer growth consequential. Long-file disclosure and continuous anchor behavior require the independent episode. |
| Ant Sender.Header + Attachments | Explicit attachment region with dismissal; stable input row; documented overflow modes | Isolated demo did not reclaim reading space; another visual/state family; source revision and rights not acquired. |
| AI Elements Prompt Input / current shadcn successor | Unified text/header/footer object and strong focus boundary; action row survives six-line growth | Old site is migrating; current successor needs exact-source and local rendering checks; public streaming was not operated. |
| Ant Ultramodern workspace | Complete entry composition with sidebar, contextual prompt token, and broad central input | Empty-entry emphasis differs from sustained reading; populated/return behavior was not established. |

## Next evidence that could change a decision

1. **Use the real local attachment affordance with one short and several long filenames.** Compare the current disclosure with actual source-supported alternatives at 1280×600. Check whether names are distinguishable before hover, full names are available by keyboard/touch, and disclosure changes the reader’s anchor.
2. **Observe one complete synthetic episode:** six-line draft → attachments → send → scroll away while chunks arrive → return to latest → stop → next question. Repeat the meaningful parts in dark/Chinese and at the narrow viewport. Keep focus/scroll state and viewed frames together.
3. If another source remains necessary, inspect the current shadcn Attachment/Prompt Input pattern and an Ant overflow example with identical filename fixtures. Pin the item/revision and verify rights before adoption.
4. Preserve assistant-ui’s runtime owner unless a concrete failing behavior warrants repair. Adding a second independent scroll follower could create a conflict; that is an integration risk to test, not an observed defect.

## Evidence and limits

Original web-tool returned objects are retained as `search-001.json`, `web-002.json`, `web-003.json`, and `web-004.json`. They include official documentation and failed GitHub retrievals.

Current web guidance was searched as prescribed. The relevant `form-fields-automatically-fit-contents` guide was then retrieved and retained in `command-002/`. It recommends explicit width and minimum/maximum size constraints for content-sized textareas, with progressive enhancement. It does not require replacing assistant-ui’s existing sizing implementation.

The owned-app capture first failed on screenshot write permissions; `command-001/` retains that failure. The corrected run wrote screenshots to a task-specific temporary directory and copied them into the research folder. `command-003/` retains its original output.

The extension Browser tool was unavailable; its actual error is retained in `browser-setup.json`. Public examples were genuinely viewed and operated in the available cloud browser. Their screenshots and accessibility outputs remain in the research tool transcript, but the documented capture API did not expose a local-file export. They are **not represented as locally archived PNGs**. Local real captures and original web outputs are archived in the package. No TLS validation was disabled.

Read the supplied role, SKILL, eight common references, evidence map/action guidance, task/input/run controls, and relevant current source. Research did not inspect sibling packages, change the formal SPEC, change product code, authorize original construction, or establish final product acceptance.
