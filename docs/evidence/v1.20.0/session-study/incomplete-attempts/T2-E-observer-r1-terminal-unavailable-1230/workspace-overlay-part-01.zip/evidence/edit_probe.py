import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
OUT=Path(__file__).resolve().parent/'edit-probe';OUT.mkdir(exist_ok=True)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,chromium_sandbox=True)
  page=await b.new_page(viewport={'width':1280,'height':600})
  await page.goto('http://127.0.0.1:4415/?theme=light&lang=en');await page.locator('.aui-composer-input').fill('Edit probe');await page.locator('.aui-composer-input').press('Enter');await page.locator('.aui-composer-cancel').wait_for();await page.wait_for_timeout(200);await page.locator('.aui-composer-cancel').click();await page.wait_for_timeout(150)
  print(json.dumps(await page.locator('button').evaluate_all('(bs)=>bs.map(b=>({text:b.textContent,aria:b.getAttribute("aria-label"),class:b.className}))')),flush=True)
  print('edit class count',await page.locator('.aui-user-action-edit').count(),'name count',await page.get_by_role('button',name='Edit',exact=True).count(),flush=True)
  editbutton=page.get_by_role('button',name='Edit',exact=True).last
  if await editbutton.count():
   await editbutton.click();await page.locator('.aui-edit-composer-input').fill('Edited question keeps the same runtime. 编辑问题。');await page.get_by_role('button',name='Update',exact=True).click();await page.locator('.aui-composer-cancel').wait_for();await page.locator('.aui-composer-cancel').click();await page.screenshot(path=str(OUT/'edited.png'));print('updated',await page.locator('.aui-user-message-content').last.inner_text(),flush=True)
  await b.close()
asyncio.run(main())
