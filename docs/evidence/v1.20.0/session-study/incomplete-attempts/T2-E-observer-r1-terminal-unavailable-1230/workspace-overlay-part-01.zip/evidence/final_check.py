import asyncio, json, time, datetime
from pathlib import Path
from playwright.async_api import async_playwright

OUT=Path(__file__).resolve().parent/'final'
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
FILES=['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','research_reading-continuity_interview-notes_round-three_final.txt','accessibility_findings_English-and-Chinese_2026-final.txt']
SIX='Compare the two readings.\n保留事实与解释的区别。\nTrace each observation.\nExplain uncertainty.\nReturn to prior paragraphs.\nWhat should we verify next?'
results=[]
def save():
  (OUT/'checks.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
def check(case,name,passed,details=None):
  entry={'case':case,'check':name,'pass':bool(passed),'details':details,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  results.append(entry);save();print(json.dumps(entry,ensure_ascii=False),flush=True)
async def measure(page):
  return await page.evaluate('''() => {const v=document.querySelector('[data-slot="aui_thread-viewport"]'),c=document.querySelector('.aui-composer-root'),i=document.querySelector('.aui-composer-input'),a=document.querySelector('.aui-composer-attachments');return {top:v.scrollTop,total:v.scrollHeight,height:v.clientHeight,bottomDistance:v.scrollHeight-v.scrollTop-v.clientHeight,composer:c.getBoundingClientRect().toJSON(),input:{height:i.clientHeight,scrollHeight:i.scrollHeight,value:i.value},attachmentRegion:{height:a.clientHeight,scrollHeight:a.scrollHeight},documentWidth:document.documentElement.scrollWidth,viewport:innerWidth,active:document.activeElement?.className,running:!!document.querySelector('.aui-composer-cancel'),readCalls:window.fileReads||[]}}''')
async def snap(page,name):
  start=time.monotonic()
  await page.screenshot(path=str(OUT/f'{name}.png'))
  results.append({'capture':f'{name}.png','captureStartMonotonic':start,'captureEndMonotonic':time.monotonic(),'state':await measure(page)});save()
async def open_page(browser,w,h,theme,lang,reduce=False):
  context=await browser.new_context(viewport={'width':w,'height':h},device_scale_factor=1,reduced_motion='reduce' if reduce else 'no-preference')
  await context.add_init_script('''window.fileReads=[];for (const name of ['text','arrayBuffer','stream']) {let fn=Blob.prototype[name];if(fn)Blob.prototype[name]=function(...args){window.fileReads.push(name);return fn.apply(this,args)}};for(const name of ['readAsText','readAsDataURL','readAsArrayBuffer','readAsBinaryString']){let fn=FileReader.prototype[name];if(fn)FileReader.prototype[name]=function(...args){window.fileReads.push(name);return fn.apply(this,args)}}''')
  page=await context.new_page()
  requests=[];errors=[]
  page.on('request',lambda r: requests.append({'method':r.method,'url':r.url}))
  page.on('pageerror',lambda e: errors.append(str(e)))
  await page.goto(f'http://127.0.0.1:4415/?theme={theme}&lang={lang}')
  await page.locator('.aui-composer-input').wait_for()
  await page.evaluate('document.fonts.ready')
  await page.wait_for_timeout(200)
  return context,page,requests,errors
async def matrix(browser):
  for w,h in [(1440,900),(1280,600),(390,844)]:
    for theme,lang in [('light','en'),('dark','zh')]:
      name=f'{w}x{h}-{theme}-{lang}'
      context,page,requests,errors=await open_page(browser,w,h,theme,lang)
      try:
        inp=page.locator('.aui-composer-input')
        await inp.fill('One-line question · 单行问题')
        await snap(page,name+'-one-line')
        await inp.fill(SIX)
        async with page.expect_file_chooser() as info:
          await page.locator('.aui-composer-add-attachment').click()
        await (await info.value).set_files([{'name':n,'mimeType':'text/plain','buffer':b'not read by app'} for n in FILES])
        await page.wait_for_timeout(200)
        await snap(page,name+'-expanded')
        m=await measure(page)
        check(name,'six-line composer and four filenames fit without document overflow',m['documentWidth']==w and m['composer']['top']>=64 and m['composer']['bottom']<=h and await page.locator('.aui-filename-chip').count()==4,m)
        trigger=page.locator('.aui-filename-chip [data-slot="dialog-trigger"]').nth(1)
        await trigger.focus();await trigger.press('Enter')
        dialog=page.get_by_role('dialog')
        await dialog.wait_for()
        check(name,'full filename and metadata boundary in keyboard dialog',FILES[1] in await dialog.inner_text() and (('not read or sent' in await dialog.inner_text()) if lang=='en' else ('不读取或发送' in await dialog.inner_text())))
        await snap(page,name+'-filename-dialog')
        await page.keyboard.press('Escape')
        await dialog.wait_for(state='hidden')
        check(name,'Escape restores filename trigger focus',await trigger.evaluate('(e)=>e===document.activeElement'))
        remove=page.locator('.aui-filename-chip').first.get_by_role('button',name=('Remove notes.txt' if lang=='en' else '移除 notes.txt'),exact=True)
        await remove.focus();await remove.press('Enter');await page.wait_for_timeout(80)
        check(name,'remove preserves draft and restores composer focus',await inp.input_value()==SIX and await inp.evaluate('(e)=>e===document.activeElement') and await page.locator('.aui-filename-chip').count()==3)
        long='\n'.join([f'{i+1}. 保留阅读位置 — preserve the current paragraph and inspect this long mixed-language question.' for i in range(20)])
        await inp.fill(long);await page.wait_for_timeout(80)
        m=await measure(page)
        check(name,'long mixed-language input is bounded and scrollable',m['input']['height']<=192 and m['input']['scrollHeight']>m['input']['height'] and m['composer']['top']>100,m)
        await snap(page,name+'-long-input')
        if w==390:
          last=page.locator('.aui-filename-chip [data-slot="dialog-trigger"]').last
          await last.focus()
          visible=await last.evaluate('''e=>{let r=e.getBoundingClientRect(),a=e.closest('.aui-composer-attachments').getBoundingClientRect();return r.top>=a.top-1&&r.bottom<=a.bottom+1}''')
          check(name,'keyboard reaches last filename inside bounded attachment region',visible)
        before=await page.locator('[data-role="user"]').count()
        await inp.fill('输入法确认候选词 — IME test')
        await inp.evaluate("e=>e.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',keyCode:229,isComposing:true,bubbles:true,cancelable:true}))")
        check(name,'composition-confirming Enter does not submit',await page.locator('[data-role="user"]').count()==before)
        await inp.press('Shift+Enter')
        check(name,'Shift+Enter keeps multiline draft', '\n' in await inp.input_value() and await page.locator('[data-role="user"]').count()==before)
        check(name,'no file contents read and no application network mutation',not (await measure(page))['readCalls'] and not [r for r in requests if r['method']!='GET'],{'fileReads':(await measure(page))['readCalls'],'nonGET':[r for r in requests if r['method']!='GET']})
        check(name,'no uncaught page errors',not errors,errors)
      except Exception as e:
        check(name,'scenario exception',False,str(e))
        await page.screenshot(path=str(OUT/(name+'-exception.png')))
      await context.close()

async def behavior(browser,theme,lang):
  name=f'episode-{theme}-{lang}'
  context,page,requests,errors=await open_page(browser,1280,600,theme,lang,True)
  try:
    inp=page.locator('.aui-composer-input')
    await inp.fill('Compare reading continuity. 请比较阅读连续性。')
    await inp.press('Enter');await page.locator('.aui-composer-cancel').wait_for()
    await page.wait_for_timeout(420)
    await snap(page,name+'-streaming')
    await page.mouse.move(800,220);await page.mouse.wheel(0,-300);await page.wait_for_timeout(220)
    a=await measure(page)
    await snap(page,name+'-manual-away')
    await page.wait_for_timeout(320)
    b=await measure(page)
    check(name,'manual reading point remains during response growth',abs(a['top']-b['top'])<=2 and b['total']>a['total'],{'before':a,'after':b})
    await snap(page,name+'-growth-away')
    await page.locator('.aui-thread-scroll-to-bottom').click();await page.wait_for_timeout(90)
    await snap(page,name+'-returned')
    await page.wait_for_timeout(150)
    m=await measure(page)
    check(name,'explicit return resumes following',m['bottomDistance']<=3,m)
    if not await page.locator('.aui-composer-cancel').count():
      await inp.fill('Stop verification');await inp.press('Enter');await page.locator('.aui-composer-cancel').wait_for()
    await inp.fill('Follow-up draft survives stopping. 停止后保留草稿。')
    stop=page.locator('.aui-composer-cancel');await stop.focus();await stop.press('Enter')
    await stop.wait_for(state='hidden');await page.wait_for_timeout(100)
    content=page.locator('[data-slot="aui_assistant-message-content"]').last
    length1=len(await content.inner_text());await page.wait_for_timeout(250);length2=len(await content.inner_text())
    check(name,'keyboard stop aborts chunks and returns to retained draft',length1==length2 and await inp.evaluate('(e)=>e===document.activeElement') and 'Follow-up draft' in await inp.input_value(),{'lengthBefore':length1,'lengthAfter':length2})
    await snap(page,name+'-stopped')
    await inp.fill('[fail] Recovery check · 恢复检查')
    await inp.press('Enter')
    await page.locator('.aui-message-error-root').wait_for(timeout=5000)
    await snap(page,name+'-failure')
    retry=page.get_by_role('button',name='Retry response' if lang=='en' else '重试回答',exact=True).last
    await retry.click();await page.locator('.aui-composer-cancel').wait_for()
    await page.locator('.aui-composer-cancel').wait_for(state='hidden',timeout=15000)
    final=await page.locator('[data-slot="aui_assistant-message-content"]').last.inner_text()
    check(name,'same failed question retries to full unchanged long response',('Observation theme 7' in final if lang=='en' else '观察主题 7' in final) and not await page.locator('.aui-message-error-root').count(),{'responseLength':len(final)})
    await snap(page,name+'-retry-complete')
    count=await page.locator('[data-role="user"]').count()
    await inp.fill('Compare reading continuity. 请比较阅读连续性。');await inp.press('Enter')
    await page.locator('.aui-composer-cancel').wait_for();await page.wait_for_timeout(100)
    await page.locator('.aui-composer-cancel').click();await page.wait_for_timeout(80)
    check(name,'repeat question creates a distinct next turn',await page.locator('[data-role="user"]').count()==count+1)
    await page.locator('.aui-user-action-edit').last.click()
    edit=page.locator('.aui-edit-composer-input');await edit.wait_for()
    await edit.fill('Edited question keeps the same runtime. 编辑问题。')
    await page.get_by_role('button',name='Update',exact=True).click()
    await page.locator('.aui-composer-cancel').wait_for();await page.locator('.aui-composer-cancel').click()
    check(name,'editing and updating remain operable', 'Edited question' in await page.locator('.aui-user-message-content').last.inner_text())
    await snap(page,name+'-edited')
  except Exception as e:
    check(name,'scenario exception',False,str(e));await page.screenshot(path=str(OUT/(name+'-exception.png')))
  await context.close()

async def main():
  async with async_playwright() as p:
    browser=await p.chromium.launch(executable_path=CHROME,headless=True,chromium_sandbox=True)
    await matrix(browser)
    for theme,lang in [('light','en'),('dark','zh')]:await behavior(browser,theme,lang)
    await browser.close()
  failed=[r for r in results if r.get('pass') is False]
  print(json.dumps({'checks':len([r for r in results if 'check'in r]),'failures':failed},ensure_ascii=False),flush=True)
  if failed:raise SystemExit(1)
asyncio.run(main())
