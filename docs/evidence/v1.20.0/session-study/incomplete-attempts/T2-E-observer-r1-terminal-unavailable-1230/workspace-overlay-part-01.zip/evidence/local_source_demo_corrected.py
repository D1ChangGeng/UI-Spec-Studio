import asyncio,json,time
from pathlib import Path
from playwright.async_api import async_playwright
OUT=Path(__file__).resolve().parent/'local-source-demo-corrected'
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
  results=[]
  async with async_playwright() as p:
    browser=await p.chromium.launch(executable_path=CHROME,headless=True,chromium_sandbox=True)
    for theme in ['light','dark']:
      page=await browser.new_page(viewport={'width':900,'height':500},device_scale_factor=1)
      errors=[]
      page.on('pageerror',lambda e:errors.append(str(e)))
      t=time.monotonic()
      await page.goto(f'http://127.0.0.1:4415/reference.html?theme={theme}')
      await page.locator('[data-slot="composer-attachment"]').first.wait_for()
      await page.evaluate('document.fonts.ready')
      await page.screenshot(path=str(OUT/f'{theme}-progress.png'))
      await page.wait_for_timeout(2800)
      await page.screenshot(path=str(OUT/f'{theme}-settled.png'))
      await page.get_by_role('button',name='Remove screenshot.png',exact=True).click()
      await page.screenshot(path=str(OUT/f'{theme}-removed.png'))
      results.append({'theme':theme,'elapsed':time.monotonic()-t,'remaining':await page.locator('[data-slot="composer-attachment"]').count(),'errors':errors})
      await page.close()
    await browser.close()
  (OUT/'results.json').write_text(json.dumps(results,indent=2))
  print(json.dumps(results))
asyncio.run(main())
