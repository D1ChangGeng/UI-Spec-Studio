# Images actually reviewed

Reviewed at the images' native viewport scale through view_image. Original tool results are retained in the named JSON files.

| Actual image | Tool record | Observation |
|---|---|---|
| 01-initial.png | view-01.json | 1280×600 dark Chinese reading surface; source composer and action boundary visible. |
| 04-six-line-draft.png | view-04.json | Four chips in two rows, all six draft lines, clear action row; earlier reading remains above the raised composer. |
| 06-full-name-dialog.png | view-06.json | Full mixed-language filename wraps into two readable lines; focused close control and metadata-only explanation. |
| 07-escape-return.png | view-07.json | Focus outline on original truncated chip; draft and reading context retained. Add tooltip is temporarily visible near the lower left. |
| 08-remove-chip.png | view-08.json | Three remaining chips in one row; composer shrinks and additional earlier text becomes visible. |
| 12-narrow-followup.png | view-12.json | 390×844 readable response, six draft lines, Add and Send. No unsent chips in this narrow frame. |
| run-004/10-stop.png | view-run004-10.json | Send replaces Stop while residual buffered response reveal remains an observed pre-repair nuance. |
| run-005/11-next-question.png | view-run005-11.json | Three filenames accompany the next user question, new synthetic answer underway, composer reset. |
| run-007-repaired-stop/04-after-stop.png | view-run007-04.json | Four chips and exact draft remain; Send visible, working dot absent, partial response settled. |

Other captured images and trace.zip files were retained but not visually reviewed or played back. Geometry was measured before each screenshot; episode.json records capture brackets, so the pixels can reflect a slightly later asynchronous state than the adjacent measurement. Timing includes browser/automation/capture overhead. No natural-speed smoothness claim is made.

Source identity: assistant-ui ff654d8156680b839774296ef644b57ab1078425, actual local Meridian app. Final repaired MarkdownText SHA-256: 49cd8237157a5223b809f50d7a55f7ea29beb892f7929851b68ae21b1869096e. Synthetic adapter remained 0cef30d84918d4dfa47168f34a4fbc9fe637d2e6b874ee08911f6d98f4b2e914.

