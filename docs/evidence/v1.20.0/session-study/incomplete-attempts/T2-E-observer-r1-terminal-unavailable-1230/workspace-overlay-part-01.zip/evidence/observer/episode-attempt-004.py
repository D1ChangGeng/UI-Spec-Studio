import asyncio,json,time,hashlib,os
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path("/workspace/scratch/e1cfe6e447ee/ui-study/active-worksets/w15")
OUT=ROOT/"evidence/observer/run-004"
NAMES=["notes.txt","城市出行访谈摘要_2026-10-31_final-revised-notes.txt","Accessibility_reading-continuity_collaborative-notes_2026_final.md","长文件名_第二轮研究_English-and-中文_完整访谈记录_revision-42.txt"]
DRAFT="第一行：回看来源与证据。\nSecond line: compare observations.\n第三行：保持当前位置。\nFourth line: retain the reading anchor.\n第五行：核对完整文件名。\nSixth line: continue the next question."
async def main():
 OUT.mkdir(exist_ok=True)
 files=OUT/"fixtures";files.mkdir(exist_ok=True)
 for n in NAMES:(files/n).write_text("Synthetic observer fixture, contents not used.",encoding="utf-8")
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path="/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell",headless=True,chromium_sandbox=True)
  ctx=await browser.new_context(viewport={"width":1280,"height":600},device_scale_factor=1,locale="zh-CN",color_scheme="dark")
  await ctx.tracing.start(screenshots=True,snapshots=True,sources=True)
  page=await ctx.new_page();errors=[]
  page.on("pageerror",lambda e:errors.append(str(e)))
  await page.goto("http://127.0.0.1:4415/?theme=dark&lang=zh")
  await page.locator(".aui-composer-input").wait_for()
  await page.evaluate("document.fonts.ready")
  start=time.monotonic();log=[]
  async def snap(label,shot=True):
   before=time.monotonic()
   d=await page.evaluate("""() => {
    const v=document.querySelector('[data-slot="aui_thread-viewport"]'),c=document.querySelector('.aui-composer-root'),a=document.activeElement;
    const box=e=>e?{x:e.getBoundingClientRect().x,y:e.getBoundingClientRect().y,w:e.getBoundingClientRect().width,h:e.getBoundingClientRect().height}:null;
    return {scroll:{top:v.scrollTop,height:v.scrollHeight,client:v.clientHeight},composer:box(c),input:box(document.querySelector('.aui-composer-input')),draft:document.querySelector('.aui-composer-input')?.value,focus:{tag:a.tagName,label:a.getAttribute('aria-label'),text:a.textContent?.slice(0,150)},dialog:document.querySelector('[role=dialog]')?.textContent,chipNames:[...document.querySelectorAll('.aui-composer-root .aui-filename-chip')].map(e=>e.textContent),stopVisible:!!document.querySelector('.aui-composer-cancel'),latest:box(document.querySelector('.aui-thread-scroll-to-bottom')),landmarks:[...document.querySelectorAll('[data-slot="aui_message-group"] h2,[data-slot="aui_message-group"] p')].map(e=>({text:e.textContent.slice(0,60),box:box(e)})),bodyWidth:document.body.scrollWidth,viewport:innerWidth};
   }""")
   if shot and label in ["04-six-line-draft","06-full-name-dialog","10-stop","11-next-question","12-narrow-followup"]:await page.screenshot(path=str(OUT/(label+".png")))
   d.update(label=label,seconds_before=before-start,seconds_after=time.monotonic()-start)
   log.append(d);(OUT/"episode.json").write_text(json.dumps(log,ensure_ascii=False,indent=2))
   print(json.dumps({k:d[k] for k in ["label","seconds_before","seconds_after","scroll","composer","focus","stopVisible"]},ensure_ascii=False),flush=True)
  await snap("01-initial")
  inp=page.locator(".aui-composer-input")
  await inp.fill("请生成长回答，观察阅读连续性。")
  await page.get_by_role("button",name="发送消息",exact=True).click()
  await page.wait_for_timeout(100)
  await page.mouse.move(800,210);await page.mouse.wheel(0,-650)
  await page.wait_for_timeout(50)
  await snap("02-reading-away")
  async with page.expect_file_chooser() as fc:
   await page.get_by_role("button",name="添加本地文件名",exact=True).click()
  chooser=await fc.value
  await chooser.set_files([str(files/n) for n in NAMES])
  await snap("03-four-chips")
  await inp.fill(DRAFT)
  await snap("04-six-line-draft")
  await inp.press("Shift+Tab");await page.keyboard.press("Shift+Tab")
  await snap("05-chip-keyboard-focus",False)
  await page.keyboard.press("Enter")
  await page.get_by_role("dialog").wait_for()
  await snap("06-full-name-dialog")
  await page.keyboard.press("Escape")
  await page.get_by_role("dialog").wait_for(state="hidden")
  await snap("07-escape-return")
  await page.get_by_role("button",name="移除 "+NAMES[2],exact=True).click()
  await snap("08-remove-chip")
  await page.get_by_role("button",name="回到最新内容",exact=True).click()
  await snap("09-return-latest")
  if await page.get_by_role("button",name="停止生成",exact=True).count():
   await page.get_by_role("button",name="停止生成",exact=True).click()
  else:print("STOP_ALREADY_COMPLETED",flush=True)
  await snap("10-stop")
  before=await page.locator('[data-slot="aui_message-group"]').text_content()
  await page.wait_for_timeout(250)
  after=await page.locator('[data-slot="aui_message-group"]').text_content()
  print(json.dumps({"after_stop_text_stable":before==after}),flush=True)
  await inp.fill("下一问：这些附件的文件名是否保留？")
  await page.get_by_role("button",name="发送消息",exact=True).click()
  await page.wait_for_timeout(180)
  await snap("11-next-question")
  if await page.get_by_role("button",name="停止生成",exact=True).count():await page.get_by_role("button",name="停止生成",exact=True).click()
  await page.set_viewport_size({"width":390,"height":844})
  await inp.fill(DRAFT)
  await snap("12-narrow-followup")
  print(json.dumps({"errors":errors,"browser":browser.version,"filename_selection":"Actual filechooser event through visible button; Playwright chooser.set_files","contentHashes":{str(x.relative_to(ROOT)):hashlib.sha256(x.read_bytes()).hexdigest() for x in [ROOT/"app/src/components/assistant-ui/elements/thread.aui.tsx",ROOT/"app/src/components/assistant-ui/elements/filename-attachment.tsx",ROOT/"app/src/synthetic.ts"]}},ensure_ascii=False),flush=True)
  await ctx.tracing.stop(path=str(OUT/"trace.zip"))
  await browser.close()
asyncio.run(main())

