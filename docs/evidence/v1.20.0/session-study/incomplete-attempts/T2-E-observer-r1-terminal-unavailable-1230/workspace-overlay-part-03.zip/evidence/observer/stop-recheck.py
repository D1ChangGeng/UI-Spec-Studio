import asyncio,json,time,hashlib
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path("/workspace/scratch/e1cfe6e447ee/ui-study/active-worksets/w15")
OUT=ROOT/"evidence/observer/run-007-repaired-stop"
DRAFT="第一行：回看来源与证据。\nSecond line: compare observations.\n第三行：保持当前位置。\nFourth line: retain the reading anchor.\n第五行：核对完整文件名。\nSixth line: continue the next question."
async def main():
 OUT.mkdir(exist_ok=True)
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path="/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell",headless=True,chromium_sandbox=True)
  ctx=await browser.new_context(viewport={"width":1280,"height":600},device_scale_factor=1,locale="zh-CN",color_scheme="dark")
  page=await ctx.new_page()
  await page.goto("http://127.0.0.1:4415/?theme=dark&lang=zh")
  inp=page.locator(".aui-composer-input");await inp.wait_for();await page.evaluate("document.fonts.ready")
  await inp.fill("请生成长回答。");await page.get_by_role("button",name="发送消息",exact=True).click()
  await page.wait_for_timeout(150)
  async with page.expect_file_chooser() as fc:await page.get_by_role("button",name="添加本地文件名",exact=True).click()
  await (await fc.value).set_files([str(x) for x in sorted((ROOT/"evidence/observer/fixtures").iterdir())])
  await inp.fill(DRAFT);await page.wait_for_timeout(200)
  await page.screenshot(path=str(OUT/"01-before-stop.png"))
  await page.get_by_role("button",name="停止生成",exact=True).click()
  start=time.monotonic();samples=[]
  for i,delay in enumerate([0,80,300,700]):
   await page.wait_for_timeout(delay)
   val=await page.evaluate("""() => {const a=document.activeElement;return {assistantText:[...document.querySelectorAll('[data-slot="aui_assistant-message-content"]')].at(-1).textContent,stopCount:document.querySelectorAll('.aui-composer-cancel').length,draft:document.querySelector('.aui-composer-input').value,focus:a.getAttribute('aria-label'),chipCount:document.querySelectorAll('.aui-composer-root .aui-filename-chip').length};}""")
   val.update(seconds_after_click=time.monotonic()-start,delay_ms=delay);samples.append(val)
   if i in [1,3]:await page.screenshot(path=str(OUT/(f"0{i+1}-after-stop.png")))
  (OUT/"samples.json").write_text(json.dumps(samples,ensure_ascii=False,indent=2))
  result={"sample_times":[r["seconds_after_click"] for r in samples],"assistant_lengths":[len(r["assistantText"]) for r in samples],"text_identical_after_80ms":len(set(r["assistantText"] for r in samples[1:]))==1,"stop_counts":[r["stopCount"] for r in samples],"draft_retained":all(r["draft"]==DRAFT for r in samples),"focus":[r["focus"] for r in samples],"chip_counts":[r["chipCount"] for r in samples],"browser":browser.version,"source_hashes":{str(x.relative_to(ROOT)):hashlib.sha256(x.read_bytes()).hexdigest() for x in [ROOT/"app/src/components/assistant-ui/elements/markdown-text.tsx",ROOT/"app/src/synthetic.ts"]}}
  print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
  (OUT/"result.json").write_text(json.dumps(result,ensure_ascii=False,indent=2))
  await browser.close()
asyncio.run(main())

