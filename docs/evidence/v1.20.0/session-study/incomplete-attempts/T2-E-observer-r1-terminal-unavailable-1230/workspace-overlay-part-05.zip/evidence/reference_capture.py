import asyncio,json,os,datetime
from pathlib import Path
from playwright.async_api import async_playwright
OUT=Path(__file__).resolve().parent/'references'
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
  results=[]
  async with async_playwright() as p:
    opts={'executable_path':CHROME,'headless':True,'chromium_sandbox':True}
    proxy=os.environ.get('HTTPS_PROXY') or os.environ.get('HTTP_PROXY')
    if proxy: opts['proxy']={'server':proxy}
    browser=await p.chromium.launch(**opts)
    for name,url,heading in [('assistant-chips','https://www.assistant-ui.com/elements/composer-attachments','Attachments'),('vercel-inline','https://elements.ai-sdk.dev/components/attachments','Inline Variant'),('assistant-file','https://www.assistant-ui.com/elements/file','File')]:
      page=await browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
      try:
        await page.goto(url,wait_until='domcontentloaded',timeout=30000)
        await page.get_by_role('heading',name=heading,exact=True).first.scroll_into_view_if_needed()
        await page.wait_for_timeout(1000)
        await page.screenshot(path=str(OUT/f'{name}.png'))
        (OUT/f'{name}.txt').write_text(await page.locator('body').inner_text())
        results.append({'name':name,'url':page.url,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'captured'})
      except Exception as e:
        results.append({'name':name,'url':url,'error':str(e)})
        await page.screenshot(path=str(OUT/f'{name}-failure.png'))
      await page.close()
    await browser.close()
  (OUT/'capture-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
  print(json.dumps(results,ensure_ascii=False))
asyncio.run(main())
