# Conversation continuity research

Researcher report, 2026-11-01. This is decision support, not a product design decision or acceptance. No product code was changed.

## Most useful finding

The existing assistant-ui family remains a credible foundation for the coupled composer/reading task. The consequential alternatives concern attachment disclosure and how much vertical space a growing prompt consumes; the public examples do not justify replacing the current runtime. A complete external workspace also exposes why inspecting a composer alone is insufficient: its placement can change substantially between an empty entry state and a populated conversation.

## Actual observations

### Current Meridian — local assembled UI

Observed the running app at `http://127.0.0.1:4415/?theme=light&lang=en`, 1280×600, device scale 1, the supplied sandboxed Chromium with the required Chinese font configuration.

- With six lines of mixed-language text, the textarea measured 654×152 CSS px. In the viewed capture the enclosing composer occupies roughly the lower third of the compact viewport, retains the same reading-column width, and keeps attach/send actions on one bottom row. The six lines remain legible; the CJK glyphs render.
- During a synthetic response, a wheel scroll into older material produced a visible return-to-latest arrow above the composer while the stop control remained reachable. The sampled view shows older paragraphs and continuing generation controls together.
- These are ordered, controlled samples, not natural-time playback or proof of a stable anchor throughout every intervening frame.
- The first attachment probe looked for an already-present file input. This app creates it on demand, so the probe did not attach files. No attachment success claim follows from that run. The independent observer should use the visible “Add local filename” control and the real file chooser.

Viewed and retained: `meridian-compact-six-line.png`, `meridian-scroll-away.png`. Additional captured, not individually reviewed: `meridian-compact-empty.png`, `meridian-streaming.png`. Full actual image-tool responses are in the `view-*.json` files. Exact executed actions and timestamped stdout are in `observe_current.py` and `command-003/`.

### Ant Design X 2.10.0 — disclosure and full-workspace alternatives

Viewed the original public attachment example and its standalone demonstration:

- https://x.ant.design/components/attachments
- https://x.ant.design/~demos/attachments-demo-with-sender

The expanded state has a distinct “Attachments” header, close control, centered drop area, then a separate input/action row. Closing the header removes the attachment region; the input row remains at the same vertical position in this isolated demo. This is evidence of deliberate disclosure and stable actions. It does **not** demonstrate that a conversation reclaims the vacated space: the isolated example leaves blank space above the row. A local thread composition trial is required for that claim.

Its documented attachment overflow choices are `wrap`, `scrollX`, and `scrollY`. These are materially different ways to manage many files, but their presence does not establish long-filename usability in Meridian. Original source links exposed by the page point to `packages/x/components/attachments/demo/with-sender.tsx` and `packages/x/components/attachments` in `ant-design/x`.

Also viewed the complete Ultramodern example:

- https://x.ant.design/docs/playground/ultramodern
- https://x.ant.design/~demos/docs-playground-ultramodern-demo-ultramodern

At the cloud browser’s 1363×936 capture size it has a 280px sidebar, a centered assistant title, a very wide input beneath it, a contextual inline “X SDK” token, a lower-left “Deep Think” action, and a strong blue send action at the far right. The input is the central entry object. This is a materially different composition from Meridian’s narrow reading column and bottom composer. Selecting an existing-looking history item did not produce a populated conversation in the observed sample. It therefore supplies an entry-state reference, not verified long-answer/return behavior.

**Adoption path:** use the exact Sender.Header/Attachments implementations and their source-supported composition if the disclosure model proves useful. Do not recreate the screenshot. Installing Ant Design X would introduce its component/token family into a currently coherent assistant-ui/shadcn application; assess styling, focus and state ownership before considering that cost. No Ant implementation was acquired or trialed in this research. GitHub source/license fetches returned DisabledError; exact source revision and rights remain to be checked before adoption.

### Vercel AI Elements — unified prompt alternative and a maintenance change

Viewed and edited the original Prompt Input demo:

- https://elements.ai-sdk.dev/components/prompt-input

The prompt’s text field and lower toolbar share one rounded boundary. Six mixed-language lines grow upward from the toolbar; attachment/menu actions remain left and submit remains right. The focus treatment strengthens the entire input boundary. In the viewed example, this makes the prompt read as one object with a stable action row. Its visible implementation documentation composes attachment content into a `PromptInputHeader` above the body and footer.

A consequential new fact appears in both the rendered page and retrieved text: the site announces migration to shadcn/ui and deprecation at the end of November 2026. The destination is verified:

- https://ui.shadcn.com/docs/ai-elements

The new documentation says existing copied components keep working; new work should use current shadcn/ui compositions. It maps old `attachments.tsx` to Attachment, `conversation.tsx` to Chat, and `prompt-input.tsx` to Prompt Input. This supports preserving an existing pinned source rather than treating an old “latest” installer as a stable adoption path.

The old Conversation page documents a conditional return-to-bottom control and a StickToBottom context. That is a documented API, not a streaming episode inspected here:

- https://elements.ai-sdk.dev/components/conversation

**Adoption path:** inspect the current shadcn/ui Prompt Input, Attachment and Message Scroller exact variants before any new acquisition. This is likely a closer token/style fit to Meridian than importing Ant’s whole family, but that is an integration inference. The new replacement variants were textually researched, not visually trialed. No replacement runtime recommendation is warranted by this evidence.

## Practical comparison

| Candidate | Useful observed relationship | Tradeoff / evidence limit |
| --- | --- | --- |
| Current assistant-ui composition | Narrow readable answer measure; growing input; stable bottom action row; return-to-latest and stop visible after scroll-away | Compact height makes composer growth consequential. Long-file disclosure and continuous anchor behavior still require the independent episode |
| Ant Sender.Header + Attachments | Explicit attachment region with dismissal; stable input row; multiple documented overflow modes | Isolated demo did not reclaim reading space; another visual/state family; source revision and rights not acquired |
| AI Elements Prompt Input / current shadcn successor | Unified text/header/footer object and strong focus boundary; action row survives six-line growth | Old site is migrating; current successor needs exact-source and local rendering checks; public streaming was not operated |
| Ant Ultramodern workspace | Complete entry composition with sidebar, contextual prompt token, and broad central input | Empty-entry emphasis differs from a sustained reading workspace; populated/return behavior was not established |

## Next evidence that could change a decision

1. Use the real local attachment affordance with one short and several long filenames. Compare the current disclosure with the actual source-supported alternatives at 1280×600. Check whether names are distinguishable before hover, full names are available by keyboard/touch, and disclosure changes the reader’s anchor.
2. Observe one complete synthetic episode: six-line draft → attachments → send → scroll away while chunks arrive → return to latest → stop → next question. Repeat the meaningful parts in dark/Chinese and at the narrow viewport. Keep focus/scroll state and actual viewed frames together.
3. If a new source is still needed, inspect the current shadcn Attachment/Prompt Input pattern and an Ant overflow example with the same filename fixtures. Pin the exact item/revision and verify rights before adoption.
4. Preserve assistant-ui’s runtime owner unless a concrete failing behavior warrants repair. Adding a second independent scroll follower could create a new conflict; this is an integration risk to test, not an observed defect.

## Evidence and limits

Original web-tool returned objects: `search-001.json`, `web-002.json`, `web-003.json`, `web-004.json`. These include successful official documentation and failed GitHub retrievals.

Current web guidance was searched as prescribed, then the relevant `form-fields-automatically-fit-contents` guide was retrieved and retained in `command-002/`. It recommends explicit width and min/max size constraints for content-sized textareas, and a progressive-enhancement fallback. It does not require replacing assistant-ui’s established sizing implementation.

The owned-app capture first failed on screenshot write permissions; `command-001/` retains that exact failure. The corrected run wrote screenshots to a task-specific temporary directory and copied them into this evidence folder. `command-003/` retains its original output.

The extension Browser tool was unavailable in this context; its actual error is retained in `browser-setup.json`. Public examples were genuinely viewed and operated in the available cloud browser. Their rendered screenshots and accessibility outputs are in the research tool transcript, but the cloud browser did not expose a local-file export through the documented capture API; they are **not** represented as locally archived PNGs. Local real captures and original web outputs are archived here. No TLS validation was disabled.

Read the supplied role, SKILL, eight common references, evidence map/action guidance, task/input/run controls and the relevant current source. Research did not inspect sibling packages, change the formal SPEC, change product code, authorize original construction, or establish final product acceptance.

