import json,time,os
from pathlib import Path
from playwright.sync_api import sync_playwright
out=Path("/tmp/w15-source-research")
out.mkdir(exist_ok=True)
log=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path="/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell",headless=True,chromium_sandbox=True)
 pg=b.new_page(viewport={"width":1280,"height":600},device_scale_factor=1)
 pg.goto("http://127.0.0.1:4415/?theme=light&lang=en",wait_until="networkidle")
 pg.screenshot(path=str(out/"meridian-compact-empty.png"))
 log.append({"state":"initial","text":pg.locator("body").inner_text(),"time":time.time()})
 field=pg.locator("textarea").first
 field.fill("Compare interview findings.\nHighlight contradictions.\nPreserve exact filenames.\nUse a concise outline.\nExplain uncertainty.\n城市出行访谈 — include the mixed-language notes.")
 pg.screenshot(path=str(out/"meridian-compact-six-line.png"))
 log.append({"state":"six-line","textarea":field.bounding_box(),"time":time.time()})
 inputs=pg.locator('input[type="file"]')
 if inputs.count():
  inputs.first.set_input_files([{"name":"notes.txt","mimeType":"text/plain","buffer":b""},{"name":"城市出行访谈摘要_2026-10-31_final-revised-notes.txt","mimeType":"text/plain","buffer":b""},{"name":"research_interviews_analysis_round_4_revised_final.txt","mimeType":"text/plain","buffer":b""}])
  pg.wait_for_timeout(150)
  pg.screenshot(path=str(out/"meridian-compact-attachments.png"))
 log.append({"state":"attachments","text":pg.locator("body").inner_text(),"time":time.time()})
 field.press("Enter")
 pg.wait_for_timeout(1000)
 pg.screenshot(path=str(out/"meridian-streaming.png"))
 pg.mouse.move(850,220);pg.mouse.wheel(0,-1600)
 pg.wait_for_timeout(600)
 pg.screenshot(path=str(out/"meridian-scroll-away.png"))
 log.append({"state":"scroll-away","text":pg.locator("body").inner_text(),"time":time.time()})
 b.close()
print(json.dumps(log,ensure_ascii=False,indent=2))

