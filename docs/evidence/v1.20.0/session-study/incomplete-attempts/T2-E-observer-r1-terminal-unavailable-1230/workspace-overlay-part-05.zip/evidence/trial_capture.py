import asyncio, json, time, datetime
from pathlib import Path
from playwright.async_api import async_playwright

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'trial'
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
    events=[]
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path=CHROME,headless=True,chromium_sandbox=True)
        for name,w,h,theme,lang in [('desktop',1440,900,'light','en'),('compact',1280,600,'dark','zh'),('mobile',390,844,'light','en')]:
            context=await browser.new_context(viewport={'width':w,'height':h},device_scale_factor=1)
            page=await context.new_page()
            page.on('pageerror',lambda error:events.append({'pageerror':str(error)}))
            await page.goto(f'http://127.0.0.1:4415/?theme={theme}&lang={lang}')
            await page.locator('.aui-composer-input').wait_for()
            await page.evaluate('document.fonts.ready')
            await page.wait_for_timeout(400)
            await page.screenshot(path=str(OUT/f'{name}-initial.png'))
            text='Compare the two readings.\n保留事实与解释的区别。\nTrace each observation.\nExplain uncertainty.\nReturn to prior paragraphs.\nWhat should we verify next?'
            await page.locator('.aui-composer-input').fill(text)
            async with page.expect_file_chooser() as chooser_info:
                await page.locator('.aui-composer-add-attachment').click()
            chooser=await chooser_info.value
            await chooser.set_files([{'name':n,'mimeType':'text/plain','buffer':b'metadata fixture'} for n in ['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','research_reading-continuity_interview-notes_round-three_final.txt','accessibility_findings_English-and-Chinese_2026-final.txt']])
            await page.wait_for_timeout(350)
            await page.screenshot(path=str(OUT/f'{name}-expanded.png'))
            geom=await page.evaluate('''() => ({viewport:{width:innerWidth,height:innerHeight}, documentWidth:document.documentElement.scrollWidth, textarea:(()=>{let e=document.querySelector('textarea'),r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,scrollHeight:e.scrollHeight}})(), attachments:[...document.querySelectorAll('.aui-attachment-root')].map(e=>({text:e.innerText,label:e.querySelector('[aria-label]')?.getAttribute('aria-label'),rect:e.getBoundingClientRect().toJSON()})), buttons:[...document.querySelectorAll('button')].map(e=>({text:e.innerText,label:e.getAttribute('aria-label')}))})''')
            events.append({'condition':name,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'geometry':geom})
            await context.close()
        await browser.close()
    (OUT/'observations.json').write_text(json.dumps(events,ensure_ascii=False,indent=2))
    print(json.dumps(events,ensure_ascii=False))
asyncio.run(main())
