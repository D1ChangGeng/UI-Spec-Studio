import asyncio,json,datetime,time
from pathlib import Path
from playwright.async_api import async_playwright
OUT=Path(__file__).resolve().parent/'trial-episode'
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
  results=[]
  async with async_playwright() as p:
    browser=await p.chromium.launch(executable_path=CHROME,headless=True,chromium_sandbox=True)
    page=await browser.new_page(viewport={'width':1280,'height':600},device_scale_factor=1)
    await page.goto('http://127.0.0.1:4415/?theme=light&lang=en')
    await page.locator('.aui-composer-input').wait_for()
    await page.evaluate('document.fonts.ready')
    clock=time.monotonic()
    async def shot(name):
      state=await page.evaluate('''() => {let v=document.querySelector('[data-slot="aui_thread-viewport"]'); let c=document.querySelector('.aui-composer-root');let b=document.querySelector('.aui-thread-scroll-to-bottom');return {scrollTop:v.scrollTop,scrollHeight:v.scrollHeight,clientHeight:v.clientHeight,composer:c.getBoundingClientRect().toJSON(),latestButton:{disabled:b.disabled,visibility:getComputedStyle(b).visibility},running:!!document.querySelector('.aui-composer-cancel'),active:document.activeElement?.className,textLength:document.querySelectorAll('[data-slot="aui_assistant-message-content"]')[1]?.textContent?.length}}''')
      before=time.monotonic()-clock
      await page.screenshot(path=str(OUT/f'{name}.png'))
      results.append({'name':name,'captureStartSeconds':before,'captureEndSeconds':time.monotonic()-clock,'state':state})
    await page.locator('.aui-composer-input').fill('One line question for reading continuity.')
    await page.get_by_role('button',name='Send message',exact=True).click()
    await page.wait_for_timeout(1000)
    await shot('01-stream-start')
    await page.mouse.move(810,220)
    await page.mouse.wheel(0,-360)
    await page.wait_for_timeout(350)
    await shot('02-manual-away')
    await page.wait_for_timeout(1100)
    await shot('03-growth-while-away')
    await page.locator('.aui-thread-scroll-to-bottom').click()
    await page.wait_for_timeout(650)
    await shot('04-explicit-return')
    await page.wait_for_timeout(1000)
    await shot('05-after-return-growth')
    await page.get_by_role('button',name='Stop generating',exact=True).click()
    await page.wait_for_timeout(250)
    await shot('06-stopped')
    await browser.close()
  (OUT/'episode.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
  print(json.dumps(results,ensure_ascii=False))
asyncio.run(main())
