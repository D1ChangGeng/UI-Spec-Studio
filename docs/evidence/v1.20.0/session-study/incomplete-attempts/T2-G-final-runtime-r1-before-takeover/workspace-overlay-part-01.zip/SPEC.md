# SPEC M1 — Compose, disclose, read, and return

## Overall goal and current product
Meridian is an in-memory research conversation with deterministic local synthetic responses and filename-only attachments. The complete assistant-ui cloud family at revision `ff654d8156680b839774296ef644b57ab1078425` is the supplied visual and behavioral foundation. This increment keeps that family and its source notices. It must improve the coupled composer / attachment / answer-space / reading-position experience without replacing mature visual design.

## Cohesive responsibility
Keep one formal SPEC: composer growth changes reading space; attachment expansion changes composer height; streaming and cancellation change the same viewport; return to latest and keyboard focus are the continuation contract. Splitting these by component would conceal the relationship being tested.

Research covers mature conversation products and independent implementations. Primary implementation is source-supported configuration, composition, integration, and specific compatibility/behavior repair in the supplied app. Regression covers sidebar/header, user messages, error/retry, editing, both content locales/themes, compact height, and narrow layout.

## Questions, evidence, and next actions
- D1: Does the mature viewport retain a reader's manual position during growth and composer resizing? Observe baseline send → growth → scroll-away → stop/return, then inspect runtime source only for a concrete defect.
- D2: Do 56px attachment tiles adequately identify several long filenames? Observe short/long filenames with pointer and keyboard. Compare an independently authored coherent attachment treatment and the supplied File/Dialog family. Any chosen composition must retain mature visible relationships.
- D3: How much reading space remains at 1280×600 for six-line input plus attachments? Compare actual geometry and rendered hierarchy. Prefer supported limits and source composition over a new shell.
- D4: Are send/cancel, failure/retry, and return controls understandable and focus-continuous in English and Chinese content conditions? Exercise actual controls and use narrow localized copy where it resolves the task.

## Conditions and boundary
1440×900, 1280×600, supplementary 390×844; light/English and dark/Chinese; one line, six lines, long mixed text, short and several long filenames. Synthetic 72-character/60ms response, full long content, [fail] recovery, and cancellation remain intact. File contents must remain unread and untransmitted. A build, DOM assertion, saved recording, viewed screenshot, and natural-time visual observation are separate evidence claims. Original visual construction is not authorized. Owner acceptance remains pending.

## Initial inherited design judgment
The supplied source establishes an integrated rounded composer, stable action row, 44rem reading measure, sticky viewport footer, semantic theme tokens, Inter / IBM Plex Mono, and accessible primitives. Their actual fit is pending baseline viewing; this record does not infer quality from source possession.

## Baseline findings and bounded trial (2026-10-31)
D1: actual controlled baseline at compact light/en held scrollTop 74 through response growth. Return moved once but remained hundreds of pixels behind continuing content. The documented top-anchor mode defaults autoScroll=false and its hold-follow mechanism is active through the run. Trial the public bottom-anchor configuration, retaining source controller ownership. Pointer stop left BODY focused; a scoped onClick restores the same composer with preventScroll. Cancellation stability will be assessed after deferred Markdown settles, separately from adapter chunk abortion.

D2: actual baseline images show indistinguishable 56px document tiles. Trial the supplied File.Root muted/sm row (official File example), existing Dialog surface and attachment runtime. Filename, per-file removal, horizontal composer strip and source-supported read-only wrapped message attachments remain coordinated. No new visual foundation or original exception is used. Detail opens through keyboard/touch and shows the complete filename and truthful metadata-only boundary.

D3: source composer starts at 94px and grows to 270px for six lines/four files in a 536px viewport. Keep its proportions and action row; constrain the existing textarea maximum by viewport height and use the existing compact File variant. Compare actual resulting reading space before adoption.

D4: retain runtime send/cancel/retry and make only task-critical action labels bilingual. Retry gets an explicit recovery name. Complete source notices and lockfile remain. External rendered assistant-ui demo access failed certificate trust through the inherited proxy; no TLS bypass was attempted. Official documentation and local source render have distinct evidence boundaries.

## Trial finding: cancellation and source animation
Controlled trial 008 passes manual position, draft growth, return-and-follow, focus return, failure/retry, and synthetic disclosure. It shows text continuing to reveal after cancellation. Source inspection identifies the separate default text animator draining already received text, not adapter chunks continuing after AbortSignal. Configure the existing MarkdownTextPrimitive smooth option off only for incomplete messages; keep normal streaming and reduced-motion support. A second cancellation run must verify stable visible text and active Stop in both locales; the first Chinese run completed before its late stop step and does not establish Chinese cancellation.

## Integrated checks and focus correction
Matrix 014 covers both target desktop sizes and the supplementary narrow size in light/en and dark/zh: four selected filenames, keyboard Enter/Space disclosure, Escape return, retained drafts, long mixed input, reachable composer, no whole-page horizontal overflow, and sent-file metadata all pass. Pointer and keyboard Stop both leave stable text at 120ms and 720ms after activation in both locales. Removal itself succeeds but its disappearing control leaves BODY focused in all conditions. Apply the same bounded focus-to-composer repair on attachment removal and check it directly; no visible source design changes.

Build tooling: the supplied TypeScript 7 setup contained removed baseUrl and omitted Vite client CSS declarations. Removed the obsolete option and referenced the installed vite/client declarations; typecheck 013 passes. The previous failed outputs are retained.
