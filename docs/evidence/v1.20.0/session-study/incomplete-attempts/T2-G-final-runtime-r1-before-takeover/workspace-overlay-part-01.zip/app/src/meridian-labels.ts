// Product copy only. Theme, typography, surfaces and behavior remain assistant-ui.
export const isChinese = new URLSearchParams(location.search).get("lang") === "zh";
export const labels = isChinese ? {
  input: "输入消息", placeholder: "继续提问…", add: "添加附件", send: "发送消息",
  stop: "停止生成", cancel: "取消发送", latest: "回到最新内容", retry: "重试回答",
  regenerate: "重新生成回答", details: "附件详情", close: "关闭",
  filenameOnly: "仅保留文件名与类型。文件内容不会被读取或发送。",
  files: (count: number) => `${count} 个附件 · 仅文件名`,
  fileDetails: (name: string) => `查看附件详情：${name}`,
  remove: (name: string) => `移除 ${name}`,
} : {
  input: "Message input", placeholder: "Ask a follow-up…", add: "Add attachment", send: "Send message",
  stop: "Stop generating", cancel: "Cancel sending", latest: "Return to latest", retry: "Retry response",
  regenerate: "Regenerate response", details: "Attachment details", close: "Close",
  filenameOnly: "Only the filename and type are retained. File contents are never read or sent.",
  files: (count: number) => `${count} ${count === 1 ? "file" : "files"} · Names only`,
  fileDetails: (name: string) => `View attachment details: ${name}`,
  remove: (name: string) => `Remove ${name}`,
};
