import asyncio,json,time
from pathlib import Path
from datetime import datetime,timezone
from playwright.async_api import async_playwright
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w08'); OUT=ROOT/'evidence/captures'
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
  result={'kind':'controlled_actual_browser_episode','started_at':datetime.now(timezone.utc).isoformat(),'runs':[]}
  async with async_playwright() as p:
    browser=await p.chromium.launch(executable_path=BROWSER,headless=True)
    for theme,lang in [('light','en'),('dark','zh')]:
      page=await browser.new_page(viewport={'width':1280,'height':600},device_scale_factor=1)
      await page.goto(f'http://127.0.0.1:4408/?theme={theme}&lang={lang}');await page.evaluate('document.fonts.ready')
      run={'condition':f'1280x600-{theme}-{lang}','states':[]};result['runs'].append(run)
      async def state(label,shot=True):
        rec={'label':label,'monotonic':time.monotonic(),'state':await page.evaluate('''() => {const e=document.querySelector('[data-slot="aui_thread-viewport"]'), c=document.querySelector('.aui-composer-root'),a=document.activeElement;return {scrollTop:e.scrollTop,scrollHeight:e.scrollHeight,height:e.clientHeight,composerTop:c.getBoundingClientRect().top,focus:{tag:a.tagName,cls:a.className,label:a.getAttribute('aria-label')},assistantText:document.querySelectorAll('[data-slot="aui_assistant-message-content"]')[document.querySelectorAll('[data-slot="aui_assistant-message-content"]').length-1]?.textContent.length,buttons:[...document.querySelectorAll('button')].filter(e=>e.getBoundingClientRect().height).map(e=>({name:e.getAttribute('aria-label')||e.textContent,disabled:e.disabled}))}}''')}
        if shot:
          rec['path']=str(OUT/f'baseline-episode-{theme}-{lang}-{label}.png');before=time.monotonic();await page.screenshot(path=rec['path']);rec['capture_bracket']=[before,time.monotonic()]
        run['states'].append(rec)
      await page.locator('.aui-composer-input').fill('Explain the unresolved observations.');await state('draft');await page.get_by_role('button',name='Send message',exact=True).click();await page.wait_for_timeout(900);await state('stream-start')
      await page.mouse.move(780,220);await page.mouse.wheel(0,-500);await page.wait_for_timeout(400);await state('read-away')
      await page.wait_for_timeout(1200);await state('read-away-growth')
      await page.get_by_role('button',name='Scroll to bottom',exact=True).click();await page.wait_for_timeout(500);await state('return-latest')
      await page.wait_for_timeout(700);await state('latest-growth')
      stop=page.get_by_role('button',name='Stop generating',exact=True)
      if await stop.count(): await stop.click()
      await page.wait_for_timeout(200);await state('stopped');await page.wait_for_timeout(600);await state('stop-stable',False)
      await page.close()
    await browser.close()
  (ROOT/'evidence/baseline-episodes.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
asyncio.run(main())
