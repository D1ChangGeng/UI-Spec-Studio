import asyncio,json,time,hashlib
from pathlib import Path
from datetime import datetime,timezone
from playwright.async_api import async_playwright
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w08'); OUT=ROOT/'evidence/captures';BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
NAMES=['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','transport-accessibility_interviews_round-03_extended-observations.txt','comparison-notes_research-context_and-open-questions_final.txt']
DRAFT='Compare the field notes.\n请保留事实与解释的区别。\nSummarize the first observation.\nExplain the unresolved question.\nKeep the original context.\nContinue the research conversation.'
LONG=('城市阅读连续性与可达性 — compare observations, interpretation, and unresolved questions.\n'*18).strip()
async def main():
 log={'kind':'actual_integrated_browser_checks','started_at':datetime.now(timezone.utc).isoformat(),'layout':[],'interruption':[]}
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=BROWSER,headless=True)
  for w,h in [(1440,900),(1280,600),(390,844)]:
   for theme,lang in [('light','en'),('dark','zh')]:
    page=await browser.new_page(viewport={'width':w,'height':h},device_scale_factor=1)
    errors=[];outbound=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:outbound.append(r.url) if not r.url.startswith('http://127.0.0.1:4408/') else None)
    await page.goto(f'http://127.0.0.1:4408/?theme={theme}&lang={lang}');await page.evaluate('document.fonts.ready');await page.wait_for_timeout(200)
    key=f'final-{w}x{h}-{theme}-{lang}';rec={'condition':key,'frames':[],'checks':{},'errors':errors,'nonlocal_requests':outbound};log['layout'].append(rec)
    async def shot(name):
     path=OUT/f'{key}-{name}.png';a=time.monotonic();await page.screenshot(path=str(path));b=time.monotonic()
     geo=await page.evaluate('''() => {const r=s=>{const e=document.querySelector(s);if(!e)return null;const b=e.getBoundingClientRect();return {x:b.x,y:b.y,width:b.width,height:b.height,scrollTop:e.scrollTop,scrollWidth:e.scrollWidth,clientWidth:e.clientWidth,scrollHeight:e.scrollHeight,clientHeight:e.clientHeight}};return {viewport:r('[data-slot="aui_thread-viewport"]'),composer:r('.aui-composer-root'),input:r('.aui-composer-input'),strip:r('.aui-composer-attachments'),bodyWidth:document.body.scrollWidth,windowWidth:innerWidth}}''')
     rec['frames'].append({'name':name,'path':str(path),'monotonic_bracket':[a,b],'geometry':geo});return geo
    await shot('initial');inp=page.locator('.aui-composer-input')
    await inp.fill('A one-line question');await inp.press('Shift+Enter');await inp.type('第二行');rec['checks']['shift_enter_retains_draft']='\n' in await inp.input_value() and await page.locator('[data-role="user"]').count()==1
    await inp.fill(DRAFT)
    async with page.expect_file_chooser() as chooser:await page.get_by_role('button',name='添加附件' if lang=='zh' else 'Add attachment',exact=True).click()
    await (await chooser.value).set_files([{'name':n,'mimeType':'text/plain','buffer':b'filename-only test fixture'} for n in NAMES]);await page.wait_for_timeout(300)
    geometry=await shot('six-lines-files');rec['checks']['page_has_no_horizontal_overflow']=geometry['bodyWidth']<=w;rec['checks']['all_four_files']=await page.locator('.aui-composer-attachments .aui-attachment-root').count()==4;rec['checks']['composer_reachable']=geometry['composer']['y']>=64 and geometry['composer']['y']+geometry['composer']['height']<=h
    target=page.locator('.aui-attachment-file').nth(1);await target.focus();await target.press('Enter');await page.get_by_role('dialog').wait_for();await page.wait_for_timeout(300)
    rec['checks']['full_filename_disclosed']=NAMES[1] in await page.get_by_role('dialog').inner_text()
    if w in [1280,390]:await shot('filename-details')
    await page.keyboard.press('Escape');await page.wait_for_timeout(150);rec['checks']['dialog_focus_return']=NAMES[1] in (await page.evaluate('document.activeElement.getAttribute("aria-label")') or '');rec['checks']['dialog_draft_retained']=await inp.input_value()==DRAFT
    last=page.locator('.aui-attachment-file').last();await last.focus();await last.press('Space');await page.get_by_role('dialog').wait_for();await page.keyboard.press('Escape');await page.wait_for_timeout(150);rec['checks']['last_file_keyboard_reachable']=NAMES[-1] in (await page.evaluate('document.activeElement.getAttribute("aria-label")') or '')
    remove=page.locator('.aui-attachment-tile-remove').last();await remove.focus();await remove.press('Enter');await page.wait_for_timeout(100);rec['checks']['remove_count_correct']=await page.locator('.aui-composer-attachments .aui-attachment-root').count()==3;rec['remove_focus']=await page.evaluate('({tag:document.activeElement.tagName,label:document.activeElement.getAttribute("aria-label")})')
    await inp.fill(LONG);await page.wait_for_timeout(150);g=await shot('long-mixed-draft') if w==1280 else await page.locator('.aui-composer-input').evaluate('(e)=>({height:e.clientHeight,scrollHeight:e.scrollHeight})');rec['checks']['long_draft_retained']=await inp.input_value()==LONG
    if w==390:
     await inp.fill(DRAFT);await page.get_by_role('button',name='发送消息' if lang=='zh' else 'Send message',exact=True).click();await page.wait_for_timeout(250);await shot('sent-files-streaming');rec['checks']['sent_files_preserved']=await page.locator('.aui-user-message-attachments-end .aui-attachment-file').count()==3;rec['checks']['sent_files_no_remove']=await page.locator('.aui-user-message-attachments-end .aui-attachment-tile-remove').count()==0
     stop=page.get_by_role('button',name='停止生成' if lang=='zh' else 'Stop generating',exact=True)
     if await stop.count():await stop.click()
    await page.close()
  for lang,theme in [('en','light'),('zh','dark')]:
   for activation in ['pointer','keyboard']:
    page=await browser.new_page(viewport={'width':1280,'height':600},device_scale_factor=1)
    await page.goto(f'http://127.0.0.1:4408/?theme={theme}&lang={lang}');await page.evaluate('document.fonts.ready');inp=page.locator('.aui-composer-input');await inp.fill('Test early interruption');await inp.press('Enter');stop=page.get_by_role('button',name='停止生成' if lang=='zh' else 'Stop generating',exact=True);await stop.wait_for();await page.wait_for_timeout(300)
    if activation=='keyboard':await stop.focus();await stop.press('Enter')
    else:await stop.click()
    await page.wait_for_timeout(120)
    first=await page.locator('[data-slot="aui_assistant-message-content"]').last().inner_text();focus=await page.evaluate('document.activeElement.tagName');await page.wait_for_timeout(600);second=await page.locator('[data-slot="aui_assistant-message-content"]').last().inner_text()
    log['interruption'].append({'locale':lang,'activation':activation,'after120ms':first,'after720ms':second,'stable':first==second,'focus':focus,'sendAvailable':await page.get_by_role('button',name='发送消息' if lang=='zh' else 'Send message',exact=True).count()==1})
    await page.close()
  await browser.close()
 (ROOT/'evidence/final-checks.json').write_text(json.dumps(log,ensure_ascii=False,indent=2));print(json.dumps({'layout':[{'condition':r['condition'],'checks':r['checks'],'remove_focus':r['remove_focus'],'errors':r['errors'],'nonlocal_requests':r['nonlocal_requests']} for r in log['layout']],'interruption':log['interruption']},ensure_ascii=False,indent=2))
asyncio.run(main())
