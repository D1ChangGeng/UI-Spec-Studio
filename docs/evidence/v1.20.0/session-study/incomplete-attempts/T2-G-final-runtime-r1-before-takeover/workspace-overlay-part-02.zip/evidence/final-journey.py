import asyncio,json,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w08');OUT=ROOT/'evidence/captures';BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
 log=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=BROWSER,headless=True)
  for lang,theme in [('en','light'),('zh','dark')]:
   page=await browser.new_page(viewport={'width':1280,'height':600},device_scale_factor=1)
   await page.goto(f'http://127.0.0.1:4408/?theme={theme}&lang={lang}');await page.evaluate('document.fonts.ready')
   rec={'condition':f'1280x600-{theme}-{lang}','checks':{},'frames':[]};log.append(rec)
   async def shot(name):
    path=OUT/f'final-journey-{theme}-{lang}-{name}.png';a=time.monotonic();await page.screenshot(path=str(path));rec['frames'].append({'name':name,'path':str(path),'monotonic_bracket':[a,time.monotonic()]})
   stopName='停止生成' if lang=='zh' else 'Stop generating';sendName='发送消息' if lang=='zh' else 'Send message';inp=page.locator('.aui-composer-input')
   user=page.locator('[data-slot="aui_user-message-root"]').last;await user.scroll_into_view_if_needed();await user.hover();await page.get_by_role('button',name='Edit',exact=True).last.click();edit=page.locator('.aui-edit-composer-input');await edit.wait_for();original=await edit.input_value();await edit.fill('An unsaved edit');cancel=page.get_by_role('button',name='Cancel',exact=True);await cancel.focus();await cancel.press('Enter');await page.wait_for_timeout(150);rec['checks']['edit_cancel_focus']=await page.evaluate('document.activeElement.classList.contains("aui-composer-input")');rec['checks']['edit_cancel_retains_original']=original in await page.locator('[data-slot="aui_user-message-root"]').last.inner_text()
   user=page.locator('[data-slot="aui_user-message-root"]').last;await user.scroll_into_view_if_needed();await user.hover();await page.get_by_role('button',name='Edit',exact=True).last.click();await edit.fill('Compare these revised field observations.');await page.get_by_role('button',name='Update',exact=True).click();await page.get_by_role('button',name=stopName,exact=True).wait_for();await page.wait_for_timeout(250);await page.get_by_role('button',name=stopName,exact=True).click();rec['checks']['edit_update_applied']='revised field observations' in await page.locator('[data-slot="aui_user-message-root"]').last.inner_text()
   before=await page.locator('[data-slot="aui_user-message-root"]').count()
   for i in range(2):
    await inp.fill('Repeat this follow-up question.');await inp.press('Enter');await page.get_by_role('button',name=stopName,exact=True).wait_for();await page.wait_for_timeout(220);await page.get_by_role('button',name=stopName,exact=True).click();await page.wait_for_timeout(120)
   rec['checks']['repeat_question_continuity']=await page.locator('[data-slot="aui_user-message-root"]').count()==before+2
   await inp.fill('[fail] final recovery check');await inp.press('Enter');await page.locator('.aui-message-error-root').wait_for();await page.wait_for_timeout(200);await shot('failure')
   retry=page.get_by_role('button',name='重试回答' if lang=='zh' else 'Retry response',exact=True);await retry.focus();await retry.press('Enter');await page.get_by_role('button',name=stopName,exact=True).wait_for();await page.get_by_role('button',name=stopName,exact=True).wait_for(state='detached',timeout=20000);await page.wait_for_timeout(1200);await shot('recovery-complete');rec['checks']['retry_complete']=await page.locator('.aui-message-error-root').count()==0 and '7' in await page.locator('[data-slot="aui_assistant-message-content"]').last.inner_text()
   await page.emulate_media(reduced_motion='reduce');rec['checks']['reduced_motion_scroll']=await page.locator('[data-slot="aui_thread-viewport"]').evaluate('(e)=>getComputedStyle(e).scrollBehavior')=='auto'
   await inp.fill('Reduced-motion continuation');await inp.press('Enter');await page.get_by_role('button',name=stopName,exact=True).wait_for();await page.wait_for_timeout(250);await page.get_by_role('button',name=stopName,exact=True).click();await page.wait_for_timeout(120);a=await page.locator('[data-slot="aui_assistant-message-content"]').last.inner_text();await page.wait_for_timeout(300);b=await page.locator('[data-slot="aui_assistant-message-content"]').last.inner_text();rec['checks']['reduced_motion_stop_stable']=a==b
   await page.close()
  await browser.close()
 (ROOT/'evidence/final-journey.json').write_text(json.dumps(log,ensure_ascii=False,indent=2));print(json.dumps(log,ensure_ascii=False,indent=2))
asyncio.run(main())
