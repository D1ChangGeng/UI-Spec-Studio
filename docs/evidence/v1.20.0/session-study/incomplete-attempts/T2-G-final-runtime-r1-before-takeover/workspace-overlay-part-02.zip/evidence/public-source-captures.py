import asyncio,json,os,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w08'); OUT=ROOT/'evidence/research'
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
 log=[]
 async with async_playwright() as p:
  options={'executable_path':BROWSER,'headless':True}
  proxy=os.environ.get('HTTPS_PROXY') or os.environ.get('HTTP_PROXY')
  if proxy: options['proxy']={'server':proxy}
  browser=await p.chromium.launch(**options)
  for slug in ['file','composer-attachments']:
   page=await browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
   rec={'source':'https://www.assistant-ui.com/elements/'+slug,'condition':'1440x900 public original demo, not local product','started_monotonic':time.monotonic()}
   try:
    response=await page.goto(rec['source'],wait_until='domcontentloaded',timeout=20000);rec['http_status']=response.status if response else None
    await page.wait_for_timeout(800)
    await page.get_by_role('heading',name='File' if slug=='file' else 'Attachments',exact=True).scroll_into_view_if_needed()
    await page.screenshot(path=str(OUT/f'original-{slug}-1440.png'))
    rec['screenshot']=str(OUT/f'original-{slug}-1440.png');rec['title']=await page.title();rec['text']=(await page.locator('body').inner_text())[:18000]
   except Exception as e:rec['error']=str(e)
   log.append(rec);await page.close()
  await browser.close()
 (OUT/'public-source-captures.json').write_text(json.dumps(log,ensure_ascii=False,indent=2));print(json.dumps(log,ensure_ascii=False,indent=2))
asyncio.run(main())
