import asyncio,json,os,time,urllib.request
from pathlib import Path
from playwright.async_api import async_playwright
OUT=Path(__file__).parent
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path="/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell",headless=True,args=["--no-sandbox"])
  context=await browser.new_context(viewport={"width":1440,"height":900},device_scale_factor=1)
  async def verified_fetch(route):
   request=route.request
   if request.method!="GET":
    await route.abort()
    return
   def fetch():
    try:
     with urllib.request.urlopen(request.url,timeout=25) as response:
      return response.status,dict(response.headers),response.read()
    except urllib.error.HTTPError as e:
     return e.code,dict(e.headers),e.read()
   try:
    status,headers,body=await asyncio.to_thread(fetch)
    headers={k:v for k,v in headers.items() if k.lower() not in ['content-encoding','transfer-encoding','content-length']}
    await route.fulfill(status=status,headers=headers,body=body)
   except Exception as e:
    print(json.dumps({'route_error':request.url,'error':str(e)}))
    await route.abort()
  await context.route('**/*',verified_fetch)
  for name,url in [("aie-attachments","https://elements.ai-sdk.dev/components/attachments"),("aie-chatbot","https://elements.ai-sdk.dev/examples/chatbot"),("claude-upload","https://support.claude.com/en/articles/8241126-upload-files-to-claude")]:
   page=await context.new_page()
   try:
    response=await page.goto(url,wait_until="domcontentloaded",timeout=45000)
    await page.wait_for_timeout(1800)
    await page.screenshot(path=str(OUT/(name+"-initial.png")))
    (OUT/(name+"-body.txt")).write_text(await page.locator("body").inner_text())
    (OUT/(name+"-dom.html")).write_text(await page.content())
    print(json.dumps({"name":name,"url":page.url,"status":response.status if response else None,"buttons":await page.get_by_role("button").all_text_contents(),"textareas":await page.locator("textarea").count()},ensure_ascii=False))
    if name=="aie-attachments":
     for anchor in ["inline-variant","list-variant"]:
      loc=page.locator("#"+anchor)
      if await loc.count():
       await loc.scroll_into_view_if_needed()
       await page.screenshot(path=str(OUT/(name+"-"+anchor+".png")))
     loc=page.get_by_text("quarterly-report.pdf",exact=True).first
     if await loc.count():
      await loc.scroll_into_view_if_needed()
      await loc.hover()
      await page.wait_for_timeout(700)
      await page.screenshot(path=str(OUT/(name+"-hover.png")))
    if name=="aie-chatbot":
     print("INPUTS",await page.locator("textarea").evaluate_all("(es)=>es.map(e=>({placeholder:e.placeholder,rect:e.getBoundingClientRect().toJSON()}))"))
     if await page.locator("textarea").count():
      await page.locator("textarea").first.fill("line one\nline two\nline three\nline four\nline five\nline six")
      await page.screenshot(path=str(OUT/(name+"-six-lines.png")))
   except Exception as e:
    print(json.dumps({"name":name,"error":str(e)}))
   await page.close()
  await browser.close()
asyncio.run(main())

