import urllib.request,json,hashlib,concurrent.futures
from pathlib import Path
OUT=Path(__file__).parent
def get(url,name):
 try:
  with urllib.request.urlopen(url,timeout=20) as r:
   body=r.read()
   (OUT/(name+".body")).write_bytes(body)
   (OUT/(name+".response.json")).write_text(json.dumps({"url":url,"status":r.status,"headers":dict(r.headers),"sha256":hashlib.sha256(body).hexdigest()},indent=2))
   return json.loads(body)
 except Exception as e:
  print(json.dumps({"url":url,"error":str(e)}))
  return None
def repo(owner,name):
 commit=get("https://api.github.com/repos/"+owner+"/"+name+"/commits/main",name+"-commit")
 if not commit:return
 sha=commit["sha"]
 tree=get("https://api.github.com/repos/"+owner+"/"+name+"/git/trees/"+sha+"?recursive=1",name+"-tree")
 print(json.dumps({"repository":owner+"/"+name,"sha":sha,"date":commit["commit"]["committer"]["date"]}))
 if not tree:return
 selected=[x["path"] for x in tree["tree"] if (x["path"].endswith(("/attachments.tsx","/conversation.tsx","/prompt-input.tsx","LICENSE","LICENSE.txt","README.md")) and (name!="ai-elements" or x["path"] in ["packages/elements/src/attachments.tsx","packages/elements/src/conversation.tsx","packages/elements/src/prompt-input.tsx","LICENSE","README.md"]))]
 print(json.dumps({"repository":name,"selected":selected}))
 for path in selected[:8]:
  url="https://raw.githubusercontent.com/"+owner+"/"+name+"/"+sha+"/"+path
  try:
   with urllib.request.urlopen(url,timeout=20) as r:
    body=r.read()
    filename=name+"-"+path.replace("/","_")
    (OUT/filename).write_bytes(body)
    (OUT/(filename+".response.json")).write_text(json.dumps({"url":url,"status":r.status,"headers":dict(r.headers),"sha256":hashlib.sha256(body).hexdigest()},indent=2))
    print(json.dumps({"source":path,"file":filename,"bytes":len(body)}))
  except Exception as e: print(json.dumps({"url":url,"error":str(e)}))
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as e:list(e.map(lambda x:repo(*x),[("vercel","ai-elements"),("stackblitz-labs","use-stick-to-bottom")]))

