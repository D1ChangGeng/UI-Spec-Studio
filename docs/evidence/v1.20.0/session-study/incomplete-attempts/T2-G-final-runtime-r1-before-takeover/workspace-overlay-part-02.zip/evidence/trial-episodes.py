import asyncio,json,time
from pathlib import Path
from datetime import datetime,timezone
from playwright.async_api import async_playwright
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w08');OUT=ROOT/'evidence/captures'
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
 log={'kind':'controlled_actual_browser_episode','started_at':datetime.now(timezone.utc).isoformat(),'runs':[]}
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=BROWSER,headless=True)
  for theme,lang in [('light','en'),('dark','zh')]:
   page=await browser.new_page(viewport={'width':1280,'height':600},device_scale_factor=1)
   await page.goto(f'http://127.0.0.1:4408/?theme={theme}&lang={lang}');await page.evaluate('document.fonts.ready')
   rec={'condition':f'1280x600-{theme}-{lang}','states':[],'checks':{}};log['runs'].append(rec)
   async def state(label,shot=True):
    data=await page.evaluate('''() => {const v=document.querySelector('[data-slot="aui_thread-viewport"]'),a=document.activeElement;return {scrollTop:v.scrollTop,scrollHeight:v.scrollHeight,clientHeight:v.clientHeight,gap:v.scrollHeight-v.clientHeight-v.scrollTop,focusTag:a.tagName,focusLabel:a.getAttribute('aria-label'),lastText:document.querySelectorAll('[data-slot="aui_assistant-message-content"]')[document.querySelectorAll('[data-slot="aui_assistant-message-content"]').length-1]?.textContent}}''')
    item={'label':label,'monotonic':time.monotonic(),'data':data}
    if shot:
     item['path']=str(OUT/f'trial-episode-{theme}-{lang}-{label}.png');before=time.monotonic();await page.screenshot(path=item['path']);item['capture_bracket']=[before,time.monotonic()]
    rec['states'].append(item);return data
   send='发送消息' if lang=='zh' else 'Send message';stop='停止生成' if lang=='zh' else 'Stop generating';latest='回到最新内容' if lang=='zh' else 'Return to latest'
   inp=page.locator('.aui-composer-input')
   await inp.fill('Continue the field research.');await page.get_by_role('button',name=send,exact=True).click();await page.wait_for_timeout(500);await state('stream-start')
   await page.mouse.move(780,210);await page.mouse.wheel(0,-600);await page.wait_for_timeout(200);away=await state('read-away')
   await page.wait_for_timeout(500);grown=await state('read-away-growth');rec['checks']['manual_hold']=abs(away['scrollTop']-grown['scrollTop'])<2
   await inp.fill('A follow-up draft\n第二行研究问题\nRetain my reading position\nKeep the context\nCompare the evidence\nContinue after this answer');await page.wait_for_timeout(150);draft=await state('draft-growth');rec['checks']['draft_hold']=abs(grown['scrollTop']-draft['scrollTop'])<2
   await page.get_by_role('button',name=latest,exact=True).click();await page.wait_for_timeout(150);returned=await state('return-latest')
   await page.wait_for_timeout(250);following=await state('latest-growth');rec['checks']['tail_follow']=following['gap']<3
   control=page.get_by_role('button',name=stop,exact=True)
   rec['checks']['stop_present']=await control.count()>0
   if await control.count():await control.click()
   await page.wait_for_timeout(500);stopped=await state('stopped');await page.wait_for_timeout(500);settled=await state('stop-settled',False)
   rec['checks']['stop_stable_after_settle']=stopped['lastText']==settled['lastText'];rec['checks']['stop_focus']=stopped['focusTag']=='TEXTAREA';rec['checks']['draft_retained']=await inp.input_value()=='A follow-up draft\n第二行研究问题\nRetain my reading position\nKeep the context\nCompare the evidence\nContinue after this answer'
   await inp.fill('[fail] Retry this research question');await page.get_by_role('button',name=send,exact=True).click();await page.locator('.aui-message-error-root').wait_for(timeout=10000);await state('failure')
   retry=page.get_by_role('button',name='重试回答' if lang=='zh' else 'Retry response',exact=True);await retry.focus();await retry.press('Enter');await page.get_by_role('button',name=stop,exact=True).wait_for();await state('retry-start');await page.get_by_role('button',name=stop,exact=True).wait_for(state='detached',timeout=20000);await page.wait_for_timeout(500);success=await state('retry-complete')
   rec['checks']['retry_success']=await page.locator('.aui-message-error-root').count()==0 and ('7' in success['lastText']);rec['checks']['synthetic_disclosure']=('Local synthetic response' in success['lastText'] if lang=='en' else '本地合成回答' in success['lastText'])
   await page.close()
  await browser.close()
 (ROOT/'evidence/trial-episodes.json').write_text(json.dumps(log,ensure_ascii=False,indent=2))
 print(json.dumps([{'condition':r['condition'],'checks':r['checks'],'states':[{'label':s['label'],'scrollTop':s['data']['scrollTop'],'gap':s['data']['gap'],'focus':s['data']['focusTag'],'textLength':len(s['data']['lastText'])} for s in r['states']]} for r in log['runs']],ensure_ascii=False,indent=2))
asyncio.run(main())
