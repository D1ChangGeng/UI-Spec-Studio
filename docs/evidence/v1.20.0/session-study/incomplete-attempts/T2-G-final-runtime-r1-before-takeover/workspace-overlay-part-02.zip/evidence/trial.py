import asyncio, json, time
from pathlib import Path
from datetime import datetime, timezone
from playwright.async_api import async_playwright
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w08')
OUT=ROOT/'evidence/captures'
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
  log={'kind':'actual_playwright_baseline','started_at':datetime.now(timezone.utc).isoformat(),'runs':[]}
  async with async_playwright() as p:
    browser=await p.chromium.launch(executable_path=BROWSER, headless=True)
    for w,h,theme,lang in [(1440,900,'light','en'),(1280,600,'dark','zh'),(390,844,'dark','zh')]:
      page=await browser.new_page(viewport={'width':w,'height':h},device_scale_factor=1)
      errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
      await page.goto(f'http://127.0.0.1:4408/?theme={theme}&lang={lang}')
      await page.evaluate('document.fonts.ready');await page.wait_for_timeout(300)
      prefix=f'trial-{w}x{h}-{theme}-{lang}'
      rec={'condition':prefix,'errors':errs,'frames':[]}
      async def capture(name):
        path=OUT/f'{prefix}-{name}.png'
        before=time.monotonic();await page.screenshot(path=str(path));after=time.monotonic()
        rec['frames'].append({'name':name,'path':str(path),'monotonic_bracket':[before,after],'geometry':await page.evaluate('''() => {const r=s=>{const e=document.querySelector(s);if(!e)return null;const x=e.getBoundingClientRect();return {x:x.x,y:x.y,width:x.width,height:x.height,scrollTop:e.scrollTop,scrollHeight:e.scrollHeight,clientHeight:e.clientHeight}};return {viewport:r('[data-slot="aui_thread-viewport"]'),composer:r('.aui-composer-root'),input:r('.aui-composer-input'),bodyWidth:document.body.scrollWidth,innerWidth}}''')})
      await capture('initial')
      inp=page.locator('.aui-composer-input');await inp.fill('Compare the field notes.\n请保留事实与解释的区别。\nSummarize the first observation.\nExplain the unresolved question.\nKeep the original context.\nContinue the research conversation.')
      async with page.expect_file_chooser() as chooser:
        await page.get_by_role('button',name='添加附件' if lang=='zh' else 'Add attachment',exact=True).click()
      await (await chooser.value).set_files([{'name':name,'mimeType':'text/plain','buffer':b'local metadata fixture'} for name in ['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','transport-accessibility_interviews_round-03_extended-observations.txt','comparison-notes_research-context_and-open-questions_final.txt']])
      await page.wait_for_timeout(400);await capture('six-lines-files')
      rec['attachments']=await page.locator('.aui-attachment-root').count()
      detail=page.locator('.aui-attachment-file').nth(1)
      await detail.focus(); await detail.press('Enter'); await page.get_by_role('dialog').wait_for()
      await capture('filename-detail')
      rec['dialogText']=await page.get_by_role('dialog').inner_text()
      await page.keyboard.press('Escape'); await page.wait_for_timeout(150)
      rec['returnFocus']=await page.evaluate('document.activeElement.getAttribute("aria-label")')
      rec['draftRetained']=await inp.input_value()
      log['runs'].append(rec)
      await page.close()
    await browser.close()
  (ROOT/'evidence/trial.json').write_text(json.dumps(log,ensure_ascii=False,indent=2))
  print(json.dumps(log,ensure_ascii=False,indent=2))
asyncio.run(main())
