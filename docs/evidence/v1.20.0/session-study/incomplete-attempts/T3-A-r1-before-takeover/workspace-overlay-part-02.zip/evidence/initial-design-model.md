# Fieldnotes editorial workspace — current design model

One cohesive increment owns reading, related-note navigation, native editing and theme composition. The TiddlyWiki 5.4.1 native store, supplied eight notes and tiddlyweb/filesystem persistence remain authoritative. No original visual construction exception is authorized or used.

Initial question: can an adoptable complete theme distinguish navigation, reading and editing while preserving the long bilingual interview? Compare Notebook 1.4.1 (left rail, centered sheet, beige/dark palettes) with native Snow White and Starlight (serif, textured ground). All are provisional until populated trials.

Research scope includes complete theme source, original demonstration and actual working tasks. Implementation remains within app/wiki. Required regression covers save/reload, cancellation, search/keyboard, related notes, two palettes, 1440×900, 1280×640 and 390×844, English/Chinese UI, and reduced motion.

Evidence is retained under evidence/. External source acquisition, actual adoption and visual inspection are recorded separately. Owner preference and broad accessibility acceptance remain unmeasured.
