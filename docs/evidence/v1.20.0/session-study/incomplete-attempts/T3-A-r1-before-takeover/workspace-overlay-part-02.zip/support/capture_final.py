from pathlib import Path
from playwright.sync_api import sync_playwright
import json,time
R=Path(__file__).resolve().parents[1];O=R/'evidence/captures';I='访谈笔记 — 傍晚通勤';INDEX='Fieldnotes — project index';log=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1);page.set_default_timeout(8000)
 page.on('dialog',lambda d:d.accept());page.goto('http://127.0.0.1:4409',wait_until='networkidle')
 def shot(name):
  page.wait_for_timeout(900);page.evaluate('document.fonts.ready');t=time.monotonic();page.screenshot(path=str(O/name));log.append({'file':name,'capture_start':t,'capture_end':time.monotonic(),'viewport':page.viewport_size,'pageOverflow':page.evaluate('document.documentElement.scrollWidth-innerWidth')})
 def frame():return page.locator('[data-tiddler-title="'+I+'"]')
 def scene(titles):page.evaluate('titles=>$tw.wiki.setText("$:/StoryList","list",null,titles)',titles);page.wait_for_timeout(300);page.evaluate('window.scrollTo(0,0)')
 for pal in ['Day','Night']:
  page.evaluate('p=>$tw.wiki.setText("$:/palette","text",null,p)','$:/palettes/VanillaPaper'+pal)
  for w,h in [(1440,900),(1280,640),(390,844)]:
   page.set_viewport_size({'width':w,'height':h});page.evaluate('()=>{$tw.wiki.setText("$:/state/sidebar","text",null,innerWidth<960?"no":"yes");}')
   scene([I]);shot(f'settled-{pal.lower()}-reading-{w}.png')
   frame().get_by_role('button',name='Edit this tiddler',exact=True).click();page.wait_for_timeout(600)
   page.frame_locator('iframe.tc-edit-texteditor').locator('textarea').focus();shot(f'settled-{pal.lower()}-editing-{w}.png')
   page.get_by_role('button',name='Discard changes to this tiddler',exact=True).click();page.wait_for_timeout(600)
 # Both localized UI conditions, including native pencil/check affordance.
 page.set_viewport_size({'width':1280,'height':640});page.evaluate('()=>{$tw.wiki.setText("$:/language","text",null,"$:/languages/zh-Hans");$tw.wiki.setText("$:/state/sidebar","text",null,"yes");}')
 for pal in ['Day','Night']:
  page.evaluate('p=>$tw.wiki.setText("$:/palette","text",null,p)','$:/palettes/VanillaPaper'+pal);scene([I]);shot(f'settled-chinese-{pal.lower()}-1280.png')
 page.evaluate('()=>{$tw.wiki.setText("$:/language","text",null,"$:/languages/en-GB");$tw.wiki.setText("$:/palette","text",null,"$:/palettes/VanillaPaperDay");$tw.wiki.setText("$:/state/sidebar","text",null,"yes");$tw.wiki.setText("$:/temp/search","text",null,"");}')
 page.set_viewport_size({'width':1440,'height':900});scene([INDEX,I]);page.reload(wait_until='networkidle');shot('settled-start.png')
 print(json.dumps(log,ensure_ascii=False));(R/'evidence/settled-captures.json').write_text(json.dumps(log,indent=2))
 b.close()
