from pathlib import Path
from playwright.sync_api import sync_playwright
import json, time, os
ROOT=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
    page.goto('http://127.0.0.1:4409',wait_until='networkidle')
    page.evaluate('document.fonts.ready')
    page.screenshot(path=str(ROOT/'evidence/captures/baseline-1440.png'))
    print(json.dumps({'title':page.title(),'frames':page.locator('.tc-tiddler-frame').count(),'buttons':page.locator('button').evaluate_all('(els)=>els.map(e=>({title:e.title,aria:e.getAttribute("aria-label"),class:e.className,text:e.textContent})).slice(0,35)')},ensure_ascii=False))
    browser.close()
