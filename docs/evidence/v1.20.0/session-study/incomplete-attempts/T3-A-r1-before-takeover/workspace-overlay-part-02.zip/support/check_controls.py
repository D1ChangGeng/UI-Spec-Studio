from playwright.sync_api import sync_playwright
from pathlib import Path
import json,time
R=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1);page.set_default_timeout(8000);page.goto('http://127.0.0.1:4409',wait_until='networkidle')
 page.get_by_role('button',name='control panel',exact=True).click();page.wait_for_timeout(600)
 cp=page.locator('[data-tiddler-title="$:/ControlPanel"]');cp.get_by_text('Appearance',exact=True).click();cp.get_by_text('Palette',exact=True).click();page.wait_for_timeout(400)
 print(json.dumps({'browser':b.version,'timezone':page.evaluate('Intl.DateTimeFormat().resolvedOptions().timeZone'),'paletteControls':cp.locator('button,input,label').evaluate_all('(els)=>els.filter(e=>(e.textContent+e.title).includes("Paper")).map(e=>({tag:e.tagName,text:e.textContent,title:e.title,aria:e.getAttribute("aria-label")}))')},ensure_ascii=False))
 page.screenshot(path=str(R/'evidence/captures/native-palette-panel.png'))
 cp.get_by_text('Vanilla Paper Night',exact=True).click();page.wait_for_timeout(500)
 print('UI palette selected:',page.evaluate('()=>$tw.wiki.getTiddlerText("$:/palette")'))
 cp.get_by_text('Vanilla Paper Day',exact=True).click();page.wait_for_timeout(300)
 cp.get_by_role('button',name='close',exact=True).click();page.wait_for_timeout(500)
 # Native tags show the related note collection.
 page.locator('[data-tiddler-title="Fieldnotes — project index"]').get_by_text('index',exact=True).click();page.wait_for_timeout(250)
 print('Tag popup links:',page.locator('.tc-block-dropdown').all_text_contents())
 page.keyboard.press('Escape');page.evaluate('()=>{$tw.wiki.setText("$:/StoryList","list",null,["Fieldnotes — project index","访谈笔记 — 傍晚通勤"]);}')
 page.wait_for_timeout(1000);b.close()
