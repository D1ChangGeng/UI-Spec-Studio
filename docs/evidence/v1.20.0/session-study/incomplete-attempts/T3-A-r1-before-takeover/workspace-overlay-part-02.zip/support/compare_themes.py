from pathlib import Path
from playwright.sync_api import sync_playwright
import json,time
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence/captures'
INTERVIEW='访谈笔记 — 傍晚通勤'
INDEX='Fieldnotes — project index'
records=[]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto('http://127.0.0.1:4409',wait_until='networkidle')
    for name,theme,palette in [('paper','$:/themes/BurningTreeC/vanilla-paper','$:/palettes/VanillaPaperDay'),('notebook','$:/themes/nico/notebook','$:/themes/nico/notebook/palettes/beige'),('starlight','$:/themes/tiddlywiki/starlight','$:/palettes/Vanilla')]:
        page.evaluate('([t,p])=>{$tw.wiki.setText("$:/theme","text",null,t);$tw.wiki.setText("$:/palette","text",null,p);}',[theme,palette])
        page.wait_for_timeout(650)
        print(name,page.evaluate('()=>$tw.wiki.filterTiddlers("[all[shadows+tiddlers]tag[$:/tags/Palette]search[beige]]")'))
        if name=='notebook':
            palette=page.evaluate('()=>$tw.wiki.filterTiddlers("[all[shadows+tiddlers]tag[$:/tags/Palette]search[beige]]")[0]')
            if palette:page.evaluate('p=>$tw.wiki.setText("$:/palette","text",null,p)',palette)
        page.wait_for_timeout(350)
        page.evaluate('window.scrollTo(0,0)')
        page.screenshot(path=str(OUT/f'trial-{name}-index.png'))
        frame=page.locator('.tc-tiddler-frame').filter(has=page.locator('.tc-title').get_by_text(INTERVIEW,exact=True))
        if not frame.count():frame=page.locator('[data-tiddler-title="'+INTERVIEW+'"]')
        frame.evaluate('(e)=>e.scrollIntoView({block:"start"})')
        page.wait_for_timeout(300)
        page.screenshot(path=str(OUT/f'trial-{name}-interview.png'))
        records.append({'candidate':name,'theme':theme,'palette':palette,'body':frame.locator('.tc-tiddler-body').evaluate('(e)=>({font:getComputedStyle(e).fontFamily,fontSize:getComputedStyle(e).fontSize,lineHeight:getComputedStyle(e).lineHeight,width:e.getBoundingClientRect().width})'),'viewport':page.viewport_size,'errors':errors[:]})
    page.evaluate('()=>{$tw.wiki.setText("$:/theme","text",null,"$:/themes/BurningTreeC/vanilla-paper");$tw.wiki.setText("$:/palette","text",null,"$:/palettes/VanillaPaperDay");}')
    page.wait_for_timeout(700)
    (ROOT/'evidence/theme-trials.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
    print(json.dumps(records,ensure_ascii=False))
    browser.close()
