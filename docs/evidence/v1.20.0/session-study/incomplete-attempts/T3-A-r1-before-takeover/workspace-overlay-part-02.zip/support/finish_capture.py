from pathlib import Path
from playwright.sync_api import sync_playwright
import json,time
R=Path(__file__).resolve().parents[1];out=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1280,'height':640},device_scale_factor=1);requests=[];page.on('request',lambda r:requests.append(r.url));page.goto('http://127.0.0.1:4409',wait_until='networkidle')
 page.evaluate('()=>{$tw.wiki.setText("$:/StoryList","list",null,["访谈笔记 — 傍晚通勤"]);$tw.wiki.setText("$:/palette","text",null,"$:/palettes/VanillaPaperNight");}')
 page.wait_for_timeout(800);page.emulate_media(reduced_motion='reduce');page.get_by_role('button',name='hide sidebar',exact=True).click();page.wait_for_timeout(800)
 page.screenshot(path=str(R/'evidence/captures/reduced-settled.png'))
 out.append({'motion':'reduce','sidebarState':page.evaluate('()=>$tw.wiki.getTiddlerText("$:/state/sidebar")'),'sidebarRect':page.locator('.tc-sidebar-scrollable').evaluate('(e)=>({x:e.getBoundingClientRect().x,right:e.getBoundingClientRect().right,visibility:getComputedStyle(e).visibility})')})
 page.get_by_role('button',name='show sidebar',exact=True).click();page.wait_for_timeout(400);page.emulate_media(reduced_motion='no-preference')
 page.get_by_role('button',name='hide sidebar',exact=True).click();start=time.monotonic()
 for n,delay in [(1,70),(2,120),(3,350)]:
  page.wait_for_timeout(delay);a=time.monotonic();page.screenshot(path=str(R/f'evidence/captures/normal-motion-{n}.png'));out.append({'file':f'normal-motion-{n}.png','startOffset':a-start,'endOffset':time.monotonic()-start})
 page.get_by_role('button',name='show sidebar',exact=True).click();page.wait_for_timeout(700)
 page.evaluate('()=>{$tw.wiki.setText("$:/StoryList","list",null,["Fieldnotes — project index","访谈笔记 — 傍晚通勤"]);$tw.wiki.setText("$:/palette","text",null,"$:/palettes/VanillaPaperDay");}')
 page.wait_for_timeout(1000)
 (R/'evidence/final-runtime.json').write_text(json.dumps({'observations':out,'network_urls':sorted(set(requests)),'external_requests':[u for u in requests if not u.startswith(('http://127.0.0.1:4409/','data:'))],'browser':b.version},ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False));b.close()
