from pathlib import Path
from playwright.sync_api import sync_playwright
import json
R=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
 page.goto('http://127.0.0.1:4409',wait_until='networkidle')
 page.evaluate('()=>{$tw.wiki.setText("$:/StoryList","list",null,["$:/themes/BurningTreeC/vanilla-paper/readme"]);}')
 page.wait_for_timeout(350)
 page.screenshot(path=str(R/'evidence/captures/paper-source-readme.png'))
 page.evaluate('()=>{$tw.wiki.setText("$:/StoryList","list",null,["Fieldnotes — project index","访谈笔记 — 傍晚通勤"]);$tw.wiki.setText("$:/themes/BurningTreeC/vanilla-paper/options/toolbaralways","text",null,"yes");$tw.wiki.setText("$:/themes/BurningTreeC/vanilla-paper/options/sidebarside","text",null,"start");$tw.wiki.setText("$:/config/Search/AutoFocus","text",null,"false");}')
 page.wait_for_timeout(350)
 page.locator('[data-tiddler-title="Fieldnotes — project index"] .tc-tiddler-body').get_by_role('link',name='访谈笔记 — 傍晚通勤',exact=True).click()
 page.wait_for_timeout(500)
 page.screenshot(path=str(R/'evidence/captures/paper-configured-reading.png'))
 page.locator('[data-tiddler-title="访谈笔记 — 傍晚通勤"]').get_by_role('button',name='Edit this tiddler',exact=True).click()
 page.wait_for_timeout(400)
 print(json.dumps({'iframes':page.locator('iframe').evaluate_all('(els)=>els.map(e=>({cls:e.className,title:e.title}))'),'textareas':page.locator('textarea').evaluate_all('(els)=>els.map(e=>({cls:e.className,value:e.value.slice(0,80)}))'),'frames':[(f.url,f.locator('textarea').count()) for f in page.frames],'buttons':page.locator('.tc-tiddler-edit-frame button').evaluate_all('(els)=>els.map(e=>({aria:e.getAttribute("aria-label"),title:e.title,text:e.textContent}))')},ensure_ascii=False))
 page.screenshot(path=str(R/'evidence/captures/paper-configured-editor.png'))
 page.get_by_role('button',name='cancel',exact=True).click()
 page.wait_for_timeout(500)
 b.close()
