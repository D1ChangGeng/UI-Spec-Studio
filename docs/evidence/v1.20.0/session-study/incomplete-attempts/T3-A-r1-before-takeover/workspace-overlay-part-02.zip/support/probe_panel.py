from playwright.sync_api import sync_playwright
import json
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900});page.set_default_timeout(4000);page.goto('http://127.0.0.1:4409',wait_until='networkidle');page.get_by_role('button',name='control panel',exact=True).click();page.wait_for_timeout(1000)
 print(json.dumps({'titles':page.locator('.tc-tiddler-frame').evaluate_all('(els)=>els.map(e=>e.getAttribute("data-tiddler-title"))'),'body':page.locator('body').inner_text()[-6000:],'buttons':page.locator('button').all_text_contents()},ensure_ascii=False));b.close()
