const fs=require('fs');
const tw=require('../app/vendor/tiddlywiki/boot/boot.js').TiddlyWiki();
tw.boot.argv=[require('path').resolve(__dirname,'../app/wiki')];
tw.boot.boot(()=>{const title='访谈笔记 — 傍晚通勤';const text=tw.wiki.getTiddlerText(title);const ok=text.includes('more than a memorable object')&&text.includes('我们需要保留这些条件差异。')&&tw.wiki.filterTiddlers('[has[draft.of]]').length===0;console.log(JSON.stringify({fresh_native_boot:ok,drafts:tw.wiki.filterTiddlers('[has[draft.of]]'),palette:tw.wiki.getTiddlerText('$:/palette'),language:tw.wiki.getTiddlerText('$:/language'),theme:tw.wiki.getTiddlerText('$:/theme')}));if(!ok)process.exitCode=1;});
