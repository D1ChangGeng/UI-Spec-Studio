from pathlib import Path
from playwright.sync_api import sync_playwright
import json,time,hashlib
R=Path(__file__).resolve().parents[1]; O=R/'evidence/captures'
I='访谈笔记 — 傍晚通勤'; INDEX='Fieldnotes — project index'
log={'checks':[],'errors':[],'captures':[],'started':time.time()}
def check(name,condition,**detail):
 log['checks'].append({'name':name,'pass':bool(condition),**detail});print(name,condition,flush=True)
 if not condition:raise AssertionError(name)
def save(): (R/'evidence/verification.json').write_text(json.dumps(log,ensure_ascii=False,indent=2))
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 context=b.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
 page=context.new_page();page.set_default_timeout(8000)
 page.on('pageerror',lambda e:log['errors'].append(str(e)))
 page.on('dialog',lambda d:d.accept())
 def shot(name):
  before=time.monotonic();page.screenshot(path=str(O/name));log['captures'].append({'file':name,'before':before,'after':time.monotonic(),'viewport':page.viewport_size})
 def fixture(titles):
  page.evaluate('titles=>$tw.wiki.setText("$:/StoryList","list",null,titles)',titles);page.wait_for_timeout(250)
 def frame(title=I): return page.locator('[data-tiddler-title="'+title+'"]')
 def editor(): return page.frame_locator('iframe.tc-edit-texteditor').locator('textarea')
 try:
  page.goto('http://127.0.0.1:4409',wait_until='networkidle')
  # Recover the previous probe through the native cancel control.
  if page.get_by_role('button',name='Discard changes to this tiddler',exact=True).count():page.get_by_role('button',name='Discard changes to this tiddler',exact=True).click()
  page.evaluate('''()=>{
   for(const [p,c] of [["$:/palettes/VanillaPaperDay","#6b6558"],["$:/palettes/VanillaPaperNight","#a49e90"]]){
    const t=$tw.wiki.getTiddler(p);let text=t.fields.text;
    for(const key of ["sidebar-controls-foreground","tiddler-controls-foreground","tiddler-subtitle-foreground"]){text=text.replace(new RegExp("^"+key+":.*$","m"),key+": "+c);}
    $tw.wiki.addTiddler(new $tw.Tiddler(t,{text}));
   }
   $tw.wiki.setText("$:/palette","text",null,"$:/palettes/VanillaPaperDay");
   $tw.wiki.setText("$:/language","text",null,"$:/languages/en-GB");
  }''')
  fixture([INDEX,I]);page.evaluate('window.scrollTo(0,0)');shot('final-day-index-1440.png')
  frame(INDEX).get_by_role('link',name=I,exact=True).click();page.wait_for_timeout(350)
  shot('final-day-reading-1440.png')
  for n in range(3):page.mouse.wheel(0,650);page.wait_for_timeout(130)
  check('complete interview final question reachable',frame().get_by_text('A final unresolved question',exact=True).is_visible())
  shot('final-day-reading-bottom.png')
  frame().get_by_role('link',name='Evidence ledger',exact=True).click();page.wait_for_timeout(350)
  check('related evidence table opened',frame('Evidence ledger').locator('table').count()==1)
  shot('final-day-ledger-1440.png')
  # Return through native sidebar link.
  page.locator('.tc-sidebar-scrollable').get_by_role('link',name=I,exact=True).click();page.wait_for_timeout(300)
  frame().get_by_role('button',name='Edit this tiddler',exact=True).click();page.wait_for_timeout(250)
  original=editor().input_value();changed=original.replace('not simply a memorable object','more than a memorable object').replace('我们需要保留这种条件差异。','我们需要保留这些条件差异。')
  check('English and Chinese editing samples present',changed!=original and 'more than a memorable object' in changed and '保留这些条件差异' in changed)
  editor().fill(changed)
  shot('final-day-editor-1440.png')
  page.get_by_role('button',name='Confirm changes to this tiddler',exact=True).click()
  page.wait_for_timeout(900)
  texts=[(f,str(f.read_text())) for f in (R/'app/wiki/tiddlers').glob('*.tid')]
  persisted=[(f,t) for f,t in texts if ('title: '+I+'\n') in t and 'draft.of:' not in t]
  check('authoritative filesystem write contains both edits',len(persisted)==1 and changed in persisted[0][1],file=str(persisted[0][0]) if persisted else None)
  page.reload(wait_until='networkidle')
  check('reload returns exactly saved native note',page.evaluate('t=>$tw.wiki.getTiddlerText(t)',I)==changed)
  fixture([I]);frame().get_by_role('button',name='Edit this tiddler',exact=True).click();editor().fill(changed+'\nDISCARD-ME-临时修改')
  page.get_by_role('button',name='Discard changes to this tiddler',exact=True).click();page.wait_for_timeout(400)
  check('cancel preserves prior saved content',page.evaluate('t=>$tw.wiki.getTiddlerText(t)',I)==changed)
  check('cancel clears native draft',not page.evaluate('t=>$tw.wiki.findDraft(t)',I))
  # Search with keyboard, then focus and activate the result's native editor.
  search=page.locator('.tc-sidebar-scrollable input[type="search"]').first
  if not search.count():search=page.locator('.tc-sidebar-scrollable input').first
  search.focus();page.keyboard.type('Quiet route');page.wait_for_timeout(350)
  links=page.locator('.tc-search-drop-down').get_by_role('link',name='Quiet route — working draft',exact=True)
  links.first.focus();page.keyboard.press('Enter');page.wait_for_timeout(300)
  edit=frame('Quiet route — working draft').get_by_role('button',name='Edit this tiddler',exact=True)
  edit.focus();page.keyboard.press('Enter');page.wait_for_timeout(200)
  check('keyboard search reaches actual editor',editor().count()==1)
  shot('final-keyboard-editor.png')
  page.get_by_role('button',name='Discard changes to this tiddler',exact=True).click();page.wait_for_timeout(200)
  # Matrix uses native configuration tiddlers to make named capture conditions repeatable.
  for theme in ['Day','Night']:
   page.evaluate('p=>$tw.wiki.setText("$:/palette","text",null,p)','$:/palettes/VanillaPaper'+theme)
   for width,height in [(1440,900),(1280,640),(390,844)]:
    page.set_viewport_size({'width':width,'height':height})
    page.evaluate('()=>{$tw.wiki.setText("$:/state/sidebar","text",null,innerWidth<960?"no":"yes");}')
    fixture([I]);page.evaluate('window.scrollTo(0,0)');page.wait_for_timeout(300)
    shot(f'final-{theme.lower()}-reading-{width}.png')
    check(f'{theme} {width} page reflows',page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
    frame().get_by_role('button',name='Edit this tiddler',exact=True).click();page.wait_for_timeout(200)
    editor().focus();shot(f'final-{theme.lower()}-editing-{width}.png')
    check(f'{theme} {width} editor within viewport',page.locator('iframe.tc-edit-texteditor').evaluate('(e)=>e.getBoundingClientRect().right<=innerWidth+1'))
    page.get_by_role('button',name='Discard changes to this tiddler',exact=True).click();page.wait_for_timeout(150)
  page.set_viewport_size({'width':1280,'height':640});page.evaluate('()=>{$tw.wiki.setText("$:/language","text",null,"$:/languages/zh-Hans");$tw.wiki.setText("$:/state/sidebar","text",null,"yes");}')
  page.wait_for_timeout(350);shot('final-chinese-ui-night-1280.png')
  check('Chinese UI active',page.evaluate('document.documentElement.lang')=='zh-Hans')
  # Native sidebar toggle: controlled timestamped episode. Screenshots are sampled, not video playback.
  page.evaluate('()=>{$tw.wiki.setText("$:/language","text",null,"$:/languages/en-GB");}')
  page.wait_for_timeout(250)
  page.emulate_media(reduced_motion='reduce')
  shot('episode-reduced-before.png')
  page.get_by_role('button',name='hide sidebar',exact=True).click()
  shot('episode-reduced-after.png')
  check('reduced motion sidebar becomes hidden',page.evaluate('()=>$tw.wiki.getTiddlerText("$:/state/sidebar")')=='no')
  page.get_by_role('button',name='show sidebar',exact=True).click();page.wait_for_timeout(300)
  page.emulate_media(reduced_motion='no-preference')
  shot('episode-normal-before.png');page.get_by_role('button',name='hide sidebar',exact=True).click();shot('episode-normal-first.png');page.wait_for_timeout(350);shot('episode-normal-settled.png')
  page.get_by_role('button',name='show sidebar',exact=True).click();page.wait_for_timeout(350)
  # Final persistent start state.
  page.evaluate('()=>{$tw.wiki.setText("$:/palette","text",null,"$:/palettes/VanillaPaperDay");$tw.wiki.setText("$:/state/sidebar","text",null,"yes");}')
  page.set_viewport_size({'width':1440,'height':900});fixture([INDEX,I]);page.evaluate('window.scrollTo(0,0)');page.wait_for_timeout(700);shot('final-start.png')
  check('no runtime page errors',not log['errors'],errors=log['errors'])
 finally:
  log['ended']=time.time();save();context.close();b.close()
