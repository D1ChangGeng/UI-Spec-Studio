# Fieldnotes — final design model

## FN-01: complete editorial research workspace

The complete task is a distinctive, usable bilingual research notebook based on adoptable external work. The audience moves between short observations, a long interview, evidence tables and unfinished arguments. TiddlyWiki 5.4.1's native wiki store, drafts, editor, search, tags, story and filesystem synchronization remain authoritative.

The delivered increment covers the whole workspace's visual foundation and connected read → related evidence → return → edit → save/reload and cancel journeys. It includes day/night, English/Simplified Chinese UI, 1440×900, 1280×640 and 390×844, reduced motion, and narrow table access.

| Layer | Final decision | Evidence / consequence |
| --- | --- | --- |
| Goal and content | Preserve all eight synthetic notes, ambiguity, unfinished status, links and table contents | Content hashes and wrapper-normalized comparisons in `evidence/package-audit.json` |
| Work and state | Native note → draft → save/cancel; browser store → tiddlyweb → Node → filesystem | Command 012 verifies actual write, reload and cancel |
| Composition | Adopt complete Paper theme: bounded sheet, separate sidebar, notebook margin and source narrow layout | Actual source demonstrations and populated Paper/Notebook trials |
| Type and surface | Source serif reading, sans controls, monospace ruled editing; Day/Night palettes | Personally viewed 24-condition matrix plus lower CJK detail |
| Interaction | Native edit/checkmark/cancel, visible controls, native palette chooser and keyboard search | Product/release checks and traces |
| Table reachability | Source `.tc-table-wrapper`, with labelled focusable region around each supplied table | Tab/ArrowRight reaches final cells in Day/Night; desktop shows all columns |
| Quiet behavior | Disable source press animation; retain normal sidebar transition; correct reduced motion to 1 ms | Computed durations, frame samples and eight captured motion states |
| Delivery | Authoritative Node server; native offline export also built and rendered | Commands 028–029 |

## Source selection

Paper was initially a candidate, not a predetermined choice. Notebook challenged it through a left accordion sidebar, fixed top navigation, stronger sans headings and compact narrow navigation. Both complete themes were tried with the same populated material. Tufte CSS supplied cross-domain comparison for editorial margins and secondary information, but no Tufte asset or application shell was imported.

Paper was selected because its distinctive reading and ruled editing surfaces survived long bilingual content. Notebook remains a defensible navigation-first alternative; its narrow bottom bar is useful. The chosen tradeoff favors more reading space and a stronger separation between navigation, reading and editing. This is a design judgment, not measured user preference.

`SOURCE-ADOPTION.md` records exact identities, licenses, observations, adaptation boundaries and risks. No original visual substitute or W1/W2/W3 exception was used.

## Evidence-driven revisions

1. An initial native save produced a title-based file alongside the supplied seed path. The failed attempt is retained. Reset to the seed and enable documented `retain-original-tiddler-path`; native save and reload then agree with the unique disk file.
2. Early Paper captures showed faint controls and dates. Reuse each palette's existing sidebar ink for those three roles.
3. Reduced motion computed 150 ms although the source layout intended 1 ms. Correct the later conflicting declaration; observed final duration is 0.001 s.
4. A supported sticky-title trial produced a narrow editor margin-line artifact. Keep source default normal scrolling titles; long-editor controls remain at the top.
5. The narrow table image revealed clipping despite a 390 px document width. Use Paper's existing scroll wrapper around both tables and prove keyboard reachability of their last columns. This supersedes the geometry-only table conclusion.
6. Remove the temporary Notebook runtime files, then repeat the 24 read/edit captures. Final server page requests no remote resources and transfers approximately 3.37 MB in the local sample.

Earlier observations and rejected states remain in evidence. `evidence/design-model-before-final.md` preserves the prior model and the table decision before implementation.

## Acceptance boundary

Native workflows, complete content, selected source direction, palettes, UI languages, viewports and table composition are implemented and verified under the stated conditions. All 8,823 supplied vendor files match the original manifest. Six note bodies are byte-identical; the other two differ only by table wrappers. Removing those exact recorded wrappers reproduces the complete original bodies. Temporary test edits were restored through native save.

Static inspection, scripted episodes and sampled transitions are distinct evidence. No natural-speed video review, physical mobile typing, screen-reader session, broad browser testing, forced transport-failure recovery or user preference study was performed. Paper is a recent reusable community theme on a mature core, not a claim of established broad production validation.

