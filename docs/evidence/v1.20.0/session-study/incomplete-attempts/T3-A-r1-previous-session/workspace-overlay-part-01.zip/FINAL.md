# Fieldnotes — completed application delivery

Fieldnotes now uses **Vanilla Paper**, a complete reusable TiddlyWiki theme, to give the populated notebook a coherent editorial direction: a warm desk, bounded paper sheets, a fine margin rule, serif reading, separate navigation and a ruled native editor. Day and Night preserve the same composition. The complete bilingual content and TiddlyWiki's real editing and filesystem persistence remain intact.

The runnable source is in [app/wiki](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w09/app/wiki). A verified native single-file export is available as [index.html](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w09/app/wiki/output/index.html). The server remains the authoritative path for saving to the supplied note files.

## Run it

Node 20 or newer is required. No package installation or network connection is needed.

```bash
cd /workspace/scratch/708e8b7f118e/ui-study/worksets/w09/app
PORT=4409 ./start.sh
```

Then open [http://127.0.0.1:4409/](http://127.0.0.1:4409/) in a browser with access to that machine. It starts with the project index and the long interview. Use the native pencil, checkmark and cancel controls. The palette button exposes Vanilla Paper Day and Night; Simplified Chinese remains available in the native Control Panel. The validation server was stopped after checking the delivered build.

![Fieldnotes desktop reading](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w09/evidence/release/en-GB-light-1440-read.png)

## Source choice and implementation

I compared Paper with **Notebook 1.4.1** on the same populated interview and native editor, and inspected **Tufte CSS** for a cross-domain editorial comparison. Notebook's accordion sidebar and compact narrow navigation are useful; its stronger sans headings and denser editor favor navigation and scanning. Paper better carries the requested reading-studio identity through the long bilingual prose and the transition into editing. This is a design judgment, not a measured preference study.

Adopted source: [Vanilla Paper 0.10.0](https://github.com/BurningTreeC/vanilla-paper), Simon Huber, MIT, exact revision `031a78d4d4187128c632f8a647fa05408eddc700`. The complete source and license are retained. The final runtime removes the trial Notebook theme/plugin. All **8,823 supplied TiddlyWiki files** still match the original provenance manifest.

Product changes stay inside `app/wiki/`:

- Select Paper and its existing Day/Night palettes; keep native note controls visible, expose native Home/Palette controls and disable press animation.
- Reuse each palette's existing stronger sidebar ink for resting controls and dates.
- Correct one source declaration that overrode the intended 1 ms reduced-motion layout with 150 ms.
- Apply Paper's existing scrollable table component to the two four-column tables, with labelled keyboard-focusable regions.
- Enable TiddlyWiki's documented `retain-original-tiddler-path` setting so saves stay on the supplied note paths.

Fifty-four of Paper's fifty-five original files are unchanged; the single source-file difference is the reduced-motion declaration. Palette shadows and table composition are documented separately. No replacement UI, custom storage system, external service, image asset or animation engine was added.

## What was verified

| Path or condition | Result and evidence |
| --- | --- |
| Complete interview → Evidence ledger → return | Native navigation exercised; full interview remains present |
| Edit an English and Chinese passage → save → reload | Native editor/checkmark write agrees with the actual unique disk file and reloaded store |
| Cancel changed draft | Saved content remains unchanged; original test text restored through native save |
| Keyboard search → open → editor | Tab/Enter path succeeds; Ctrl+F is not claimed as an application shortcut |
| Reading and editing matrix | 24 real captures across two UI languages, two palettes and all three required viewports |
| Normal/reduced motion | Actual frame samples and eight inspected states; computed duration 0.4 s / 0.001 s |
| Narrow evidence/prototype tables | Tab reaches each region; ArrowRight exposes the final column in both palettes |
| Content integrity | Six note bodies remain byte-identical; removing the recorded wrappers from the two table notes reproduces their exact original bodies |
| Build and offline rendering | `npm run build` succeeds; 3,339,669-byte export renders the initial notes and wrapped table with no page errors |

The narrow table check matters: an earlier screenshot showed clipped columns even though document width equalled viewport width. The source wrapper fixed that defect, and actual keyboard scrolling verified access to the last cells. The failed capture is preserved alongside the corrected result.

Selected rendered body contrast is 14.844:1 in Day and 11.724:1 in Night. Repaired controls and dates measure 5.543:1 and 6.253:1 against their note surfaces. These selected-role measurements do not constitute a complete accessibility audit.

The final server capture observed no page errors or remote resource requests. Its approximately 3.37 MB transfer and 0.83 s local load are recorded observations, not performance guarantees.

## Reviewable evidence

- [SOURCE-ADOPTION.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w09/SOURCE-ADOPTION.md) — exact revisions, rights, source-versus-product comparison and bounded changes.
- [DESIGN-MODEL.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w09/DESIGN-MODEL.md) — final decisions and revisions prompted by evidence.
- [VISUAL-REVIEW.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w09/VISUAL-REVIEW.md) — personally inspected images, controlled episodes and limits.
- [Native workflow checks](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w09/evidence/product/checks.json), [final matrix checks](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w09/evidence/release/checks.json), [table checks](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w09/evidence/table-final/checks.json), and [package audit](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w09/evidence/package-audit.json).
- Representative [dark Chinese editor](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w09/evidence/release/zh-Hans-dark-390-edit.png), [lower Chinese reading](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w09/evidence/release/zh-Hans-dark-390-cjk.png), and [reachable final table column](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w09/evidence/table-final/Day-ledger-last-column.png).

Original command outputs, failures, corrected attempts, source snapshots, browser traces and actual image-tool responses remain under `evidence/`.

## Remaining limits

Paper is a recent community theme on a mature TiddlyWiki core; the delivery does not establish broad production validation. Checks cover the supplied single-user collection in Chromium. Physical mobile typing, screen readers, other browsers, forced transport-failure recovery and user acceptance were not tested.

Narrow tables require horizontal scrolling. Long editing requires returning to the top for save/cancel; the source's sticky-title option was trialed and rejected after a narrow header artifact. Motion was examined through controlled captures and samples, without natural-speed video review, so subjective smoothness and frame pacing remain unverified.

