# Source adoption and comparison

## Scope and authority

This delivery adopts a complete TiddlyWiki theme within the supplied native product. It does not construct a replacement application, editor, icon set, data model or persistence layer. Product changes are confined to `app/wiki/`. No W1/W2/W3 exception was requested or used.

## Exact sources and rights

| Source | Exact revision | Rights and retained material | Disposition |
| --- | --- | --- | --- |
| TiddlyWiki 5.4.1 | `d391595836e2aead565480763f9bf9eb52e29e75` | Complete supplied npm distribution, BSD notices and third-party notices preserved under `app/vendor/tiddlywiki`; original `PROVENANCE.json` retained | Native product, editor, draft store, search, tags and server remain authoritative |
| [Vanilla Paper](https://github.com/BurningTreeC/vanilla-paper), Simon Huber, 0.10.0 | `031a78d4d4187128c632f8a647fa05408eddc700` | MIT; complete source clone in `evidence/sources/vanilla-paper`; license in clone and `app/wiki/themes/paper/LICENSE` | Adopted whole theme with bounded repairs |
| [Notebook](https://github.com/NicolasPetton/Notebook), Nicolas Petton, 1.4.1 | `465c832c885894ee3c97be76449cc524e1252eb0` | MIT; complete comparison source and notices in `evidence/sources/notebook` | Installed temporarily for fair populated trials; removed from final runtime |
| [Tufte CSS](https://github.com/edwardtufte/tufte-css) | `b5d7b7bbe5ce9c4c50fcfad4f19ee3646cfd7ae1` | Source and license retained for research; no runtime assets copied | Cross-domain editorial composition reference only |

The host-provided Noto Sans CJK SC is a test fixture, not a bundled product font. The delivered theme uses its original system font stacks. No imagery, downloaded font, animation engine, external API or remote runtime service was added.

## Evidence ladder

Source acquisition is recorded by command captures 003, 004 and 014, with full exact source identities in `evidence/sources/identities.json` and `evidence/package-audit.json`. Actual rendered source demonstrations are `evidence/trials/paper-source-demo.png` and `notebook-source-demo.png`; retrieved HTML and fetch metadata remain beside them. Their image-tool responses were captured at viewing time.

Both complete themes were then rendered against the same long interview in the owned application. `paper-interview.png` and `notebook-interview.png` show the populated comparison. Additional Notebook menu, editor and narrow dark captures are in `evidence/product/`. Source descriptions did not establish this local fit.

The live Tufte page could not be rendered by the isolated browser because its TLS certificate chain was rejected. Command 013 retains that failure. The original, unaltered cloned index was rendered locally in command 015; `evidence/research/tufte-source-sidenotes.png` was personally viewed. TLS verification was not bypassed.

## Comparative design judgment

Paper's source demonstration establishes a warm desk, a bounded cream sheet, serif reading, compact sans navigation, a red margin rule and a ruled native editor. The populated interview preserves these relationships: long English paragraphs have an editorial rhythm; the Chinese sections remain readable with the host CJK fallback; the sidebar is spatially separate from the reading page. The reading-to-edit change is visibly purposeful through the native draft header, title field, toolbar and ruled monospace body. Night retains the same material and hierarchy rather than becoming a separate design.

Notebook is a consequential challenger. Its left accordion navigation and fixed top bar expose more navigation in a compact space, and its bold sans headings give faster scanning. The observed interview is denser; the translucent top bar overlays the reading area at the captured scroll position. This is a legitimate navigation-first alternative, but Paper better carries the requested editorial character through ordinary long reading and editing. This is the designer's comparative judgment, not measured user preference.

Tufte's broad margin, serif reading and side-note composition illustrate how editorial space can separate primary and secondary information. Importing that publication layout would require a new application shell and would displace the mature native navigation. It informed comparison but was not copied into the product.

## Source-to-product map and bounded changes

The complete Paper theme is in `app/wiki/themes/paper/`. Its original tiddler identities, typography, sizing system, palette identities, responsive composition, sidebar mechanism, editor and icon relationships remain. Fifty-four of its fifty-five original files match the acquired source byte for byte. The only changed source file is `3-surface.tid`; its reduced-motion transition declaration changes from 150 ms to 1 ms. The exact diff is `evidence/source-adaptation.diff`.

Supported settings select Paper and Vanilla Paper Day; expose native Home and Palette controls; keep note toolbars visible; disable press animation; retain normal scrolling titles. Source defaults for serif reading, sans controls, monospace editing, 720 px sheets, margin rule and sidebar composition remain.

Two palette shadows preserve the original `$:/palettes/VanillaPaperDay` and `Night` identities. Each remaps three faint control/subtitle roles to that palette's existing `sidebar-foreground` role. No new colors were invented. Final rendered controls and timestamps measured 5.543:1 in Day and 6.253:1 in Night against their note surfaces. These are selected-role measurements, not a full accessibility conformance audit.

The motion change resolves a source cascade conflict: `1-layout.tid` intends 1 ms under reduced motion, but a later generic 150 ms declaration in `3-surface.tid` overrode it. The repair restores the source's intended instant layout state. Ordinary sidebar interpolation remains the source's 400 ms mechanism. The current motion guidance favors targeted reduced-motion behavior; this is a compatibility repair inside the existing mechanism rather than the introduction of a new blanket animation system.

The source sticky-title option was trialed, then returned to its default `no`. Its narrow editor trial exposed the margin rule crossing the draft heading. `evidence/sticky-trial/` preserves that rejected state. The delivered long editor keeps native scrolling; returning to its top remains necessary for its controls.

Actual narrow-table inspection exposed clipped columns despite a 390 px document width. The two supplied tables now use Paper's existing `.tc-table-wrapper` with its original `overflow-x:auto; max-inline-size:100%` rules. A labelled focusable region permits keyboard scrolling. Every original table byte remains; only wrapper markup was added to `note-05.tid` and `note-06.tid`. This supported composition is recorded in `evidence/table-composition.json` and checked separately in `evidence/table-final/`.

Finally, the documented TiddlyWiki setting `retain-original-tiddler-path: true` keeps native saves on the supplied `note-*.tid` paths. An initial save test exposed duplicate title-based and seed-path files; the failed evidence and disk snapshot are retained. The correction uses the upstream filesystem contract, not a new storage implementation. Official source: [tiddlywiki.info Files](https://tiddlywiki.com/static/tiddlywiki.info%2520Files.html); actual retrieval is `evidence/research/filesystem-configuration.json`.

## Source fidelity and limits

The result is recognisably Paper in its composition, type roles, palette relationships and native reading/editing surfaces. Local improvements are control visibility, source-consistent quiet motion, table reachability and deterministic native file paths. Paper is a recent community release; its author explicitly described incomplete testing. Its maturity is bounded to a complete reusable theme on a mature core, not established broad production validation. Physical mobile keyboards, other browsers, screen readers and large multi-user research collections remain untested.

