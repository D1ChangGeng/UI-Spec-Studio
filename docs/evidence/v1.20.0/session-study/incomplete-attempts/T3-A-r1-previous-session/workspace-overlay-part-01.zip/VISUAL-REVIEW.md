# Visual and behavior review

## Observer and environment

The primary designer personally opened the images below with `view_image`. Exact tool-return objects were saved at viewing time as `evidence/view-*.json`, including the actual returned image data. This document is an authored review, not a tool transcript.

Chromium headless 143.0.7499.4, Playwright 1.57.0, DPR 1, `FONTCONFIG_FILE=/tmp/ui-spec-fonts/fonts.conf`. Sizes: 1440×900, 1280×640 and 390×844. UI locales: en-GB and zh-Hans. Content remains bilingual in both.

## Personally viewed static conditions

| Group | Viewed conditions | Observations |
| --- | --- | --- |
| `evidence/trials/` | Paper and Notebook source demos and both populated interviews | Paper retains cream sheet, margin and serif rhythm with long content. Notebook uses bold sans headings, compact navigation and denser text. |
| `evidence/product/` | Selected Paper desktop/narrow reading and editing; Notebook menu, editor and dark narrow view | Paper's ruled editor distinctly marks editing. Notebook's narrow bottom bar is useful, but its unruled editor is compressed. A captured translucent top bar overlaps the reading area at a trial scroll position. |
| `evidence/research/tufte-source-sidenotes.png` | Unaltered Tufte source index rendered locally | Strong reading column and broad secondary margin; publication layout would displace native application navigation. |
| `evidence/sticky-trial/` | Four desktop/narrow read/edit images | Sticky heading helps orientation but the margin line crosses the narrow draft title. This option was rejected. |
| `evidence/final/` | All 24 read/edit images: two locales × two palettes × three viewports; desktop initial story | Clear title, date, tags and controls; native title focus ring visible in editing. Both languages fit. Night remains warm and legible. |
| `evidence/release/` | Initial 1440 and 390; English light desktop interview; Chinese dark narrow editor and lower CJK passage; narrow ledger; all eight motion frames | Repeat after removing the unused Notebook runtime. Read/edit composition remains. Initial narrow navigation appears above notes and can collapse. The ledger image exposed hidden right-hand columns. |
| `evidence/table-final/` | Day ledger before/after keyboard scroll, Night comparison last column and desktop ledger | Source wrapper contains the table, shows inherited focus and reveals the final column. Desktop preserves all four columns. |
| `evidence/offline/start.png` | Built offline variant at 1440×900 | Paper, native initial notes and sidebar render correctly. Render verification is separate from server persistence. |

Matrix names: `{en-GB,zh-Hans}-{light,dark}-{1440,1280,390}-{read,edit}.png`. Release contains the repeat matrix without the challenger. The later table composition changes only the two table notes; `table-final` is authoritative for those final states.

## Composition and type judgment

At desktop width the 720 px sheet is clearly distinct from the warm desk. The 34 px margin rule provides a recognisable notebook cue. Navigation stays separate on the right. English serif text and the CJK fallback differ in character but coexist with generous line height. Chinese titles retain weight without colliding with controls.

At 1280×640 the source maintains reading width; the shorter viewport shows less content without changing the hierarchy. At 390 px the source removes the red margin, wraps the tag editor and toolbar, and flows the complete interview within the sheet. The native narrow editor remains tall because its full toolbar and content are preserved.

Day and Night share placement, spacing and type roles. Night uses warm dark surfaces. Stronger controls and dates remain subordinate to titles but are visible at rest. Selected measured contrast ratios are 14.844:1 / 11.724:1 for body text and 5.543:1 / 6.253:1 for the repaired control/date roles. This is not full accessibility certification; faint secondary close-list controls and all plugin states were not comprehensively audited.

## Controlled behavior outcomes

Command 012 scrolls the complete interview, follows its native Evidence ledger link and returns by sidebar. It edits one English passage and one Chinese passage in the real iframe editor, saves with the native checkmark, compares the disk body and reloads. A changed draft is cancelled without changing the saved note. The supplied interview was restored by native save.

Keyboard search uses sequential navigation. Ctrl+F did not focus application search here and is not claimed as working. Tab reaches search, typing returns Quiet route, Tab/Enter opens it, and subsequent Tab/Enter reaches its editor. The edit is then cancelled.

The release matrix enters/cancels editing through native localized controls in all 12 locale/palette/size conditions. It retains the entire 2,408-character interview. Native palette switching is exercised through the chooser as well as programmatic test fixtures.

The final table check uses Tab and ArrowRight: ledger scrollLeft 0→165 px; comparison 0→136 px, both palettes. The final cell fits inside the 318 px scroll region. Five ledger rows and four comparison rows remain. This resolves a defect that document-width-only checks missed.

## Temporal evidence

Normal and reduced-motion sidebar episodes retain before, trigger, intermediate and settled PNGs plus requestAnimationFrame samples. In normal motion the sheet moves from the sidebar layout to the centered reading position and the source scalar reaches zero. Reduced motion reaches the same settled composition with computed 0.001 s duration; normal duration is 0.4 s. The intermediate images are actual captures.

These are controlled episodes and still-image observations. No natural-speed video was watched; perceived smoothness, frame pacing and motion comfort remain unverified. The source interpolates layout, so this is not a compositor-only or 60 fps claim.

## Remaining limits

Narrow tables require horizontal scrolling; physical touch interaction and scrollbar discoverability were not tested. Long editing still requires returning to the top for save/cancel. Initial narrow navigation occupies the upper page until collapsed. These are explicit source tradeoffs.

The local run observed no page errors and no remote resource requests. Approximately 3.37 MB transfer and 0.83 s load are a single local sample, not a device/network benchmark. The unchanged upstream server logs a Node `url.parse()` deprecation notice; build logs an inherited npm proxy-config warning. Both completed. Transport-failure recovery, other browsers, screen readers, physical mobile input and user acceptance remain outside the evidence.

