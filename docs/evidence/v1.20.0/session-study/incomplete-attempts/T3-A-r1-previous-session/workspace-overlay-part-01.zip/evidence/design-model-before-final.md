# Fieldnotes — current design model

## SPEC FN-01: editorial research workspace

The complete goal is an expressive, usable bilingual research notebook. The supplied TiddlyWiki 5.4.1 store, native drafts, search/tags, story navigation and editor/save/cancel controls remain authoritative. This one increment owns composition, typography, surface identity and coherent day/night reading and editing across 1440×900, 1280×640 and 390×844. It includes the connected read → related evidence → return → edit → save/reload and cancel journeys because their spatial and persistence relationships determine whether the visual direction is usable.

## Evidence and decisions in progress

- L0/L1: researchers work on durable linked notes, including long bilingual prose, an evidence table and unfinished arguments. Supplied notes retain their complete meaning and cross-links. No new product model or external service.
- L2/L3: native TiddlyWiki shell, sidebar/search/tag lists, story river and per-note editing are the inherited functional and visual baseline. Theme candidates must retain those tasks.
- L4 candidate A: Simon Huber's Vanilla Paper 0.10.0, exact commit 031a78d4d4187128c632f8a647fa05408eddc700. Complete standalone theme with sheet/desk contrast, serif/sans roles, red margin, ruled editor and sliding sidebar. Cross-domain notebook/publishing material is already implemented by its source. Newness and author's stated mobile/accessibility limitations remain risks to test.
- L4 challenger B: Nicolas Petton's Notebook 1.4.1, exact commit 465c832c885894ee3c97be76449cc524e1252eb0. Compact left sidebar, top navigation and beige/dark conditions challenge Paper's page-like reading treatment. MIT source with included mobile plugin.
- L5: sources acquired in evidence/sources, full licenses retained. Actual visual comparison and local fit are pending; source descriptions are not observation. Both candidates are copied intact into app/wiki/themes for temporary local trials. No W1/W2/W3 construction is authorized or proposed.

## Next consequential evidence

Render source demonstrations and the same populated interview under both candidates. Paper wins only if its editorial character persists through complete bilingual reading and native editing without hidden controls or harmful narrow overflow. Compare Notebook's navigation efficiency, reading density and dark state. Then remove unselected runtime code, apply supported configuration only, exercise persistence at the filesystem boundary and personally view final captures.

## Conditions and claim boundary

Chromium 143 headless, Playwright 1.57, device scale 1, host Noto CJK fixture. Static screenshot viewing establishes composition; scripted UI episodes establish exercised outcomes. Natural-speed human playback, physical mobile keyboard, screen-reader acceptance and user preference remain separate and will not be inferred from screenshots.

## Review decision FN-02: table visibility

The actual release/light-390-ledger.png image revealed that native four-column tables overflowed their note frame; document width alone incorrectly looked healthy. Adopt the existing Paper 2-structure.tid .tc-table-wrapper composition around the supplied ledger and prototype tables. Retain every table byte and add a keyboard-focusable, labelled region. This uses source-supported composition, with no new table styling or layout. Reverify actual ArrowRight scrolling to the last column before accepting.
