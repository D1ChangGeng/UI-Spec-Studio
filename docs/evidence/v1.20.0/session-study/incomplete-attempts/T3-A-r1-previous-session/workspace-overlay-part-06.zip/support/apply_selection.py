from pathlib import Path
import shutil,json
P=Path(__file__).resolve().parents[1]
wiki=P/'app/wiki'
shutil.copytree(wiki/'tiddlers',P/'evidence/persistence-attempt-01-tiddlers')
shutil.move(str(P/'evidence/product'),str(P/'evidence/product-attempt-01'))
shutil.rmtree(wiki/'tiddlers');shutil.copytree(P/'evidence/seed-wiki/tiddlers',wiki/'tiddlers')
info=json.loads((wiki/'tiddlywiki.info').read_text());info['config']={'retain-original-tiddler-path':True};(wiki/'tiddlywiki.info').write_text(json.dumps(info,indent=2)+'\n')
settings={'$:/theme':'$:/themes/BurningTreeC/vanilla-paper','$:/palette':'$:/palettes/VanillaPaperDay','$:/themes/BurningTreeC/vanilla-paper/options/toolbaralways':'yes','$:/themes/BurningTreeC/vanilla-paper/options/pressanimation':'no','$:/config/PageControlButtons/Visibility/$:/core/ui/Buttons/home':'show','$:/config/PageControlButtons/Visibility/$:/core/ui/Buttons/palette':'show'}
for i,(title,value) in enumerate(settings.items()):
 if title=='$:/palette':path=wiki/'tiddlers/config-04.tid'
 else:path=wiki/f'tiddlers/fieldnotes-setting-{i}.tid'
 path.write_text(f'title: {title}\n\n{value}\n')
shutil.copy2(P/'evidence/sources/vanilla-paper/LICENSE',wiki/'themes/paper/LICENSE')
print(json.dumps({'selection':settings,'filesystem_config':info['config'],'attempt_preserved':'evidence/product-attempt-01'}))
