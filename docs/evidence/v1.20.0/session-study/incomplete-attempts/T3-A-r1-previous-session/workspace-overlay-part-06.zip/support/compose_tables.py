from pathlib import Path
import re,json
P=Path(__file__).resolve().parents[1];records=[]
for name,label in [('note-05.tid','Evidence ledger table'),('note-06.tid','Prototype comparison table')]:
 f=P/'app/wiki/tiddlers'/name;s=f.read_text();header,body=s.split('\n\n',1)
 opening=f'<div class="tc-table-wrapper" tabindex="0" role="region" aria-label="{label}">\n\n'
 closing='\n</div>\n'
 matches=list(re.finditer(r'(?m)^\|.*(?:\n\|.*)*\n',body));assert len(matches)==1
 m=matches[0];adapted=body[:m.start()]+opening+m.group()+closing+body[m.end():]
 assert adapted.replace(opening,'').replace(closing,'')==body
 f.write_text(header+'\n\n'+adapted)
 records.append({'file':str(f.relative_to(P)),'source_class':'tc-table-wrapper','table_bytes_preserved':True,'added_opening':opening,'added_closing':closing})
(P/'evidence/table-composition.json').write_text(json.dumps(records,indent=2));print(json.dumps(records,indent=2))
