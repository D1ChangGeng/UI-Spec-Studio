from pathlib import Path
from playwright.sync_api import sync_playwright
import json,time
P=Path(__file__).resolve().parents[1];O=P/'evidence/research'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
 response=page.goto((P/'evidence/sources/tufte-css/index.html').as_uri(),wait_until='load',timeout=30000)
 page.screenshot(path=str(O/'tufte-source-top.png'));page.get_by_role('heading',name='Sidenotes: Footnotes and Marginal Notes').scroll_into_view_if_needed();page.screenshot(path=str(O/'tufte-source-sidenotes.png'))
 (O/'tufte-browser.json').write_text(json.dumps({'url':page.url,'status':response.status if response else None,'viewport':page.viewport_size,'at':time.time(),'body_font':page.locator('body').evaluate('(e)=>getComputedStyle(e).fontFamily'),'condition':'unaltered acquired source rendered locally after live browser certificate failure'},indent=2))
 b.close()
