from pathlib import Path
import json
from playwright.sync_api import sync_playwright
P=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900})
 page.goto('http://127.0.0.1:4409/');page.wait_for_timeout(1300)
 print(json.dumps(page.evaluate('()=>({story:$tw.wiki.getTiddlerList("$:/StoryList"),notes:$tw.wiki.filterTiddlers("[has[draft.of]]").map(t=>({title:t,fields:$tw.wiki.getTiddler(t).fields})),orig:$tw.wiki.getTiddler("访谈笔记 — 傍晚通勤").fields})'),ensure_ascii=False,default=str))
 print('frames',len(page.frames))
 for f in page.frames:print(f.url, f.locator('textarea').count(), [f.locator('textarea').nth(i).input_value()[:90] for i in range(f.locator('textarea').count())])
 page.screenshot(path=str(P/'evidence/trials/editor-probe.png'))
 b.close()
