from playwright.sync_api import sync_playwright
import json
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900})
 page.goto('http://127.0.0.1:4409/');page.wait_for_timeout(800)
 page.evaluate('()=>{$tw.wiki.setText("$:/theme","text",null,"$:/themes/BurningTreeC/vanilla-paper");$tw.wiki.setText("$:/palette","text",null,"$:/palettes/VanillaPaperDay");$tw.wiki.setText("$:/themes/BurningTreeC/vanilla-paper/options/toolbaralways","text",null,"yes");$tw.wiki.setText("$:/themes/BurningTreeC/vanilla-paper/options/toolbarhover","text",null,"no");$tw.wiki.setText("$:/StoryList","list",null,["访谈笔记 — 傍晚通勤"])}')
 page.wait_for_timeout(500)
 print(json.dumps(page.locator('button').evaluate_all('(es)=>es.map(e=>({title:e.title,aria:e.getAttribute("aria-label"),class:e.className,text:e.textContent.trim().slice(0,50)}))'),ensure_ascii=False))
 page.locator('button[title="Edit this tiddler"]').first.click();page.wait_for_timeout(350)
 print(json.dumps(page.locator('textarea,input').evaluate_all('(es)=>es.map(e=>({tag:e.tagName,class:e.className,placeholder:e.getAttribute("placeholder"),title:e.title,value:e.value.slice(0,70)}))'),ensure_ascii=False))
 print(json.dumps(page.locator('button').evaluate_all('(es)=>es.filter(e=>e.closest(".tc-tiddler-frame")).slice(0,12).map(e=>({title:e.title,aria:e.getAttribute("aria-label"),class:e.className,text:e.textContent.trim()}))'),ensure_ascii=False))
 b.close()
