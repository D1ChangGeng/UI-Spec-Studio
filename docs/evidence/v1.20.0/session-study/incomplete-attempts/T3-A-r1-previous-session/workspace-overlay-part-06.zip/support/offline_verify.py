from pathlib import Path
from playwright.sync_api import sync_playwright
import json,hashlib
P=Path(__file__).resolve().parents[1];F=P/'app/wiki/output/index.html';O=P/'evidence/offline';O.mkdir(exist_ok=True)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox']);p=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1);errors=[];p.on('pageerror',lambda e:errors.append(str(e)));p.goto(F.as_uri());p.wait_for_function('!!window.$tw&&!!$tw.wiki');p.wait_for_timeout(500)
 result={'bytes':F.stat().st_size,'sha256':hashlib.sha256(F.read_bytes()).hexdigest(),'theme':p.evaluate('$tw.wiki.getTiddlerText("$:/theme")'),'palette':p.evaluate('$tw.wiki.getTiddlerText("$:/palette")'),'story':p.evaluate('$tw.wiki.getTiddlerList("$:/StoryList")'),'page_errors':errors}
 assert result['story']==['Fieldnotes — project index','访谈笔记 — 傍晚通勤'];assert result['theme'].strip()=='$:/themes/BurningTreeC/vanilla-paper';assert not errors
 p.screenshot(path=str(O/'start.png'));p.evaluate('$tw.wiki.setText("$:/StoryList","list",null,["Evidence ledger"])');p.wait_for_timeout(350);assert p.locator('.tc-tiddler-body .tc-table-wrapper').count()==1;assert p.locator('.tc-tiddler-body table tr').count()==5
 result['wrapped_table_rendered']=True;(O/'checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2));b.close()
