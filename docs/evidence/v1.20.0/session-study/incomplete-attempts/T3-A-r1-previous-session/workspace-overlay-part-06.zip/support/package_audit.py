from pathlib import Path
import json,hashlib,shutil,subprocess,difflib
P=Path(__file__).resolve().parents[1];W=P/'app/wiki';E=P/'evidence'
for rel in ['themes/notebook','plugins/notebook-mobile']:
 p=W/rel
 if p.exists():shutil.rmtree(p)
 assert not p.exists(),str(p)
provenance=json.loads((P/'PROVENANCE.json').read_text())
keys=list(provenance)
manifest=next(v for v in provenance.values() if isinstance(v,dict) and len(v)>100)
bad=[]
for rel,expected in manifest.items():
 f=P/'app/vendor/tiddlywiki'/rel
 if not f.exists() or hashlib.sha256(f.read_bytes()).hexdigest()!=expected:bad.append(rel)
assert not bad,bad
adopt=E/'sources/vanilla-paper/themes/BurningTreeC/vanilla-paper';runtime=W/'themes/paper';changes=[];same=0;diffs=[]
for f in adopt.rglob('*'):
 if not f.is_file():continue
 rel=f.relative_to(adopt);g=runtime/rel
 assert g.exists(),str(rel)
 if f.read_bytes()==g.read_bytes():same+=1
 else:
  changes.append(str(rel));diffs.extend(difflib.unified_diff(f.read_text().splitlines(True),g.read_text().splitlines(True),fromfile='source/'+str(rel),tofile='runtime/'+str(rel)))
for mode in ['day','night']:
 f=adopt/('VanillaPaper'+mode.title()+'.tid');g=W/'tiddlers'/('fieldnotes-paper-'+mode+'.tid')
 diffs.extend(difflib.unified_diff(f.read_text().splitlines(True),g.read_text().splitlines(True),fromfile='source/'+f.name,tofile='shadow/'+g.name))
(E/'source-adaptation.diff').write_text(''.join(diffs))
notes=[];titles={};drafts=[]
for f in (W/'tiddlers').glob('*.tid'):
 s=f.read_text();head,_,body=s.partition('\n\n');title=next((l[7:] for l in head.splitlines() if l.startswith('title: ')),None)
 if title:titles.setdefault(title,[]).append(str(f.relative_to(P)))
 if 'draft.of:' in head:drafts.append(title)
for f in (E/'seed-wiki/tiddlers').glob('note-*.tid'):
 s=f.read_text();head,body=s.split('\n\n',1);title=next(l[7:] for l in head.splitlines() if l.startswith('title: '));paths=titles[title];assert len(paths)==1
 actual=(P/paths[0]).read_text().split('\n\n',1)[1];raw_equal=actual==body
 normalized=actual
 if title in ['Evidence ledger','Prototype comparison — signs and landmarks']:
  label='Evidence ledger table' if title=='Evidence ledger' else 'Prototype comparison table'
  normalized=actual.replace(f'<div class="tc-table-wrapper" tabindex="0" role="region" aria-label="{label}">\n\n','',1).replace('\n</div>\n','',1)
 assert normalized==body
 notes.append({'title':title,'path':paths[0],'raw_body_matches_seed':raw_equal,'content_after_removing_recorded_wrapper_matches_seed':True,'body_sha256':hashlib.sha256(body.encode()).hexdigest()})
dupes={k:v for k,v in titles.items() if len(v)>1};assert not dupes and not drafts
repos={n:subprocess.check_output(['git','rev-parse','HEAD'],cwd=E/'sources'/n,text=True).strip() for n in ['vanilla-paper','notebook','tufte-css']}
result={'vendor_files_verified':len(manifest),'vendor_mismatches':bad,'paper_unchanged_source_files':same,'paper_changed_source_files':changes,'paper_added_notice':'LICENSE','palette_shadow_overrides':2,'notes':notes,'duplicate_titles':dupes,'native_drafts_remaining':drafts,'removed_challenger_paths':['themes/notebook','plugins/notebook-mobile'],'sources':repos,'tiddlywiki_revision':provenance['revision']}
(E/'package-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
