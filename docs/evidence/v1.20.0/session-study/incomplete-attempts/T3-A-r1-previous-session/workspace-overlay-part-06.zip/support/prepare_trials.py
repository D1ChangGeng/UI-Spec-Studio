from pathlib import Path
import shutil,json,subprocess,hashlib
p=Path(__file__).resolve().parents[1]
shutil.copytree(p/'app/wiki',p/'evidence/seed-wiki')
for src,dst in [('vanilla-paper/themes/BurningTreeC/vanilla-paper','themes/paper'),('notebook/themes/notebook','themes/notebook'),('notebook/plugins/notebook-mobile','plugins/notebook-mobile')]:
    shutil.copytree(p/'evidence/sources'/src,p/'app/wiki'/dst)
(p/'app/wiki/tiddlers/selected-theme.tid').write_text('title: $:/theme\n\n$:/themes/tiddlywiki/snowwhite\n')
record={}
for repo in ['vanilla-paper','notebook']:
    root=p/'evidence/sources'/repo
    record[repo]={'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'license':(root/'LICENSE').read_text(),'files':{str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in root.rglob('*') if f.is_file() and '.git' not in f.parts}}
(p/'evidence/sources/identities.json').write_text(json.dumps(record,indent=2))
print(json.dumps({k:v['commit'] for k,v in record.items()}))
