from pathlib import Path
import shutil,json,re,hashlib
P=Path(__file__).resolve().parents[1];W=P/'app/wiki'
shutil.copytree(W/'tiddlers',P/'evidence/pre-refinement-tiddlers')
for n in ['Day','Night']:
 original=(W/f'themes/paper/VanillaPaper{n}.tid').read_text()
 adapted=original
 for key in ['tiddler-controls-foreground','sidebar-controls-foreground','tiddler-subtitle-foreground']:
  adapted=re.sub(r'^'+key+r':.*$',key+': <<colour sidebar-foreground>>',adapted,flags=re.M)
 (W/f'tiddlers/fieldnotes-paper-{n.lower()}.tid').write_text(adapted)
surface=W/'themes/paper/3-surface.tid';s=surface.read_text();assert s.count('transition-duration: 150ms !important;')==1;surface.write_text(s.replace('transition-duration: 150ms !important;','transition-duration: 1ms !important;'))
# The exploratory sticky state is deliberately returned to the source default.
for f in (W/'tiddlers').glob('*.tid'):
 s=f.read_text()
 if 'title: $:/themes/BurningTreeC/vanilla-paper/options/stickytitles\n' in s:
  f.write_text('title: $:/themes/BurningTreeC/vanilla-paper/options/stickytitles\n\nno\n')
shutil.rmtree(W/'themes/notebook');shutil.rmtree(W/'plugins/notebook-mobile')
# Clear runtime story history and unused trial configuration, retaining real content and native configuration.
for f in (W/'tiddlers').glob('*.tid'):
 s=f.read_text();title=next((l[7:] for l in s.split('\n\n',1)[0].splitlines() if l.startswith('title: ')),'')
 if title=='$:/StoryList' or title.startswith('$:/state/notebook') or title.startswith("Draft of '"):f.unlink()
print(json.dumps({'runtime_theme':'Paper only','palette_roles_reused':['tiddler-controls-foreground','sidebar-controls-foreground','tiddler-subtitle-foreground'],'motion_patch':'150ms → 1ms in source reduced-motion rule','sticky_titles':'source default no'}))
