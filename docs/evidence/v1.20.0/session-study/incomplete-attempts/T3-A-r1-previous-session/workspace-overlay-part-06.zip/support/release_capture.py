from pathlib import Path
from playwright.sync_api import sync_playwright
import json,time,re,hashlib,traceback
P=Path(__file__).resolve().parents[1];O=P/'evidence/release';O.mkdir(exist_ok=True)
CH='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
NOTE='访谈笔记 — 傍晚通勤';INDEX='Fieldnotes — project index';records=[];network=[];errors=[]
def record(**r):
 r['at']=time.time();records.append(r);(O/'checks.json').write_text(json.dumps(records,ensure_ascii=False,indent=2));print(json.dumps(r,ensure_ascii=False),flush=True)
def ratio(rgb1,rgb2):
 def lum(c):
  v=[float(x)/255 for x in re.findall(r'[\d.]+',c)[:3]]
  v=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in v]
  return sum(a*b for a,b in zip(v,[.2126,.7152,.0722]))
 a,b=sorted([lum(rgb1),lum(rgb2)]);return round((b+.05)/(a+.05),3)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=CH,args=['--no-sandbox']);c=b.new_context(viewport={'width':1440,'height':900},device_scale_factor=1,locale='en-GB');c.tracing.start(screenshots=True,snapshots=True,sources=True)
 page=c.new_page();page.on('dialog',lambda d:d.accept());page.on('pageerror',lambda e:errors.append(str(e)));page.on('response',lambda r:network.append({'url':r.url,'status':r.status,'method':r.request.method}))
 def settext(t,v,field='text'):page.evaluate('([t,v,f])=>$tw.wiki.setText(t,f,null,v)',[t,v,field])
 def settle():page.wait_for_timeout(450)
 def note(title):return page.locator('[data-tiddler-title]').filter(has=page.locator('.tc-title',has_text=title)).first
 def snap(name):
  page.screenshot(path=str(O/(name+'.png')));record(kind='capture',file=name+'.png',viewport=page.viewport_size,scroll=page.evaluate('scrollY'),palette=page.evaluate('$tw.wiki.getTiddlerText("$:/palette")'),language=page.locator('html').get_attribute('lang'))
 try:
  page.goto('http://127.0.0.1:4409/');page.wait_for_function('!!window.$tw && !!$tw.wiki');settle()
  seeds=[]
  for f in (P/'evidence/seed-wiki/tiddlers').glob('note-*.tid'):
   s=f.read_text();header,body=s.split('\n\n',1);title=next(l[7:] for l in header.splitlines() if l.startswith('title: '));assert page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',title)==body;seeds.append(title)
  titles={}
  for f in (P/'app/wiki/tiddlers').glob('*.tid'):
   title=next((l[7:] for l in f.read_text().split('\n\n',1)[0].splitlines() if l.startswith('title: ')),None)
   if title:titles.setdefault(title,[]).append(str(f.relative_to(P)))
  duplicates={k:v for k,v in titles.items() if len(v)>1};assert not duplicates
  assert '$:/themes/nico/notebook' not in page.evaluate('$tw.wiki.filterTiddlers("[plugin-type[theme]]")')
  assert page.evaluate('$tw.wiki.getTiddlerText("$:/theme")').strip()=='$:/themes/BurningTreeC/vanilla-paper'
  record(kind='post-restart integrity',passed=True,notes_matching_seed=seeds,duplicate_titles=duplicates,retained_themes=page.evaluate('$tw.wiki.filterTiddlers("[plugin-type[theme]]")'))
  # Native palette chooser is the actual user path for switching day/night.
  page.get_by_role('button',name='palette',exact=True).click();settle();snap('palette-chooser')
  page.locator('.tc-chooser-item a').filter(has_text='Vanilla Paper Night').first.click();settle();assert page.evaluate('$tw.wiki.getTiddlerText("$:/palette")')=='$:/palettes/VanillaPaperNight'
  record(kind='native palette switching',passed=True)
  for language in ['en-GB','zh-Hans']:
   settext('$:/language','$:/languages/'+language);settle()
   for mode,palette in [('light','$:/palettes/VanillaPaperDay'),('dark','$:/palettes/VanillaPaperNight')]:
    settext('$:/palette',palette)
    for w,h in [(1440,900),(1280,640),(390,844)]:
     page.set_viewport_size({'width':w,'height':h});settext('$:/StoryList',[NOTE],'list');settext('$:/temp/search','');settext('$:/state/sidebar','yes');settle()
     # At narrow width the source's own collapse control creates its reading condition.
     if w==390:page.locator('.tc-hide-sidebar-btn').click();settle()
     page.keyboard.press('Escape');page.mouse.move(5,h-5);page.evaluate('document.activeElement.blur()');page.evaluate('scrollTo(0,0)');settle()
     prefix=f'{language}-{mode}-{w}'
     snap(prefix+'-read')
     geom=page.evaluate('()=>({viewport:innerWidth,document:document.documentElement.scrollWidth})');assert geom['document']<=geom['viewport']
     colors=note(NOTE).evaluate('(e)=>({background:getComputedStyle(e).backgroundColor,body:getComputedStyle(e.querySelector(".tc-tiddler-body")).color,control:getComputedStyle(e.querySelector(".tc-tiddler-controls svg")).fill,subtitle:getComputedStyle(e.querySelector(".tc-subtitle")).color})')
     contrast={k:ratio(colors[k],colors['background']) for k in ['body','control','subtitle']}
     record(kind='rendered contrast and reflow',condition=prefix,geometry=geom,colors=colors,contrast=contrast)
     # Enter using the inherited native pencil. Matching by class survives localization.
     note(NOTE).locator('button[class*="Buttons%2Fedit"]').click();page.frame_locator('iframe.tc-edit-texteditor').locator('textarea').wait_for();settle();page.evaluate('scrollTo(0,0)');snap(prefix+'-edit')
     text=page.frame_locator('iframe.tc-edit-texteditor').locator('textarea').input_value();assert '从描述到问题' in text and 'A final unresolved question' in text
     page.locator('button[class*="Buttons%2Fcancel"]').click();settle()
     if w==390:
      note(NOTE).get_by_text('这提示我们检查信息出现的时机。',exact=False).scroll_into_view_if_needed();page.mouse.move(5,h-5);snap(prefix+'-cjk')
  # Source control motion after the targeted reduced-motion conflict correction.
  settext('$:/language','$:/languages/en-GB');page.set_viewport_size({'width':1440,'height':900});settext('$:/palette','$:/palettes/VanillaPaperDay');settext('$:/StoryList',[NOTE],'list');settext('$:/state/sidebar','yes');settle()
  for pref in ['no-preference','reduce']:
   page.emulate_media(reduced_motion=pref);settext('$:/state/sidebar','yes');settle();page.evaluate('scrollTo(0,0)');snap('motion-'+pref+'-before')
   page.evaluate('()=>{window.__motion=[];let start=performance.now();let sample=()=>{let e=document.querySelector(".tc-page-container");window.__motion.push({ms:performance.now()-start,open:getComputedStyle(e).getPropertyValue("--btc-open"),riverX:document.querySelector(".tc-story-river").getBoundingClientRect().x});if(performance.now()-start<700)requestAnimationFrame(sample)};requestAnimationFrame(sample)}')
   page.locator('.tc-hide-sidebar-btn').click();snap('motion-'+pref+'-trigger');page.wait_for_timeout(180);snap('motion-'+pref+'-middle');page.wait_for_timeout(550);snap('motion-'+pref+'-settled')
   motion=page.evaluate('window.__motion');duration=page.locator('.tc-page-container').evaluate('(e)=>getComputedStyle(e).transitionDuration')
   record(kind='motion samples',preference=pref,transition_duration=duration,samples=motion)
   if pref=='reduce':assert duration=='0.001s'
   page.locator('.tc-show-sidebar-btn').click();settle()
  page.emulate_media(reduced_motion='no-preference')
  # Evidence table on narrow view uses native flow and retains all cells.
  settext('$:/StoryList',['Evidence ledger'],'list');page.set_viewport_size({'width':390,'height':844});settext('$:/state/sidebar','no');settle();page.evaluate('scrollTo(0,0)');snap('light-390-ledger');assert note('Evidence ledger').locator('tr').count()==5
  record(kind='narrow evidence table',rows=5,document_width=page.evaluate('document.documentElement.scrollWidth'),viewport=390)
  for w,h in [(1440,900),(1280,640),(390,844)]:
   page.set_viewport_size({'width':w,'height':h});settext('$:/StoryList',[INDEX,NOTE],'list');settext('$:/state/sidebar','yes');settext('$:/temp/search','');settle();page.evaluate('scrollTo(0,0)');snap(f'start-{w}')
  page.set_viewport_size({'width':1440,'height':900});settext('$:/state/sidebar','yes');settle()
  record(kind='runtime health',page_errors=errors,remote_requests=[r for r in network if not r['url'].startswith('http://127.0.0.1:4409')],navigation=page.evaluate('performance.getEntriesByType("navigation").map(n=>({transferSize:n.transferSize,decodedBodySize:n.decodedBodySize,domContentLoaded:n.domContentLoadedEventEnd,load:n.loadEventEnd}))'),noto_cjk_ready=page.evaluate('document.fonts.check(\'17px "Noto Sans CJK SC"\')'))
 except Exception as e:
  record(kind='FAILURE',error=repr(e),traceback=traceback.format_exc());page.screenshot(path=str(O/'failure.png'));raise
 finally:
  (O/'network.json').write_text(json.dumps(network,indent=2));(O/'page-errors.json').write_text(json.dumps(errors));c.tracing.stop(path=str(O/'trace.zip'));c.close();b.close()
