from pathlib import Path
from playwright.sync_api import sync_playwright
import json,time
P=Path(__file__).resolve().parents[1];O=P/'evidence/sticky-trial';O.mkdir(exist_ok=True)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900});page.on('dialog',lambda d:d.accept());page.goto('http://127.0.0.1:4409/');page.wait_for_timeout(700)
 page.evaluate('()=>{$tw.wiki.setText("$:/themes/BurningTreeC/vanilla-paper/options/stickytitles","text",null,"yes");$tw.wiki.setText("$:/StoryList","list",null,["访谈笔记 — 傍晚通勤"]);$tw.wiki.setText("$:/temp/search","text",null,"")}');page.wait_for_timeout(400)
 for width,height in [(1440,900),(390,844)]:
  page.set_viewport_size({'width':width,'height':height});page.evaluate('scrollTo(0,0)');page.wait_for_timeout(400)
  if width==390:page.locator('button[title="Hide sidebar"]').click();page.wait_for_timeout(500)
  page.mouse.wheel(0,700);page.wait_for_timeout(400);page.screenshot(path=str(O/f'{width}-read.png'))
  page.locator('button[title="Edit this tiddler"]').first.click();page.wait_for_timeout(400);page.mouse.wheel(0,650);page.wait_for_timeout(400);page.screenshot(path=str(O/f'{width}-edit.png'))
  print(json.dumps({'width':width,'save_button':page.locator('button[title="Confirm changes to this tiddler"]').bounding_box(),'title':page.locator('.tc-tiddler-title').bounding_box(),'at':time.time()}))
  page.locator('button[title="Discard changes to this tiddler"]').click();page.wait_for_timeout(300)
 b.close()
