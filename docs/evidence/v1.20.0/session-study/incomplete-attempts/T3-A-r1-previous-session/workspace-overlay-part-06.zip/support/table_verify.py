from pathlib import Path
from playwright.sync_api import sync_playwright
import json,time
P=Path(__file__).resolve().parents[1];O=P/'evidence/table-final';O.mkdir(exist_ok=True);rows=[]
CH='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path=CH,args=['--no-sandbox']);c=b.new_context(viewport={'width':390,'height':844},device_scale_factor=1);c.tracing.start(screenshots=True,snapshots=True,sources=True);p=c.new_page();errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
 p.goto('http://127.0.0.1:4409');p.wait_for_function('!!window.$tw&&!!$tw.wiki')
 for mode in ['Day','Night']:
  p.evaluate('(v)=>$tw.wiki.setText("$:/palette","text",null,v)','$:/palettes/VanillaPaper'+mode)
  for title,slug in [('Evidence ledger','ledger'),('Prototype comparison — signs and landmarks','comparison')]:
   p.evaluate('(v)=>{$tw.wiki.setText("$:/StoryList","list",null,[v]);$tw.wiki.setText("$:/state/sidebar","text",null,"no")} ',title);p.wait_for_timeout(500);p.evaluate('scrollTo(0,0)')
   w=p.locator('.tc-tiddler-body .tc-table-wrapper');assert w.count()==1
   assert w.locator('tr').count()==(5 if slug=='ledger' else 4)
   # Reach the explicitly focusable source wrapper using real sequential keyboard navigation.
   p.evaluate('document.activeElement.blur()');found=False
   for step in range(80):
    p.keyboard.press('Tab')
    if w.evaluate('(e)=>document.activeElement===e'):found=True;break
   assert found
   p.screenshot(path=str(O/f'{mode}-{slug}-before.png'))
   before=w.evaluate('(e)=>({left:e.scrollLeft,client:e.clientWidth,scroll:e.scrollWidth})')
   for i in range(24):p.keyboard.press('ArrowRight');p.wait_for_timeout(20)
   p.wait_for_timeout(250)
   after=w.evaluate('(e)=>({left:e.scrollLeft,client:e.clientWidth,scroll:e.scrollWidth,lastRight:e.querySelector("tr:last-child td:last-child").getBoundingClientRect().right,regionRight:e.getBoundingClientRect().right})')
   assert after['left']>before['left'];assert after['lastRight']<=after['regionRight']+1
   p.screenshot(path=str(O/f'{mode}-{slug}-last-column.png'))
   rows.append({'mode':mode,'title':title,'keyboard_tab_steps':step+1,'before':before,'after':after,'document_width':p.evaluate('document.documentElement.scrollWidth')})
 p.set_viewport_size({'width':1440,'height':900});p.evaluate('$tw.wiki.setText("$:/palette","text",null,"$:/palettes/VanillaPaperDay")');p.evaluate('$tw.wiki.setText("$:/StoryList","list",null,["Evidence ledger"])');p.wait_for_timeout(450);p.evaluate('scrollTo(0,0)');p.screenshot(path=str(O/'desktop-ledger.png'))
 # Leave the supplied initial story and language ready for the next launch.
 p.evaluate('$tw.wiki.setText("$:/StoryList","list",null,["Fieldnotes — project index","访谈笔记 — 傍晚通勤"]);$tw.wiki.setText("$:/state/sidebar","text",null,"yes");$tw.wiki.setText("$:/language","text",null,"$:/languages/en-GB")');p.wait_for_timeout(600)
 result={'passed':True,'conditions':rows,'page_errors':errors};(O/'checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2));c.tracing.stop(path=str(O/'trace.zip'));b.close()
