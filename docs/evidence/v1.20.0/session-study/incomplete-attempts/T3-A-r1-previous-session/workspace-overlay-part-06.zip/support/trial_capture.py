from pathlib import Path
import json,time,urllib.request,os
from playwright.sync_api import sync_playwright
P=Path(__file__).resolve().parents[1]
O=P/'evidence/trials';O.mkdir(parents=True,exist_ok=True)
CH='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path=CH,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
 page.goto('http://127.0.0.1:4409/');page.wait_for_function('!!window.$tw && !!$tw.wiki');page.wait_for_timeout(800)
 records=[]
 for label,theme,palette in [('baseline','$:/themes/tiddlywiki/snowwhite','$:/palettes/Vanilla'),('paper','$:/themes/BurningTreeC/vanilla-paper','$:/palettes/VanillaPaperDay'),('notebook','$:/themes/nico/notebook','$:/themes/nico/notebook/palettes/palette-beige')]:
  page.evaluate('([theme,palette])=>{$tw.wiki.setText("$:/theme","text",null,theme);$tw.wiki.setText("$:/palette","text",null,palette);$tw.wiki.setText("$:/StoryList","list",null,["Fieldnotes — project index","访谈笔记 — 傍晚通勤"]);$tw.wiki.setText("$:/state/sidebar","text",null,"yes")}',[theme,palette])
  page.wait_for_timeout(900);page.evaluate('scrollTo(0,0)');page.screenshot(path=str(O/f'{label}-start.png'))
  card=page.locator('.tc-tiddler-frame').filter(has=page.locator('.tc-title',has_text='访谈笔记 — 傍晚通勤')).first
  if not card.count():card=page.locator('[data-tiddler-title="访谈笔记 — 傍晚通勤"]')
  card.scroll_into_view_if_needed();page.wait_for_timeout(400);page.screenshot(path=str(O/f'{label}-interview.png'))
  records.append({'candidate':label,'theme':theme,'palette':palette,'timestamp':time.time(),'title':page.title(),'bodyFont':page.locator('.tc-tiddler-body').last.evaluate('(e)=>getComputedStyle(e).fontFamily'),'viewport':page.viewport_size})
 (O/'conditions.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
 for label,url in [('paper','https://burningtreec.github.io/vanilla-paper/'),('notebook','https://saqimtiaz.github.io/sq-tw/notebook.html')]:
  try:
   with urllib.request.urlopen(url,timeout=20) as r:
    data=r.read();(O/f'{label}-demo.html').write_bytes(data);(O/f'{label}-fetch.json').write_text(json.dumps({'url':url,'status':r.status,'headers':dict(r.headers),'bytes':len(data)},indent=2))
   page.goto((O/f'{label}-demo.html').as_uri());page.wait_for_timeout(1000);page.screenshot(path=str(O/f'{label}-source-demo.png'))
  except Exception as e:(O/f'{label}-demo-error.txt').write_text(repr(e))
 b.close()
print(json.dumps(records,ensure_ascii=False))
