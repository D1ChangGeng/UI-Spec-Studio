from pathlib import Path
from playwright.sync_api import sync_playwright
import json,time,hashlib,traceback
P=Path(__file__).resolve().parents[1]
O=P/'evidence/product';O.mkdir(parents=True,exist_ok=True)
CH='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
NOTE='访谈笔记 — 傍晚通勤';INDEX='Fieldnotes — project index'
results=[];errors=[];requests=[];episode=[]
def log(name,**facts):
 r={'check':name,'at':time.time(),**facts};results.append(r);(O/'checks.json').write_text(json.dumps(results,ensure_ascii=False,indent=2,default=str));print(json.dumps(r,ensure_ascii=False,default=str),flush=True)
def disk_note(title):
 for f in (P/'app/wiki/tiddlers').rglob('*.tid'):
  s=f.read_text()
  if f'title: {title}\n' in s.split('\n\n',1)[0]+'\n':return f,s.split('\n\n',1)[1]
 raise AssertionError('Note missing on disk: '+title)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=CH,args=['--no-sandbox'])
 c=b.new_context(viewport={'width':1440,'height':900},device_scale_factor=1,locale='en-GB')
 c.tracing.start(screenshots=True,snapshots=True,sources=True)
 page=c.new_page();page.on('dialog',lambda d:d.accept());page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('response',lambda r:requests.append({'url':r.url,'status':r.status,'method':r.request.method}))
 def settext(title,value,field='text'):
  page.evaluate('([t,v,f])=>$tw.wiki.setText(t,f,null,v)',[title,value,field])
 def ready():page.wait_for_timeout(350)
 def card(title):return page.locator('[data-tiddler-title]').filter(has=page.locator('.tc-title',has_text=title)).first
 def top(title):
  page.locator('[data-tiddler-title]').filter(has=page.locator('.tc-title',has_text=title)).first.locator('.tc-title').scroll_into_view_if_needed();ready()
 def snap(name):
  page.screenshot(path=str(O/(name+'.png')));episode.append({'image':name+'.png','at':time.time(),'scroll':page.evaluate('scrollY'),'viewport':page.viewport_size})
 def editor():return page.frame_locator('iframe.tc-edit-texteditor').locator('textarea')
 def cancel():
  page.locator('button[title="Discard changes to this tiddler"]').first.click();ready()
 def edit(title):
  top(title);card(title).locator('button[title="Edit this tiddler"]').click();editor().wait_for();ready()
 def save():
  page.locator('button[title="Confirm changes to this tiddler"]').first.click();ready()
 def wait_disk(title,text):
  for i in range(60):
   f,value=disk_note(title)
   if value==text:return {'file':str(f.relative_to(P)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'text_sha256':hashlib.sha256(value.encode()).hexdigest(),'bytes':f.stat().st_size}
   page.wait_for_timeout(150)
  raise AssertionError('Filesystem text did not match saved content')
 try:
  page.goto('http://127.0.0.1:4409/');page.wait_for_function('!!window.$tw && !!$tw.wiki');page.wait_for_timeout(700)
  settext('$:/theme','$:/themes/BurningTreeC/vanilla-paper');settext('$:/palette','$:/palettes/VanillaPaperDay')
  for name,value in [('toolbaralways','yes'),('toolbarhover','yes'),('pressanimation','no')]:settext('$:/themes/BurningTreeC/vanilla-paper/options/'+name,value)
  for button in ['home','palette']:settext('$:/config/PageControlButtons/Visibility/$:/core/ui/Buttons/'+button,'show')
  settext('$:/StoryList',[INDEX,NOTE],'list');ready()
  # Existing native draft from the earlier probe is resumed and discarded through its controls.
  edit(NOTE);assert 'small anchors' in editor().input_value();cancel()
  original=page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',NOTE)
  log('native framed editor',passed=True,characters=len(original))
  # Full interview scroll episode, followed by linked evidence and native-sidebar return.
  top(NOTE);snap('reading-start')
  for i in range(5):
   page.mouse.wheel(0,620);page.wait_for_timeout(180);episode.append({'action':'wheel','deltaY':620,'at':time.time(),'scroll':page.evaluate('scrollY')})
   if i==1:snap('reading-middle')
  card(NOTE).get_by_text('如果标志必须很少',exact=False).scroll_into_view_if_needed();snap('reading-end')
  card(NOTE).get_by_role('link',name='Evidence ledger',exact=True).click();ready();top('Evidence ledger');snap('evidence-ledger')
  assert card('Evidence ledger').locator('table').count()>0
  page.locator('.tc-sidebar-lists').get_by_role('link',name=NOTE,exact=True).click();ready()
  assert page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',NOTE)==original
  log('read interview → evidence ledger → return',passed=True,table_rows=card('Evidence ledger').locator('tr').count(),interview_retained=True)
  # Actual English and Chinese text changes, native save, filesystem observation, then reload.
  edit(NOTE)
  edited=original.replace('The bakery window mattered because','The bakery window was important because').replace('我们需要保留这种条件差异。','我们需要保留这些条件差异。')
  assert edited!=original and 'was important' in edited and '这些条件差异' in edited
  editor().fill(edited);snap('edit-bilingual-before-save');save()
  write=wait_disk(NOTE,edited);page.reload();page.wait_for_timeout(900)
  assert page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',NOTE)==edited
  log('English and Chinese edits persist after native save and reload',passed=True,**write)
  # A changed draft is cancelled; stored note must keep the last saved text.
  edit(NOTE);editor().fill(edited+'\n\nUNSAVED CANCELLATION PROBE');cancel()
  assert page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',NOTE)==edited
  assert disk_note(NOTE)[1]==edited
  log('cancel changed draft preserves saved note',passed=True)
  # Restore authored content through the same native editor/save path.
  edit(NOTE);editor().fill(original);save();restored=wait_disk(NOTE,original)
  log('supplied interview restored through native save',passed=True,**restored)
  # Search entirely with keyboard, then tab to the chosen note's edit action.
  page.keyboard.press('Control+f');ready()
  log('search shortcut focus',active=page.evaluate('()=>({tag:document.activeElement.tagName,cls:document.activeElement.className})'))
  if page.evaluate('document.activeElement.tagName')!='INPUT':
   for i in range(90):
    page.keyboard.press('Tab')
    if page.evaluate('document.activeElement.tagName==="INPUT" && !!document.activeElement.closest(".tc-search")'):break
  page.keyboard.type('Quiet route');page.wait_for_timeout(600)
  found=False;focus_path=[]
  for i in range(90):
   page.keyboard.press('Tab');a=page.evaluate('()=>({tag:document.activeElement.tagName,text:document.activeElement.textContent.trim(),title:document.activeElement.title})');focus_path.append(a)
   if a['tag']=='A' and a['text']=='Quiet route — working draft':found=True;break
  assert found,'Keyboard did not find search result'
  page.keyboard.press('Enter');ready();snap('keyboard-search-result')
  reached=False
  for i in range(100):
   page.keyboard.press('Tab')
   reached=page.evaluate('()=>document.activeElement.title==="Edit this tiddler" && document.activeElement.closest("[data-tiddler-title]")?.getAttribute("data-tiddler-title")==="Quiet route — working draft"')
   if reached:break
  assert reached,'Keyboard did not reach note edit action'
  snap('keyboard-edit-focus');page.keyboard.press('Enter');editor().wait_for();assert 'unfinished' in editor().input_value().lower();cancel()
  log('keyboard search → open → editor → cancel',passed=True,focus_path=focus_path,edit_tabs=i+1)
  # Fairer challenger: its actual menu-open state, compact dark reading, and editing.
  settext('$:/theme','$:/themes/nico/notebook');settext('$:/palette','$:/themes/nico/notebook/palettes/palette-beige');settext('$:/state/notebook-sidebar','yes');settext('$:/StoryList',[NOTE],'list');ready();top(NOTE);snap('challenger-notebook-menu-open')
  edit(NOTE);snap('challenger-notebook-editor');cancel()
  settext('$:/palette','$:/themes/nico/notebook/palettes/palette-dark');page.set_viewport_size({'width':390,'height':844});ready();settext('$:/state/notebook-sidebar','no');top(NOTE);snap('challenger-notebook-dark-narrow')
  # Restore selected complete source; sample all required size × palette states.
  settext('$:/theme','$:/themes/BurningTreeC/vanilla-paper')
  for mode,palette in [('light','$:/palettes/VanillaPaperDay'),('dark','$:/palettes/VanillaPaperNight')]:
   for width,height in [(1440,900),(1280,640),(390,844)]:
    page.set_viewport_size({'width':width,'height':height});settext('$:/palette',palette);settext('$:/StoryList',[NOTE],'list');settext('$:/state/sidebar','yes');ready();top(NOTE)
    snap(f'{mode}-{width}-read')
    geometry=page.evaluate('()=>({document:document.documentElement.scrollWidth,viewport:innerWidth,body:document.body.scrollWidth})')
    edit(NOTE);snap(f'{mode}-{width}-edit');edit_geometry=editor().evaluate('(e)=>({width:e.clientWidth,scrollWidth:e.scrollWidth,font:getComputedStyle(e).fontFamily,lineHeight:getComputedStyle(e).lineHeight,textLength:e.value.length})');cancel()
    log('theme/viewport reading and editing',mode=mode,viewport={'width':width,'height':height},geometry=geometry,editor=edit_geometry)
  # Simplified Chinese UI with the same long note; native language switch is persisted.
  page.set_viewport_size({'width':1440,'height':900});settext('$:/language','$:/languages/zh-Hans');ready();top(NOTE);snap('dark-zh-ui')
  log('Simplified Chinese UI',html_language=page.locator('html').get_attribute('lang'),note_title=NOTE)
  settext('$:/language','$:/languages/en-GB');settext('$:/palette','$:/palettes/VanillaPaperDay');ready()
  # Normal and reduced-motion sidebar episodes: actual controls and timed frame records.
  for reduced in ['no-preference','reduce']:
   page.emulate_media(reduced_motion=reduced);settext('$:/state/sidebar','yes');ready();snap('sidebar-'+reduced+'-before')
   page.locator('button[title="Hide sidebar"]').click();snap('sidebar-'+reduced+'-trigger');page.wait_for_timeout(400);snap('sidebar-'+reduced+'-settled')
   computed=page.locator('.tc-page-container').evaluate('(e)=>({transition:getComputedStyle(e).transitionDuration,open:getComputedStyle(e).getPropertyValue("--btc-open")})')
   log('sidebar motion condition',preference=reduced,computed=computed)
   page.locator('button[title="Show sidebar"]').click();ready()
  page.emulate_media(reduced_motion='no-preference');settext('$:/StoryList',[INDEX,NOTE],'list');page.evaluate('scrollTo(0,0)');ready();snap('final-start')
  log('runtime health',page_errors=errors,remote_requests=[r for r in requests if not r['url'].startswith('http://127.0.0.1:4409')],navigation=page.evaluate('performance.getEntriesByType("navigation").map(n=>({transferSize:n.transferSize,decodedBodySize:n.decodedBodySize,domContentLoaded:n.domContentLoadedEventEnd,load:n.loadEventEnd}))'))
 except Exception as e:
  log('FAILURE',error=repr(e),traceback=traceback.format_exc());page.screenshot(path=str(O/'failure.png'));raise
 finally:
  (O/'episode.json').write_text(json.dumps(episode,ensure_ascii=False,indent=2));(O/'network.json').write_text(json.dumps(requests,indent=2));(O/'page-errors.json').write_text(json.dumps(errors));c.tracing.stop(path=str(O/'trace.zip'));c.close();b.close()
