# Preservation observation

This is a new preservation note, not a reconstruction or revision of any original work-package report.

The exact original directory `/workspace/scratch/708e8b7f118e/ui-study/worksets/w11` was unavailable when checked on 2026-11-01. Ordinary access at 10:49:28 UTC and elevated access at 10:50:48 UTC both returned `FileNotFoundError`, errno 2. The actual tool returns are saved beside this note.

Thirty-five original tool-response JSON exports survived in `/tmp/w11-*`. They were copied byte-for-byte into `retained-tmp-tool-exports/`. All source and destination SHA-256 hashes match. The files total 7,603,473 bytes. `retained-tmp-file-hash-manifest.json` records original paths, destinations, sizes, hashes, and copy actions; `preservation-copy-tool-result.json` is the actual copy command's returned result.

The copied original export wrappers contain 4 `web_run` returns and 31 `view_image` returns. The image returns retain their original embedded data URLs, including the final delivery image and the inspected settled light/dark, desktop/mobile matrix. These originals have not been decoded, re-rendered, or modified during preservation.

The missing application tree, original reports, independent command logs, and any evidence without a surviving export have not been reconstructed. This directory is a partial preservation of original evidence, not a recovered complete work package.

The original independent research child also retained the exact research-report string in its runtime store under `w11_final_report`. It exported that original string as 13,785 UTF-8 bytes into `child-retained-exports/w11_final_report-tool-store-original.txt`. The source and destination SHA-256 are both `ce510e6013d0dfde5c0fa128f37c8fd0fc3c43078c4c347abcdf61dedc952fd0`; primary readback independently verified the destination hash. The child's provenance record retains the correction of an initial patch export that had added a newline. This is recovered original report text; the report's references do not establish survival of its cited evidence.

There are therefore 36 preserved original artifacts totaling 7,617,258 bytes. The remainder of this directory consists of new preservation observations, manifests, and actual preservation-command results.
