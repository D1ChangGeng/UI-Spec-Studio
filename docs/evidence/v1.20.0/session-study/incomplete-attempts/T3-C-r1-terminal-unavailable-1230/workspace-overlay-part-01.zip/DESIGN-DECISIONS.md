# Fieldnotes — current design model

## SPEC F1: editorial research workspace

Status: implemented and inspected; direction selected by the primary designer under the task's existing authority. No owner acceptance is asserted. The complete native TiddlyWiki 5.4.1 application remains the product; the single increment owns its sidebar, reading sheet, note controls and editor relationship. No W1/W2/W3 exception or replacement shell was used.

Goal: a recognisable editorial studio for a bilingual team reading short observations, a long interview, tables and unfinished arguments, while preserving read → follow evidence → edit → save → reload → return. Identity should survive ordinary populated work. Authoritative content remains the native wiki store, tiddlyweb adaptor and filesystem plugin.

## Direction and source comparison

The primary designer inspected original demonstrations and locally populated trials. The independent child researched sources and rights only. Its recommendation was an input, not delegated design authority.

| Direction | Actual scope and observed relationship | Judgment and consequence |
|---|---|---|
| Native Vanilla/Snow White baseline | Broad reading card; narrow right utility column; clear bilingual text but weak distinction between the long reading surface and utilities | Usable baseline, insufficient editorial identity for the explicit goal |
| Native Starlight trial | Arvo headings and a photographic/texture background layer, inherited Snow White structure | Light material has character, but its fixed bright background remains in dark mode and competes with utility text. Rejected as the defining foundation; source itself describes a placeholder refinement |
| Notebook 1.4.1 | Complete theme plus mobile plugin; centered sheet, compact persistent top controls, collapsible left navigation, sans type | Material challenger to the first Paper preference. Efficient working composition, but comparatively little distinction between reading type and utilities. Not selected for this editorial brief |
| Vanilla Paper 0.10.0 | Complete sheet/sidebar/editor system; bounded reading measure, serif reading with sans utilities, warm day/night materials, red sheet margin and ruled native editor | Selected. Its paper-writing metaphor provides a coherent cross-domain composition and material language. Identity is carried by type, measure, rule and surface, with no new imagery or ambient motion needed |

Original demos contain different content: they establish source character, not a fair product winner. Populated trials use the supplied long interview. Source Paper demo ran 5.5.0-prerelease; product compatibility was established locally on 5.4.1. Notebook's longer history and Paper's shorter testing history remain relevant maintenance tradeoffs.

## Source-to-product responsibility

The complete 55-file Paper theme is retained under app/wiki/themes/vanilla-paper with original $:/themes/BurningTreeC/vanilla-paper identity. Its default widths, breakpoint, typography, margins, surfaces, editor ruling and structural rules remain the design owner. App changes select the source and its supported options; no replacement layout or visual assets were drawn.

1. Always-visible native note controls address the source's resting hover-only actions. Sticky titles are enabled to preserve action access on long material. Press animation is disabled.
2. Day/night palette overrides keep their original titles and map four faint support/control tokens to the source's existing sidebar foreground token. This improves observed hierarchy without inventing a new palette. Exact diff: evidence/source-adaptation.diff.
3. The native animation duration is zero. A narrow copied-source repair changes the surface reduced-motion transition from 150ms to 1ms, matching the source's quiet strategy and avoiding reintroducing visible motion under reduced preference. No smoothness claim is based on screenshots.
4. Three supplied tables use the documented native tc-table-wrapper and actual header cells. The wrapper is a labelled keyboard-focusable region. Paper already supplies its overflow rule. Table cell text remains intact. The final narrow ledger reaches its last column at scrollLeft 165; the prototype reaches 136; the observation table fits at 318px.
5. Supported retain-original-tiddler-path configuration prevents duplicate title-derived files when saving the starter's numbered files. This was added only after an actual cancel/reload inconsistency, not hypothesized. The upstream runtime remains unchanged.
6. Two small bilingual interview copy corrections were made through the actual editor and saved. The rest of the interview remains complete. The three table notes changed only markup; four other notes remain untouched. The unfinished note retains its status and content.

## Evidence and revisions

The initial hypothesis preferred a cohesive complete source to a collection of palette/assets. Starlight's actual dark result narrowed that route; Notebook challenged Paper through a different navigation composition. Paper was chosen after original-demo and populated comparisons. Observed hidden actions, low-contrast support text and clipped narrow tables resulted in supported configuration and narrow integration repairs.

Failed selection serialization first fell back to the baseline theme; removing trailing newlines from scalar configuration values corrected it. Native title-path migration then caused duplicate files; canonical files were restored while the server was stopped, and native path retention resolved the repeated save/cancel journey. All failed attempts remain in evidence/attempt1, evidence/attempt2 and command exports. Table capture attempts 025/026 failed on the new evidence directory's permissions; 027 uses the existing writable browser-capture area and completed.

Verification: 36/36 core journey and appearance checks in evidence/verification/checks.json, followed by 13/13 fresh-server/table checks in evidence/final/table-repair/checks.json. All 8,823 supplied vendor file hashes match. Native offline build completed. Detailed visual observations are in VISUAL-REVIEW.md, provenance in SOURCE-PROVENANCE.md, and runnable entry/limits in FINAL.md.

## Current limits and authority

Inspected in sandboxed headless Chromium 143 at DPR1 with supplied Noto CJK host fixture. English UI covers both themes and all three target sizes. Chinese UI is sampled in light at 1440×900; reduced preference in dark at 390×844. This is not every locale/theme/viewport permutation. No screen-reader, physical-touch, other-engine, multi-user or natural-speed motion acceptance is claimed. The child report and exact spawn request/result are retained; a separate byte-exact export of its final host notification was not available at finalization. No source lifecycle stability or user preference was inferred from static captures.
