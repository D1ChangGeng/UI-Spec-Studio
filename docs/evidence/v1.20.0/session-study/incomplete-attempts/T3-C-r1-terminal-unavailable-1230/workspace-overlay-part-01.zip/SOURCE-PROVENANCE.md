# Adopted resources and provenance

## Product foundation

TiddlyWiki 5.4.1, commit d391595836e2aead565480763f9bf9eb52e29e75, from https://github.com/TiddlyWiki/TiddlyWiki5 . The original npm distribution, BSD notices and frozen PROVENANCE.json remain present. Final verification compared every one of 8,823 upstream files with its supplied SHA-256 and found zero mismatches (evidence/vendor-integrity.json).

Native tiddlyweb/filesystem/highlight plugins remain. No new service or external runtime request was introduced. No dependency install was required. All implementation changes live in app/wiki. The authoritative mode is the native local server; app/wiki/output/index.html is the upstream offline export.

## Adopted complete visual foundation

Vanilla Paper 0.10.0 by Simon Huber / BurningTreeC. Repository: https://github.com/BurningTreeC/vanilla-paper . Exact revision: 031a78d4d4187128c632f8a647fa05408eddc700. Public demonstration: https://burningtreec.github.io/vanilla-paper/ . MIT copyright Simon Huber 2026. Complete original notice retained at app/wiki/THIRD-PARTY/Vanilla-Paper-LICENSE.txt and in evidence/research/paper-LICENSE.

Source archive, HTTP/hash records, API metadata and extracted source remain under evidence/research. The 55 source files were copied as a complete theme with original tiddler identities. Only 3-surface.tid differs inside that copy, by one reduced-motion transition duration. Two full palette copies override four source tokens each while preserving palette identity. Exact differences: evidence/source-adaptation.diff; copy audit: evidence/final-source-audit.json. Source-supported options are named in DESIGN-DECISIONS.md.

The source uses system font stacks. No image or font asset was added to the product. Noto CJK is the supplied host observation fixture, not a product font distribution. Native table composition is documented in app/vendor/tiddlywiki/editions/tw5.com/tiddlers/wikitext/Utility Classes.tid and styled by the adopted Paper 2-structure.tid.

## Trialled but not shipped

Notebook 1.4.1, https://github.com/NicolasPetton/Notebook , commit 465c832c885894ee3c97be76449cc524e1252eb0. MIT Nicolas Petton 2020; license and pinned theme/mobile-plugin source remain in evidence/research. Demo linked by the official community catalogue: https://saqimtiaz.github.io/sq-tw/notebook.html . Notebook theme and its plugin were removed from the product after comparison.

Native Starlight was trialled from the unchanged supplied distribution. Its Arvo type and image were not adopted into the active design. Vanilla and Snow White remain available native fallback dependencies; Centralised being present during a trial does not establish that it was visually active.

## Evidence boundary

Original public HTML demonstrations were downloaded through normal proxy/TLS policy and rendered unmodified locally. Public web-tool repository opens failed; those failures and successful direct HTTP retrievals are retained. Original demonstrations, local populated candidates and integrated final views have separate evidence directories. The primary designer personally opened the decisive images; full image-tool return objects are retained as evidence/view-*.json.
