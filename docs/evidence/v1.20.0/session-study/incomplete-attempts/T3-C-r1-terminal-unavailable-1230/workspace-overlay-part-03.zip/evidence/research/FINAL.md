# Fieldnotes source research handover

## Outcome and boundary

Two complete, licensed TiddlyWiki theme implementations are available for populated comparison. **Vanilla Paper** supplies the clearest observed editorial language; **Notebook** is a materially different challenger with a compact persistent toolbar and collapsible left navigation. This is a research recommendation for trials, not a final theme choice or product acceptance.

I changed no product files. The parent owns installation, populated comparisons, compatibility repairs, final selection and verification. Research closed at the parent's request once both pinned sources and original-demo observations were available.

## Decision-useful comparison

### Vanilla Paper — editorial sheets and differentiated type roles

- **Source:** [BurningTreeC/vanilla-paper](https://github.com/BurningTreeC/vanilla-paper), commit `031a78d4d4187128c632f8a647fa05408eddc700`, dated 2026-08-28. Source plugin version **0.10.0**, declared core requirement **>=5.3.0**. MIT, copyright Simon Huber, 2026.
- **Original demonstration:** [Vanilla Paper demo](https://burningtreec.github.io/vanilla-paper/). The downloaded, unchanged HTML was rendered locally. Its observed runtime was **TiddlyWiki 5.5.0-prerelease**, with Vanilla Paper Day active.
- **Actually viewed:** At 1440×900, the cream reading sheet sits on a warmer grey-beige ground. A fine red vertical rule defines the inner margin; substantial serif headings and serif paragraphs contrast with the smaller sans navigation on the right. The reading sheet occupies a bounded column rather than the current app's broad text field. This relationship gives long-form material a recognizable editorial setting without requiring imagery.
- **Meaningful concern:** Per-note action icons were not visible in the resting source frame. Source options explicitly include `toolbarhover: yes` and `toolbaralways: no`; therefore an always-visible action treatment has a supported configuration route. Whether that improves repeated editing should be decided in the populated trial.
- **Actual reuse scope:** A standalone workspace theme, including layout, surfaces, editor treatment, palette variants and supported configuration. It is more than a palette or font layer.
- **Adoption route:** Use the unmodified theme directory under `themes/BurningTreeC/vanilla-paper/`, retain identity and MIT notice, select the theme through TiddlyWiki's normal theme mechanism, and configure its own settings/options. Source defaults include separate reading/UI/code font stacks, 17px/30px reading metrics, 720px tiddler width, 360px sidebar and 960px breakpoint. These are source values, not newly proposed design tokens.
- **Limits:** The creator's August 2026 introduction requested testing; its history is shorter than Notebook's. The demo's prerelease core is not the product's 5.4.1 runtime. Source documentation describes a menubar dimension-tracker dependency with zero-height fallback when absent; compatibility still needs the product trial. Day/night, ruled editing, sliding navigation, reduced motion and accessibility claims are documented/source-backed, but their actual operation was not inspected by this researcher.

Local source: `paper-source/vanilla-paper-031a78d4d4187128c632f8a647fa05408eddc700/`. Original archive: `paper-source.tar.gz`. License: `paper-LICENSE`.

### Notebook — compact navigation around a centered writing surface

- **Source:** [NicolasPetton/Notebook](https://github.com/NicolasPetton/Notebook), commit `465c832c885894ee3c97be76449cc524e1252eb0`, dated 2021-02-02. Theme **1.4.1**, declared core requirement **>=5.1.22**. MIT, copyright Nicolas Petton, 2020.
- **Original demonstration:** The [demo linked by TiddlyWiki's official community catalogue](https://saqimtiaz.github.io/sq-tw/notebook.html). The downloaded, unchanged HTML was rendered locally. Its observed runtime was **TiddlyWiki 5.3.3**, with Notebook beige active. Keep this maintained demo's runtime identity separate from the pinned repository.
- **Actually viewed:** An approximately 800px centered sheet, sans headings/body, subtle sheet shadow and light ground. Search, menu and utilities share a narrow bar above the sheet. The initial sidebar is collapsed, leaving a wide quiet margin. Note actions remain visible but pale. Compared with Paper, the composition places less emphasis on editorial type contrast and more on a compact working toolbar.
- **Actual reuse scope:** A complete theme with custom sidebar, top/bottom toolbar structure, palettes and mobile behavior. The declared dependencies are Vanilla and the Notebook mobile plugin.
- **Adoption route:** Preserve the `$:/themes/nico/notebook` identity and install the supplied theme plus `$:/plugins/nico/notebook-mobile`; retain Vanilla and the MIT notice. Use its normal palette switch and theme configuration. Grey, beige and dark palettes are supplied.
- **Limits:** The older source establishes a longer public history, not automatic current compatibility. Narrow layout, mobile behavior, keyboard continuation and the native save/cancel contract require current-product trials. The initial source screenshot does not establish how the left rail behaves while reading or editing.

Local source: `notebook-source/Notebook-465c832c885894ee3c97be76449cc524e1252eb0/`. Original archive: `notebook-source.tar.gz`. License: `notebook-LICENSE`.

## Current-app relationship and revised inquiry

I viewed the live current app at `http://127.0.0.1:4411/` without editing. The index occupies a broad reading panel, while sidebar text and note controls are comparatively pale. The source comparison therefore sharpens the question from “which palette feels editorial?” to **“which complete source preserves useful reading measure, clear note actions and navigation continuity through a long bilingual edit?”**

The live capture includes the parent's transient interview-draft indicator. It is a read-only observation of shared current state, not a frozen starter baseline.

Native Starlight was inspected in source only by this researcher. Its stylesheet calls itself a placeholder refinement of Snow White and supplies Arvo plus a background image. That establishes a narrower type/background reuse scope; it does not independently establish a complete new editorial workspace. I did not claim a visual rejection from that source read.

## Material uncertainties transferred to the parent

1. Compare both implementations with the same complete interview, evidence table and unfinished note. The original demos contain different content and therefore establish source character, not a fair product-level winner.
2. Verify Paper's serif/CJK fallback relationship and Notebook's sans/CJK rhythm in both themes. No additional font or image asset is needed by the proposed source routes.
3. Exercise actual search/tag navigation, keyboard arrival at the editor, English/Chinese editing, cancel, save and reload against the native filesystem owner.
4. Inspect 1280×640 and 390×844, especially action reachability, long titles, tables and reading/editor distinction.
5. Observe sidebar open/close, return and interruptions at natural speed and with reduced motion. This researcher inspected static initial frames only and makes no smoothness, timing, accessibility-conformance or persistence claim.

## Evidence retained

All paths below are relative to `evidence/research/`.

- **Original source retrieval:** `search-001.json`, `search-002.json`, `source-003.json`; the last preserves failed web-tool repository/demo opens. Direct HTTP then succeeded through the normal route.
- **Exact downloaded material:** `paper-demo.html`, `notebook-demo.html`, their `.fetch.json` records, repository/commit/license API responses, pinned source archives, extracted source, and archive HTTP/hash records.
- **Actual command exports:** `commands/001-fetch/`, `002-archives/`, `003-initial-captures/`, `004-guidance-search/`, `005-guidance-accessibility/`.
- **Genuinely viewed captures:** `captures/paper-initial-1440.png`, `captures/notebook-initial-1440.png`, `captures/current-initial-1440.png`. Each has the full actual image-tool return in `view-001-paper.json`, `view-002-notebook.json`, or `view-003-current.json`.
- **Viewing conditions and DOM/state observations:** the three `*-initial-inspection.json` records and `VISUAL-REVIEW.md`. Chromium 143.0.7499.4; CSS viewport 1440×900; DPR 1; English browser locale; normal motion preference; host CJK font fixture. Source demos were unmodified local renders, not live public-site interaction.

The task role, all eight common method references, evidence map/action guidance and integration reference were read. The modern-web-guidance search and accessibility retrieval are retained; its relevant implication is to inspect real focus, naming, reflow and keyboard paths rather than infer accessibility from theme claims. No new product implementation was made.

