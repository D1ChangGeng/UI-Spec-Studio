# Research visual review

## Scope

Researcher personally opened all three listed PNGs with `view_image`; the full actual returned objects are preserved beside this report. These are static viewport observations, not continuous episodes, natural-time playback, interaction tests or user acceptance.

All three: Chromium 143.0.7499.4, 1440×900 CSS viewport, device scale factor 1, English browser locale, no-preference motion, `FONTCONFIG_FILE=/tmp/ui-spec-fonts/fonts.conf`. Capture script waited for fonts and the initialized TiddlyWiki store. No source-demo stylesheet was injected or changed.

## Paper initial frame

Evidence: `captures/paper-initial-1440.png`; actual view response `view-001-paper.json`.

Observed a bounded cream sheet on warm grey-beige ground, hairline red margin rule, serif reading title/headings/body, and smaller sans navigation. The title and main reading content form the dominant mass. The note action toolbar is visually absent in this resting frame. Source options supply hover/always-visible behavior; that source explanation does not replace a keyboard/editor trial.

Interpretation: strongest observed editorial identity of the two original demos. Its long reading rhythm and note-action discoverability should be tested together in populated work. Dark, narrow, CJK, editor and motion states were not viewed here.

## Notebook initial frame

Evidence: `captures/notebook-initial-1440.png`; actual view response `view-002-notebook.json`.

Observed an approximately 800px centered white sheet on a pale ground; a compact search/menu/utility bar aligns with the sheet above it. Sans headings and body keep a more uniform type voice. Initial left navigation is collapsed. Per-note action icons appear faintly at the upper right. The second note begins below the first, preserving the familiar story-river structure.

Interpretation: a useful challenger because it changes navigation organization and content occupancy, not merely color. A populated trial must establish whether persistent utilities and collapsed navigation serve the team's return/edit task.

## Current app initial frame

Evidence: `captures/current-initial-1440.png`; actual view response `view-003-current.json`.

Observed a broad white index panel with long English lines and a Chinese final paragraph, right-side navigation, pale metadata and pale note controls. The interview draft indicator is visible at the bottom boundary. The researcher made no edits; this is a shared live-state snapshot while the parent was testing, not frozen baseline evidence.

Interpretation: useful source directions should coordinate reading measure with action visibility. This frame alone does not establish long-interview reading, editor behavior, persistence or user comprehension.

## Source-to-product limit

The source demos use different content and core versions (Notebook 5.3.3; Paper 5.5.0-prerelease). Their static views demonstrate source composition, not retained craft in the product's 5.4.1 environment. The parent explicitly owns the equal-content local trials and all final assembled-product inspection.

