#!/bin/sh
exec runuser -u oai -- env FONTCONFIG_FILE=/tmp/ui-spec-fonts/fonts.conf /tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell "$@"

