import concurrent.futures, json, urllib.request, hashlib, tarfile, base64
from pathlib import Path
ROOT=Path(__file__).parent
def one(name):
 meta=json.loads((ROOT/(name+"-repository.json")).read_text())
 commit=json.loads((ROOT/(name+"-commits.json")).read_text())[0]
 license=json.loads((ROOT/(name+"-license.json")).read_text())
 sha=commit["sha"]; repo=meta["full_name"]
 url="https://codeload.github.com/"+repo+"/tar.gz/"+sha
 with urllib.request.urlopen(url,timeout=40) as r:
  data=r.read(); response={"url":url,"status":r.status,"headers":dict(r.headers)}
 out=ROOT/(name+"-source.tar.gz");out.write_bytes(data)
 response.update(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),commit=sha)
 (ROOT/(name+"-archive-fetch.json")).write_text(json.dumps(response,indent=2))
 target=ROOT/(name+"-source");target.mkdir(exist_ok=True)
 with tarfile.open(out) as t:t.extractall(target,filter="data")
 (ROOT/(name+"-LICENSE")).write_bytes(base64.b64decode(license["content"]))
 print(json.dumps({"name":name,"repo":repo,"commit":sha,"commit_date":commit["commit"]["committer"]["date"],"license":license["license"]["spdx_id"],"archive":str(out),"extracted":str(target),"size":len(data)}),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:list(p.map(one,["notebook","paper"]))

