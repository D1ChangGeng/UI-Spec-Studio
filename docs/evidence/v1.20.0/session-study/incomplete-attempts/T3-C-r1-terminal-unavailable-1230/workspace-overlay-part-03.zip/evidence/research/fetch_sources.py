import concurrent.futures, datetime, hashlib, json, urllib.request, urllib.error
from pathlib import Path
ROOT=Path(__file__).parent
sources=[
 ("notebook-demo.html","https://saqimtiaz.github.io/sq-tw/notebook.html"),
 ("paper-demo.html","https://burningtreec.github.io/vanilla-paper/"),
 ("notebook-repository.json","https://api.github.com/repos/NicolasPetton/Notebook"),
 ("paper-repository.json","https://api.github.com/repos/BurningTreeC/vanilla-paper"),
 ("notebook-commits.json","https://api.github.com/repos/NicolasPetton/Notebook/commits?per_page=1"),
 ("paper-commits.json","https://api.github.com/repos/BurningTreeC/vanilla-paper/commits?per_page=1"),
 ("notebook-license.json","https://api.github.com/repos/NicolasPetton/Notebook/license"),
 ("paper-license.json","https://api.github.com/repos/BurningTreeC/vanilla-paper/license")
]
def one(item):
 name,url=item
 record={"url":url,"started_at":datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  req=urllib.request.Request(url,headers={"User-Agent":"Fieldnotes-source-research/1.0"})
  with urllib.request.urlopen(req,timeout=35) as response:
   data=response.read()
   record.update(status=response.status,final_url=response.url,headers=dict(response.headers),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),file=name)
   (ROOT/name).write_bytes(data)
 except Exception as exc: record.update(error=repr(exc))
 (ROOT/(name+".fetch.json")).write_text(json.dumps(record,ensure_ascii=False,indent=2))
 print(json.dumps(record,ensure_ascii=False),flush=True)
 return record
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 results=list(pool.map(one,sources))
(ROOT/"fetch-summary.json").write_text(json.dumps(results,ensure_ascii=False,indent=2))

