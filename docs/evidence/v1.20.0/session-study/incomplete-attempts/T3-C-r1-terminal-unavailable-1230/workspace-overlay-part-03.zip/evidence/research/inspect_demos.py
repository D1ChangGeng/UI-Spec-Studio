import json, time, os
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).parent
CAP=ROOT/"captures";CAP.mkdir(exist_ok=True)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=str(ROOT/"chrome-wrapper.sh"),headless=True,chromium_sandbox=True)
 context=browser.new_context(viewport={"width":1440,"height":900},device_scale_factor=1,locale="en-US")
 for name,url in [("current","http://127.0.0.1:4411/"),("notebook",(ROOT/"notebook-demo.html").as_uri()),("paper",(ROOT/"paper-demo.html").as_uri())]:
  page=context.new_page(); errors=[]
  page.on("pageerror",lambda e:errors.append(str(e)))
  page.goto(url,wait_until="domcontentloaded",timeout=30000)
  page.wait_for_function("window.$tw && $tw.wiki")
  page.evaluate("document.fonts.ready")
  page.wait_for_timeout(500)
  page.screenshot(path=str(CAP/(name+"-initial-1440.png")))
  result={"name":name,"url":url,"title":page.title(),"viewport":{"width":1440,"height":900},"browser":browser.version,"motion":"no-preference","fontconfig":os.environ.get("FONTCONFIG_FILE"),"errors":errors}
  result["ui"]=page.locator("body").inner_text()[:16000]
  result["buttons"]=page.locator("button").evaluate_all("(els)=>els.map(e=>({text:e.innerText,title:e.title,aria:e.getAttribute('aria-label'),class:e.className}))")[:100]
  result["store"]=page.evaluate("({version:$tw.version,theme:$tw.wiki.getTiddlerText('$:/theme'),palette:$tw.wiki.getTiddlerText('$:/palette'),themes:$tw.wiki.filterTiddlers('[is[plugin]plugin-type[theme]]'),palettes:$tw.wiki.filterTiddlers('[tag[$:/tags/Palette]]')})")
  (ROOT/(name+"-initial-inspection.json")).write_text(json.dumps(result,ensure_ascii=False,indent=2))
  print(json.dumps(result,ensure_ascii=False),flush=True)
  page.close()
 context.close();browser.close()

