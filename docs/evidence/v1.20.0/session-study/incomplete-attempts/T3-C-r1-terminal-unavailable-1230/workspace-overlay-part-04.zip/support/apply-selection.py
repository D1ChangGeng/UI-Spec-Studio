from pathlib import Path
import shutil,json,hashlib,difflib,re
ROOT=Path(__file__).resolve().parents[1];WIKI=ROOT/'app/wiki';TID=WIKI/'tiddlers'
backup=ROOT/'evidence/pre-final-store';shutil.copytree(TID,backup)
discarded=[]
for f in list(TID.glob('*.tid')):
    text=f.read_text();header,_,body=text.partition('\n\n')
    fields=dict(line.split(': ',1) for line in header.splitlines() if ': ' in line)
    title=fields.get('title','')
    if title in ['$:/palette','$:/theme','$:/StoryList']:
        discarded.append({'path':f.name,'title':title,'reason':'normalize trial configuration into one canonical file'});f.unlink()
    elif fields.get('draft.of')=='访谈笔记 — 傍晚通勤':
        original=(TID/'note-04.tid').read_text().partition('\n\n')[2]
        assert body==original,'Unexpected draft content; preserve it instead of cleanup'
        discarded.append({'path':f.name,'title':title,'reason':'unchanged disposable trial draft; body equals source interview'});f.unlink()

def tid(filename,title,text,fields=''):
    (TID/filename).write_text('title: '+title+'\n'+fields+'\n'+text)
tid('fieldnotes-theme.tid','$:/theme','$:/themes/BurningTreeC/vanilla-paper')
tid('config-04.tid','$:/palette','$:/palettes/VanillaPaperDay')
tid('fieldnotes-story.tid','$:/StoryList','', 'list: [[Fieldnotes — project index]] [[访谈笔记 — 傍晚通勤]]\n')
tid('fieldnotes-toolbar.tid','$:/themes/BurningTreeC/vanilla-paper/options/toolbaralways','yes')
tid('fieldnotes-sticky.tid','$:/themes/BurningTreeC/vanilla-paper/options/stickytitles','yes')
tid('fieldnotes-press.tid','$:/themes/BurningTreeC/vanilla-paper/options/pressanimation','no')
tid('fieldnotes-motion.tid','$:/config/AnimationDuration','0')

theme=WIKI/'themes/vanilla-paper'
diffs=[]
for mode in ['Day','Night']:
    src=theme/f'VanillaPaper{mode}.tid';old=src.read_text();new=old
    for token in ['tiddler-subtitle-foreground','tiddler-controls-foreground','sidebar-controls-foreground','sidebar-muted-foreground']:
        new=re.sub(r'^'+token+r':.*$',token+': <<colour sidebar-foreground>>',new,flags=re.M)
    (TID/f'fieldnotes-paper-{mode.lower()}.tid').write_text(new)
    diffs.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(src.relative_to(ROOT)),tofile='app/wiki/tiddlers/fieldnotes-paper-'+mode.lower()+'.tid'))

surface=theme/'3-surface.tid';old=surface.read_text()
assert old.count('transition-duration: 150ms !important;')==1
new=old.replace('transition-duration: 150ms !important;','transition-duration: 1ms !important;')
surface.write_text(new)
diffs.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='upstream/3-surface.tid',tofile='app/wiki/themes/vanilla-paper/3-surface.tid'))
shutil.rmtree(WIKI/'themes/notebook');shutil.rmtree(WIKI/'plugins/notebook-mobile')
(WIKI/'THIRD-PARTY/Notebook-LICENSE.txt').unlink()
(ROOT/'evidence/source-adaptation.diff').write_text(''.join(diffs))
(ROOT/'evidence/trial-state-cleanup.json').write_text(json.dumps(discarded,ensure_ascii=False,indent=2))
timing=json.loads((ROOT/'RUN-TIMING.json').read_text());timing['deadline_utc']='2026-11-01T12:27:31.906750Z';timing['deadline_basis']='earlier parent coordination timestamp used conservatively';(ROOT/'RUN-TIMING.json').write_text(json.dumps(timing,indent=2))
print(json.dumps({'adopted':'Vanilla Paper 0.10.0','revision':'031a78d4d4187128c632f8a647fa05408eddc700','unchanged_original_note_files':8,'cleanup':discarded,'diff':'evidence/source-adaptation.diff'},ensure_ascii=False,indent=2))
