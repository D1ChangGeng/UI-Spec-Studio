from pathlib import Path
from playwright.sync_api import sync_playwright
import json,sys,time

ROOT=Path(__file__).resolve().parents[1]
name=sys.argv[1];light=sys.argv[2];dark=sys.argv[3]
OUT=ROOT/'evidence'/name
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',chromium_sandbox=True)
    page=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto('http://127.0.0.1:4411/',wait_until='networkidle')
    page.evaluate('document.fonts.ready')
    page.on('dialog',lambda d:d.accept())
    discard=page.get_by_role('button',name='Discard changes to this tiddler',exact=True)
    if discard.count():
        discard.first.click();page.wait_for_timeout(300)
    if len(sys.argv)>4:
        page.evaluate('(theme)=>$tw.wiki.addTiddler(new $tw.Tiddler({title:"$:/theme",text:theme}))',sys.argv[4])
        page.wait_for_timeout(600)
    page.evaluate('(palette)=>$tw.wiki.addTiddler(new $tw.Tiddler({title:"$:/palette",text:palette}))',light)
    page.wait_for_timeout(500)
    page.screenshot(path=str(OUT/'opening-light-1440.png'))
    note=page.locator('[data-tiddler-title="访谈笔记 — 傍晚通勤"]')
    page.evaluate('document.querySelector(\'[data-tiddler-title="访谈笔记 — 傍晚通勤"]\').scrollIntoView()')
    page.screenshot(path=str(OUT/'interview-light-1440.png'))
    page.evaluate('(palette)=>$tw.wiki.addTiddler(new $tw.Tiddler({title:"$:/palette",text:palette}))',dark)
    page.wait_for_timeout(500)
    page.screenshot(path=str(OUT/'interview-dark-1440.png'))
    page.evaluate('(palette)=>$tw.wiki.addTiddler(new $tw.Tiddler({title:"$:/palette",text:palette}))',light)
    page.set_viewport_size({'width':1280,'height':640})
    page.wait_for_timeout(300)
    page.evaluate('document.querySelector(\'[data-tiddler-title="访谈笔记 — 傍晚通勤"]\').scrollIntoView()')
    page.screenshot(path=str(OUT/'interview-light-1280.png'))
    note.get_by_role('button',name='Edit this tiddler',exact=True).click()
    page.wait_for_timeout(300)
    page.screenshot(path=str(OUT/'editor-light-1280.png'))
    print(json.dumps({'name':name,'frames':[(f.name,f.url) for f in page.frames],'buttons':page.locator('.tc-tiddler-frame button').evaluate_all('(xs)=>xs.map(x=>({text:x.innerText,title:x.title,aria:x.getAttribute("aria-label")}))'),'inputs':page.locator('input,textarea,iframe').evaluate_all('(xs)=>xs.map(x=>({tag:x.tagName,type:x.type,placeholder:x.placeholder,aria:x.getAttribute("aria-label"),class:x.className}))'),'errors':errors},ensure_ascii=False,indent=2))
    page.get_by_role('button',name='Discard changes to this tiddler',exact=True).first.click()
    page.wait_for_timeout(300)
    page.set_viewport_size({'width':390,'height':844})
    page.wait_for_timeout(300)
    page.evaluate('document.querySelector(\'[data-tiddler-title="访谈笔记 — 傍晚通勤"]\').scrollIntoView()')
    page.screenshot(path=str(OUT/'interview-light-390.png'))
    page.wait_for_timeout(700)
    browser.close()
