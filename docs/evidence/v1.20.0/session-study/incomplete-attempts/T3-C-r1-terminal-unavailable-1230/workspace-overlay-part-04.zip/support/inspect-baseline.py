from pathlib import Path
from playwright.sync_api import sync_playwright
import json,time

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence'/'baseline-run';OUT.mkdir(exist_ok=True)
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',chromium_sandbox=True)
    page=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
    errors=[]
    page.on('pageerror',lambda err:errors.append(str(err)))
    page.goto('http://127.0.0.1:4411/',wait_until='networkidle')
    page.evaluate('document.fonts.ready')
    page.screenshot(path=str(OUT/'baseline-opening-light.png'))
    print(json.dumps({'title':page.title(),'buttons':page.locator('button').evaluate_all('(xs)=>xs.map(x=>({text:x.innerText,title:x.title,aria:x.getAttribute("aria-label"),class:x.className}))'),'inputs':page.locator('input,textarea').evaluate_all('(xs)=>xs.map(x=>({tag:x.tagName,type:x.type,placeholder:x.placeholder,aria:x.getAttribute("aria-label"),class:x.className}))'),'errors':errors},ensure_ascii=False,indent=2))
    page.locator('[data-tiddler-title="访谈笔记 — 傍晚通勤"]').scroll_into_view_if_needed()
    page.evaluate('document.querySelector(\'[data-tiddler-title="访谈笔记 — 傍晚通勤"]\').scrollIntoView()')
    page.screenshot(path=str(OUT/'baseline-interview-light.png'))
    page.evaluate('$tw.wiki.addTiddler(new $tw.Tiddler({title:"$:/palette",text:"$:/palettes/Nord"}))')
    page.wait_for_timeout(300)
    page.screenshot(path=str(OUT/'baseline-interview-dark.png'))
    page.evaluate('$tw.wiki.addTiddler(new $tw.Tiddler({title:"$:/palette",text:"$:/palettes/Vanilla"}))')
    page.wait_for_timeout(700)
    browser.close()
