from pathlib import Path
from playwright.sync_api import sync_playwright
import json,time,hashlib,traceback

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence/final';LOG=ROOT/'evidence/verification'
TITLE='访谈笔记 — 傍晚通勤';INDEX='Fieldnotes — project index'
events=[];errors=[];requests=[];checks=[];t0=time.monotonic()
def event(kind,**data):
    events.append({'elapsed_s':round(time.monotonic()-t0,3),'event':kind,**data})
def check(name,value,**data):
    checks.append({'check':name,'pass':bool(value),**data});assert value,name
def norm(s):return s.rstrip('\n')
def disk(title):
    matches=[]
    for f in (ROOT/'app/wiki/tiddlers').glob('*.tid'):
        header,_,body=f.read_text().partition('\n\n')
        if ('title: '+title) in header.splitlines():matches.append((f.name,body))
    return matches
def sync(page):
    page.wait_for_timeout(100)
    page.wait_for_function('!$tw.syncer || !$tw.syncer.isDirty()',timeout=20000)
    page.wait_for_timeout(150)
def settle(page):page.wait_for_timeout(450)
def snap(page,name):
    a=time.monotonic()-t0;page.screenshot(path=str(OUT/(name+'.png')));b=time.monotonic()-t0
    event('capture',file='evidence/final/'+name+'.png',capture_bracket_s=[round(a,3),round(b,3)],viewport=page.viewport_size)
def note(page,title=TITLE):return page.locator('[data-tiddler-title='+json.dumps(title,ensure_ascii=False)+']')
def show(page,title=TITLE):
    page.evaluate('(title)=>document.querySelector("[data-tiddler-title="+CSS.escape(title)+"]").scrollIntoView({block:"start"})',title)
    settle(page)
def editor(page):return page.frame_locator('iframe.tc-edit-texteditor-body').locator('textarea')
def cancel(page):
    page.get_by_role('button',name='Discard changes to this tiddler',exact=True).click();sync(page);settle(page)
def fixture(page,palette):
    page.evaluate('({palette,titles})=>{$tw.wiki.addTiddler(new $tw.Tiddler({title:"$:/palette",text:palette}));$tw.wiki.addTiddler(new $tw.Tiddler({title:"$:/StoryList",list:titles}));}',{'palette':palette,'titles':[INDEX,TITLE]})
    sync(page);settle(page)

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',chromium_sandbox=True)
    context=browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1,locale='en-GB',reduced_motion='no-preference')
    context.tracing.start(screenshots=True,snapshots=True,sources=True)
    page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
    page.on('request',lambda r:requests.append({'url':r.url,'method':r.method,'type':r.resource_type}))
    page.on('dialog',lambda d:(event('native-dialog',message=d.message),d.accept()))
    try:
        page.goto('http://127.0.0.1:4411/',wait_until='networkidle');page.evaluate('document.fonts.ready');sync(page)
        check('selected theme active',page.evaluate('$tw.wiki.getTiddlerText("$:/theme")')=='$:/themes/BurningTreeC/vanilla-paper')
        check('clean initial drafts',page.evaluate('$tw.wiki.filterTiddlers("[is[draft]]")')==[])
        original=page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',TITLE)
        originals=page.evaluate('()=>Object.fromEntries($tw.wiki.filterTiddlers("[!is[system]!is[draft]]").map(t=>[t,$tw.wiki.getTiddlerText(t)]))')
        snap(page,'opening-light-1440')
        note(page,INDEX).get_by_role('link',name=TITLE,exact=True).click();settle(page)
        snap(page,'journey-interview-entry')
        note(page).get_by_role('heading',name='A final unresolved question',exact=True).scroll_into_view_if_needed();settle(page)
        snap(page,'interview-tail-light-1440')
        check('full interview tail visible',note(page).get_by_text('如果标志必须很少',exact=False).is_visible())
        note(page).get_by_role('link',name='Evidence ledger',exact=True).click();settle(page)
        check('ledger table present',note(page,'Evidence ledger').locator('table').count()==1)
        snap(page,'ledger-light-1440')
        note(page,'Evidence ledger').get_by_role('link',name=TITLE,exact=True).click();settle(page)
        event('native-return-to-interview')
        note(page).get_by_role('button',name='Edit this tiddler',exact=True).click();settle(page)
        check('native body editor contains complete note',editor(page).input_value()==original)
        revised=original.replace('A competing hypothesis is','An alternative hypothesis is').replace('下一轮访谈应当分别追问','下一轮访谈应分别追问')
        check('two small bilingual corrections prepared',revised!=original and 'An alternative hypothesis is' in revised and '下一轮访谈应分别追问' in revised)
        editor(page).fill(revised);sync(page);snap(page,'journey-edit-bilingual')
        event('native-save-click');page.get_by_role('button',name='Confirm changes to this tiddler',exact=True).click();sync(page);settle(page)
        saved=disk(TITLE)
        check('filesystem content agrees after native save',len(saved)==1 and norm(saved[0][1])==norm(revised),paths=[x[0] for x in saved],sha256=hashlib.sha256(norm(revised).encode()).hexdigest())
        page.reload(wait_until='networkidle');sync(page)
        check('reload agrees with saved bilingual content',page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',TITLE)==revised)
        show(page);snap(page,'journey-saved-reloaded')
        note(page).get_by_role('button',name='Edit this tiddler',exact=True).click();settle(page)
        editor(page).fill(revised+'\n\nDISPOSABLE CANCEL CHECK — 不应保存');sync(page)
        snap(page,'journey-before-cancel');cancel(page)
        check('cancel preserves authoritative content',norm(disk(TITLE)[0][1])==norm(revised))
        page.reload(wait_until='networkidle');sync(page)
        check('cancel survives reload without draft',page.evaluate('$tw.wiki.filterTiddlers("[is[draft]]")')==[] and page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',TITLE)==revised)
        note(page,INDEX).get_by_role('link',name='Next field session',exact=True).click();settle(page)
        check('continue to another note after cancel',note(page,'Next field session').count()==1)
        snap(page,'journey-next-note')

        # Native keyboard search -> result -> note toolbar -> editor.
        page.reload(wait_until='networkidle');sync(page)
        for _ in range(90):
            if page.evaluate('document.activeElement?.type==="search"'):break
            page.keyboard.press('Tab')
        check('search reachable by keyboard',page.evaluate('document.activeElement?.type==="search"'))
        page.keyboard.press('Control+A');page.keyboard.type('Quiet route');page.wait_for_timeout(500)
        found=False;focus_path=[]
        for _ in range(90):
            active=page.evaluate('()=>({tag:document.activeElement.tagName,text:document.activeElement.textContent,aria:document.activeElement.getAttribute("aria-label")})');focus_path.append(active)
            if active['tag']=='A' and active['text'].strip()=='Quiet route — working draft':found=True;break
            page.keyboard.press('Tab')
        check('search result reachable with Tab',found,focus_path=focus_path)
        snap(page,'keyboard-search-result');page.keyboard.press('Enter');settle(page)
        reached=False;focus_path=[]
        for _ in range(140):
            active=page.evaluate('()=>({aria:document.activeElement.getAttribute("aria-label"),title:document.activeElement.closest("[data-tiddler-title]")?.getAttribute("data-tiddler-title"),tag:document.activeElement.tagName})');focus_path.append(active)
            if active['aria']=='Edit this tiddler' and active['title']=='Quiet route — working draft':reached=True;break
            page.keyboard.press('Tab')
        check('note pencil reachable by keyboard after search',reached,focus_path=focus_path)
        snap(page,'keyboard-editor-trigger');page.keyboard.press('Enter');settle(page)
        reached=False
        for _ in range(100):
            if page.evaluate('()=>document.activeElement?.tagName==="IFRAME" && document.activeElement.contentDocument.activeElement.tagName==="TEXTAREA"'):reached=True;break
            page.keyboard.press('Tab')
        check('body editor reachable with keyboard',reached)
        snap(page,'keyboard-body-editor');cancel(page)

        # Settled appearance fixtures use the native store's configuration API;
        # user-task behavior above uses actual links, buttons and keyboard input.
        geometries=[]
        for theme,palette in [('light','$:/palettes/VanillaPaperDay'),('dark','$:/palettes/VanillaPaperNight')]:
            for width,height in [(1440,900),(1280,640),(390,844)]:
                page.set_viewport_size({'width':width,'height':height});fixture(page,palette);show(page)
                snap(page,f'interview-{theme}-{width}')
                geometries.append(page.evaluate('()=>({viewport:innerWidth,documentWidth:document.documentElement.scrollWidth,bodyFont:getComputedStyle(document.querySelector(".tc-tiddler-body")).fontFamily,bodySize:getComputedStyle(document.querySelector(".tc-tiddler-body")).fontSize,palette:$tw.wiki.getTiddlerText("$:/palette"),animations:document.getAnimations().length})'))
                check(f'no page horizontal overflow {theme} {width}',page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
                note(page).get_by_role('button',name='Edit this tiddler',exact=True).click();sync(page);settle(page)
                snap(page,f'editor-{theme}-{width}')
                check(f'editor has complete bilingual content {theme} {width}',editor(page).input_value()==revised)
                cancel(page)
        (LOG/'geometry.json').write_text(json.dumps(geometries,ensure_ascii=False,indent=2))

        # Ledger's narrow table and long-argument tail are separate content checks.
        note(page).get_by_role('link',name='Evidence ledger',exact=True).click();settle(page);snap(page,'ledger-dark-390')
        check('ledger narrow document does not overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
        table=note(page,'Evidence ledger').locator('table');check('narrow ledger retains five rows',table.locator('tr').count()==5)
        page.emulate_media(reduced_motion='reduce');fixture(page,'$:/palettes/VanillaPaperNight');show(page);snap(page,'reduced-motion-reading-dark-390')
        note(page).get_by_role('button',name='Edit this tiddler',exact=True).click();sync(page);settle(page);snap(page,'reduced-motion-editor-dark-390')
        check('reduced motion requested and quiet native duration',page.evaluate('matchMedia("(prefers-reduced-motion: reduce)").matches && $tw.utils.getAnimationDuration()===0'))
        cancel(page)
        page.set_viewport_size({'width':1440,'height':900});fixture(page,'$:/palettes/VanillaPaperDay')
        page.evaluate('$tw.wiki.addTiddler(new $tw.Tiddler({title:"$:/language",text:"$:/languages/zh-Hans"}))');sync(page);show(page)
        snap(page,'chinese-ui-reading-light-1440')
        note(page).locator('button[class*="%2FButtons%2Fedit"]').click();sync(page);settle(page);snap(page,'chinese-ui-editor-light-1440')
        check('Chinese UI preserves editable note',editor(page).input_value()==revised)
        page.locator('.tc-tiddler-frame button[class*="%2FButtons%2Fcancel"]').click();sync(page)
        page.evaluate('$tw.wiki.addTiddler(new $tw.Tiddler({title:"$:/language",text:"$:/languages/en-GB"}))');sync(page)
        fixture(page,'$:/palettes/VanillaPaperDay');page.emulate_media(reduced_motion='no-preference');page.evaluate('scrollTo(0,0)');settle(page)
        check('eight original notes retained',all(page.evaluate('(t)=>$tw.wiki.tiddlerExists(t)',title) for title in originals))
        check('other seven notes unchanged',all(page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',title)==text for title,text in originals.items() if title!=TITLE))
        check('no remaining native drafts',page.evaluate('$tw.wiki.filterTiddlers("[is[draft]]")')==[])
        check('no browser page errors',errors==[],errors=errors)
        check('no external runtime requests',all(r['url'].startswith(('http://127.0.0.1:4411/','data:','about:')) for r in requests))
        snap(page,'final-opening-light-1440')
        event('completed')
    except Exception as exc:
        event('failure',error=str(exc));traceback.print_exc();snap(page,'failure-state');raise
    finally:
        (LOG/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
        (LOG/'events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2))
        (LOG/'browser-errors.json').write_text(json.dumps(errors,ensure_ascii=False,indent=2))
        (LOG/'requests.json').write_text(json.dumps(requests,ensure_ascii=False,indent=2))
        context.tracing.stop(path=str(LOG/'native-journey-trace.zip'))
        context.close();browser.close()
        print(json.dumps({'checks':len(checks),'passed':sum(c['pass'] for c in checks),'last_event':events[-1]},ensure_ascii=False))
