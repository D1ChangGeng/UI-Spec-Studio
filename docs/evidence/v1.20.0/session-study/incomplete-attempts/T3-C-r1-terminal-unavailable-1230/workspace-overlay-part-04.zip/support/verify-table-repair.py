from pathlib import Path
from playwright.sync_api import sync_playwright
import json,time
R=Path(__file__).resolve().parents[1]; O=R/'evidence/final/table-repair'; O.mkdir(exist_ok=True); checks=[]; events=[]; t=time.monotonic()
def check(n,v,**kw):
 checks.append({'check':n,'pass':bool(v),**kw}); assert v,n
def sync(p):
 p.wait_for_timeout(100);p.wait_for_function('!$tw.syncer.isDirty()',timeout=15000);p.wait_for_timeout(300)
def shot(p,n):
 a=time.monotonic()-t;p.screenshot(path=str(O/(n+'.png')));events.append({'capture':n+'.png','bracket_s':[a,time.monotonic()-t]})
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',chromium_sandbox=True)
 c=b.new_context(viewport={'width':1440,'height':900},device_scale_factor=1,locale='en-GB');c.tracing.start(screenshots=True,snapshots=True,sources=True);p=c.new_page();errs=[];p.on('pageerror',lambda e:errs.append(str(e)))
 try:
  p.goto('http://127.0.0.1:4411/',wait_until='networkidle');p.evaluate('document.fonts.ready');sync(p)
  check('fresh server theme and palette',p.evaluate('$tw.wiki.getTiddlerText("$:/theme")==="$:/themes/BurningTreeC/vanilla-paper" && $tw.wiki.getTiddlerText("$:/palette")==="$:/palettes/VanillaPaperDay"'))
  check('fresh server persisted bilingual correction',p.evaluate('()=>{let t=$tw.wiki.getTiddlerText("访谈笔记 — 傍晚通勤");return t.includes("An alternative hypothesis is")&&t.includes("下一轮访谈应分别追问")}'))
  check('fresh server has no drafts',p.evaluate('$tw.wiki.filterTiddlers("[is[draft]]").length===0'))
  shot(p,'final-opening-clean-1440')
  for title,label,cols in [('Evidence ledger','Evidence ledger table',4),('Observation log — East entrance','Observation log table',3),('Prototype directions','Prototype comparison table',4)]:
   # The fixture sets native story state; all scrolling is real browser keyboard input.
   exists=p.evaluate('(t)=>$tw.wiki.tiddlerExists(t)',title)
   if not exists:
    title=p.evaluate('(label)=>$tw.wiki.filterTiddlers("[!is[system]]").find(t=>$tw.wiki.getTiddlerText(t).includes(label))',label)
   p.evaluate('(t)=>$tw.wiki.addTiddler(new $tw.Tiddler({title:"$:/StoryList",list:[t]}))',title);sync(p)
   p.set_viewport_size({'width':390,'height':844});p.wait_for_timeout(300)
   region=p.get_by_role('region',name=label);region.scroll_into_view_if_needed()
   check(title+' semantic headers',region.locator('th').count()==cols,count=region.locator('th').count())
   g=region.evaluate('(e)=>({width:e.clientWidth,scrollWidth:e.scrollWidth,documentWidth:document.documentElement.scrollWidth,viewport:innerWidth})')
   check(title+' bounded native wrapper',g['width']<=390 and g['documentWidth']<=390,geometry=g)
   region.focus();region.press('Home');p.wait_for_timeout(150);shot(p,title.split(' ')[0].lower()+'-light-left-390')
   for _ in range(20):region.press('ArrowRight')
   p.wait_for_timeout(300)
   check(title+' keyboard reaches final column',region.evaluate('(e)=>e.scrollWidth<=e.clientWidth || e.scrollLeft>0'),scrollLeft=region.evaluate('(e)=>e.scrollLeft'))
   shot(p,title.split(' ')[0].lower()+'-light-right-390')
   if label=='Evidence ledger table':
    p.evaluate('$tw.wiki.addTiddler(new $tw.Tiddler({title:"$:/palette",text:"$:/palettes/VanillaPaperNight"}))');sync(p);region.focus();shot(p,'ledger-dark-right-390')
    p.evaluate('$tw.wiki.addTiddler(new $tw.Tiddler({title:"$:/palette",text:"$:/palettes/VanillaPaperDay"}))');sync(p)
  p.evaluate('()=>{$tw.wiki.addTiddler(new $tw.Tiddler({title:"$:/StoryList",list:["Fieldnotes — project index","访谈笔记 — 傍晚通勤"]}));}');sync(p)
  check('no browser errors in final repair check',not errs,errors=errs)
 finally:
  (O/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2));(O/'events.json').write_text(json.dumps(events,indent=2));c.tracing.stop(path=str(O/'table-repair-trace.zip'));c.close();b.close()
  print(json.dumps({'checks':len(checks),'passed':sum(x['pass'] for x in checks)}))
