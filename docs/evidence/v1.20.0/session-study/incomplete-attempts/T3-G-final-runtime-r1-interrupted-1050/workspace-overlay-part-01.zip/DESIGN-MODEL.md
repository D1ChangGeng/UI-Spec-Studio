# Fieldnotes — current design model

## Formal increment F1: editorial research workspace

The overall goal is a distinctive, mature whole-workspace direction that remains useful for reading, navigating, editing, saving and returning to bilingual research notes. This increment owns the composition, reading/editor distinction, theme variants and their native task continuity together. The current product is TiddlyWiki 5.4.1 at the pinned revision in PROVENANCE.json. Its authoritative tiddlyweb/filesystem boundary and supplied note meaning are unchanged.

Research scope includes alternative mature TW themes and editorial/notebook composition; implementation scope is supported theme adoption and configuration in app/wiki; regression covers long reading, evidence tables, native edit/save/reload/cancel, search, keyboard, narrow and short viewports, dark/light and reduced motion. No W1/W2/W3 authorization exists and no original visual construction is proposed.

## Important questions and current evidence

1. **L0/L2/L4 — Can an editorial sheet give long work a recognizable character?** BurningTreeC's vanilla-paper v0.10.0, revision 031a78d4d4187128c632f8a647fa05408eddc700, is a complete self-contained theme with structural, layout and surface implementation. Its supplied Paper Day/Night palettes, serif/UI type roles, margin rule, ruled editor and sidebar transitions are plausible. Acquired source, MIT rights and documented supported settings are in evidence/candidates/paper. Local trial is pending actual visual judgment.
2. **L1/L2 — Could a more compact notebook arrangement serve the task better?** Nicolas Petton's Notebook v1.4.1, revision 465c832c885894ee3c97be76449cc524e1252eb0, has left navigation and a top toolbar. It challenges the editorial-first hypothesis with a different organizing structure. Native Vanilla and notebook-mobile supply its dependencies. Same-content local trial is being prepared. Krystal's horizontal story is an additional research direction; its fit and rights remain research questions, not adoption.
3. **L3/L5 — Do the native workflows remain real?** All note controls, drafts, search/tags, tiddlyweb and filesystem remain TiddlyWiki-owned. Browser editing and filesystem/reload checks will establish persistence; a visible save state alone will not.
4. **L4/L5 — Does bilingual type actually render under controlled conditions?** First sandbox-enabled browser attempt failed under root (commands/003). Nonprivileged oai with the Chromium sandbox intact succeeded (commands/005), but actual inspection showed missing Chinese glyphs because the host font directory was not accessible. Coordinator repaired the nonsecret directory access with file bytes unchanged. Fresh captures with the same fixture are required; the first capture remains historical failed evidence.
5. **L4/L5 — Can expression stay quiet?** Prefer source-provided reduced-motion and normal controls. Actual time-bounded sequences and static frame inspection will have separate claims; no natural-time smoothness claim is supported yet.

## Source and responsibility boundaries

The selected complete theme must carry layout, spacing, type hierarchy, surfaces, controls and state treatment. TiddlyWiki core continues to own markup, editor engine, native operations and persistence. Host Noto Sans CJK SC is an observation fixture, not a redistributed product asset. Product wording and note lengths remain as supplied. No decorative imagery is required. Modern web guidance was searched and retrieved in commands/001 and 004; upstream source behavior will be checked against it without adding unrelated new APIs.

## Next evidence-producing action

Capture and personally inspect original Paper/Notebook demos and same-content trials at 1440×900, with the long interview and editor. If Paper's type/material relationships remain coherent across CJK and editing, configure it in the native server product and test required conditions. If the editorial measure or editor treatment fails, use source-supported options or reconsider Notebook rather than inventing a replacement layer. Final owner preference remains unrequested/unconfirmed; the task delegates a provisional design selection to this run.

## Terminal status

The substantive window ended with corrected same-content trial captures awaiting main-designer image inspection. The four-image inspection batch stalled and was interrupted. No final candidate was adopted in app/wiki; the original expressive and verification goals remain unresolved. See FINAL.md, VISUAL-REVIEW.md and RUN-TIMING.json. Subsequent work is preservation only.
