# Visual review — terminal scope

## Main designer: actually viewed

1. **Native baseline, 1440×900 light** — evidence/baseline/1440-light.png; full actual response evidence/view-001.json. The broad white note sheet, right sidebar, blue links and pale controls were visible. Chinese appeared as boxes. This is failed typography evidence, not a valid bilingual baseline: the sandbox-preserving oai browser could not access the host font directory then.
2. **Original Paper demo, 1440×900 light** — evidence/trial-captures/paper-original-demo.png; full actual response evidence/view-002.json. Warm ground, cream sheet, red margin rule and serif text were directly visible. Sans sidebar utilities supported a distinct reading/interface relationship. This supports the source's English demo appearance only.
3. **First Paper product export, 1440×900** — evidence/trial-captures/paper-index.png; full actual response evidence/view-003.json. The page was unstyled. Chinese rendered after the coordinator's font-directory access repair. Native theme/palette text contained a trailing newline. The builder was corrected and a new attempt retained separately.

## Captured but not visually accepted

Corrected source-demo, index, interview and editor screenshots for Paper and Notebook exist under evidence/trial-captures-v2/. The successful script used actual note links and per-note edit controls in offline trials. Conditions and command results are retained. The next batch requested four view_image inspections but stalled until interruption. No completed image-tool results or pixels from that batch were delivered to the main designer; view-004.json through view-007.json were not created. Those captures remain unreviewed. An exit code and DOM measurements do not establish their appearance.

## Research-child observations

The child reports personally viewing three source-demo PNGs. Original report, screenshots, image-tool responses and exact final notification are retained under evidence/research-child/. Those observations concern downloaded public demos, not Fieldnotes' final application. The main designer did not personally inspect the child's Notebook or Krystal renders before interruption.

## Temporal and final-product limits

No natural-time sequence was viewed. No final integrated theme exists in app/wiki. No dark, 1280×640, 390×844, reduced-motion, UI-language, save/reload, cancellation, search-to-editor keyboard, pending/error or resource-cost acceptance was completed. Offline editor entry is narrower evidence than a persistent server-backed edit. This review is incomplete, not owner approval or expressive completion.
