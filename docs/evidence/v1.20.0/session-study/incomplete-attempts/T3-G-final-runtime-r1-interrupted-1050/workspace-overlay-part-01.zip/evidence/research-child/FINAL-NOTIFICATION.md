**Vanilla Paper 0.10.0 is the strongest editorial candidate; Notebook 1.4.1 is the serious alternative to trial before committing.** Both have acquired pinned source archives and verified MIT licenses. Krystal provides a stronger challenge to the book metaphor, but its redistribution rights remain unresolved.

| Candidate | Exact source | Why it matters |
|---|---|---|
| **Vanilla Paper** | [BurningTreeC/vanilla-paper](https://github.com/BurningTreeC/vanilla-paper), commit `031a78d4d4187128c632f8a647fa05408eddc700`, version **0.10.0**, MIT | Complete standalone theme: warm paper/desk distinction, serif reading, sans interface, mono editor, red margin rule, source-defined day/night palettes, sliding sidebar. Acquired source contains `themes/BurningTreeC/vanilla-paper`; requires TW ≥5.3.0. |
| **Notebook** | [NicolasPetton/Notebook](https://github.com/NicolasPetton/Notebook), commit `465c832c885894ee3c97be76449cc524e1252eb0`, version **1.4.1**, MIT | Central cards, sans reading and headings, top search/utilities, custom left sidebar. Its work-tool composition could improve repeated search/edit cycles. Depends on Vanilla and `notebook-mobile` 1.0.0. |
| **Krystal** | [crazko/krystal](https://github.com/crazko/krystal), commit `d1d0574ce36cd8c7a7f3e88eaa0bc3aa985a9305`, version **0.5.2** | Horizontal note columns and thin top toolbar challenge the sequential manuscript model. Demo explicitly credits Andy Matuschak’s Evergreen notes. **License not established; reference only pending rights evidence.** |

I **personally viewed actual renders of all three downloaded public demos**, at 1440×900. Paper’s material and type identity persists throughout populated text. Notebook visibly concentrates navigation above central reading cards. Krystal visibly establishes a narrow initial note pane with space for related columns, though I did not operate its multi-note episode.

**Evidence and report**

All paths retain the registered package root:

`/workspace/scratch/708e8b7f118e/ui-study/worksets/w12/evidence/research-child/`

- `REPORT.md`: concise comparison, provenance, observed relationships, limitations and suggested trial.
- `{paper,notebook,krystal}-source.tar.gz`: pinned source archives.
- `{paper,notebook,krystal}-demo.html`: acquired public demo bytes.
- `{paper,notebook,krystal}-local-demo.png`: inspected actual renders.
- `theme-research-{paper,notebook,krystal}-view.json`: full original image inspection tool objects.
- `r01.json`–`r03.json`, repository JSON files and `acquisition.json`: original search/API/acquisition evidence.
- `render_demos.py` and `*-local-render.json`: reproducible capture route and actual errors.

**Limits that affect the decision:** These captures are source demos, not Fieldnotes trials. Dark mode, narrow/short viewports, editing, save persistence, reduced motion and natural-time behavior remain unverified. Direct HTTPS rendering encountered certificate errors; downloaded demos were rendered locally with the nonprivileged `oai` user and Chromium sandbox enabled. CJK font access remained blocked, so no Chinese typography claim is made. Metadata extraction failed after screenshots and text capture; exact plugin identities instead come from the pinned archives.

For the next comparison, use the same **interview → ledger → interview → edit/cancel** sequence in Paper and Notebook. Paper’s readme warns that its Vanilla compatibility shim holds static metrics, which matters if changing its sidebar breakpoint while using the menubar plugin.

No app code or instructions were changed.