# Mature TiddlyWiki direction research
## Decision-useful result
Vanilla Paper 0.10.0 is the strongest source-backed editorial candidate found; Notebook 1.4.1 is a serious composition and workflow challenge. Krystal 0.5.2 offers a more radical horizontal research desk, but its redistribution permission was not established. These are research recommendations, not final design choices. No application files or instructions were edited.

## Candidates and provenance
| Candidate | Exact identity and rights | Main contribution | Adoption route / limits |
|---|---|---|---|
| Vanilla Paper | BurningTreeC/vanilla-paper, commit 031a78d4d4187128c632f8a647fa05408eddc700, plugin version 0.10.0, MIT copyright Simon Huber 2026 | Complete standalone theme: warm paper material, serif reading role, sans interface, mono editing; red margin rule; sliding native sidebar; source-defined day/night palettes and editor ruling | Acquired paper-source.tar.gz. Theme folder themes/BurningTreeC/vanilla-paper. Requires core >=5.3.0. Preserves core markup through its own structural and surface styles. Source's readme warns that its Vanilla-namespace shim contains static metrics, so changing its breakpoint plus menubar requires keeping the compatibility value aligned. |
| Notebook | NicolasPetton/Notebook, commit 465c832c885894ee3c97be76449cc524e1252eb0, version 1.4.1, MIT copyright Nicolas Petton 2020 | Complete source-backed alternative: central reading cards, strong sans headings, top utilities and search, custom left sidebar, grey/beige/dark variants | Acquired notebook-source.tar.gz. Folder themes/notebook; depends on Vanilla plus plugins/notebook-mobile (version 1.0.0); core >=5.1.22. Current TW 5.4.1 compatibility still needs local product trial. |
| Krystal | crazko/krystal, commit d1d0574ce36cd8c7a7f3e88eaa0bc3aa985a9305, version 0.5.2 | Horizontal story river and top bar; source demo explicitly credits Andy Matuschak's Evergreen notes. Strong challenge to a serial book metaphor: related notes can occupy neighboring columns. | Acquired krystal-source.tar.gz; plugins/rmnvsl/krystal; core >=5.0.8. GitHub license endpoint returned no license and inspected archive metadata/readme did not establish permission. Keep as observed reference until rights resolved. Not a permission-cleared adoption recommendation. |

Primary source links:
- https://github.com/BurningTreeC/vanilla-paper
- https://burningtreec.github.io/vanilla-paper/
- https://github.com/NicolasPetton/Notebook
- https://nicolas.petton.fr/tw/notebook.html (repository's named original)
- https://saqimtiaz.github.io/sq-tw/notebook.html (TiddlyWiki's community listing links this maintained public demo)
- https://github.com/crazko/krystal
- https://crazko.github.io/krystal/

## Actual visual observation
I personally opened all three local screenshots using view_image. These are browser renders of acquired public demo HTML, not screenshots of Fieldnotes or current-content trials. Viewport 1440×900, DPR 1, supplied Chromium executable, local file origin. Final rendering used the existing nonprivileged oai user with chromium_sandbox=True. No TLS bypass was used.

Paper: cream page sheet stands above a darker warm ground, with a fine red rule aligned down the left content edge. Large bold serif title and body rhythm create a clear book/paper association; sans sidebar utilities remain visually separate. Right sidebar is roomy. In this English demonstration the reading column is comfortable and unmistakably editorial. Very light secondary icons/date text merit attention in the integrated dark/light checks. The warm surface and margin rule continue down populated content, so identity is not restricted to a hero.

Notebook: central white cards sit within a muted near-white background, with larger sans headings and a low horizontal toolbar. Search sits immediately above the reading surface; per-note edit/close affordances remain at the card's upper right. Its stronger work-tool character and reduced permanent sidebar mass could outperform Paper for frequent search/edit cycles, even if Paper better matches the initial art hypothesis. The initial sidebar is collapsed, so its expanded composition has not been inspected.

Krystal: a thin full-width toolbar leaves a narrow note column on the left and a broad open region for subsequent notes. This visibly differs from a vertical manuscript river. The source demo documents backlinks and horizontal expansion, but I did not click through a multi-note episode; appearance of adjacent populated columns and keyboard/scroll continuity remain unobserved.

## Why the challenge matters
The editorial hypothesis emphasizes sustained reading, material identity and separation of interface from authored text. Notebook instead concentrates search and repeated tools above the work while keeping reading in central cards. Krystal challenges the sequential book model itself by treating related notes as neighboring working objects. Fieldnotes requires returning from evidence to an interview; the decisive trial is therefore a populated interview → ledger → interview → edit/cancel sequence, not an empty-theme screenshot. Notebook is the rights-cleared alternative worth that trial. Krystal remains a conceptual/source reference pending license evidence.

Cross-domain material was pursued only through these supported paths: Paper supplies its own editorial/paper composition and three type roles; Krystal supplies an actual TW implementation of an Evergreen-notes-inspired spatial model. No unrelated font, texture, image, animation engine or replacement CSS is proposed.

## Evidence index
- r01.json, r02.json, r03.json: original web tool request/returned objects, including failed GitHub opens.
- vanilla-paper.json, Notebook.json, krystal.json: raw GitHub API metadata/commit/license/release responses.
- acquisition.json: actual HTTP URL/status/header/byte outputs for downloaded demos and pinned archives.
- paper-source.tar.gz, notebook-source.tar.gz, krystal-source.tar.gz: pinned source archives.
- paper-demo.html, notebook-demo.html, krystal-demo.html: acquired public demo bytes.
- paper-demo.json, notebook-demo.json, krystal-demo.json: initial direct-navigation failures (ERR_CERT_AUTHORITY_INVALID).
- render_demos.py: sandbox-preserving local-render script.
- paper-local-demo.png, notebook-local-demo.png, krystal-local-demo.png: real local browser captures.
- paper-local-render.json, notebook-local-render.json, krystal-local-render.json: actual text/conditions/errors returned by local render script.
- theme-research-paper-view.json, theme-research-notebook-view.json, theme-research-krystal-view.json: full original view_image argument/result objects, including image data.

## Limitations and next action
No Fieldnotes content trial, edit/save persistence validation, narrow viewport, dark-state, reduced-motion or natural-time inspection was performed by this research child. Those remain with the main designer. The host's CJK font directory was inaccessible to oai during this bounded inquiry; no mixed-script quality is claimed. Public demos were acquired with normal TLS verification using Python HTTP, then rendered locally because direct Chromium HTTPS requests failed certificate verification. Local file origin can affect network-dependent features.

The local metadata extraction attempted an unavailable $tw.wiki.tiddlers property after successfully writing screenshots and reading body text; those JSON records correctly retain the error, and do not claim extracted plugin metadata. Source identities above come from inspected pinned archives instead. The initial failed remote browser attempt used Playwright's default launch behavior; the successful captures explicitly enabled Chromium sandbox under oai. I did not alter sandbox, proxy or TLS policies.

Recommend the main designer trial the unchanged Paper theme with Fieldnotes first, and compare Notebook under the same long interview and ledger content before committing. Preserve source-defined type/surface relationships; configure source-supported options only. For Paper, examine editor ruling, light/dark secondary controls, Chinese fallback and short/narrow sidebar behavior. This report does not certify expressive completion or accept the final product.

