from playwright.sync_api import sync_playwright
from pathlib import Path
import json,time
root=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w12/evidence/research-child')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,chromium_sandbox=True)
 for name in ['paper','notebook','krystal']:
  page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
  result={'file':name+'-demo.html','viewport':[1440,900],'browser_sandbox':True,'local_copy_of_public_demo':True}
  try:
   page.goto((root/(name+'-demo.html')).as_uri(),wait_until='load',timeout=20000)
   page.wait_for_function('window.$tw && $tw.wiki',timeout=10000)
   page.screenshot(path=str(root/(name+'-local-demo.png')))
   result['text']=page.locator('body').inner_text()
   result['plugins']=page.evaluate('Object.values($tw.wiki.tiddlers).filter(t=>t.fields["plugin-type"]).map(t=>({title:t.fields.title,version:t.fields.version,type:t.fields["plugin-type"],description:t.fields.description}))')
   result['theme']=page.evaluate('$tw.wiki.getTiddlerText("$:/theme")')
   result['palette']=page.evaluate('$tw.wiki.getTiddlerText("$:/palette")')
   result['themes']=page.evaluate('Object.values($tw.wiki.tiddlers).filter(t=>t.fields["plugin-type"]==="theme").map(t=>t.fields)')
  except Exception as e:result['error']=str(e)
  (root/(name+'-local-render.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2))
  print(name,json.dumps({k:v for k,v in result.items() if k not in ['text','themes']},ensure_ascii=False))
  page.close()
 b.close()

