import json, shutil, subprocess
from pathlib import Path
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w12')
for name in ['paper','notebook']:
    trial=ROOT/'evidence/trials'/name
    trial.mkdir(parents=True,exist_ok=True)
    shutil.copytree(ROOT/'app/wiki/tiddlers',trial/'tiddlers',dirs_exist_ok=True)
    info=json.loads((ROOT/'app/wiki/tiddlywiki.info').read_text())
    if name=='paper':
        info['themes']=[]
        shutil.copytree(ROOT/'evidence/candidates/paper/themes/BurningTreeC/vanilla-paper',trial/'themes/paper',dirs_exist_ok=True)
        theme='$:/themes/BurningTreeC/vanilla-paper'; palette='$:/palettes/VanillaPaperDay'
    else:
        info['themes']=['tiddlywiki/vanilla']
        shutil.copytree(ROOT/'evidence/candidates/notebook/themes/notebook',trial/'themes/notebook',dirs_exist_ok=True)
        if (ROOT/'evidence/candidates/notebook/plugins/notebook-mobile').exists():
            shutil.copytree(ROOT/'evidence/candidates/notebook/plugins/notebook-mobile',trial/'plugins/notebook-mobile',dirs_exist_ok=True)
        theme='$:/themes/nico/notebook'; palette='$:/palettes/Vanilla'
    (trial/'tiddlywiki.info').write_text(json.dumps(info,indent=2))
    (trial/'tiddlers/selected-theme.tid').write_text('title: $:/theme\n\n'+theme)
    (trial/'tiddlers/config-04.tid').write_text('title: $:/palette\n\n'+palette)
    result=subprocess.run(['node',str(ROOT/'app/vendor/tiddlywiki/tiddlywiki.js'),str(trial),'--build','index'],capture_output=True,text=True)
    print(json.dumps({'candidate':name,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr}))
    result.check_returncode()
