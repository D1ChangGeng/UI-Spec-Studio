import json,time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w12')
OUT=ROOT/'evidence/trial-captures-v2'; OUT.mkdir(exist_ok=True)
records=[]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,chromium_sandbox=True)
    for name in ['paper','notebook']:
        page=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
        page.goto((ROOT/f'evidence/research-child/{name}-demo.html').as_uri(),wait_until='load')
        page.wait_for_timeout(400)
        page.screenshot(path=str(OUT/f'{name}-original-demo.png'))
        page.close()
        page=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
        page.goto((ROOT/f'evidence/trials/{name}/output/index.html').as_uri(),wait_until='load')
        page.wait_for_timeout(300)
        page.screenshot(path=str(OUT/f'{name}-index.png'))
        page.get_by_role('link',name='访谈笔记 — 傍晚通勤',exact=True).first.click()
        page.wait_for_timeout(500)
        page.screenshot(path=str(OUT/f'{name}-interview.png'))
        frame=page.locator('.tc-tiddler-frame[data-tiddler-title="访谈笔记 — 傍晚通勤"]')
        frame.get_by_role('button',name='Edit this tiddler',exact=True).click()
        page.wait_for_timeout(250)
        page.screenshot(path=str(OUT/f'{name}-editor.png'))
        records.append({'candidate':name,'time':time.time(),'frames':len(page.frames),'width':1440,'height':900,'device_scale_factor':1,'browser':browser.version,'fontconfig':'/tmp/ui-spec-fonts/fonts.conf','theme':page.evaluate('$tw.wiki.getTiddlerText("$:/theme")'),'palette':page.evaluate('$tw.wiki.getTiddlerText("$:/palette")'),'font':page.locator('body').evaluate('(el)=>getComputedStyle(el).fontFamily'),'overflow':page.evaluate('document.documentElement.scrollWidth>innerWidth')})
        page.close()
    browser.close()
(OUT/'conditions.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
print(json.dumps(records,ensure_ascii=False,indent=2))
