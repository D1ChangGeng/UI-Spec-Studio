import json, os, time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w12')
OUT=ROOT/'evidence/baseline'; OUT.mkdir(parents=True,exist_ok=True)
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,chromium_sandbox=True)
    page=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
    page.goto('http://127.0.0.1:4412/',wait_until='networkidle')
    page.screenshot(path=str(OUT/'1440-light.png'))
    result={'url':page.url,'title':page.title(),'browser':browser.version,'time':time.time(),'buttons':page.locator('button').evaluate_all('(els)=>els.map(x=>({text:x.innerText,title:x.title,aria:x.getAttribute("aria-label"),classes:x.className}))'),'inputs':page.locator('input,textarea').evaluate_all('(els)=>els.map(x=>({tag:x.tagName,type:x.type,placeholder:x.placeholder,classes:x.className}))'),'tiddlers':page.locator('.tc-tiddler-frame').evaluate_all('(els)=>els.map(x=>({title:x.getAttribute("data-tiddler-title"),rect:x.getBoundingClientRect().toJSON()}))')}
    (OUT/'inspection.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps(result,ensure_ascii=False,indent=2))
    browser.close()
