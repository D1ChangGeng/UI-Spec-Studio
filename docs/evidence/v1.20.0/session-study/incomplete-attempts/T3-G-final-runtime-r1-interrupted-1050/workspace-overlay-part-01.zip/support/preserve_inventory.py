import hashlib,json,datetime
from pathlib import Path
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w12')
excluded=['SOURCE-INVENTORY.json','evidence/commands/010-preservation-inventory/']
entries=[]
for path in sorted(ROOT.rglob('*')):
    if not path.is_file(): continue
    relative=str(path.relative_to(ROOT))
    if any(relative==item or relative.startswith(item) for item in excluded): continue
    content=path.read_bytes()
    entries.append({'path':relative,'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()})
record={'evidence_kind':'preservation_source_and_artifact_inventory','generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'registered_root':str(ROOT),'excluded':excluded,'file_count':len(entries),'total_bytes':sum(x['bytes'] for x in entries),'files':entries,'claim_limit':'Current file inventory only; no product verification or visual acceptance implied.'}
(ROOT/'SOURCE-INVENTORY.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['generated_at','file_count','total_bytes','claim_limit']}))
