# Work allocation



Work package: `/workspace/scratch/708e8b7f118e/ui-study/worksets/w04`. Use a unique local port, suggested 4404.

The main agent retains the complete product goal, all final design choices and assembled-product inspection.

Keep primary implementation in the main agent except for the explicitly assigned settled integration scope.

All four distributed instruction roles are available in `roles/`. Decide adaptively whether an independent inquiry or settled bounded integration would help this specific task. You may complete a well-supported task directly. If delegating, use fresh contexts, read the appropriate role instructions, keep research and implementation responsibilities distinct, and retain actual coordination/tool exports. Model and effort inherit the session defaults.

Use at most one live child at a time and at most two children overall. Keep the substantive work bounded to 30 minutes; if a genuine blocker or quality gap remains, preserve it honestly instead of claiming completion.

Save child coordination exports and the child report references in `DELEGATION.json` if any child is used. The exact schemas can be simple: retain original tool requests/results rather than creating native-looking events.

Keep normal source and role instructions unchanged. Save actual product changes, captured observations and FINAL.md.
