# T1 input — Fieldnotes account settings

## Product and requested increment

Fieldnotes is a bilingual knowledge-work product for researchers who collect notes with a small distributed team. Improve this one existing settings experience: profile identity, weekly notifications, and profile visibility should read as one coherent mature application, including editing, validation, saving, one failed save, retry, and return. The complete assignment is in `TASK.md`.

The application starts from Tabler's original settings page, not a new visual mockup. Preserve its established settings navigation, content hierarchy, typography, surfaces, form family, theme system, and browser-local settings model. Source-supported configuration, composition and narrow adaptation are authorized. No original visual construction, unrelated navigation redesign, service integration, or authentication work is authorized.

## Selected foundation and provenance

- Upstream: `https://github.com/tabler/tabler`, MIT.
- Version: `@tabler/core@1.7.1`; exact tag commit and package/snapshot digests are in `SOURCE-MANIFEST.json`.
- Complete original rendered settings page: `sources/official-settings-snapshot.html`, fetched from `https://preview.tabler.io/settings.html`; it reports v1.7.1. The public deployment does not expose its exact commit, so its own content digest is the authoritative compiled-page identity. Tagged Astro source is separately retained under `sources/`.
- All required styles and scripts are local under `app/dist`; the original demo CSS is local. No installation or remote account is needed.
- Preparation changed product copy, connected a local settings service, removed the advertising script and portrait dependencies, retained the native avatar initials fallback, and composed the notification control from the same existing Tabler switch markup. The unchanged system source remains the visual foundation.
- Upstream gallery navigation outside this settings page is peripheral source context; those gallery routes are not part of the runnable product contract. Do not expand the task to implement the gallery.

## Authoritative behavior

`app/settings-store.js` owns validation, persistence and save results. `app/settings-controller.js` binds the current page. The browser key is `fieldnotes-settings-v1`, schema version 1. `readSettings()` reads real browser storage, and `saveSettings(draft)` commits the captured draft only after its 750 ms delay succeeds. Failed saves preserve the draft and previously stored value. `subscribeSettings(listener)` emits `invalid`, `pending`, `success`, or `error` facts. Do not replace persistence with a visual simulation or change the validation rules to make a check pass.

The data fields are display name (required, at most 100 characters), organization (at most 180), location (at most 100), syntactically valid email, weekly digest, and public-profile visibility. Email remains private. Profile visibility has no effect on email disclosure. All content is synthetic, and no user information is transmitted. The initial values include `Mei Lin · 林玫`, `Fieldnotes Research / 城市日常研究小组`, and `Singapore / 新加坡`.

Use `?fail=once` on a fresh page load to make the next otherwise valid save fail. A retry in the same session succeeds. `window.fieldnotes.setFailureMode(true)` sets the same control without navigation. Failure remains an explicit fixture of the local service; no real remote outage is implied. Cancel restores the last persisted settings. Check the distinction between a submitted snapshot and edits made while it is pending.

## Content and conditions

Inspect English and Simplified Chinese, light and dark, at 1440×900 and 1280×600. Include a 390×844 narrow check of the same settings path. Use both a short name and `跨城市田野研究协作小组 — Longitudinal everyday-mobility research programme` as long representative content. Keep actual entered values visible and editable. The existing theme and language controls are fixture controls using native Tabler buttons; polish their hierarchy within the existing family where useful.

Start with `/?theme=light&lang=en` or `/?theme=dark&lang=zh`. Use the same task content and conditions in every paired run. Keyboard-only editing, saving, error recovery, focus visibility, scrolling at compact height, reload, and return are part of the requested path. The initial implementation has basic real status feedback; its full field association, state presentation, content coherence and compact-height quality remain work for the participant.

## Run and scope

From `app/` run:

```bash
python3 -m http.server 4111 --bind 127.0.0.1
```

Open `http://127.0.0.1:4111/`. Change the port only to avoid another study instance. No build is required. `package.json` also provides `npm run dev` for convenience.

Normal editable product files are `index.html`, `settings-controller.js`, and any justified source-preserving adapters. Preserve the authoritative store contract and upstream license. Retain acquired source notices with any additional adopted resources. Avoid editing minified distribution files; use supported classes, configuration and source components. Deliver the integrated application, actual adopted sources, useful observation evidence and remaining limitations. Starter-readiness evidence does not establish participant completion.
