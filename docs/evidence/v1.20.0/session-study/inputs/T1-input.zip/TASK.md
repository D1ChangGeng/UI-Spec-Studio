# T1 — coherent settings under a mature system

Improve the supplied settings application for a bilingual knowledge-work product. Keep its established task model and authoritative settings behavior. The supplied INPUT.md identifies the selected mature system, starter revision, content, error behavior, permitted changes and preview command.

Make profile, notification and privacy controls coherent in hierarchy, type, surfaces, real validation/pending/success/failure states, keyboard focus and narrow-height use. Preserve an already adequate mature family rather than introducing decorative replacements. Use authorized source-supported configuration/composition. No original visual construction is authorized.

Use representative short/long Chinese and English content and both declared themes. Validate the user path through editing, saving, failure, retry and return. Study actual demos and current renders where a consequential gap exists. Do not expand a straightforward verified change into an unnecessary research campaign. Retain the main Agent's visual judgment and unresolved quality. Deliver the integrated product, actual adopted sources, relevant evidence and observed limitations.
