# T2 input — Meridian conversation workspace

## Product and requested increment

Meridian helps a researcher ask a question, read a long unfolding answer, attach local filenames, revisit earlier paragraphs and continue a thread. Improve the coupled relationship between the composer, attachment disclosure, answer reading space and user-controlled reading position. The exact original assignment is in `TASK.md`.

The baseline is the complete assistant-ui cloud-template workspace with its actual styled Thread, ThreadListSidebar, composer, attachment UI, message actions and native behavior. A local deterministic adapter replaces the cloud transport. This is a real mature interface implementation with synthetic responses, not a real model service. Its source, core components and license are supplied for direct inspection.

## Sources and preparation boundary

- Repository: `https://github.com/assistant-ui/assistant-ui`.
- Exact source revision: `ff654d8156680b839774296ef644b57ab1078425`, MIT.
- Original application composition: `templates/cloud/app/assistant.tsx`.
- Every copied mature component and its original path/digest is listed in `SOURCE-MANIFEST.json`. The component files under `app/src/components/`, hooks and utility were copied without code changes. Source-provided CSS is preserved except for its Tailwind discovery path. The original Inter/IBM Plex Mono font configuration is self-hosted; pinned font source and OFL notices are recorded in `FONT-SOURCES.json`.
- Preparation replaces the Next/cloud shell with a standalone Vite shell, changes only the breadcrumb copy, supplies representative initial conversation data, and implements a filename-only local attachment adapter. The full thread/sidebar/composer UI is upstream code.
- `app/package-lock.json` freezes dependencies. `app/LICENSE` preserves the upstream notice. The checked-in `dist/` build is a quick runnable initial artifact; rebuild after source edits.

The current source already solves many interaction problems. Research should establish which consequential properties are adequate and where another mature product or independently authored implementation can improve the requested experience. Do not replace the mature family merely to produce different code. No general original-construction permission is granted.

## State and synthetic response contract

`app/src/synthetic.ts` owns fixed synthetic content and the model/attachment adapters. It makes no network calls. `useLocalRuntime` and assistant-ui own conversation, composer, message status, abort and reading behavior. The supplied runtime keeps thread state in memory; reload returns to the seeded conversation. Persistent remote history, real file upload and real language-model output are outside the task.

- Every ordinary question yields the same long local example, delivered in 72-character chunks about 60 ms apart. The response begins with an explicit synthetic-response disclosure.
- Include `[fail]` in a question to fail that question's first response after partial text. Retrying that same question during the session succeeds. This gives a stable failure/retry path.
- Stop must abort future chunks. New questions, editing, retry and return should remain operable through the source runtime.
- Attachments accept local files but retain only filename/type metadata. Their contents are never read or transmitted. The attachment UI receives the real selected filename; its current compact tiles and hover disclosure remain a concrete area to inspect with long filenames and multiple files.

Keep these state boundaries intact. Participants may repair adapter defects if discovered, but must not remove failure, shorten the long response, hide attachments or force scrolling as a shortcut to satisfying the experience.

## Representative conditions

Inspect at 1440×900 and 1280×600, with a supplementary 390×844 check. Run both light and dark. `/?theme=dark&lang=zh` selects dark mode and Chinese seeded response text; `/?theme=light&lang=en` selects the English condition. Baseline upstream action labels remain English even in the Chinese content condition; localized labeling where needed is within the product increment. Both conditions contain actual Chinese/English text, not empty rectangles.

Use a one-line question; a six-line question; a long mixed-language question; one short filename and several long filenames such as `城市出行访谈摘要_2026-10-31_final-revised-notes.txt`; and responses long enough to scroll. Observe manual scroll-away while content grows, return to latest, cancel, failure/retry, keyboard focus, and repeat-question continuity. Keep the composer and reading relationships together in the same formal SPEC.

## Run

For an unchanged initial build:

```bash
cd app
python3 -m http.server 4112 --bind 127.0.0.1 --directory dist
```

For development:

```bash
cd app
npm ci --ignore-scripts --no-audit --no-fund
npm run dev -- --host 127.0.0.1 --port 4112
```

Build with `npm run build`. The study host may provision the same dependency cache to all copies; the lockfile remains authoritative. No account, token, server API or external model cost is required. Keep source provenance, actual observations, adopted resources and unresolved gaps with the result. A successful build or initial screenshot establishes only that boundary.
