# T2 — conversation composer and reading continuity

Improve the supplied desktop conversation workspace around one cohesive experience: growing input, attachment disclosure, streaming answers and user-controlled reading position. INPUT.md identifies the starter, synthetic-response controls (not a real model service), viewport/theme/locale targets and preview.

Research mature products and independently authored implementations, not only generic input primitives. Observe full spatial relationships and meaningful episodes. High visual completeness in the input surface, typography, action hierarchy and continuity matters alongside behavior. Track design references separately from usable implementations. If an exceptional reference lacks code, preserve it honestly without reconstructing it from scratch.

Handle single/multi-line input, attachment growth, send/cancel, long responses, manual scrolling while content grows, compact height, keyboard focus and return. Keep coupled relationships in this formal SPEC even if multiple research tasks are delegated. Realize the chosen mature resources in the starter and inspect their defining qualities in context. No general original-construction permission is granted. Keep evidence of actual observation, candidate differences, adoption and unresolved gaps.
