import type { AttachmentAdapter, ChatModelAdapter, ThreadMessageLike } from '@assistant-ui/react';

// Application data/response adapter, not a model service. No network calls.
const zh = new URLSearchParams(location.search).get('lang') === 'zh';
const paragraph = zh
  ? '现场记录提示我们把观察、解释和待验证的问题分开。阅读者会在长回答中回看来源、比较不同时间段，并继续补充问题。保留当前位置比强行跟随最新文字更重要；只有使用者选择回到底部时，才应重新跟随新增内容。以上内容是固定的合成示例，不是访谈结果，也不代表真实研究结论。'
  : 'The field notes separate what was observed, how the team interpreted it, and what still needs verification. Readers return to earlier passages, compare time periods, and add follow-up questions while a response is still arriving. Their chosen reading position should remain stable until they explicitly return to the latest content. This is fixed synthetic demonstration text, not interview evidence or a real research conclusion.';
const longResponse = [
  zh ? '# 综合研究笔记\n\n本地合成回答 · 未连接模型服务。' : '# Research synthesis\n\nLocal synthetic response · No model service is connected.',
  ...Array.from({length: 7},(_,i)=>`${zh ? '## 观察主题' : '## Observation theme'} ${i+1}\n\n${paragraph}\n\n${paragraph}\n\n- ${zh ? '核对原始语境和观察日期。' : 'Recheck the original context and observation date.'}\n- ${zh ? '保留尚未解决的分歧。' : 'Keep unresolved differences visible.'}`),
].join('\n\n');
const failures = new Set<string>();
export const syntheticModel: ChatModelAdapter = {
  async *run({messages, abortSignal}) {
    const user = [...messages].reverse().find(m=>m.role==='user');
    const query = user?.content.filter(p=>p.type==='text').map(p=>(p as {text:string}).text).join(' ') || '';
    const shouldFail = /\[fail\]/i.test(query) && !failures.has(query);
    for(let end=0; end<longResponse.length; end+=72){
      if(abortSignal.aborted) return;
      await new Promise<void>(resolve=>setTimeout(resolve,60));
      if(abortSignal.aborted) return;
      if(shouldFail && end>=432){ failures.add(query); throw new Error(zh ? '合成服务暂时不可用。重试会继续使用本地示例。' : 'The synthetic response failed once. Retry uses the same local example.'); }
      yield {content:[{type:'text',text:longResponse.slice(0,end+72)}]};
    }
  },
};

// File contents are never read or sent. The mature attachment UI receives metadata.
export const filenameAttachments: AttachmentAdapter = {
  accept:'*',
  async add({file}) { return {id:crypto.randomUUID(),type:'document',name:file.name,contentType:file.type || 'application/octet-stream',file,status:{type:'requires-action',reason:'composer-send'}}; },
  async remove(){},
  async send(attachment){ return {...attachment,status:{type:'complete'},content:[{type:'text',text:`[Local attachment filename: ${attachment.name}; contents not read]`}]}; },
};

export const initialMessages: readonly ThreadMessageLike[] = [
  {role:'user',content:zh ? '请比较研究资料中的可达性、阅读连续性和协作记录三个主题。保留事实与解释的区别。' : 'Compare accessibility, reading continuity, and collaborative notes. Keep observations distinct from interpretation.'},
  {role:'assistant',content:(zh ? '## 研究材料的阅读路径\n\n' : '## A reading path through the research\n\n')+paragraph+'\n\n'+paragraph+'\n\n'+(zh ? '### 下一步\n\n可以继续提问、添加本地文件名，或在回答生成时返回此前内容。' : '### Next step\n\nAsk a follow-up, attach a local filename, or revisit an earlier passage while a new response arrives.')},
];
