# Work allocation



Work package: `/workspace/scratch/708e8b7f118e/ui-study/worksets/w11`. Use a unique local port, suggested 4411.

The main agent retains the complete product goal, all final design choices and assembled-product inspection.

Keep primary implementation in the main agent except for the explicitly assigned settled integration scope.

Delegate the substantive research inquiry in `RESEARCH-PROMPT.md` to one fresh independent child using `collaboration.spawn_agent` with `fork_turns: "none"`. Send the file contents exactly. You may send a focused follow-up within that same inquiry if actual evidence requires it. Do not delegate product code changes. Inspect the important returned evidence yourself and make the design choice.

Leave the child model and reasoning effort unspecified so the session defaults are inherited.

Use at most one live child at a time and at most two children overall. Keep the substantive work bounded to 30 minutes; if a genuine blocker or quality gap remains, preserve it honestly instead of claiming completion.

Save child coordination exports and the child report references in `DELEGATION.json` if any child is used. The exact schemas can be simple: retain original tool requests/results rather than creating native-looking events.

Keep normal source and role instructions unchanged. Save actual product changes, captured observations and FINAL.md.
