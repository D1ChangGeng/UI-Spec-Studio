# T3 input — Fieldnotes research workspace

## Supplied application and authority

The app is the genuine **TiddlyWiki 5.4.1** native client–server application. Its complete upstream npm distribution is retained under `app/vendor/tiddlywiki/`; its Vanilla and Snow White themes supply the initial page, sidebar, story river, editor, controls and typography. `app/wiki/` uses the upstream server edition with the native tiddlyweb and filesystem plugins. This is an existing mature product populated for the study, not a newly drawn replacement interface.

Pinned upstream revision: `d391595836e2aead565480763f9bf9eb52e29e75`. Source: `https://github.com/TiddlyWiki/TiddlyWiki5`; release archive: `https://registry.npmjs.org/tiddlywiki/-/tiddlywiki-5.4.1.tgz`. `PROVENANCE.json` records archive integrity and file hashes; upstream license and notices are retained in full. Preparation added only content, supported configuration, and a launcher. No prior participant output or study conclusion is included.

## Product goal and audience

Fieldnotes serves a small bilingual research team moving between short observations, long interview synthesis, evidence tables and unfinished arguments. The immediate experience is **read a note, follow a related note, edit a passage, save it, and return without losing the work or the meaning of the material**.

Give this populated workspace a distinctive, mature visual direction based on adoptable external work. Aim for an editorial research studio with a recognisable point of view: strong but useful composition, intentional type relationships, material or colour that carries identity, and clear differences between navigation, reading and editing. The result should feel composed during ordinary work, including the long mixed-language interview, rather than only at an empty start screen. Calm reading is a requirement; visual restraint by itself is not the art direction. Compare materially different mature directions, including one that challenges the initial preference. No final palette, theme, asset or candidate has been selected for the participant.

The complete original task is in `TASK.md`. Preserve its separate responsibilities for experience validity and expressive completion.

## Content and working paths

Eight supplied notes contain synthetic field-research material about a fictional harbour district. They include short English observations, longer Chinese paragraphs, a mixed-language interview, a table, an unfinished draft, and cross-links. Their fictional status is disclosed in the index note. Preserve the notes' meaning, deliberate differences in length, related-note links, tables and unfinished status. Small copy corrections are allowed; shortening content merely to improve a screenshot is not.

The start state opens `Fieldnotes — project index` and `访谈笔记 — 傍晚通勤`. Use the native sidebar/search/tag navigation and the per-note pencil/checkmark controls for the core path. Important tasks:

1. Read the complete interview, inspect `Evidence ledger`, and return to the interview.
2. Edit an English and a Chinese passage, save, and reload to confirm persistence.
3. Start and cancel an edit while preserving the existing note; continue to another note.
4. Find a note by search or tags and reach its editor with the keyboard.
5. Compare long reading and editing in both themes, compact height and narrow width.

## Authoritative data and state

The authoritative content belongs to TiddlyWiki's native wiki store. Browser edits are synchronized through the upstream tiddlyweb adaptor to the Node server, and the filesystem plugin writes `app/wiki/tiddlers/`. A save indicator or toast alone is not proof of persistence: the write and subsequent reload must agree. Do not replace this with fake success text, an unrelated localStorage store, or a remote service. Native drafts, tags, search, story navigation and pending/error recovery remain the same product contract. This is a local single-user workspace; there are no real research participants, model services, accounts or collaboration guarantees.

Stop the local server before editing tiddler files directly. TiddlyWiki's running store owns its current content; use browser editing while the server is active, or restart after source edits. Use a fresh copy of the starter for each run so saved notes and theme settings cannot leak between participants.

## Permitted design and code changes

Work inside `app/wiki/`. Add licensed themes/plugins or documented upstream-supported configuration there, and preserve the adopted source and notices. The existing distribution is available for inspection and source comparison. If a narrow source-preserving adaptation requires a copied upstream tiddler or theme file, keep its original identity and record the actual difference. Do not silently edit or relabel the complete vendored distribution.

A whole-workspace theme/layout, a source-supported editor treatment, and narrow composition/configuration changes are in scope when they serve the reading/editing/navigation experience. Keep the authoritative data model, supplied content, persistence boundary and native user tasks intact. New remote services, authentication, collaborative editing, an entirely different product model, and original visual substitutes are outside the request. No W1, W2 or W3 exception is authorized. There is no settled `INTEGRATION-DECISION.md` for this task.

All third-party imagery, fonts and visual mechanisms must have documented permitted rights. No additional image assets are required. The upstream package includes native themes/palettes as available mature sources, not a prescribed final selection. Assess any candidate at its actual reuse scope; a palette alone does not establish an expressive whole-product result.

## Run and observation conditions

Node 20 or newer is required. No package install, model key or network connection is needed to run the supplied application.

```bash
cd app
PORT=4313 ./start.sh
```

Open `http://127.0.0.1:4313/`. `npm start` uses the same default port. Use a task-specific port if another application is running. `npm run build` exports the upstream offline single-file variant to `wiki/output/index.html`; the server path is the authoritative study path.

Inspect at 1440×900, 1280×640 and 390×844, device scale factor 1. The frozen baseline uses native Vanilla light and native Nord dark; both are available through the native Control Panel → Appearance → Palette. The target result must include a coherent light and dark condition using its selected mature source. The initial interface language is English, with Simplified Chinese available via Control Panel → Basics → Language. Long English and Chinese note content is present in both UI language conditions. Use the same content, viewports and fonts across compared arms.

Inspect normal motion and the browser's `prefers-reduced-motion: reduce` condition. Any introduced motion must preserve a quiet way to read and edit. The common host supplies Noto Sans CJK SC using `FONTCONFIG_FILE=/tmp/ui-spec-fonts/fonts.conf`; the font is a host fixture rather than an adopted product asset.

## Preparation evidence and limits

`evidence/` contains a separate starter-readiness smoke and actual screenshots, not participant results. It checks the native edit/save/reload path using a disposable copy of the seed wiki so the frozen input remains unchanged. The baseline is a complete usable native product; the expressive direction and its source research remain participant work. Saved screenshots establish their stated static conditions, not natural-speed animation quality, broad accessibility acceptance or user preference.
