# T3 — expressive but usable research workspace

Give the supplied populated research-note workspace a distinctive, mature visual direction, based on adoptable external work. INPUT.md defines audience, explicit art goals, permitted assets/rights, realistic reading and input content, themes and operating conditions.

Investigate cross-domain composition, typography, surface/material, imagery or motion as valuable to the actual goal. Compare materially different mature directions, including a candidate that challenges the first preference. Visual simplicity is not an automatic goal; neither is gratuitous movement. Do not equate an animation engine or an imported icon library with a mature page foundation.

Trial defining assets and visual mechanisms with populated content. Preserve reading, editing, navigation, focus, quiet/reduced-motion states and bounded resource cost. Use mature-source configuration, supported composition and narrow source-preserving adaptation. No W1/W2/W3 exception is authorized unless INTEGRATION-DECISION.md explicitly contains its actual scope and user authority. Return a renderable working result with source provenance, representative real visual evidence, source-versus-product comparison and remaining limitations.
