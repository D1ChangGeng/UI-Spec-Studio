# Fieldnotes — TiddlyWiki 5.4.1

Run `PORT=4313 ./start.sh` from this directory, then open `http://127.0.0.1:4313/`. Node 20+ is required. There are no install-time dependencies.

The app retains the complete upstream TiddlyWiki distribution and native server edition. Edits made through the browser persist to `wiki/tiddlers/` through upstream tiddlyweb/filesystem plugins. Stop the server before editing files directly, then restart it. The content is synthetic bilingual research material.

Read `../INPUT.md` for the task, frozen conditions, scope and source responsibility. Upstream license: `vendor/tiddlywiki/license`. The server is bound to loopback for this local study.
