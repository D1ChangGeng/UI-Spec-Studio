# Settled integration decision — Tabler action-bearing save feedback

## Decision identity and authority

The experiment coordinator selected and personally inspected the acquired source rendering and the current settings application before freezing this input. The coordinator confirmed this source-preserving integration under the already authorized study preparation: retain the exact Tabler action-toast header/body/action-footer shell, native close behavior, typography, borders, shadow and spacing, and map it to the authoritative local save events. This is a settled experiment-design decision. It is not a claim of end-user aesthetic acceptance.

No W1, W2 or W3 original-construction exception is authorized. No source comparison or direction change remains delegated to the integrator.

## Actual selected resource

Use `sources/tabler-toast-cookies.html`, acquired from the original `https://preview.tabler.io/toasts.html`, plus the MIT Tabler 1.7.1 `shared/components/demo/Toast.astro` source already supplied. `SOURCE-MANIFEST.json` contains the exact tagged revision and SHA-256 identities of the deployed HTML and extracted block. The acquired deployed page reports 1.7.1 but does not advertise an exact deployment commit; preserve this limitation.

The source variant has a header with an avatar/identity slot, title, relative time and native close button; a compact body; and a separated action row containing one primary small button. It uses `role="status"`, polite announcements, `aria-atomic="true"`, and `data-bs-autohide="false"`. The source's cookie text and person portrait are sample content, not required design elements.

Use the already loaded matching Tabler assets and its bundled Bootstrap Toast implementation. Do not reimplement the surface, close mechanism, transition, focus ring or spacing in a new CSS system.

## Settled composition and placement

Preserve the header → body → separated action-row relationship, the source's standard width, padding, typography, border, shadow, button size and native close interaction. Replace the portrait with the same source avatar initials fallback `FN`; use `Fieldnotes` as the identity. No imagery or emoji is required.

Place the toast in a native utility-configured container, `toast-container position-fixed top-0 end-0 p-3`. This uses the existing Tabler/Bootstrap toast container and position utilities, keeping feedback outside form flow and away from the lower save controls. Preserve its source maximum width and responsive containment. Inspect the header/menu area and close control for reachability while feedback is visible. Do not invent a different notification rail or restyle this block.

Retain the current inline status slot as a concise non-duplicating form summary; assign announcements so the same result is not announced twice. A toast must not steal focus merely because a save completes. Failed or successful feedback remains until explicitly dismissed or replaced by a subsequent save event; automatic disappearance is outside the decision.

## Data and state owners

`app/settings-store.js` is read-only for this integration. It owns `fieldnotes-settings-v1`, schema version 1, validation, the 750 ms pending interval, snapshot persistence, and `invalid` / `pending` / `success` / `error` events. Its `subscribeSettings(listener)` event payloads are authoritative. `app/settings-controller.js` owns current form values and the save/cancel controls. The notification adapter owns only rendering of these events and invoking an explicitly requested retry.

`pending` includes `operationId` and `snapshot`; `success` includes saved `settings`, `savedAt` and `operationId`; `error` includes `snapshot`, `error` and `operationId`; `invalid` includes `fieldErrors` and the submitted `draft`. Successful storage writes, not timers or button clicks, authorize saved wording. Do not clear the user's fields, rewrite stored data from notification rendering, or replace a newer draft with an older saved snapshot.

## State/content/action mapping

| Authoritative state | Header/body content | Source action row | Focus and continuity |
| --- | --- | --- | --- |
| Pending | Saving changes / 正在保存更改; explain that the current submitted version is being saved locally | Hidden; no second submit | Keep focus and draft edits; mark the existing save operation pending |
| Success | Changes saved / 更改已保存; identify the actual browser-local boundary and saved time | Hidden | Announce once politely; preserve reading and form focus |
| Error | Save did not complete / 保存未完成; draft remains available / 草稿仍然保留 | Retry save / 重试保存 | Retry the failed snapshot through `saveSettings`; do not read an unrelated later draft silently |
| Invalid | Check profile fields / 请检查个人资料字段; name the actual first invalid field | Hidden | Associate existing field errors with fields and move focus only when necessary to recover from the user's rejected submit |

Native close dismisses only feedback. It never cancels a save, discards a draft or changes persistence. If the user explicitly activates Retry, keep the error context until the authoritative pending event arrives, then display that state. An error notification from an older operation must not overwrite a newer authoritative result. Preserve a route back to a sensible initiating control if a focused retry/close control disappears.

## Bounded edit surface

Allowed edits are `app/index.html` for the selected source container/block, `app/settings-controller.js` for subscriptions/focus/inline summary coordination, and a new `app/save-notification.js` adapter if useful. Preserve `settings-store.js`, `dist/`, `preview/`, the source-preview file, and unrelated navigation/theme controls. Copy license notices with the adopted block. No new dependency is needed. Any consequential store-contract ambiguity returns to the main agent rather than widening the integration.

## Required inspection

Inspect the original source rendering, then the actual assembled settings page in both declared themes and languages at 1440×900 and 1280×600; include the 390×844 containment check. Exercise valid save, pending edits, success, forced one-time failure, retry, invalid input, explicit close and return, with keyboard focus. Read back browser storage after successful save and after a failed write. Compare source shell retention with the integrated block and inspect neighboring header, settings controls and lower save action. Keep source inspection, behavior checks and whole-product judgment separate. Test success alone does not establish visual acceptance.
