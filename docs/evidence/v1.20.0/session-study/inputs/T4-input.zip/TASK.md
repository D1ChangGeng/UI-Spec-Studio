# T4 — bounded source integration with independent whole-product inspection

Implement only the already settled mature-resource decision in INTEGRATION-DECISION.md. The supplied document must identify actual source revision/variant/rights, preserved visual relationships, allowed files/shared contracts, data/state owners and required inspection conditions. An empty or hypothetical selection is not a valid experiment input.

Connect the chosen component/block to the existing real data/state contract, including error/retry and keyboard/focus behavior. Preserve composition, type, material, spacing and motion. Do not change art direction, choose another source or fill unresolved visual design with handwritten substitutes. Return consequential ambiguity to the main Agent.

In the delegated arm, let ui_integrator carry the bounded changes while the main Agent maintains design responsibility and independently inspects the source, assembled result and affected neighboring experience. In the main-only arm, perform the same scope directly. Compare code changes, source craft retention, merge/rework costs and actual behavior. Do not equate test success with final visual acceptance.
