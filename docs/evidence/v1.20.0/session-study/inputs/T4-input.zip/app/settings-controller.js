import { readSettings, saveSettings, subscribeSettings, setFailureMode } from './settings-store.js';

const ids = {displayName:'business-name',organization:'business-id',location:'location',email:'email',weeklyDigest:'weekly-digest',publicProfile:'public-profile'};
const status = document.querySelector('#save-status');
const save = document.querySelector('#save-settings');
const params = new URLSearchParams(location.search);
const zh = params.get('lang') === 'zh';
const copy = zh ? {idle:'更改仅保存在当前浏览器中。',pending:'正在保存…',success:'更改已保存到当前浏览器。',error:'保存未完成。草稿仍然保留，请重试。',invalid:'请检查个人资料字段。'} : {idle:'Changes are saved only in this browser.',pending:'Saving…',success:'Changes saved in this browser.',error:'Save did not complete. Your draft is preserved; try again.',invalid:'Check the profile fields.'};
function draft() { return Object.fromEntries(Object.entries(ids).map(([key,id])=>{const el=document.getElementById(id);return [key,el.type==='checkbox'?el.checked:el.value];})); }
function load() { const data=readSettings(); for(const [key,id] of Object.entries(ids)){const el=document.getElementById(id); if(el.type==='checkbox')el.checked=data[key];else el.value=data[key];} }
try { load(); status.textContent=copy.idle; } catch(error) { status.textContent=error.message; }
subscribeSettings(event=>{save.disabled=event.status==='pending';status.textContent=copy[event.status] || copy.idle;status.dataset.state=event.status;});
save.addEventListener('click',async()=>{try{await saveSettings(draft());}catch{}});
document.querySelector('#cancel-settings').addEventListener('click',()=>{try{load();status.textContent=copy.idle;}catch(error){status.textContent=error.message;}});
document.querySelector('#focus-email').addEventListener('click',()=>document.querySelector('#email').focus());
document.querySelector('#language-toggle').addEventListener('click',()=>{params.set('lang',zh?'en':'zh');location.search=params.toString();});
document.querySelector('#theme-toggle').addEventListener('click',()=>{const dark=document.documentElement.getAttribute('data-bs-theme')==='dark';document.documentElement.setAttribute('data-bs-theme',dark?'light':'dark');localStorage.setItem('tabler-theme',dark?'light':'dark');});
window.fieldnotes = { readSettings, saveSettings, setFailureMode, draft };
if (zh) {
  document.documentElement.lang='zh-CN';
  const dictionary={
    'Account Settings':'账户设置','My Account':'我的账户','Profile Details':'个人资料','Business Profile':'工作资料','Display name':'显示名称','Organization':'机构','Location':'地点','Email':'电子邮件','Edit email':'编辑邮箱','Notifications':'通知','My Notifications':'我的通知','Privacy':'隐私','Public profile':'公开个人资料','Save changes':'保存更改','Cancel':'取消','Switch theme':'切换主题','Business settings':'工作设置',
    'Receive a weekly digest of research notes shared with your workspace.':'每周接收工作区共享研究笔记的摘要。',
    'Weekly digest is enabled':'已开启每周摘要','Weekly digest is disabled':'已关闭每周摘要',
    'Allow other members of this research workspace to find your profile. Your email remains private.':'允许研究工作区的其他成员找到你的个人资料。电子邮箱仍为私密信息。',
    "You're currently visible":'当前可见',"You're currently invisible":'当前不可见',
    'This contact will be shown to others publicly, so choose it carefully.':'此邮箱用于工作区通知，不会显示在公开个人资料中。'
  };
  const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
  while(walker.nextNode()){const node=walker.currentNode;const source=node.textContent.trim();if(dictionary[source])node.textContent=node.textContent.replace(source,dictionary[source]);}
} else {
  for(const el of document.querySelectorAll('.card-subtitle')) if(el.textContent.trim()==='This contact will be shown to others publicly, so choose it carefully.') el.textContent='This email receives workspace notifications and stays private.';
}
