#!/usr/bin/env python3
import os, sys, json, shutil, subprocess, datetime, traceback, time, urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path("/workspace/scratch/5499118f5564/ui-study/independent-review")
PACK=Path("/workspace/scratch/5499118f5564/ui-study/review-pack/products")
OUT=ROOT/"evidence/behavior-001"
OUT.mkdir(parents=True,exist_ok=False)
CHROME="/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell"
os.environ["FONTCONFIG_FILE"]="/tmp/ui-spec-fonts/fonts.conf"
os.environ["PLAYWRIGHT_BROWSERS_PATH"]="/tmp/ui-spec-preview-browser"
LONG="跨城市田野研究协作小组 — Longitudinal everyday-mobility research programme"
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
records=[]
def log(p, event, **details):
    obj={"at":now(),"product":p,"event":event,**details};records.append(obj)
    (OUT/"events.json").write_text(json.dumps(records,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps(obj,ensure_ascii=False),flush=True)
def snap(page,p,name):
    path=OUT/f"{p}-{name}.png";page.screenshot(path=str(path))
    log(p,"screenshot",name=name,path=str(path),viewport=page.viewport_size)
def state(page):
    return page.evaluate("""() => ({status:document.querySelector('#save-status')?.textContent,state:document.querySelector('#save-status')?.dataset.state,active:document.activeElement?.id,activeTag:document.activeElement?.tagName,draft:window.fieldnotes?.draft(),stored:localStorage.getItem('fieldnotes-settings-v1'),invalid:[...document.querySelectorAll('[aria-invalid=true]')].map(e=>({id:e.id,describedby:e.getAttribute('aria-describedby')})),horizontalOverflow:document.documentElement.scrollWidth>innerWidth,theme:document.documentElement.dataset.bsTheme,lang:document.documentElement.lang})""")
servers=[]
try:
  for p in ["P03","P06","P16","P09","P10"]:
    dest=ROOT/"disposable"/p/"app"
    shutil.copytree(PACK/p/"app",dest,dirs_exist_ok=False)
    port=4600+int(p[1:]);serve=dest if p in ["P03","P06","P16"] else dest/"dist"
    stdout=(OUT/f"{p}-server-stdout.txt").open("wb");stderr=(OUT/f"{p}-server-stderr.txt").open("wb")
    proc=subprocess.Popen([sys.executable,"-m","http.server",str(port),"--bind","127.0.0.1","--directory",str(serve)],stdout=stdout,stderr=stderr,env=os.environ.copy())
    servers.append((p,proc,stdout,stderr))
    for _ in range(50):
      try:
        urllib.request.urlopen(f"http://127.0.0.1:{port}/",timeout=0.2).close();break
      except Exception:
        if proc.poll() is not None:raise RuntimeError(f"{p} server exited {proc.returncode}")
        time.sleep(0.1)
    log(p,"server_started",port=port,pid=proc.pid,disposable=str(dest),command=[sys.executable,"-m","http.server",str(port),"--bind","127.0.0.1","--directory",str(serve)])
  with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path=CHROME,headless=True,args=["--no-sandbox"],env=os.environ.copy())
    log("COHORT","browser",version=browser.version,executable=CHROME,fontconfig=os.environ["FONTCONFIG_FILE"],playwright="1.57.0")
    for p in ["P03","P06","P16"]:
      context=browser.new_context(viewport={"width":1440,"height":900},device_scale_factor=1,locale="en-US")
      context.tracing.start(screenshots=True,snapshots=True,sources=True)
      page=context.new_page();page.set_default_timeout(10000)
      page.on("pageerror",lambda e,p=p:log(p,"pageerror",message=str(e)))
      page.on("dialog",lambda d,p=p:(log(p,"dialog",type=d.type,message=d.message),d.accept()))
      try:
        page.goto(f"http://127.0.0.1:{4600+int(p[1:])}/?theme=light&lang=en&fail=once",wait_until="networkidle")
        page.wait_for_function("window.fieldnotes !== undefined")
        snap(page,p,"initial-desktop-light");log(p,"initial",observation=state(page))
        page.set_viewport_size({"width":1280,"height":600})
        page.locator("#business-name").fill("")
        page.locator("#email").fill("incomplete")
        page.locator("#save-settings").focus();page.keyboard.press("Enter")
        page.wait_for_timeout(120)
        log(p,"invalid_submit",observation=state(page));snap(page,p,"invalid-compact")
        page.keyboard.type("Lin")
        page.locator("#email").fill("reviewer@example.invalid")
        page.locator("#save-settings").focus();page.keyboard.press("Enter")
        page.wait_for_timeout(100);log(p,"pending_first_save",observation=state(page))
        page.wait_for_timeout(850)
        log(p,"first_save_failure",observation=state(page));snap(page,p,"failure-compact")
        page.locator("#save-settings").focus();page.keyboard.press("Enter")
        page.wait_for_timeout(900)
        log(p,"retry_success",observation=state(page));snap(page,p,"retry-success-compact")
        page.locator("#business-name").fill(LONG);page.locator("#business-id").fill(LONG)
        page.locator("#save-settings").focus();page.keyboard.press("Enter")
        page.wait_for_timeout(70)
        page.locator("#location").fill("Newer unsaved location / 新编辑")
        log(p,"edited_while_pending",observation=state(page))
        page.wait_for_timeout(850)
        log(p,"snapshot_completed",observation=state(page));snap(page,p,"submitted-snapshot-with-new-edits")
        page.locator("#cancel-settings").click()
        log(p,"cancel_restore",observation=state(page))
        page.locator("#public-profile").check();page.locator("#weekly-digest").uncheck()
        page.locator("#save-settings").focus();page.keyboard.press("Enter");page.wait_for_timeout(900)
        log(p,"toggles_saved",observation=state(page))
        page.set_viewport_size({"width":390,"height":844})
        page.locator("#language-toggle").click();page.locator("#theme-toggle").click()
        page.evaluate("window.scrollTo(0,0)");page.wait_for_timeout(150)
        snap(page,p,"narrow-dark-zh-long-top")
        log(p,"narrow_dark_zh",observation=state(page),fields=page.locator("#business-name,#business-id,#email").evaluate_all("(els)=>els.map(e=>({id:e.id,tag:e.tagName,value:e.value,clientWidth:e.clientWidth,scrollWidth:e.scrollWidth,clientHeight:e.clientHeight,scrollHeight:e.scrollHeight,rect:e.getBoundingClientRect().toJSON()}))"))
        page.locator("#save-settings").scroll_into_view_if_needed();snap(page,p,"narrow-dark-bottom")
        toggle=page.locator("#settings-nav-toggle")
        if toggle.count():
          toggle.scroll_into_view_if_needed();toggle.click();page.wait_for_timeout(400)
        nav=page.locator("a[href='#notifications-heading']")
        if not nav.count():nav=page.locator("a[href='#notifications-section']")
        if nav.count() and nav.first.is_visible():
          nav.first.click();page.wait_for_timeout(450)
          log(p,"section_navigation",active=page.evaluate("({id:document.activeElement.id,tag:document.activeElement.tagName,scrollY:scrollY})"))
          snap(page,p,"narrow-section-navigation")
        page.reload(wait_until="networkidle");page.wait_for_function("window.fieldnotes !== undefined")
        log(p,"reload_persistence",observation=state(page))
      except Exception as e:
        log(p,"test_exception",message=str(e),traceback=traceback.format_exc())
        try:snap(page,p,"exception")
        except:pass
      finally:
        context.tracing.stop(path=str(OUT/f"{p}-trace.zip"));context.close()
    for p in ["P09","P10"]:
      context=browser.new_context(viewport={"width":1280,"height":600},device_scale_factor=1,locale="en-US")
      page=context.new_page();page.set_default_timeout(10000)
      try:
        page.goto(f"http://127.0.0.1:{4600+int(p[1:])}/?theme=light&lang=en",wait_until="networkidle")
        snap(page,p,"initial-compact")
        log(p,"dom_inventory",controls=page.locator("button,textarea,input").evaluate_all("(els)=>els.map(e=>({tag:e.tagName,text:e.textContent,label:e.getAttribute('aria-label'),type:e.getAttribute('type'),class:e.className,hidden:e.getAttribute('aria-hidden')}))"),scrollports=page.locator("[data-slot='aui_thread-viewport']").evaluate_all("(els)=>els.map(e=>({class:e.className,h:e.clientHeight,sh:e.scrollHeight,w:e.clientWidth,sw:e.scrollWidth,top:e.scrollTop}))"))
      except Exception as e:log(p,"test_exception",message=str(e),traceback=traceback.format_exc())
      finally:context.close()
    browser.close()
finally:
  for p,proc,stdout,stderr in servers:
    proc.terminate()
    try:proc.wait(timeout=5)
    except subprocess.TimeoutExpired:proc.kill();proc.wait()
    stdout.close();stderr.close();log(p,"server_stopped",pid=proc.pid,returncode=proc.returncode)

