# Condition-blind independent product review — cohort 01

Review date: 2026-11-01 (UTC). The exact freeze time and content hashes are recorded in the separate cohort freeze manifest.

Anonymous products: **P01, P03, P06, P09, P10, P13, P16, P18**.

This is an independent agent product and visual judgment made before receiving a condition mapping. It is not a release decision, a human acceptance vote, an assistive-technology study, or a mechanical certification. No comparator was repaired.

## Initial judgments

| Product | Task | Blind judgment | Main reason |
| --- | --- | --- | --- |
| P01 | T4 — bounded save-feedback integration | Satisfactory within the bounded integration scope | The selected Toast shell and authoritative snapshot/retry behavior are retained; inherited narrow-form limitations remain. |
| P03 | T1 — coherent settings | Satisfactory in the exercised scope, with minor limits | Clear form hierarchy, complete representative long values at narrow width, useful localized feedback, and working recovery/persistence. |
| P06 | T1 — coherent settings | Satisfactory in the exercised scope, with minor limits | Compact identity/header composition, useful local-save context, wrapping long fields, and working recovery/persistence. |
| P09 | T2 — composer and reading continuity | Satisfactory in the exercised scope, with minor limits | Useful filename disclosure and bounded composer growth; manual reading position and explicit return to the growing latest content worked. |
| P10 | T2 — composer and reading continuity | Revision required for full task acceptance | “Return to latest” visibly and measurably lagged behind the response throughout streaming. Its other core paths worked. |
| P13 | T3 — expressive research workspace | Core workflow and editorial direction supported; narrow-layout revision required for full scope | The adopted Notebook composition is coherent and native edits persist, but the evidence table causes page-level horizontal overflow at 390 px. |
| P16 | T1 — coherent settings | Core workflow supported; narrow and long-content completion requires revision | The navigation stack consumes much of the narrow opening view and representative long names/organizations remain horizontally clipped single-line fields. |
| P18 | T4 — bounded save-feedback integration | Satisfactory within the bounded integration scope | The selected Toast shell, failed-snapshot retry, newer-draft preservation, and explicit-close focus return worked. |

These judgments concern each product’s own task. T4 explicitly restricts changes to the settled feedback integration; its inherited form layout is not judged as though it had T1’s broader improvement mandate.

## Evidence and isolation

I personally opened original PNGs for every product with view_image, in batches of at most three images. The original-file lists and complete corresponding request/response exports are enumerated in products.json and the immutable cohort records. Those lists contain only files actually opened. Additional reviewer captures have separate additional_viewed_files and additional_view_exports lists; creating a screenshot did not make it viewed evidence.

I also opened fresh renderings of the supplied T1 settings foundation, T2 conversation foundation, T3 native wiki foundation, and the T4 selected action-toast source preview. Original captures may precede disclosed repairs, so consequential behavior was exercised against the frozen delivered application in a disposable copy. Fresh captures resolve current-state uncertainty without replacing the original evidence.

Isolation was **instructional on a shared host**, not enforced by a separate security sandbox. I did not inspect the coordinating repository, condition map, allocation/role records, producer judgments, release decisions, sibling worksets, or other reviewers’ results. Task documents and visible source choices necessarily reveal the task and visual differences. The supplied capture indexes contain producer-view flags; those were not used as a quality criterion. No condition membership was inferred or recorded.

### Runtime

- Playwright 1.57.0 through /tmp/ui-spec-validation-venv/bin/python.
- Headless Chromium 143.0.7499.4 at the prescribed executable path.
- FONTCONFIG_FILE=/tmp/ui-spec-fonts/fonts.conf and the prescribed browser path for every browser process; device scale factor 1.
- T1, T2 and T4: 1440 × 900, 1280 × 600, and 390 × 844 CSS pixels.
- T3: 1440 × 900, 1280 × 640, and 390 × 844 CSS pixels.
- Light/English and dark/Chinese settings and conversation conditions were exercised. T3 used Notebook Beige and Nord with bilingual note content; direct switching of the wiki’s UI language was not exercised.
- T3’s reduced-motion media preference was exercised. The observed targeted menu/dropdown animation names were none and transition durations were 0s. This is not a natural-speed playback assessment.
- Stateful settings, conversations and wiki tests used disposable copies. Wiki writes were made through the native browser editor and verified on disk and after reload. Only owned preview servers were started and stopped.

The default sandbox browser-launch failure is retained in command 007. Its declared local-application escalation succeeded in command 008. Early wiki locator failures are retained in commands 012, 016, 019 and 021; the successful follow-ups use the delivered controls’ actual labels and palette UI. Those locator errors are test failures, not product defects.

Each substantive shell command has its own wrapper directory with actual stdout, stderr, invocation, return status and timestamps. Complete tool returns were saved at call time, including full view_image return objects. The initial instruction bootstrap read preceded wrapper setup and remains in the conversation transcript; the instructions were subsequently captured through the wrapper in command 026. Raw outputs are separate from this report’s judgments and structured findings. Review records carry UTC timestamps; visible save-time wording follows application-browser formatting. Scripted relative timings use the local monotonic clock, not cross-runtime wall-clock subtraction.

### Main behavioral records

All paths below are under:

/workspace/scratch/e1cfe6e447ee/ui-study/independent-review-recovery/evidence/

| Record | Contents |
| --- | --- |
| behavior-settings-002/Pxx.json | Final-source core paths for P01, P03, P06, P16 and P18; actual values, storage, focus, status, long-field geometry, source checks and capture paths |
| behavior-conversations-001/Pxx.json | P09/P10 file disclosure, six-line composer, send, manual scroll-away, return, stop, failure/retry, repeat question and reload |
| behavior-conversation-followup-001/Pxx.json | Revisited return-to-latest and stop behavior, sampled Markdown content, focus and scroll state |
| behavior-return-latest-001/P10.json | P10 followed without further focus changes until response completion, then a second return action |
| behavior-wiki-003/P13.json | Native bilingual edit, actual file write, reload agreement, cancel and onward navigation |
| behavior-wiki-005/P13.json | Native palette selection, long reading, compact/narrow editing, reduced-motion menu and narrow evidence-table geometry |
| foundation-comparison-001/record.json | Actual source rendering conditions and unchanged existing Tabler asset checks |
| command-026-final-source-checks/ | Notebook MIT notice, comparison of supplied TiddlyWiki vendor files, and retained review instructions |

The evidence index records exact absolute paths and hashes. The reports do not treat assertion totals, screenshot totals, implementation size or delegation as evidence of product quality.

## Product findings

### P01 — bounded Tabler save feedback

**Observed pixels.** Original captures 010, 012 and 020 show the actual integration in a dark desktop failure state, a light compact failure state and a narrow light failure state. The toast retains the small identity header, time/close area, body and separated primary action row. The chosen shell looks like the source preview I opened: restrained border/shadow, compact typography and native blue action. The English failure copy wraps within the toast; the retry action remains legible. The dark form and feedback retain the source’s surface and type relationships.

The narrow screenshot also shows the cost of the settled placement: feedback covers part of the header/navigation area while the long settings navigation precedes the form. Fresh narrow inspection confirms that long profile values remain single-line fields, with a 656 px text scroll width inside a 330 px client width. These are relevant whole-product limitations, but the task expressly preserves that surrounding form and specifies the top-right toast placement.

**Exercised behavior.** A valid save stored the submitted snapshot while a subsequent location edit remained in the form. Cancel restored the persisted value. A forced failure preserved both prior storage and the failed draft. After a newer name was entered, activating Retry saved the failed snapshot, retained the newer form draft and left a concise unsaved-edits summary. The retry control’s disappearance returned focus to Save. Explicit close returned focus to Save and did not discard the draft. Rejected empty-name submission focused and marked the actual field. A later successful save survived reload.

**Source and judgment.** The authoritative store and existing dist/preview assets match the supplied foundation. The notification adapter uses the existing Toast implementation and operation IDs. The inspected integration is satisfactory for T4’s bounded scope. Full settings redesign, native assistive-technology announcements, exceptional browser-storage failures and all upstream gallery routes remain outside this judgment.

### P03 — coherent settings

**Observed pixels.** Original 089 shows a clear account/profile hierarchy with full-width display-name and organization fields; 090 shows representative long bilingual values wrapping over three lines in the dark narrow layout. The settings navigation collapses into a named control, allowing the form to appear early. Labels, required markers, length hints and private-email wording form a consistent hierarchy. Light error feedback has a distinct native alert treatment; the dark text, inputs and switches remain readable in the viewed material.

The identity unit provides a saved-name reference separate from editable fields. The full-width long fields use the same Tabler form surface rather than a competing component style. At 390 px, both inspected long fields had equal client and scroll widths of 330 px and fitted their text vertically. The footer still requires vertical scrolling, especially at compact height; this is a limitation of the long form, not an observed inability to reach or operate Save.

**Exercised behavior.** The review used actual Tab navigation from the page into the profile controls and onward to Save, then keyboard activation. Snapshot saving, later edits, failure, retry, cancel, field validation and reload worked. T1’s retry saved the currently edited form, consistent with its contract. Later field edits were not replaced by completion of the submitted snapshot. The disabled Save button briefly left document.activeElement at the body during pending, then regained focus after completion when no other control had taken it; later field focus was preserved.

**Source and judgment.** The store and existing distribution assets match the supplied source. The resizing textarea adaptation preserves the existing form family and materially improves the required representative content. Satisfactory in the exercised scope. No screen-reader, physical mobile-keyboard or exhaustive maximum-length/unbroken-token study was performed.

### P06 — coherent settings

**Observed pixels.** Original 033 shows long values and a visible native field focus ring in the dark desktop form; 079 shows the newer-edit/saved-snapshot distinction at narrow width; 083 shows a dark compact footer state with a visible Save focus treatment. Fresh desktop and narrow captures show a compact avatar/account heading with the browser-local persistence boundary beside it. Compared with the supplied foundation, the profile controls and hints read as a single useful form, and the language/theme controls occupy a secondary page-level position.

The narrow navigation collapses and the representative long name and organization wrap cleanly. Their measured client/scroll widths were both 330 px, and all three text lines remained visible. The header uses less vertical space than P03’s separate saved-name identity unit. P06’s error/status surface is more restrained than P03’s tinted alert: the wording remains clear, but its visual emphasis is lower.

**Exercised behavior.** The same actual Tab-to-edit/save path, pending edit, failed save, current-draft retry, cancel, invalid-name recovery and reload path completed. Storage retained the submitted snapshot; a later location edit remained available; a failed write left the prior value intact. Initiating focus returned after pending completion, and invalid submission identified and focused the real name field. There were no page errors in this run.

**Source and judgment.** The store and existing mature distribution assets match the foundation. This is a source-coherent improvement, not a replacement visual system. Satisfactory for the exercised T1 scope. Vertical scrolling remains necessary, and the review does not establish assistive-technology announcement quality, storage-quota recovery or all possible content extremes.

### P09 — conversation composer and reading continuity

**Observed pixels.** Original 045, 049 and 040 cover dark desktop, narrow light and compact dark composer states with multiple filenames and a six-line question. The source reading column, type hierarchy, sidebar and input surface remain coherent. The adopted chips use a compact wrapped arrangement. At narrow width the attachment region scrolls vertically; it does not show every filename simultaneously.

Fresh keyboard disclosure of the last narrow chip produced a fully readable tooltip containing the whole long filename and the filename-only boundary. The tooltip stays near the composer and leaves much of the reading context visible. Six input lines remain usable at 1280 × 600, although the expanded composer necessarily reduces visible answer space. Failure is presented beside the partial answer in the existing alert family, with native message actions below it.

**Exercised behavior.** File removal returned focus to the composer. A user wheel scroll-away remained at scrollTop 10 while content height grew from 1298 to 1620 px. Explicit Return to latest reached the bottom and remained at zero bottom gap throughout the revisited 1.5-second sampling interval. Stop settled the response and returned focus to the input. A forced partial-response failure retried to the complete long example, including its final theme. A subsequent question remained operable, and reload returned to the seeded in-memory boundary.

**Source and judgment.** The synthetic adapter is unchanged. The thread’s existing primitive is configured for bottom anchoring, and Return to latest uses the source-supported instant behavior. The filename chip is a selective adoption from the same assistant-ui source family. Satisfactory in the exercised scope. The error action is still an icon with “Regenerate response” terminology, and attachment overflow relies on users exploring a bounded region; neither invalidated the exercised path. Real uploads, remote history and live model output are not part of this product.

### P10 — conversation composer and reading continuity

**Observed pixels.** Original 021, 032 and 039 cover a dark desktop disclosure, a narrow light reading state and a compact streaming/composer state. The mature workspace is retained. Horizontal File cards give individual attachments a clear frame and separate removal control. The fresh light and dark dialogs disclose a complete long filename, a clear filename-only explanation and an evident close action. Long filenames sometimes break at an awkward final character or extension, but remain readable.

The dialog intentionally obscures the surrounding workspace. This is a heavier interaction than P09’s local tooltip, but it is coherent with the source Dialog family and worked with Escape. The horizontal attachment strip preserves more vertical reading room while showing only a subset of cards at once.

**Exercised behavior and defect.** File disclosure/removal, focus return, send, manual scroll-away, partial failure/retry, repeat question and reload worked. Manual reading position stayed at scrollTop 37 as content height increased from 1325 to 1647 px.

Return to latest did not fulfill its purpose during growth. In the follow-up, an actual click left a 653 px bottom gap; the gap grew to 1144 px after about 1.5 seconds. The personally viewed capture still shows earlier content and the return control. A separate run continued without another focus action: the bottom gap was 1145 px at 1.51 seconds and 2134 px when generation first became non-running at 5.05 seconds. After another 600 ms, 798 px remained. A second explicit return click after completion reached zero gap. This is a material continuity defect in the requested condition, not merely a screenshot-selection issue.

An earlier broad stop check returned false because visible body text changed after the control stopped running. The narrower follow-up retained that failure and clarified it: final Markdown text settled, the running control disappeared and composer focus returned. P10’s visible rendering continued to settle for roughly a second; the source uses deferred Markdown rendering. I do not classify that first check as evidence that new synthetic chunks continued indefinitely. Source inspection suggests smooth scrolling during repeated content growth as a contributor to the return defect; that is an inference, not a proven causal diagnosis.

**Judgment.** Full T2 acceptance requires revision of Return to latest and another retained growth/scroll-away/return check. Do not repair this frozen comparator or erase the original observations. No general condition-level or methodology claim follows from this product difference.

### P13 — expressive research workspace

**Observed pixels and direction.** Original 007/008, 015/016 and 018 show long reading in light and dark, narrow reading, and the project index. Compared with the personally viewed Vanilla foundation, the Notebook theme creates a materially different composition: a centered paper-like reading surface, restrained cream surroundings, purple links in light mode, generous heading/body relationships and a compact toolbar. Nord preserves the note hierarchy in dark mode. This is a recognizable editorial direction based on an actual whole-workspace theme, not a palette or icon import alone. Its identity is strongest in reading; the native wikitext editor is visibly denser, and its dark toolbar symbols have subdued contrast.

Fresh compact and narrow editor captures preserve bilingual content, tag controls, formatting tools and a visible field focus treatment. The narrow menu provides an orderly separate navigation view. Under reduced motion, targeted menu/dropdown styles report no animation and zero-duration transitions; no motion-quality claim is made beyond that observation.

**Exercised native workflow.** Native search and related-note navigation reached the long interview and Evidence ledger, then returned. English and Chinese passages were edited through the actual body editor and confirmed through the native checkmark. The resulting text agreed in the native wiki store, an actual tiddler file and a subsequent reload. A later edit was discarded and the saved content remained intact. Navigation continued to the unfinished working draft. Palette changes were made through the native Control Panel’s observed palette labels. Early assumptions about control labels/selectors failed; those attempts and successful corrections remain in the evidence.

**Narrow-layout defect.** At 390 × 844, the Evidence ledger table is 440.36 px wide and begins at x = 15, putting its right edge at approximately x = 455.36. The document reports horizontal overflow. The viewed frame clips the “Does not establish” column, which carries an important limitation on the evidence. I do not claim its content is permanently unreachable, since horizontal-panning recovery was not exercised, but the narrow presentation is incomplete and lacks an evident local scrolling cue in the inspected frame.

**Source and judgment.** Notebook 1.4.1 identifies its actual upstream source and retains the MIT notice; the supplied TiddlyWiki vendor files match the foundation. Supported theme settings and narrow compatibility adapters remain inside the native product model. The core workflow and editorial direction are supported. Full narrow-layout acceptance requires revision of the table treatment, with meaning and content preserved. Direct Chinese UI-language switching, server outage recovery, broad accessibility and all native editor tools remain unverified.

### P16 — coherent settings

**Observed pixels.** Original 092 shows a legible required-name error in the desktop form, 094 the narrow dark invalid state, and 091 the compact dark pending footer. The form retains the mature typography, surfaces, validation family, switches and primary action hierarchy. The explicit local-save boundary and field error wording are useful.

Its narrow and long-content handling remains substantially less complete than P03/P06 for the same task. The fresh 390 px view retains full vertical settings navigation before the form; the first name field lies around y = 760 and the organization field below the viewport. The representative long name and organization remain single-line inputs with a 656 px text scroll width inside 330 px client widths. The viewed name shows only the trailing portion, so the actual complete value is not readable in one form view. The original narrow invalid capture also clips the email value beside the separate Edit email action.

The off privacy switch’s wording, “Keep my profile hidden,” is an imperative rather than a simple positive setting label. In my judgment that makes the switch’s state/action relationship less immediate; this is a semantic critique, not an observed human error.

**Exercised behavior.** The actual edit/save/pending-edit/failure/retry/cancel/invalid/reload path worked. Prior persisted values survived failure, later edits survived completion of a submitted snapshot, and validation focused the relevant field. The store and existing distribution assets match the foundation. There is no demonstrated core data-loss defect.

**Judgment.** The browser-local settings workflow is supported, but I would not treat the full T1 narrow/long-content goal as complete. Layout and long-field treatment require source-preserving revision for full scope. This finding should not be generalized to the narrower T4 integrations, whose edit authority differs.

### P18 — bounded Tabler save feedback

**Observed pixels.** Original 055 and 061 show coherent dark and light success states with the selected toast and native Save focus treatment. Original 047 shows field-associated invalid feedback at 390 px: the notification names the first invalid field while the form presents the actual name/email errors. The identity header, close control, body padding and source surface remain recognizable. The successful state hides the action row without replacing the source family.

Fresh narrow inspection confirms the same surrounding form limitations as P01: long single-line values and a large navigation stack. Top-right feedback overlaps upper content but remains contained, legible and explicitly dismissible. The placement is the settled task decision, rather than a new layout choice made by this reviewer.

**Exercised behavior.** Successful storage reflects the submitted snapshot, while newer edits remain in the form and are identified as unsaved. Forced failure preserved prior storage and the draft. Retry saved the failed snapshot even after a newer name was entered; it did not silently substitute the newer form state. The disappearing retry action and explicit close returned focus to Save. Empty-name validation focused and associated the real field. A subsequent successful short-name save persisted through reload.

**Source and judgment.** The authoritative store and matching existing Tabler assets remain unchanged. The inspected whole-product feedback integration is satisfactory within T4’s bounded scope. Visible success wording and saved time describe browser-local storage rather than a server guarantee. Broad storage-failure cases, assistive-technology announcement behavior and unrelated gallery navigation remain outside the observed scope.

## Within-task comparison and remaining scope

For T1, P03 and P06 offer the more complete representative long-content and narrow-form treatment in this cohort. P03 emphasizes saved identity and stronger colored status surfaces; P06 uses a more compact identity/local-save heading. Both preserve the same mature family. P16 has a working data path but retains more of the source’s narrow navigation and single-line content constraints.

For T2, P09’s compact disclosure preserves reading context; P10’s File/Dialog composition gives a clearer dedicated detail surface and a more explicit failed-response retry label. The decisive functional difference is Return to latest during growth: P09 followed the latest content in the tested condition, whereas P10 did not.

P01 and P18 both satisfy the observed bounded integration contract. They share inherited surrounding-form limitations and should not be ranked by the number of captures or tests. Small copy differences do not establish a material product-quality separation in this review.

Only one T3 product belongs to this cohort. P13 provides a coherent source-based editorial direction and verified native persistence, but its narrow evidence table requires attention. No within-T3 causal comparison is possible from this cohort alone.

The material unresolved items are P10’s streaming return behavior, P13’s narrow table layout and P16’s narrow/long-content completion. They remain possible grounds for limited acceptance or rejection in a separate later disposition. No repair or condition mapping has been incorporated into this blind report.

The initial report and cohort records are frozen. Later cohorts must be added separately, preserving these judgments verbatim. Any eventual condition disclosure, repair disposition or acceptance statement belongs in a new continuation.

