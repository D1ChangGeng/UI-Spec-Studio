import os,sys,json,time,subprocess,traceback
from pathlib import Path
from datetime import datetime,timezone
from urllib.request import urlopen
from playwright.sync_api import sync_playwright
ROOT=Path("/workspace/scratch/e1cfe6e447ee/ui-study/independent-review-recovery");OUT=ROOT/"evidence/behavior-conversation-followup-001";OUT.mkdir(parents=True,exist_ok=False)
ENV=dict(os.environ,FONTCONFIG_FILE="/tmp/ui-spec-fonts/fonts.conf",PLAYWRIGHT_BROWSERS_PATH="/tmp/ui-spec-preview-browser")
CHROME="/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell"
def now():return datetime.now(timezone.utc).isoformat()
def snap(page):
 return page.evaluate("""() => {const vp=document.querySelector('[data-slot="aui_thread-viewport"]'), md=[...document.querySelectorAll('.aui-md')].at(-1);return {at:performance.now(),running:!!document.querySelector('.aui-composer-cancel'),text:md?.textContent,innerText:md?.innerText,scroll:{top:vp.scrollTop,height:vp.scrollHeight,client:vp.clientHeight,gap:vp.scrollHeight-vp.clientHeight-vp.scrollTop},focus:{tag:document.activeElement?.tagName,label:document.activeElement?.getAttribute('aria-label'),class:document.activeElement?.className}}}""")
all_data=[]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=CHROME,headless=True,env=ENV,args=["--no-sandbox"])
 for i,pid in enumerate(["P09","P10"]):
  data={"product":pid,"started":now(),"browser":browser.version,"fontconfig":ENV["FONTCONFIG_FILE"],"trials":[]}
  app=ROOT/"copies/conversations-001"/pid/"app";port=4710+i
  log=open(OUT/(pid+"-server.log"),"w");server=subprocess.Popen([sys.executable,"-m","http.server",str(port),"--bind","127.0.0.1","--directory",str(app/"dist")],stdout=log,stderr=subprocess.STDOUT,env=ENV);context=None
  try:
   for _ in range(50):
    try:urlopen(f"http://127.0.0.1:{port}/",timeout=.5).close();break
    except Exception:time.sleep(.1)
   context=browser.new_context(viewport={"width":1280,"height":600},device_scale_factor=1)
   for mode in ["reading-return-keyboard-stop","direct-pointer-stop"]:
    page=context.new_page();page.goto(f"http://127.0.0.1:{port}/?theme=light&lang=en",wait_until="networkidle")
    page.locator(".aui-composer-input:visible").fill("Independent stop continuity follow-up / 研究")
    page.locator(".aui-composer-input:visible").press("Enter");page.locator(".aui-composer-cancel").wait_for();page.wait_for_timeout(700)
    trial={"mode":mode,"before":snap(page),"return_samples":[],"stop_samples":[]}
    if mode=="reading-return-keyboard-stop":
     vp=page.locator('[data-slot="aui_thread-viewport"]');b=vp.bounding_box();page.mouse.move(b["x"]+100,b["y"]+120);page.mouse.wheel(0,-700);page.wait_for_timeout(150)
     trial["away"]=snap(page);page.get_by_role("button",name="Return to latest",exact=True).click();start=time.monotonic()
     for delay in [0,100,200,300,400,500]:
      page.wait_for_timeout(delay);s=snap(page);s["elapsed_ms"]=(time.monotonic()-start)*1000;trial["return_samples"].append(s)
     page.screenshot(path=str(OUT/(pid+"-returned-1500ms.png")))
     page.locator(".aui-composer-cancel").focus();page.keyboard.press("Enter")
    else:page.locator(".aui-composer-cancel").click()
    start=time.monotonic()
    for delay in [0,100,150,250,500,1000]:
     page.wait_for_timeout(delay);s=snap(page);s["elapsed_ms"]=(time.monotonic()-start)*1000;trial["stop_samples"].append(s)
    page.screenshot(path=str(OUT/(pid+"-"+mode+"-stopped.png")))
    a,b=trial["stop_samples"][-2:];trial["stable_final_text"]=a["text"]==b["text"] and not b["running"];trial["final_focus_composer"]="aui-composer-input" in b["focus"]["class"]
    data["trials"].append(trial);page.close()
  except Exception:data["failure"]=traceback.format_exc()
  finally:
   if context:context.close()
   server.terminate();server.wait(timeout=5);log.close();data["server_stopped"]=now()
   (OUT/(pid+".json")).write_text(json.dumps(data,ensure_ascii=False,indent=2));all_data.append(data)
   print(json.dumps({"product":pid,"failure":data.get("failure"),"trials":[{"mode":t["mode"],"return_gaps":[(round(s["elapsed_ms"]),s["scroll"]["gap"]) for s in t["return_samples"]],"stop_lengths":[(round(s["elapsed_ms"]),len(s["text"] or ""),s["running"]) for s in t["stop_samples"]],"stable_final_text":t["stable_final_text"],"final_focus_composer":t["final_focus_composer"]} for t in data["trials"]]},ensure_ascii=False),flush=True)
 browser.close()

