import os, sys, json, time, shutil, subprocess, traceback, hashlib
from pathlib import Path
from datetime import datetime, timezone
from urllib.request import urlopen
from importlib.metadata import version
from playwright.sync_api import sync_playwright
ROOT=Path("/workspace/scratch/e1cfe6e447ee/ui-study/independent-review-recovery")
PACK=Path("/workspace/scratch/e1cfe6e447ee/ui-study/review-pack")
OUT=ROOT/"evidence/behavior-conversations-001"
OUT.mkdir(parents=True,exist_ok=False)
CHROME="/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell"
ENV=dict(os.environ,FONTCONFIG_FILE="/tmp/ui-spec-fonts/fonts.conf",PLAYWRIGHT_BROWSERS_PATH="/tmp/ui-spec-preview-browser")
FILES=["notes.txt","城市出行访谈摘要_2026-10-31_final-revised-notes.txt","accessibility-interview-analysis-final-notes-2026.txt","reading-continuity-fieldnotes-long-working-draft.txt"]
SIX="Please compare these materials.\nSeparate observations from interpretation.\n城市交通研究 notes\nKeep caveats visible.\nInclude seven themes.\nThen suggest next questions."
def now():return datetime.now(timezone.utc).isoformat()
def state(page):
 return page.evaluate("""() => {
 const vp=document.querySelector('[data-slot="aui_thread-viewport"]'), input=document.querySelector('.aui-composer-input'), composer=document.querySelector('.aui-composer-root'), rect=vp?.getBoundingClientRect(), cr=composer?.getBoundingClientRect();
 const visibleParagraphs=[...vp.querySelectorAll('p')].map(el=>({text:el.textContent,top:el.getBoundingClientRect().top,bottom:el.getBoundingClientRect().bottom})).filter(x=>x.bottom>rect.top && x.top<(cr?.top??rect.bottom)).slice(0,3);
 return {url:location.href,viewport:{width:innerWidth,height:innerHeight},scroll:vp?{top:vp.scrollTop,height:vp.scrollHeight,client:vp.clientHeight,rect:rect.toJSON()}:null,visibleParagraphs,composer:{text:input?.value,rect:cr?.toJSON(),inputHeight:input?.getBoundingClientRect().height},focus:{tag:document.activeElement?.tagName,label:document.activeElement?.getAttribute('aria-label'),role:document.activeElement?.getAttribute('role'),class:document.activeElement?.className},attachmentNames:[...document.querySelectorAll('.aui-attachment-root')].map(el=>el.innerText),attachmentStrip:[...document.querySelectorAll('.aui-composer-attachments')].map(el=>({scrollLeft:el.scrollLeft,scrollTop:el.scrollTop,scrollWidth:el.scrollWidth,clientWidth:el.clientWidth,scrollHeight:el.scrollHeight,clientHeight:el.clientHeight})),dialogs:[...document.querySelectorAll('[role="dialog"],[role="tooltip"]')].map(el=>({role:el.getAttribute('role'),text:el.textContent,rect:el.getBoundingClientRect().toJSON()})),errors:[...document.querySelectorAll('.aui-message-error-root')].map(el=>el.textContent),running:!!document.querySelector('.aui-composer-cancel'),bodyTextLength:document.body.innerText.length,bodyTextTail:document.body.innerText.slice(-1000),horizontalOverflow:document.documentElement.scrollWidth>innerWidth};
 }""")
def rec(data,name,page):
 data["steps"].append({"time":now(),"name":name,"observed":state(page)})
 (OUT/(data["product"]+".json")).write_text(json.dumps(data,ensure_ascii=False,indent=2))
def shot(data,name,page):
 path=OUT/(data["product"]+"-"+name+".png");page.screenshot(path=str(path));data["screenshots"].append({"name":name,"path":str(path),"time":now(),"viewport":page.viewport_size})
def files(page):
 with page.expect_file_chooser() as fc:
  page.locator(".aui-composer-add-attachment").click()
 fc.value.set_files([{"name":name,"mimeType":"text/plain","buffer":b"synthetic review fixture"} for name in FILES])
 page.wait_for_timeout(250)
def disclose(page,pid,name,zh=False):
 if pid=="P09":
  target=page.get_by_role("group",name=name,exact=True).last
  target.focus()
 else:
  target=page.get_by_role("button",name=("查看附件详情："+name if zh else "View attachment details: "+name),exact=True).last
  target.focus();page.keyboard.press("Enter")
 page.wait_for_timeout(450)
 return target
summary=[]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=CHROME,headless=True,env=ENV,args=["--no-sandbox"])
 for i,pid in enumerate(["P09","P10"]):
  data={"product":pid,"started":now(),"browser":browser.version,"playwright":version("playwright"),"device_scale_factor":1,"fontconfig":ENV["FONTCONFIG_FILE"],"steps":[],"screenshots":[],"checks":[],"console_errors":[]}
  app=ROOT/"copies/conversations-001"/pid/"app"
  shutil.copytree(PACK/"products"/pid/"app",app,ignore=shutil.ignore_patterns("node_modules"))
  data["source_checks"]={"synthetic_adapter_matches_foundation":(app/"src/synthetic.ts").read_bytes()==(PACK/"foundations/T2/app/src/synthetic.ts").read_bytes(),"dist_index_sha256":hashlib.sha256((app/"dist/index.html").read_bytes()).hexdigest()}
  data["tested_copy"]=str(app);port=4710+i
  log=open(OUT/(pid+"-server.log"),"w")
  server=subprocess.Popen([sys.executable,"-m","http.server",str(port),"--bind","127.0.0.1","--directory",str(app/"dist")],stdout=log,stderr=subprocess.STDOUT,env=ENV)
  data["server"]={"pid":server.pid,"port":port,"started":now()};context=None
  try:
   for _ in range(50):
    if server.poll() is not None:raise RuntimeError("Preview server exited")
    try:urlopen(f"http://127.0.0.1:{port}/",timeout=.5).close();break
    except Exception:time.sleep(.1)
   context=browser.new_context(viewport={"width":1440,"height":900},device_scale_factor=1)
   page=context.new_page();page.on("pageerror",lambda e:data["console_errors"].append(str(e)))
   page.goto(f"http://127.0.0.1:{port}/?theme=light&lang=en",wait_until="networkidle")
   input=page.locator(".aui-composer-input:visible");input.wait_for()
   rec(data,"initial-light",page);shot(data,"initial-light",page)
   files(page);input.fill(SIX)
   rec(data,"four-files-six-line",page);shot(data,"four-files-six-line",page)
   disclose(page,pid,FILES[1]);rec(data,"long-filename-keyboard-disclosure",page);shot(data,"filename-disclosure",page)
   data["checks"].append({"name":"full_filename_disclosed","pass":any(FILES[1] in x["text"] for x in state(page)["dialogs"])})
   page.keyboard.press("Escape");page.wait_for_timeout(300);rec(data,"disclosure-escape-focus",page)
   page.get_by_role("button",name="Remove notes.txt",exact=True).last.focus();page.keyboard.press("Enter");page.wait_for_timeout(150)
   rec(data,"remove-file-focus",page)
   data["checks"].append({"name":"remove_returns_to_composer","pass":page.evaluate("document.activeElement.classList.contains('aui-composer-input')")})
   page.set_viewport_size({"width":1280,"height":600});input.fill(SIX);shot(data,"compact-height-composer",page)
   input.press("Enter");page.locator(".aui-composer-cancel").wait_for();page.wait_for_timeout(350)
   rec(data,"stream-start",page)
   vp=page.locator('[data-slot="aui_thread-viewport"]');box=vp.bounding_box()
   page.mouse.move(box["x"]+100,box["y"]+120);page.mouse.wheel(0,-700);page.wait_for_timeout(140)
   a=state(page);rec(data,"manual-scroll-away",page)
   page.wait_for_timeout(650);b=state(page);rec(data,"content-grows-reading-position",page);shot(data,"stream-reading-away",page)
   data["checks"].append({"name":"manual_scroll_preserved_while_growing","pass":abs(b["scroll"]["top"]-a["scroll"]["top"])<5 and b["scroll"]["height"]>=a["scroll"]["height"],"before":a["scroll"],"after":b["scroll"]})
   page.get_by_role("button",name="Return to latest",exact=True).click();page.wait_for_timeout(300);rec(data,"explicit-return-latest",page)
   page.locator(".aui-composer-cancel").focus();page.keyboard.press("Enter");page.wait_for_timeout(100)
   rec(data,"stop-focus",page);s1=state(page);page.wait_for_timeout(400);s2=state(page)
   data["checks"].append({"name":"stop_aborts_growth_and_focus","pass":not s2["running"] and s1["bodyTextLength"]==s2["bodyTextLength"] and "aui-composer-input" in s2["focus"]["class"],"before_length":s1["bodyTextLength"],"after_length":s2["bodyTextLength"]})
   input.fill("[fail] Independent review recovery "+pid+" / 研究问题");input.press("Enter")
   page.locator(".aui-message-error-root").wait_for(state="visible",timeout=15000)
   rec(data,"forced-response-failure",page);shot(data,"forced-response-failure",page)
   retry_name="Regenerate response" if pid=="P09" else "Retry response"
   page.get_by_role("button",name=retry_name,exact=True).last.focus();page.keyboard.press("Enter")
   page.locator(".aui-composer-cancel").wait_for(state="visible")
   page.locator(".aui-composer-cancel").wait_for(state="hidden",timeout=20000);page.wait_for_timeout(200)
   rec(data,"retry-completed",page);shot(data,"retry-completed",page)
   data["checks"].append({"name":"retry_completes_long_response","pass":page.locator(".aui-message-error-root").count()==0 and "Observation theme 7" in page.locator("body").inner_text()})
   input.fill("One-line follow-up / 后续问题");input.press("Enter");page.locator(".aui-composer-cancel").wait_for();page.wait_for_timeout(180)
   page.locator(".aui-composer-cancel").click();rec(data,"repeat-question-and-stop",page)
   page.reload(wait_until="networkidle");rec(data,"reload-seeded-memory-boundary",page)
   data["checks"].append({"name":"reload_returns_to_seed","pass":"Independent review recovery" not in page.locator("body").inner_text()})
   page.set_viewport_size({"width":390,"height":844})
   page.goto(f"http://127.0.0.1:{port}/?theme=dark&lang=zh",wait_until="networkidle")
   files(page);page.locator(".aui-composer-input:visible").fill(SIX)
   rec(data,"narrow-dark-four-files-six-line",page);shot(data,"narrow-dark-composer",page)
   disclose(page,pid,FILES[-1],zh=True)
   rec(data,"narrow-last-file-keyboard-disclosure",page);shot(data,"narrow-last-file-disclosure",page)
   page.keyboard.press("Escape");page.wait_for_timeout(250)
   page.set_viewport_size({"width":1440,"height":900});page.locator(".aui-composer-input:visible").focus()
   rec(data,"dark-desktop-return",page);shot(data,"dark-desktop-composer",page)
   data["completed"]=now()
  except Exception:
   data["failure"]=traceback.format_exc();print(pid,data["failure"],flush=True)
  finally:
   if context:context.close()
   server.terminate()
   try:server.wait(timeout=5)
   except subprocess.TimeoutExpired:server.kill();server.wait()
   log.close();data["server"]["stopped"]=now();data["server"]["returncode"]=server.returncode
   (OUT/(pid+".json")).write_text(json.dumps(data,ensure_ascii=False,indent=2))
   summary.append({"product":pid,"checks":data["checks"],"failure":data.get("failure"),"console_errors":data["console_errors"],"evidence":str(OUT/(pid+".json"))})
   print(json.dumps(summary[-1],ensure_ascii=False),flush=True)
 browser.close()
(OUT/"summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2))

