import os,sys,json,time,subprocess,traceback
from pathlib import Path
from datetime import datetime,timezone
from urllib.request import urlopen
from playwright.sync_api import sync_playwright
ROOT=Path("/workspace/scratch/e1cfe6e447ee/ui-study/independent-review-recovery");OUT=ROOT/"evidence/behavior-return-latest-001";OUT.mkdir(parents=True,exist_ok=False)
ENV=dict(os.environ,FONTCONFIG_FILE="/tmp/ui-spec-fonts/fonts.conf",PLAYWRIGHT_BROWSERS_PATH="/tmp/ui-spec-preview-browser")
CHROME="/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell"
data={"product":"P10","started":datetime.now(timezone.utc).isoformat(),"samples":[]}
def snap(page):
 return page.evaluate("""()=>{const v=document.querySelector('[data-slot="aui_thread-viewport"]');return {at:performance.now(),running:!!document.querySelector('.aui-composer-cancel'),top:v.scrollTop,height:v.scrollHeight,client:v.clientHeight,gap:v.scrollHeight-v.clientHeight-v.scrollTop,focus:document.activeElement?.getAttribute('aria-label')}}""")
log=open(OUT/"P10-server.log","w");app=ROOT/"copies/conversations-001/P10/app"
server=subprocess.Popen([sys.executable,"-m","http.server","4711","--bind","127.0.0.1","--directory",str(app/"dist")],stdout=log,stderr=subprocess.STDOUT,env=ENV)
with sync_playwright() as p:
 browser=None
 try:
  for _ in range(50):
   try:urlopen("http://127.0.0.1:4711/",timeout=.5).close();break
   except Exception:time.sleep(.1)
  browser=p.chromium.launch(executable_path=CHROME,headless=True,env=ENV,args=["--no-sandbox"]);page=browser.new_page(viewport={"width":1280,"height":600},device_scale_factor=1)
  data["browser"]=browser.version;data["fontconfig"]=ENV["FONTCONFIG_FILE"]
  page.goto("http://127.0.0.1:4711/?theme=light&lang=en",wait_until="networkidle")
  input=page.locator(".aui-composer-input:visible");input.fill("Return to latest independent completion check");input.press("Enter")
  page.locator(".aui-composer-cancel").wait_for();page.wait_for_timeout(700)
  v=page.locator('[data-slot="aui_thread-viewport"]');b=v.bounding_box();page.mouse.move(b["x"]+100,b["y"]+120);page.mouse.wheel(0,-700);page.wait_for_timeout(150)
  data["before_click"]=snap(page);page.get_by_role("button",name="Return to latest",exact=True).click();start=time.monotonic()
  for _ in range(24):
   s=snap(page);s["elapsed_ms"]=(time.monotonic()-start)*1000;data["samples"].append(s)
   (OUT/"P10.json").write_text(json.dumps(data,indent=2))
   if not s["running"]:break
   page.wait_for_timeout(500)
  page.wait_for_timeout(600);data["after_completion"]=snap(page);page.screenshot(path=str(OUT/"P10-after-completion.png"))
  if page.get_by_role("button",name="Return to latest",exact=True).is_visible():
   page.get_by_role("button",name="Return to latest",exact=True).click();page.wait_for_timeout(1500)
   data["second_click_after_completion"]=snap(page);page.screenshot(path=str(OUT/"P10-second-click-after-completion.png"))
 except Exception:data["failure"]=traceback.format_exc()
 finally:
  if browser:browser.close()
  server.terminate();server.wait(timeout=5);log.close();data["server_stopped"]=datetime.now(timezone.utc).isoformat()
  (OUT/"P10.json").write_text(json.dumps(data,indent=2))
  print(json.dumps(data,indent=2),flush=True)

