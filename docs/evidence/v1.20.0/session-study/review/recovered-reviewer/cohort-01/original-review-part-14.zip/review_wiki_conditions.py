import os,sys,json,time,subprocess,traceback,re
from pathlib import Path
from datetime import datetime,timezone
from urllib.request import urlopen
from playwright.sync_api import sync_playwright
ROOT=Path("/workspace/scratch/e1cfe6e447ee/ui-study/independent-review-recovery");OUT=ROOT/"evidence/behavior-wiki-004";OUT.mkdir(parents=True,exist_ok=False)
ENV=dict(os.environ,FONTCONFIG_FILE="/tmp/ui-spec-fonts/fonts.conf",PLAYWRIGHT_BROWSERS_PATH="/tmp/ui-spec-preview-browser")
CHROME="/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell"
TITLE="访谈笔记 — 傍晚通勤";app=ROOT/"copies/wiki-003/P13/app"
def now():return datetime.now(timezone.utc).isoformat()
def state(page):
 return page.evaluate("""() => ({url:location.href,viewport:{width:innerWidth,height:innerHeight},palette:$tw.wiki.getTiddlerText('$:/palette'),language:$tw.wiki.getTiddlerText('$:/language'),story:$tw.wiki.getTiddlerList('$:/StoryList'),focus:{tag:document.activeElement?.tagName,label:document.activeElement?.getAttribute('aria-label'),title:document.activeElement?.getAttribute('title')},controls:[...document.querySelectorAll('button,[role="tab"]')].filter(e=>e.getBoundingClientRect().width).map(e=>({role:e.getAttribute('role'),label:e.getAttribute('aria-label'),title:e.getAttribute('title'),text:e.innerText})),selects:[...document.querySelectorAll('select')].map(e=>({value:e.value,options:[...e.options].map(o=>({value:o.value,text:o.textContent}))})),horizontalOverflow:document.documentElement.scrollWidth>innerWidth,scrollY,bodyText:document.body.innerText.slice(0,18000)})""")
data={"product":"P13","started":now(),"tested_copy":str(app),"steps":[],"screenshots":[],"checks":[]}
def rec(name,page):
 data["steps"].append({"time":now(),"name":name,"observed":state(page)});(OUT/"P13.json").write_text(json.dumps(data,ensure_ascii=False,indent=2))
def shot(name,page):
 path=OUT/("P13-"+name+".png");page.screenshot(path=str(path));data["screenshots"].append({"name":name,"path":str(path),"time":now(),"viewport":page.viewport_size})
def open_note(page,title):
 search=page.locator('input[type="search"]:visible').first;search.fill(title);page.wait_for_timeout(300)
 page.get_by_role("link",name=title,exact=True).last.click();page.wait_for_timeout(200);search.fill("");page.keyboard.press("Escape")
 return page.locator(".tc-tiddler-frame").filter(has=page.locator(".tc-titlebar").filter(has_text=title)).first
def control_panel(page):
 page.get_by_role("button",name="control panel",exact=True).first.click();page.wait_for_timeout(150);rec("control-panel",page)
def tab(page,text):
 page.locator("button").filter(has_text=re.compile("^"+re.escape(text)+"$")).last.click();page.wait_for_timeout(200)
def choose_palette(page,value):
 control_panel(page);tab(page,"Appearance");rec("appearance-ui",page)
 palette_tab=page.locator("button").filter(has_text=re.compile("^Palette$"))
 if palette_tab.count():palette_tab.last.click();page.wait_for_timeout(150)
 rec("palette-ui",page)
 page.locator("select").filter(has=page.locator('option[value="'+value+'"]')).first.select_option(value);page.wait_for_timeout(250)
def editor(page):
 for f in page.frames:
  for t in f.locator("textarea").all():
   if t.is_visible() and "A route remembered" in t.input_value():return t
 raise RuntimeError("No note body editor")
log=open(OUT/"P13-server.log","w");server=subprocess.Popen(["bash",str(app/"start.sh")],cwd=app,env=dict(ENV,PORT="4714"),stdout=log,stderr=subprocess.STDOUT)
data["server"]={"pid":server.pid,"port":4714,"started":now()}
with sync_playwright() as p:
 browser=None
 try:
  for _ in range(100):
   if server.poll() is not None:raise RuntimeError("Owned server exited")
   try:urlopen("http://127.0.0.1:4714/",timeout=.5).close();break
   except Exception:time.sleep(.1)
  browser=p.chromium.launch(executable_path=CHROME,headless=True,env=ENV,args=["--no-sandbox"])
  data["browser"]=browser.version;data["fontconfig"]=ENV["FONTCONFIG_FILE"];data["device_scale_factor"]=1
  page=browser.new_page(viewport={"width":1440,"height":900},device_scale_factor=1);page.set_default_timeout(8000)
  page.on("dialog",lambda d:d.accept())
  page.goto("http://127.0.0.1:4714/",wait_until="domcontentloaded");page.wait_for_function("window.$tw && $tw.wiki");page.wait_for_timeout(600)
  rec("resumed-verified-copy",page)
  choose_palette(page,"$:/palettes/Nord")
  frame=open_note(page,TITLE);frame.locator(".tc-titlebar").scroll_into_view_if_needed();rec("dark-reading",page);shot("dark-reading",page)
  page.set_viewport_size({"width":1280,"height":640});frame.locator(".tc-titlebar").scroll_into_view_if_needed();rec("dark-compact",page);shot("dark-compact",page)
  frame.get_by_role("button",name="Edit this tiddler",exact=True).click();page.wait_for_timeout(200)
  page.get_by_role("button",name="Confirm changes to this tiddler",exact=True).scroll_into_view_if_needed()
  rec("dark-editor",page);shot("dark-editor",page)
  page.set_viewport_size({"width":390,"height":844})
  page.get_by_role("button",name="Confirm changes to this tiddler",exact=True).scroll_into_view_if_needed()
  rec("narrow-dark-editor",page);shot("narrow-dark-editor",page)
  ta=editor(page);ta.focus();ta.press("Control+Home");rec("narrow-dark-editor-body",page);shot("narrow-dark-editor-body",page)
  page.get_by_role("button",name="Discard changes to this tiddler",exact=True).scroll_into_view_if_needed()
  page.get_by_role("button",name="Discard changes to this tiddler",exact=True).focus();page.keyboard.press("Enter");page.wait_for_timeout(200)
  frame=page.locator(".tc-tiddler-frame").filter(has=page.locator(".tc-titlebar").filter(has_text=TITLE)).first;frame.locator(".tc-titlebar").scroll_into_view_if_needed()
  rec("dark-narrow-reading",page);shot("dark-narrow-reading",page)
  page.emulate_media(reduced_motion="reduce")
  page.locator('button[title="Toggle menu"]').first.click();page.wait_for_timeout(150)
  data["reduced_motion_styles"]=page.evaluate("""() => ({matches:matchMedia('(prefers-reduced-motion: reduce)').matches,styles:[...document.querySelectorAll('.nc-sidebar,.tc-drop-down,.sidebar-toggle')].map(e=>({class:e.className,animation:getComputedStyle(e).animationName,transition:getComputedStyle(e).transitionDuration}))})""")
  rec("narrow-reduced-motion-menu",page);shot("narrow-reduced-motion-menu",page)
  page.locator('button[title="Toggle menu"]').first.click();page.set_viewport_size({"width":1440,"height":900})
  choose_palette(page,"$:/themes/nico/notebook/palettes/palette-beige")
  frame=open_note(page,"Evidence ledger");page.set_viewport_size({"width":390,"height":844});frame.locator(".tc-titlebar").scroll_into_view_if_needed()
  rec("light-narrow-ledger",page);shot("light-narrow-ledger",page)
  data["narrow_table_geometry"]=frame.locator("table").evaluate_all("els=>els.map(e=>({rect:e.getBoundingClientRect().toJSON(),scrollWidth:e.scrollWidth,clientWidth:e.clientWidth,text:e.innerText}))")
  page.set_viewport_size({"width":1440,"height":900});control_panel(page);tab(page,"Basics");rec("basics-ui",page)
  language=page.locator("select").filter(has=page.locator('option[value="$:/languages/zh-Hans"]'))
  if language.count():
   language.first.select_option("$:/languages/zh-Hans");page.wait_for_timeout(400);rec("chinese-language-selected",page)
   frame=open_note(page,TITLE);frame.locator(".tc-titlebar").scroll_into_view_if_needed();shot("chinese-light-reading",page)
  else:data["language_limit"]="Native Basics view had no language select with the supplied zh-Hans value; no direct state mutation used."
  data["completed"]=now()
 except Exception:data["failure"]=traceback.format_exc();print(data["failure"],flush=True)
 finally:
  if browser:browser.close()
  server.terminate();server.wait(timeout=5);log.close();data["server"]["stopped"]=now();data["server"]["returncode"]=server.returncode
  (OUT/"P13.json").write_text(json.dumps(data,ensure_ascii=False,indent=2))
  print(json.dumps({"product":"P13","steps":[s["name"] for s in data["steps"]],"failure":data.get("failure"),"language_limit":data.get("language_limit"),"reduced_motion_styles":data.get("reduced_motion_styles")},ensure_ascii=False),flush=True)

