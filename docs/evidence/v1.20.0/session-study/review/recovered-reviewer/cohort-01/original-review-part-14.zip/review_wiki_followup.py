from pathlib import Path
source=Path("/workspace/scratch/e1cfe6e447ee/ui-study/independent-review-recovery/review_wiki.py").read_text()
source=source.replace("import os,sys,json,time,shutil,subprocess,traceback,hashlib","import os,sys,json,time,shutil,subprocess,traceback,hashlib,re")
source=source.replace("wiki-001","wiki-002")
source=source.replace('[("T3-foundation",4713),("P13",4714)]','[("P13",4714)]')
source=source.replace('".tc-title-text"','".tc-titlebar"')
source=source.replace('name="edit",exact=True','name="Edit this tiddler",exact=True')
source=source.replace('name="save changes",exact=True','name=re.compile("save changes",re.I)')
source=source.replace('name="cancel",exact=True','name=re.compile("cancel",re.I)')
exec(source)

