from pathlib import Path
source=Path("/workspace/scratch/e1cfe6e447ee/ui-study/independent-review-recovery/review_wiki.py").read_text()
source=source.replace("wiki-001","wiki-003")
source=source.replace('[("T3-foundation",4713),("P13",4714)]','[("P13",4714)]')
source=source.replace('".tc-title-text"','".tc-titlebar"')
source=source.replace('name="edit",exact=True','name="Edit this tiddler",exact=True')
source=source.replace('name="save changes",exact=True','name="Confirm changes to this tiddler",exact=True')
source=source.replace('name="cancel",exact=True','name="Discard changes to this tiddler",exact=True')
source=source.replace('page=context.new_page();','page=context.new_page();page.set_default_timeout(8000);')
exec(source)

