from pathlib import Path
source=Path("/workspace/scratch/e1cfe6e447ee/ui-study/independent-review-recovery/review_conversations.py").read_text()
source=source.replace("conversations-001","conversations-cohort02-001")
source=source.replace('enumerate(["P09","P10"])','enumerate(["P17"])')
source=source.replace('port=4710+i','port=4727+i')
source=source.replace('"查看附件详情："+name if zh else "View attachment details: "+name','"查看附件："+name if zh else "Details for "+name')
old='page.get_by_role("button",name="Return to latest",exact=True).click();page.wait_for_timeout(300);rec(data,"explicit-return-latest",page)'
new='''page.get_by_role("button",name="Return to latest",exact=True).click()
   return_samples=[]
   for delay in [150,350,1000]:
    page.wait_for_timeout(delay);sample=state(page);return_samples.append({"time":now(),"scroll":sample["scroll"],"running":sample["running"],"gap":sample["scroll"]["height"]-sample["scroll"]["client"]-sample["scroll"]["top"]})
   data["return_latest_samples"]=return_samples
   data["checks"].append({"name":"return_latest_reaches_and_follows","pass":all(abs(s["gap"])<=2 for s in return_samples),"samples":return_samples})
   rec(data,"explicit-return-latest",page);shot(data,"returned-1500ms",page)'''
assert old in source;source=source.replace(old,new)
old='rec(data,"stop-focus",page);s1=state(page);page.wait_for_timeout(400);s2=state(page)'
new='''rec(data,"stop-focus",page)
   page.wait_for_timeout(1000);rec(data,"stop-after-settling",page);s1=state(page)
   page.wait_for_timeout(500);s2=state(page);rec(data,"stop-stable-followup",page)'''
assert old in source;source=source.replace(old,new)
exec(compile(source,"cohort02-conversation-derived-run","exec"))
