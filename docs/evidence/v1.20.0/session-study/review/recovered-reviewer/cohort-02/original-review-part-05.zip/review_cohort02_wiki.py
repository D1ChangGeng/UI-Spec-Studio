from pathlib import Path
source=Path("/workspace/scratch/e1cfe6e447ee/ui-study/independent-review-recovery/review_wiki.py").read_text()
source=source.replace("wiki-001","wiki-cohort02-001")
source=source.replace('[("T3-foundation",4713),("P13",4714)]','[("P12",4726)]')
source=source.replace('products/P13/app','products/P12/app')
source=source.replace('".tc-title-text"','".tc-titlebar"')
source=source.replace('name="edit",exact=True','name="Edit this tiddler",exact=True')
source=source.replace('name="save changes",exact=True','name="Confirm changes to this tiddler",exact=True')
source=source.replace('name="cancel",exact=True','name="Discard changes to this tiddler",exact=True')
source=source.replace('page=context.new_page();','page=context.new_page();page.set_default_timeout(8000);')
start='    control=page.get_by_role("button",name="control panel",exact=True).first;control.click();page.wait_for_timeout(250)'
end='    data["completed"]=now()'
a=source.index(start);b=source.index(end,a)
source=source[:a]+'''    page.get_by_role("button",name="control panel",exact=True).first.click();page.wait_for_timeout(200)
    rec(data,"control-panel-controls",page)
'''+source[b:]
exec(compile(source,"cohort02-wiki-derived-run","exec"))
