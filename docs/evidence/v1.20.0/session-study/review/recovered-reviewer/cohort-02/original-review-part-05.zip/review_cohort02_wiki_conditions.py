from pathlib import Path
prefix=Path("/workspace/scratch/e1cfe6e447ee/ui-study/independent-review-recovery/review_wiki_conditions.py").read_text().split('log=open(OUT/"P13-server.log"')[0]
prefix=prefix.replace("behavior-wiki-004","behavior-wiki-conditions-cohort02-001").replace("copies/wiki-003/P13/app","copies/wiki-cohort02-001/P12/app").replace("P13","P12")
exec(compile(prefix,"review-shared-wiki-condition-helpers","exec"))
def choose_paper_palette(page,name):
 control_panel(page);tab(page,"Appearance")
 options=page.locator("button").filter(has_text=re.compile("^Palette$"))
 if options.count():options.last.click();page.wait_for_timeout(150)
 rec("palette-options",page)
 page.get_by_text(re.compile("^"+re.escape(name)+" - ")).first.click();page.wait_for_timeout(300)
 data["checks"].append({"name":"native-palette-selection","selected_label":name,"actual":page.evaluate("$tw.wiki.getTiddlerText('$:/palette')")})
log=open(OUT/"P12-server.log","w");server=subprocess.Popen(["bash",str(app/"start.sh")],cwd=app,env=dict(ENV,PORT="4726"),stdout=log,stderr=subprocess.STDOUT)
data["server"]={"pid":server.pid,"port":4726,"started":now()}
with sync_playwright() as p:
 browser=None
 try:
  for _ in range(100):
   if server.poll() is not None:raise RuntimeError("Owned wiki server exited")
   try:urlopen("http://127.0.0.1:4726/",timeout=.5).close();break
   except Exception:time.sleep(.1)
  browser=p.chromium.launch(executable_path=CHROME,headless=True,env=ENV,args=["--no-sandbox"])
  data["browser"]=browser.version;data["fontconfig"]=ENV["FONTCONFIG_FILE"];data["device_scale_factor"]=1
  page=browser.new_page(viewport={"width":1440,"height":900},device_scale_factor=1);page.set_default_timeout(8000);page.on("dialog",lambda d:d.accept())
  page.goto("http://127.0.0.1:4726/",wait_until="domcontentloaded");page.wait_for_function("window.$tw && $tw.wiki");page.wait_for_timeout(500)
  rec("resumed-verified-copy",page)
  choose_paper_palette(page,"Vanilla Paper Night")
  frame=open_note(page,TITLE);frame.locator(".tc-titlebar").scroll_into_view_if_needed();rec("dark-reading",page);shot("dark-reading",page)
  page.set_viewport_size({"width":1280,"height":640});frame.locator(".tc-titlebar").scroll_into_view_if_needed();rec("dark-compact-reading",page);shot("dark-compact-reading",page)
  frame.get_by_role("button",name="Edit this tiddler",exact=True).focus();page.keyboard.press("Enter");page.wait_for_timeout(200)
  page.get_by_role("button",name="Confirm changes to this tiddler",exact=True).scroll_into_view_if_needed();rec("dark-editor",page);shot("dark-editor",page)
  page.set_viewport_size({"width":390,"height":844});page.get_by_role("button",name="Confirm changes to this tiddler",exact=True).scroll_into_view_if_needed();rec("dark-narrow-editor",page);shot("dark-narrow-editor",page)
  ta=editor(page);ta.focus();ta.press("Control+Home");rec("dark-narrow-editor-body",page);shot("dark-narrow-editor-body",page)
  page.get_by_role("button",name="Discard changes to this tiddler",exact=True).scroll_into_view_if_needed();page.get_by_role("button",name="Discard changes to this tiddler",exact=True).click();page.wait_for_timeout(200)
  frame=page.locator(".tc-tiddler-frame").filter(has=page.locator(".tc-titlebar").filter(has_text=TITLE)).first;frame.locator(".tc-titlebar").scroll_into_view_if_needed();rec("dark-narrow-reading",page);shot("dark-narrow-reading",page)
  page.emulate_media(reduced_motion="reduce")
  data["reduced_motion_styles"]=page.evaluate("""() => ({matches:matchMedia('(prefers-reduced-motion: reduce)').matches,animationDuration:$tw.wiki.getTiddlerText('$:/config/AnimationDuration'),styles:[...document.querySelectorAll('.tc-tiddler-frame,.tc-sidebar-scrollable,.tc-tiddler-title')].slice(0,8).map(e=>({class:e.className,animation:getComputedStyle(e).animationName,transition:getComputedStyle(e).transitionDuration}))})""")
  rec("narrow-reduced-motion-reading",page);shot("narrow-reduced-motion-reading",page)
  page.set_viewport_size({"width":1440,"height":900})
  choose_paper_palette(page,"Vanilla Paper Day")
  frame=open_note(page,"Evidence ledger");page.set_viewport_size({"width":390,"height":844});frame.locator(".tc-titlebar").scroll_into_view_if_needed();rec("light-narrow-ledger",page);shot("light-narrow-ledger",page)
  data["narrow_table_geometry"]=frame.locator("table").evaluate_all("els=>els.map(e=>({rect:e.getBoundingClientRect().toJSON(),scrollWidth:e.scrollWidth,clientWidth:e.clientWidth,text:e.innerText,parent:{class:e.parentElement.className,scrollWidth:e.parentElement.scrollWidth,clientWidth:e.parentElement.clientWidth,overflowX:getComputedStyle(e.parentElement).overflowX}}))")
  page.set_viewport_size({"width":1440,"height":900});control_panel(page);tab(page,"Info");tab(page,"Basics");rec("native-language-controls",page)
  page.locator("select").filter(has=page.locator('option[value="$:/languages/zh-Hans"]')).first.select_option("$:/languages/zh-Hans");page.wait_for_timeout(350)
  rec("chinese-language-selected",page);frame=open_note(page,TITLE);frame.locator(".tc-titlebar").scroll_into_view_if_needed();shot("chinese-light-reading",page)
  data["checks"].append({"name":"native-language-selection","actual":page.evaluate("$tw.wiki.getTiddlerText('$:/language')")})
  data["completed"]=now()
 except Exception:data["failure"]=traceback.format_exc();print(data["failure"],flush=True)
 finally:
  if browser:browser.close()
  server.terminate();server.wait(timeout=5);log.close();data["server"]["stopped"]=now();data["server"]["returncode"]=server.returncode
  (OUT/"P12.json").write_text(json.dumps(data,ensure_ascii=False,indent=2))
  print(json.dumps({"product":"P12","checks":data["checks"],"steps":[s["name"] for s in data["steps"]],"narrow_table_geometry":data.get("narrow_table_geometry"),"reduced_motion_styles":data.get("reduced_motion_styles"),"failure":data.get("failure"),"evidence":str(OUT/"P12.json")},ensure_ascii=False),flush=True)
