# Evidence index

- `commands/001-guidance-search`, `002-guidance-forms`: actual current guidance command exports.
- `tabler-research-001.json`, `tabler-docs-002.json`–`004.json`: actual primary documentation tool responses, including inaccessible Markdown exports.
- `initial/`: original starter captures; failed original-reference route is retained.
- `source-corrected/`: corrected retained official-source render.
- `trial/`: first integrated form and narrow composition.
- `commands/006-full-verification`, `final/`: first browser run with the keyboard focus recovery failure.
- `commands/007-full-verification-r2`, `final-r2/`: complete required viewport matrix and keyboard journeys, 141 passing assertions; 48 captures and recorded videos.
- `commands/008-contrast-before`, `009-contrast-after`: actual contrast diagnostics; only opaque alert/error calculations support reported ratios.
- `commands/010-refinement-checks`, `final-r3/`: contrast/textarea correction checks, 24 passing assertions.
- `commands/011-loading-footprint`, `final-r4/`: final affected-state check, 28 passing assertions and 18 captures.
- `commands/012-final-concurrency`, `final-concurrency/`: final delivered-controller snapshot separation, length validation and Cancel in all four variants.
- `commands/013-delivery-captures`, `delivery-en-light.png`, `delivery-zh-dark.png`: final settled preview images, personally opened.
- `view-*.json`: actual view_image argument/result exports from personally opening the referenced PNGs.
- `index-before.html`, `controller-before.js`, `index.patch`, `controller.patch`: source-before and final adaptation differences.
- `delivery-digests.json`: delivered source and source-reference SHA-256 identities.
- `server-start.json`, `server-stop-attempt.json`: actual preview session start/stop tool responses; stop response reports successful keyboard interrupt and exit. Its access-log output is explicitly truncated by the tool and is not a complete request ledger.

All captures use synthetic settings. No parent/sibling package, release record or unrelated user content was inspected. See VISUAL-REVIEW.md for which artifacts were personally viewed and the limits of temporal/device claims.

