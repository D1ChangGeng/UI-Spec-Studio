from pathlib import Path
p=Path('app/index.html')
s=p.read_text()
Path('evidence/index-before.html').write_text(s)
Path('evidence/controller-before.js').write_text(Path('app/settings-controller.js').read_text())
s=s.replace('<title>Fieldnotes — Account settings (local demo)</title>', '<title>Fieldnotes — Account settings</title>')
s=s.replace('content="Premium and Open Source dashboard template with responsive and high quality UI."', 'content="Profile, notifications and privacy settings for Fieldnotes."')
s=s.replace('<h1 class="page-title">Account Settings</h1>', '<h1 class="page-title" data-i18n="accountSettings">Account settings</h1>')
needle='''                  <h1 class="page-title" data-i18n="accountSettings">Account settings</h1>
                </div>'''
s=s.replace(needle, needle+'''
                <div class="col-auto ms-auto">
                  <div class="btn-list">
                    <button type="button" class="btn btn-sm" id="language-toggle" lang="zh-CN">中文</button>
                    <button type="button" class="btn btn-sm" id="theme-toggle">Use dark theme</button>
                  </div>
                </div>''')
a=s.index('          <!-- BEGIN PAGE BODY -->')
b=s.index('          <!-- END PAGE BODY -->',a)+len('          <!-- END PAGE BODY -->')
s=s[:a]+'''          <!-- BEGIN PAGE BODY -->
          <div class="page-body">
            <div class="container-xl">
              <div class="card">
                <div class="row g-0">
                  <div class="col-12 col-md-3 border-end">
                    <div class="card-body">
                      <button type="button" class="btn w-100 d-md-none" data-bs-toggle="collapse" data-bs-target="#account-navigation" aria-expanded="false" aria-controls="account-navigation" data-i18n="sections">Settings sections</button>
                      <div id="account-navigation" class="collapse d-md-block">
                        <h2 class="subheader" data-i18n="businessSettings">Business settings</h2>
                        <nav aria-label="Account settings" class="list-group list-group-transparent" id="settings-nav">
                          <a href="#profile-heading" class="list-group-item list-group-item-action active d-flex align-items-center" aria-current="location" data-i18n="myAccount">My account</a>
                          <a href="#notifications-heading" class="list-group-item list-group-item-action d-flex align-items-center" data-i18n="notifications">Notifications</a>
                          <a href="#privacy-heading" class="list-group-item list-group-item-action d-flex align-items-center" data-i18n="privacy">Privacy</a>
                          <a href="./settings-plan.html" class="list-group-item list-group-item-action d-flex align-items-center" data-i18n="plans">Plans</a>
                          <a href="#" class="list-group-item list-group-item-action d-flex align-items-center" data-i18n="billing">Billing &amp; invoices</a>
                        </nav>
                        <h2 class="subheader mt-4" data-i18n="experience">Experience</h2>
                        <nav aria-label="Experience" class="list-group list-group-transparent">
                          <a href="#" class="list-group-item list-group-item-action" data-i18n="feedback">Give feedback</a>
                        </nav>
                      </div>
                    </div>
                  </div>
                  <form id="settings-form" class="col-12 col-md-9 d-flex flex-column" novalidate>
                    <div class="card-body">
                      <h2 class="mb-4" id="profile-heading" tabindex="-1" data-i18n="myAccount">My account</h2>
                      <h3 class="card-title" data-i18n="profileDetails">Profile details</h3>
                      <div class="row align-items-center g-3 mb-4">
                        <div class="col-auto"><span class="avatar avatar-md" id="profile-avatar" aria-hidden="true">ML</span></div>
                        <div class="col"><div class="fw-medium text-break" id="saved-name">Mei Lin · 林玫</div><div class="text-secondary" data-i18n="profileContext">Your identity in this research workspace.</div></div>
                      </div>
                      <div class="row g-3">
                        <div class="col-12">
                          <label class="form-label required" for="business-name" data-i18n="displayName">Display name</label>
                          <textarea class="form-control" id="business-name" name="displayName" rows="1" autocomplete="name" required aria-describedby="displayName-hint displayName-error"></textarea>
                          <div class="invalid-feedback" id="displayName-error"></div>
                          <div class="form-hint" id="displayName-hint" data-i18n="nameHint">Required · Up to 100 characters.</div>
                        </div>
                        <div class="col-12">
                          <label class="form-label" for="business-id" data-i18n="organization">Organization</label>
                          <textarea class="form-control" id="business-id" name="organization" rows="1" autocomplete="organization" aria-describedby="organization-hint organization-error"></textarea>
                          <div class="invalid-feedback" id="organization-error"></div>
                          <div class="form-hint" id="organization-hint" data-i18n="organizationHint">Optional · Up to 180 characters.</div>
                        </div>
                        <div class="col-12 col-lg-6">
                          <label class="form-label" for="location" data-i18n="location">Location</label>
                          <input type="text" class="form-control" id="location" name="location" autocomplete="address-level2" aria-describedby="location-hint location-error" />
                          <div class="invalid-feedback" id="location-error"></div>
                          <div class="form-hint" id="location-hint" data-i18n="locationHint">Optional · Up to 100 characters.</div>
                        </div>
                        <div class="col-12 col-lg-6">
                          <label class="form-label required" for="email" data-i18n="email">Email</label>
                          <input type="email" class="form-control" id="email" name="email" autocomplete="email" inputmode="email" autocapitalize="off" spellcheck="false" required aria-describedby="email-hint email-error" />
                          <div class="invalid-feedback" id="email-error"></div>
                          <div class="form-hint" id="email-hint" data-i18n="emailHint">Required · Used for notifications. Always private.</div>
                        </div>
                      </div>
                      <h3 class="card-title mt-4" id="notifications-heading" tabindex="-1" data-i18n="notifications">Notifications</h3>
                      <p class="card-subtitle" id="notifications-help" data-i18n="notificationsHelp">Receive a weekly digest of research notes shared with your workspace.</p>
                      <label class="form-check form-switch form-switch-lg">
                        <input class="form-check-input" type="checkbox" id="weekly-digest" name="weeklyDigest" aria-describedby="notifications-help" />
                        <span class="form-check-label" data-i18n="weeklyDigest">Weekly digest</span>
                      </label>
                      <h3 class="card-title mt-4" id="privacy-heading" tabindex="-1" data-i18n="publicProfile">Public profile</h3>
                      <p class="card-subtitle" id="privacy-help" data-i18n="privacyHelp">Let other workspace members find your profile. Your email stays private.</p>
                      <label class="form-check form-switch form-switch-lg">
                        <input class="form-check-input" type="checkbox" id="public-profile" name="publicProfile" aria-describedby="privacy-help" />
                        <span class="form-check-label" data-i18n="profileVisible">Visible to workspace members</span>
                      </label>
                    </div>
                    <div class="card-footer bg-transparent mt-auto">
                      <div id="save-status" class="text-secondary mb-3" role="status" aria-live="polite" aria-atomic="true"></div>
                      <div class="btn-list justify-content-end">
                        <button type="button" class="btn" id="cancel-settings" data-i18n="cancel">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="save-settings" disabled>Save changes</button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <!-- END PAGE BODY -->'''+s[b:]
p.write_text(s)
print('Updated app/index.html; original page retained in evidence/index-before.html.')
