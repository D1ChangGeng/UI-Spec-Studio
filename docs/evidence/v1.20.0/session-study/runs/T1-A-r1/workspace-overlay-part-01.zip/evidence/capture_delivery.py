import asyncio,json,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent.parent
LONG='跨城市田野研究协作小组 — Longitudinal everyday-mobility research programme'
async def main():
 rows=[]
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
  for lang,theme,w,h in [('en','light',1440,900),('zh','dark',390,844)]:
   page=await b.new_page(viewport={'width':w,'height':h},device_scale_factor=1)
   await page.goto(f'http://127.0.0.1:4401/?theme={theme}&lang={lang}')
   await page.wait_for_function('Boolean(window.fieldnotes)')
   await page.locator('#business-name').fill(LONG)
   await page.locator('#business-id').fill(LONG)
   await page.evaluate('document.activeElement.blur();window.scrollTo({top:0,behavior:"instant"})')
   await page.wait_for_timeout(400)
   a=time.monotonic();name=f'delivery-{lang}-{theme}.png'
   await page.screenshot(path=str(ROOT/'evidence'/name))
   rows.append({'file':name,'viewport':[w,h],'capture_bracket_monotonic':[a,time.monotonic()],'state':await page.locator('#save-status').get_attribute('data-state')})
   await page.close()
  await b.close()
 (ROOT/'evidence/delivery-captures.json').write_text(json.dumps(rows,indent=2))
 print(json.dumps(rows))
asyncio.run(main())
