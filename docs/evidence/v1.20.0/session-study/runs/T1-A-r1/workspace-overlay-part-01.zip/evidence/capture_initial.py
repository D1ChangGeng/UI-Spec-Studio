import asyncio, json, os, time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'evidence' / 'initial'
OUT.mkdir(parents=True, exist_ok=True)
async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell', args=['--no-sandbox'])
        page = await browser.new_page(viewport={'width':1440,'height':900}, device_scale_factor=1)
        await page.goto('http://127.0.0.1:4401/?theme=light&lang=en')
        await page.locator('#business-name').wait_for()
        await page.evaluate('document.fonts.ready')
        await page.screenshot(path=str(OUT/'starter-en-light.png'))
        await page.set_viewport_size({'width':390,'height':844})
        await page.screenshot(path=str(OUT/'starter-narrow.png'))
        # Render the retained official snapshot using its original local CSS/JS.
        source=(ROOT/'sources/official-settings-snapshot.html').read_text()
        await page.route('http://127.0.0.1:4401/official-reference.html',lambda route: route.fulfill(body=source,content_type='text/html'))
        await page.set_viewport_size({'width':1440,'height':900})
        await page.goto('http://127.0.0.1:4401/official-reference.html?theme=light')
        await page.evaluate('document.fonts.ready')
        await page.screenshot(path=str(OUT/'official-source-reference.png'))
        print(json.dumps({'browser':browser.version,'viewport':[1440,900],'dpr':1,'fontconfig':os.environ.get('FONTCONFIG_FILE'),'images':[x.name for x in OUT.glob('*.png')],'reference':'supplied original snapshot rendered locally; portrait assets may be absent'}))
        await browser.close()
asyncio.run(main())
