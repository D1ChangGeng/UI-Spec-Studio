import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent.parent
async def main():
  results=[]
  async with async_playwright() as p:
    browser=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
    for theme in ['light','dark']:
      page=await browser.new_page(viewport={'width':1280,'height':600})
      await page.goto('http://127.0.0.1:4401/?theme='+theme)
      await page.wait_for_function('Boolean(window.fieldnotes)')
      await page.locator('#business-name').fill('')
      await page.locator('#save-settings').click()
      await page.wait_for_timeout(250)
      result=await page.evaluate("""() => {
        function rgba(color) { let c=document.createElement('canvas').getContext('2d'); c.fillStyle=color; c.fillRect(0,0,1,1); return [...c.getImageData(0,0,1,1).data]; }
        function lum(rgb) { let values=rgb.slice(0,3).map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4});return values[0]*.2126+values[1]*.7152+values[2]*.0722; }
        function bg(el) { while(el) {let color=rgba(getComputedStyle(el).backgroundColor);if(color[3]===255)return color;el=el.parentElement;}return [255,255,255,255]; }
        return ['#save-status','#displayName-error','#displayName-hint'].map(selector=>{let el=document.querySelector(selector),style=getComputedStyle(el),fg=rgba(style.color),back=bg(el);return {selector,color:style.color,foreground:fg,background:back,contrast:(Math.max(lum(fg),lum(back))+.05)/(Math.min(lum(fg),lum(back))+.05)}});
      }""")
      results.append({'theme':theme,'measurements':result})
      await page.close()
    await browser.close()
  print(json.dumps(results,indent=2))
asyncio.run(main())

