import asyncio, datetime, hashlib, json, os, time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT/'evidence'/'final'
OUT.mkdir(parents=True,exist_ok=True)
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
LONG='跨城市田野研究协作小组 — Longitudinal everyday-mobility research programme'
report={'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'browser':None,'checks':[],'screenshots':[],'console_errors':[],'episodes':[],'source_sha256':{f:hashlib.sha256((ROOT/'app'/f).read_bytes()).hexdigest() for f in ['index.html','settings-controller.js','settings-store.js']}}
def check(name,result,details=None):
    report['checks'].append({'name':name,'pass':bool(result),'details':details})
    assert result, f'{name}: {details}'
async def shot(page,name):
    start=time.monotonic()
    await page.screenshot(path=str(OUT/(name+'.png')))
    report['screenshots'].append({'file':name+'.png','capture_start_monotonic':start,'capture_end_monotonic':time.monotonic(),'viewport':page.viewport_size,'url':page.url,'scroll_y':await page.evaluate('scrollY'),'active':await page.evaluate('document.activeElement.id'),'state':await page.locator('#save-status').get_attribute('data-state')})
async def tab_to(page,id,limit=40):
    for _ in range(limit):
        if await page.evaluate('document.activeElement.id')==id: return
        await page.keyboard.press('Tab')
    raise AssertionError('Keyboard could not reach '+id)
async def type_here(page,value):
    await page.keyboard.press('ControlOrMeta+A')
    await page.keyboard.insert_text(value)
async def main():
  async with async_playwright() as p:
    browser=await p.chromium.launch(executable_path=BROWSER,args=['--no-sandbox'])
    report['browser']=browser.version
    for lang in ['en','zh']:
      for theme in ['light','dark']:
        for width,height in [(1440,900),(1280,600),(390,844)]:
          context=await browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1)
          page=await context.new_page()
          page.on('pageerror',lambda error: report['console_errors'].append(str(error)))
          await page.goto(f'http://127.0.0.1:4401/?theme={theme}&lang={lang}')
          await page.wait_for_function('Boolean(window.fieldnotes)')
          await page.evaluate('document.fonts.ready')
          tag=f'{lang}-{theme}-{width}x{height}'
          check(tag+' theme',await page.locator('html').get_attribute('data-bs-theme')==theme)
          check(tag+' locale',await page.locator('html').get_attribute('lang')==('zh-CN' if lang=='zh' else 'en'))
          await page.locator('#business-name').fill(LONG)
          await page.locator('#business-id').fill(LONG)
          await page.evaluate('window.scrollTo(0,0)')
          await shot(page,tag+'-top-long')
          metrics=await page.evaluate("""() => ({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,textareas:[...document.querySelectorAll('#settings-form textarea')].map(e=>({id:e.id,clientHeight:e.clientHeight,scrollHeight:e.scrollHeight,value:e.value}))})""")
          check(tag+' no horizontal overflow',metrics['scrollWidth']<=width,metrics)
          check(tag+' wrapped content visible',all(e['clientHeight']>=e['scrollHeight']-1 for e in metrics['textareas']),metrics)
          await page.locator('#save-settings').scroll_into_view_if_needed()
          await shot(page,tag+'-footer')
          check(tag+' save reachable',await page.locator('#save-settings').is_visible())
          if width==390:
            await page.evaluate('window.scrollTo(0,0)')
            await page.locator('[data-bs-target="#account-navigation"]').click()
            check(tag+' mobile navigation opens',await page.locator('#settings-nav').is_visible())
            await page.locator('#settings-nav a[href="#privacy-heading"]').click()
            check(tag+' section focus',await page.evaluate('document.activeElement.id')=='privacy-heading')
          await context.close()
        # Complete keyboard-first save/failure/retry path for each declared variant.
        context=await browser.new_context(viewport={'width':1280,'height':600},device_scale_factor=1,record_video_dir=str(OUT/'videos'),record_video_size={'width':1280,'height':600})
        page=await context.new_page()
        page.on('pageerror',lambda error: report['console_errors'].append(str(error)))
        page.on('dialog',lambda dialog: dialog.accept())
        await page.goto(f'http://127.0.0.1:4401/?theme={theme}&lang={lang}&fail=once')
        await page.wait_for_function('Boolean(window.fieldnotes)')
        await page.evaluate("""async () => { window.saveEvents=[]; const store=await import('./settings-store.js'); store.subscribeSettings(e=>window.saveEvents.push({status:e.status,operationId:e.operationId,time:performance.now(),snapshot:e.snapshot||e.settings||e.draft})); }""")
        tag=f'{lang}-{theme}-episode'
        # Native keyboard entry starts at the supplied skip link.
        await page.keyboard.press('Tab'); await page.keyboard.press('Enter')
        await tab_to(page,'business-name')
        await shot(page,tag+'-keyboard-focus')
        await type_here(page,'')
        await page.keyboard.press('Tab'); await type_here(page,'x'*181)
        await page.keyboard.press('Tab'); await type_here(page,'x'*101)
        await page.keyboard.press('Tab'); await type_here(page,'invalid-email')
        await tab_to(page,'save-settings')
        await page.keyboard.press('Enter')
        await page.wait_for_function("document.querySelector('#save-status').dataset.state==='invalid'")
        check(tag+' four authoritative errors',await page.locator('#settings-form [aria-invalid="true"]').count()==4)
        check(tag+' validation focuses first field',await page.evaluate('document.activeElement.id')=='business-name')
        check(tag+' invalid does not persist',await page.evaluate("localStorage.getItem('fieldnotes-settings-v1')") is None)
        await shot(page,tag+'-invalid')
        # Correct through keyboard only and submit a short name plus long organization.
        await type_here(page,'Li')
        await page.keyboard.press('Tab'); await type_here(page,LONG)
        await page.keyboard.press('Tab'); await type_here(page,'Singapore / 新加坡')
        await page.keyboard.press('Tab'); await type_here(page,'li@example.invalid')
        await page.keyboard.press('Tab'); await page.keyboard.press('Space')
        await page.keyboard.press('Tab'); await page.keyboard.press('Space')
        await tab_to(page,'save-settings')
        trigger=time.monotonic()
        await page.keyboard.press('Enter')
        check(tag+' pending event visible',await page.locator('#save-status').get_attribute('data-state')=='pending')
        check(tag+' duplicate and cancel disabled',await page.locator('#save-settings').is_disabled() and await page.locator('#cancel-settings').is_disabled())
        check(tag+' pending not persisted',await page.evaluate("localStorage.getItem('fieldnotes-settings-v1')") is None)
        await shot(page,tag+'-pending')
        await page.wait_for_function("document.querySelector('#save-status').dataset.state==='error'")
        check(tag+' failure retains draft',await page.locator('#business-name').input_value()=='Li')
        check(tag+' failure leaves storage unchanged',await page.evaluate("localStorage.getItem('fieldnotes-settings-v1')") is None)
        await shot(page,tag+'-failure')
        await tab_to(page,'save-settings')
        await page.keyboard.press('Enter')
        await page.wait_for_function("document.querySelector('#save-status').dataset.state==='success'")
        saved=await page.evaluate("JSON.parse(localStorage.getItem('fieldnotes-settings-v1')).settings")
        check(tag+' retry persists all fields',saved=={'displayName':'Li','organization':LONG,'location':'Singapore / 新加坡','email':'li@example.invalid','weeklyDigest':False,'publicProfile':True},saved)
        await shot(page,tag+'-success')
        # Snapshot concurrency: later edits are not silently replaced or called saved.
        await page.locator('#business-name').fill(LONG)
        await page.locator('#save-settings').click()
        await page.locator('#business-name').fill('Later edit / 后续编辑')
        check(tag+' pending newer-edit feedback',await page.locator('#save-status').get_attribute('data-message')=='pendingNew')
        await page.wait_for_function("document.querySelector('#save-status').dataset.state==='success'")
        check(tag+' submitted snapshot persisted',await page.evaluate("JSON.parse(localStorage.getItem('fieldnotes-settings-v1')).settings.displayName")==LONG)
        check(tag+' later edit preserved',await page.locator('#business-name').input_value()=='Later edit / 后续编辑')
        check(tag+' newer edits explicitly unsaved',await page.locator('#save-status').get_attribute('data-message')=='savedNew')
        await page.locator('#save-settings').scroll_into_view_if_needed()
        await shot(page,tag+'-newer-edits')
        # Switch variants in place, retaining draft and the actual saved snapshot.
        await page.locator('#language-toggle').click()
        await page.locator('#theme-toggle').click()
        check(tag+' variant switch retains draft',await page.locator('#business-name').input_value()=='Later edit / 后续编辑')
        await page.locator('#cancel-settings').click()
        check(tag+' cancel restores last committed snapshot',await page.locator('#business-name').input_value()==LONG)
        await page.reload()
        await page.wait_for_function('Boolean(window.fieldnotes)')
        check(tag+' reload reads persisted value',await page.locator('#business-name').input_value()==LONG)
        # Return from an actual in-page settings destination.
        await page.locator('#settings-nav a[href="#notifications-heading"]').click()
        await page.locator('#settings-nav a[href="#profile-heading"]').click()
        check(tag+' return retains values',await page.locator('#business-name').input_value()==LONG)
        check(tag+' return focus',await page.evaluate('document.activeElement.id')=='profile-heading')
        report['episodes'].append({'variant':tag,'trigger_monotonic':trigger,'events_before_reload':None,'video':str(await page.video.path())})
        await context.close()
    check('No uncaught page exceptions',not report['console_errors'],report['console_errors'])
    await browser.close()
try:
    asyncio.run(main())
finally:
    report['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    (OUT/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps({'checks':len(report['checks']),'passed':sum(c['pass'] for c in report['checks']),'screenshots':len(report['screenshots']),'console_errors':report['console_errors'],'report':str(OUT/'verification.json')},ensure_ascii=False))

