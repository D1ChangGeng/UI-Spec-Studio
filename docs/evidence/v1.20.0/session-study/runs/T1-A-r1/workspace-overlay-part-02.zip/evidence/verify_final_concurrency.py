import asyncio,hashlib,json,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'evidence'/'final-concurrency';OUT.mkdir(exist_ok=True)
LONG='跨城市田野研究协作小组 — Longitudinal everyday-mobility research programme'
rows=[]
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
  for lang in ['en','zh']:
   for theme in ['light','dark']:
    page=await browser.new_page(viewport={'width':1280,'height':600})
    await page.goto(f'http://127.0.0.1:4401/?theme={theme}&lang={lang}')
    await page.wait_for_function('Boolean(window.fieldnotes)')
    await page.locator('#business-name').fill(LONG)
    await page.locator('#save-settings').click()
    await page.locator('#business-name').fill('Newer edit / 后续编辑')
    assert await page.locator('#save-status').get_attribute('data-message')=='pendingNew'
    await page.wait_for_function("document.querySelector('#save-status').dataset.state==='success'")
    assert await page.evaluate('window.fieldnotes.readSettings().displayName')==LONG
    assert await page.locator('#business-name').input_value()=='Newer edit / 后续编辑'
    assert await page.locator('#save-status').get_attribute('data-message')=='savedNew'
    await page.locator('#save-settings').scroll_into_view_if_needed()
    await page.wait_for_timeout(350)
    start=time.monotonic()
    await page.screenshot(path=str(OUT/(lang+'-'+theme+'-newer-edits.png')))
    row={'lang':lang,'theme':theme,'snapshot_preserved':True,'newer_edit_retained':True,'explicit_unsaved_feedback':True,'capture_bracket_monotonic':[start,time.monotonic()]}
    await page.locator('#business-name').fill('x'*101)
    await page.locator('#save-settings').click()
    message=await page.locator('#displayName-error').text_content()
    assert ('100' in message) and await page.locator('#business-name').get_attribute('aria-invalid')=='true'
    row['name_max_length_error']=message
    await page.locator('#cancel-settings').click()
    assert await page.locator('#business-name').input_value()==LONG
    row['cancel_restores_snapshot']=True
    rows.append(row)
    await page.close()
  await browser.close()
try:asyncio.run(main())
finally:
 result={'variants':rows,'controller_sha256':hashlib.sha256((ROOT/'app/settings-controller.js').read_bytes()).hexdigest()}
 (OUT/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
 print(json.dumps(result,ensure_ascii=False))

