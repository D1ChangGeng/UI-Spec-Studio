import asyncio,json,time,hashlib,datetime
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'evidence'/'final-r3';OUT.mkdir(exist_ok=True)
LONG='跨城市田野研究协作小组 — Longitudinal everyday-mobility research programme'
result={'checks':[],'frames':[],'events':[],'network':[],'source_sha256':{f:hashlib.sha256((ROOT/'app'/f).read_bytes()).hexdigest() for f in ['index.html','settings-controller.js','settings-store.js']}}
def check(name,ok,detail=None):
 result['checks'].append({'name':name,'pass':bool(ok),'detail':detail});assert ok,name
async def shot(page,name):
 a=time.monotonic();await page.screenshot(path=str(OUT/(name+'.png')));b=time.monotonic()
 result['frames'].append({'file':name+'.png','capture_bracket_monotonic':[a,b],'state':await page.locator('#save-status').get_attribute('data-state'),'active':await page.evaluate('document.activeElement.id'),'viewport':page.viewport_size,'scrollY':await page.evaluate('scrollY')})
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
  for lang in ['en','zh']:
   for theme in ['light','dark']:
    page=await browser.new_page(viewport={'width':1280,'height':600})
    page.on('request',lambda r: result['network'].append({'url':r.url,'method':r.method}))
    await page.goto(f'http://127.0.0.1:4401/?theme={theme}&lang={lang}&fail=once')
    await page.wait_for_function('Boolean(window.fieldnotes)')
    await page.evaluate("""async()=>{window.events=[];const s=await import('./settings-store.js');s.subscribeSettings(e=>events.push({time:performance.now(),status:e.status,operationId:e.operationId}));}""")
    tag=lang+'-'+theme
    await page.locator('#business-name').fill('')
    await page.locator('#business-id').fill('x'*181)
    await page.locator('#email').fill('invalid')
    await page.locator('#save-settings').click()
    await page.wait_for_timeout(250)
    sizes=await page.locator('#settings-form textarea').evaluate_all('(els)=>els.map(e=>({id:e.id,client:e.clientHeight,scroll:e.scrollHeight}))')
    check(tag+' invalid text remains visible',all(s['client']>=s['scroll']-1 for s in sizes),sizes)
    await shot(page,tag+'-invalid-settled')
    await page.locator('#business-name').fill(LONG)
    await page.locator('#business-id').fill(LONG)
    await page.locator('#email').fill('mei.lin@example.invalid')
    await page.locator('#save-settings').focus()
    await page.keyboard.press('Enter')
    await page.wait_for_timeout(180)
    await shot(page,tag+'-pending')
    await page.wait_for_function("document.querySelector('#save-status').dataset.state==='error'")
    await page.wait_for_timeout(250)
    check(tag+' keyboard focus after failure',await page.evaluate('document.activeElement.id')=='save-settings')
    check(tag+' emphasis class present','text-danger-emphasis' in await page.locator('#save-status').get_attribute('class'))
    await shot(page,tag+'-failure-settled')
    await page.keyboard.press('Enter')
    await page.wait_for_function("document.querySelector('#save-status').dataset.state==='success'")
    await page.wait_for_timeout(250)
    check(tag+' persisted after keyboard retry',await page.evaluate("window.fieldnotes.readSettings().displayName")==LONG)
    check(tag+' focus after retry',await page.evaluate('document.activeElement.id')=='save-settings')
    await shot(page,tag+'-success-settled')
    result['events'].append({'variant':tag,'events':await page.evaluate('events')})
    await page.close()
  # Narrow touch-sized viewport: actual save / failure / retry and long edit.
  page=await browser.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True,device_scale_factor=1)
  await page.goto('http://127.0.0.1:4401/?theme=dark&lang=zh&fail=once')
  await page.wait_for_function('Boolean(window.fieldnotes)')
  await page.locator('#business-name').fill(LONG)
  await page.locator('#save-settings').tap()
  await page.wait_for_function("document.querySelector('#save-status').dataset.state==='error'")
  await page.wait_for_timeout(250)
  await shot(page,'zh-dark-narrow-failure')
  await page.locator('#save-settings').tap()
  await page.wait_for_function("document.querySelector('#save-status').dataset.state==='success'")
  await page.wait_for_timeout(250)
  await shot(page,'zh-dark-narrow-success')
  check('Narrow touch retry persisted',await page.evaluate('window.fieldnotes.readSettings().displayName')==LONG)
  await page.close()
  # Unreadable persisted state is preserved, not overwritten by empty inputs.
  page=await browser.new_page()
  await page.goto('http://127.0.0.1:4401/?theme=light&lang=en')
  await page.evaluate("localStorage.setItem('fieldnotes-settings-v1','unreadable-fixture')")
  await page.reload();await page.wait_for_function('Boolean(window.fieldnotes)')
  check('Unreadable store keeps raw value',await page.evaluate("localStorage.getItem('fieldnotes-settings-v1')")=='unreadable-fixture')
  check('Unreadable store disables save',await page.locator('#save-settings').is_disabled())
  check('Settings have no external requests',all(r['url'].startswith('http://127.0.0.1:4401/') for r in result['network']))
  await browser.close()
try:asyncio.run(main())
finally:
 (OUT/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
 print(json.dumps({'checks':len(result['checks']),'passed':sum(x['pass'] for x in result['checks']),'frames':len(result['frames'])}))

