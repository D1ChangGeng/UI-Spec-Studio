# Research visual inspection record

This record covers research evidence only; final product inspection belongs to the parent designer.

## Actual images viewed

- Baseline 1440 light: coherent existing Tabler hierarchy, quarter navigation/content split, utility controls occupy the profile row.
- Baseline 1440 long name: focused single-line input shows the end of the long name through horizontal scrolling; equal-width field allocation makes the whole value hard to inspect.
- Baseline 1280 invalid: invalid email remains a normal focused input without field error text; top status is outside the visible viewport, confirmed by DOM geometry.
- Baseline 1280 save failure: footer remains visible but the failure message is outside the viewport.
- Baseline 1280 saved snapshot/newer draft: screenshot shows newer draft; the paired store log distinguishes it from persisted submitted snapshot.
- Baseline locale reload: the screenshot after language switch displays Submitted snapshot; paired DOM/store output establishes loss of the newer unsaved draft.
- Baseline 390 dark Chinese footer: email helper and privacy description wrap inside the card; Save/Cancel remain side by side, status is absent from the visible viewport.
- Source specimen 1440 light and 1280 dark: invalid feedback is adjacent to its field; default alert tint and minor border-only surface are materially distinct native variants.
- Source specimen 390 dark: cards stack, retry wraps beneath explanation, long title is compressed by the header action. The last minor alert extends below the initial viewport.
- Supplied official snapshot local 1440: original settings hierarchy retained; missing avatar and blocked external banner qualify this local source render.

## Evidence roles and limits

Public settings and minor-alert originals were viewed through cloud Browser earlier. Their screenshot export failed to become available in the executor workspace; no local screenshot is labeled an original public demo capture. The source specimen uses exact tagged example markup with a native composed wrapper. It is a provisional research trial, not adopted product or an exact full-page public demo reproduction.

Every local view listed above has the actual view_image response in a matching view-*.json. No video or natural-time viewing was performed. No contrast ratio or assistive-technology claim follows from these static images.

