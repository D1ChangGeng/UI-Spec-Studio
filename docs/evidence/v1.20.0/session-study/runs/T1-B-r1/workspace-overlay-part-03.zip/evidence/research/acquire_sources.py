from pathlib import Path
import urllib.request, hashlib, json, datetime
root=Path(__file__).parent
out=root/'source-snapshots'
out.mkdir(exist_ok=True)
sources={
 'alert-doc.html':'https://docs.tabler.io/ui/components/alert',
 'toast-doc.html':'https://docs.tabler.io/ui/components/toast',
 'validation-doc.html':'https://docs.tabler.io/ui/forms/validation',
 'header-doc.html':'https://docs.tabler.io/ui/layout/page-headers',
 'form-elements.html':'https://preview.tabler.io/form-elements.html',
 'alerts.html':'https://preview.tabler.io/alerts.html',
 'toasts.html':'https://preview.tabler.io/toasts.html',
}
records=[]
for name,url in sources.items():
 try:
  with urllib.request.urlopen(url,timeout=25) as response:
   data=response.read()
   record={'url':url,'resolved_url':response.url,'status':response.status,'headers':dict(response.headers),'file':str(out/name),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
   (out/name).write_bytes(data)
   if name in ('form-elements.html','alerts.html','toasts.html'):
    (root/'baseline-app'/name).write_bytes(data)
   records.append(record)
 except Exception as e:
  records.append({'url':url,'error':repr(e)})
print(json.dumps(records,ensure_ascii=False,indent=2))
(root/'source-snapshots/acquisition.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))

