from pathlib import Path
import json,re,shutil,hashlib
root=Path(__file__).parent
alert=json.loads((root/'tool-012-tagged-alert-docs.json').read_text())['result']['structuredContent']['content']
validation=json.loads((root/'tool-011-source-0.json').read_text())['value']['structuredContent']['content']
def example(section,n=0):
    return re.findall(r'<Example(?: column)?>\s*(.*?)\s*</Example>',section,re.S)[n]
def section(doc,name):
    return doc.split('## '+name+'\n',1)[1].split('\n## ',1)[0]
error=example(section(alert,'Alert links'),1)
minor=example(section(alert,'Minor alerts'))
field=example(section(validation,'Validation feedback'))
valid=example(section(validation,'Validation feedback'),1)
html='''<!doctype html><html lang="en" data-bs-theme="light"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Source specimen — Tabler 1.7.1</title><link href="./dist/css/tabler.min.css" rel="stylesheet"></head><body><div class="page"><div class="page-wrapper"><div class="page-header d-print-none"><div class="container-xl"><div class="row g-2 align-items-center"><div class="col"><div class="page-pretitle">Research trial · source markup unchanged</div><h2 class="page-title">Tabler 1.7.1: validation and alerts</h2><div class="text-secondary mt-1">Local source specimen, not the public demo or a product design.</div></div><div class="col-auto ms-auto d-print-none"><div class="btn-list"><button class="btn" type="button">Header action</button></div></div></div></div></div><div class="page-body"><div class="container-xl"><div class="row row-cards"><div class="col-md-6"><div class="card"><div class="card-header"><h3 class="card-title">Field-local feedback</h3></div><div class="card-body"><div class="mb-3">'''+field+'''</div>'''+valid+'''</div></div></div><div class="col-md-6"><div class="card"><div class="card-header"><h3 class="card-title">Operation feedback variants</h3></div><div class="card-body">'''+error+minor+'''</div></div></div></div></div></div></div></div></body></html>'''
(root/'baseline-app/source-specimen.html').write_text(html)
snapshot=root.parent.parent/'sources/official-settings-snapshot.html'
shutil.copyfile(snapshot,root/'baseline-app/official-settings-snapshot.html')
record={'revision':'07f60c07da13d8ff957a370434b7ef5c86f5ab94','specimen':'baseline-app/source-specimen.html','parts':{'validation':'docs/content/ui/forms/validation.mdx: Validation feedback examples, exact markup','alerts':'docs/content/ui/components/alert.mdx: Alert links second example and Minor alerts, exact markup','wrapper':'Native page-header/row/card grid composition based on PageHeader.astro and form-elements.astro; contextual research labels and action label are adaptations'},'stylesheet':'copied app/dist/css/tabler.min.css @tabler/core 1.7.1','original_snapshot':{'path':'baseline-app/official-settings-snapshot.html','sha256':hashlib.sha256(snapshot.read_bytes()).hexdigest()},'limitations':['Not the original deployed public demo','No product code or controller changes','Source specimen has no application behavior or persistence','Original snapshot has unchanged HTML; browser blocks nonlocal requests during local observation']}
(root/'source-specimen-provenance.json').write_text(json.dumps(record,ensure_ascii=False,indent=2))
print(json.dumps(record,ensure_ascii=False))
