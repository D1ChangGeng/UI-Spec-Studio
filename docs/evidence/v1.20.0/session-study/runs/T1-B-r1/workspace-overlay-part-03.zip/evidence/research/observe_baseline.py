from pathlib import Path
from playwright.sync_api import sync_playwright
import json,time,hashlib
ROOT=Path(__file__).parent
OUT=ROOT/'captures'
OUT.mkdir(exist_ok=True)
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
LONG='跨城市田野研究协作小组 — Longitudinal everyday-mobility research programme'
records=[]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=BROWSER,headless=True)
 def make(width,height,theme,lang,fail=False):
  ctx=browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1,locale='zh-CN' if lang=='zh' else 'en-US')
  page=ctx.new_page()
  page.goto(f'http://127.0.0.1:4412/?theme={theme}&lang={lang}'+('&fail=once' if fail else ''),wait_until='networkidle')
  page.evaluate('document.fonts.ready')
  page.evaluate("""async()=>{window.researchEvents=[]; const s=await import('./settings-store.js');s.subscribeSettings(e=>window.researchEvents.push({at:performance.now(),status:e.status,operationId:e.operationId,snapshot:e.snapshot,settings:e.settings,fieldErrors:e.fieldErrors}));}""")
  return ctx,page
 def capture(page,name):
  t0=time.monotonic()
  page.screenshot(path=str(OUT/(name+'.png')),full_page=False)
  t1=time.monotonic()
  state=page.evaluate("""()=>({url:location.href,viewport:{w:innerWidth,h:innerHeight},scrollY,theme:document.documentElement.dataset.bsTheme,lang:document.documentElement.lang,status:document.getElementById('save-status').textContent,statusRect:document.getElementById('save-status').getBoundingClientRect().toJSON(),active:document.activeElement.id,saveDisabled:document.getElementById('save-settings').disabled,draft:window.fieldnotes.draft(),persisted:window.fieldnotes.readSettings(),events:window.researchEvents,fields:[...document.querySelectorAll('#business-name,#business-id,#location,#email')].map(e=>({id:e.id,value:e.value,classes:e.className,ariaInvalid:e.getAttribute('aria-invalid'),describedBy:e.getAttribute('aria-describedby'),rect:e.getBoundingClientRect().toJSON()}))})""")
  record={'capture':name+'.png','capture_monotonic_bracket':[t0,t1],**state}
  records.append(record)
  print(json.dumps(record,ensure_ascii=False))
 ctx,page=make(1440,900,'light','en')
 capture(page,'baseline-1440-light-en')
 page.locator('#business-name').fill(LONG)
 capture(page,'baseline-1440-long-name')
 ctx.close()
 ctx,page=make(1280,600,'light','en',True)
 capture(page,'baseline-1280-light-en-top')
 page.locator('#business-name').fill('')
 page.locator('#email').fill('incomplete')
 page.locator('#save-settings').click()
 capture(page,'baseline-1280-invalid-at-footer')
 page.locator('#business-name').fill('林玫')
 page.locator('#email').fill('mei.lin@example.invalid')
 page.locator('#save-settings').click()
 capture(page,'baseline-1280-pending-at-footer')
 page.wait_for_function("document.getElementById('save-status').dataset.state==='error'")
 capture(page,'baseline-1280-error-at-footer')
 page.locator('#save-settings').click()
 page.wait_for_function("document.getElementById('save-status').dataset.state==='success'")
 capture(page,'baseline-1280-retry-success-at-footer')
 page.locator('#business-name').fill('Submitted snapshot')
 page.locator('#save-settings').click()
 page.locator('#business-name').fill('Newer unsaved draft')
 capture(page,'baseline-1280-new-edit-during-pending')
 page.wait_for_function("document.getElementById('save-status').dataset.state==='success'")
 capture(page,'baseline-1280-success-with-unsaved-edit')
 page.locator('#language-toggle').click()
 page.wait_for_load_state('networkidle')
 page.evaluate('document.fonts.ready')
 capture(page,'baseline-language-switch-reloads-saved-value')
 ctx.close()
 ctx,page=make(390,844,'dark','zh')
 capture(page,'baseline-390-dark-zh-top')
 page.locator('#business-name').fill(LONG)
 capture(page,'baseline-390-dark-zh-long-name-focus')
 page.locator('#save-settings').scroll_into_view_if_needed()
 capture(page,'baseline-390-dark-zh-footer')
 ctx.close()
 browser.close()
(ROOT/'baseline-observations.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
print(json.dumps({'captures':len(records),'index':'baseline-observations.json'}))

