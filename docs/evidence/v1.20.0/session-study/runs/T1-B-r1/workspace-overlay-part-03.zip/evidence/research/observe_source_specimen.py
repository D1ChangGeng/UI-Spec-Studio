from pathlib import Path
from playwright.sync_api import sync_playwright
import json,time
root=Path(__file__).parent
out=root/'captures'
records=[]
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True)
    for name,url,width,height,theme in [('source-specimen-1440-light','source-specimen.html',1440,900,'light'),('source-specimen-1280-dark','source-specimen.html',1280,600,'dark'),('source-specimen-390-dark','source-specimen.html',390,844,'dark'),('official-snapshot-local-1440-light','official-settings-snapshot.html',1440,900,'light')]:
        c=b.new_context(viewport={'width':width,'height':height},device_scale_factor=1)
        page=c.new_page()
        blocked=[]; failed=[]
        def route(r):
            if r.request.url.startswith('http://127.0.0.1:4412/') or r.request.url.startswith('data:'):r.continue_()
            else:blocked.append(r.request.url);r.abort()
        page.route('**/*',route)
        page.on('response',lambda r:failed.append({'url':r.url,'status':r.status}) if r.status>=400 else None)
        page.goto('http://127.0.0.1:4412/'+url,wait_until='networkidle')
        page.evaluate('(theme)=>document.documentElement.dataset.bsTheme=theme',theme)
        page.evaluate('document.fonts.ready')
        t0=time.monotonic();page.screenshot(path=str(out/(name+'.png')));t1=time.monotonic()
        records.append({'capture':name+'.png','url':page.url,'viewport':{'width':width,'height':height},'theme':theme,'capture_monotonic_bracket':[t0,t1],'blocked_external':blocked,'failed_local_requests':failed,'fields':page.locator('input').evaluate_all('(els)=>els.map(e=>({id:e.id,ariaInvalid:e.getAttribute("aria-invalid"),describedBy:e.getAttribute("aria-describedby")}))')})
        c.close()
    b.close()
(root/'source-observations.json').write_text(json.dumps(records,indent=2))
print(json.dumps(records))
