from pathlib import Path
import json, time, os
from playwright.sync_api import sync_playwright

root=Path(__file__).resolve().parents[2]
out=root/'evidence/baseline';out.mkdir(exist_ok=True)
for name in ['index.html','settings-controller.js','settings-store.js']:
    (out/name).write_bytes((root/'app'/name).read_bytes())
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
    log=[]
    for name,w,h,theme,lang in [('light-en',1440,900,'light','en'),('dark-zh-compact',1280,600,'dark','zh'),('narrow-en',390,844,'light','en')]:
        page=browser.new_page(viewport={'width':w,'height':h},device_scale_factor=1)
        errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto(f'http://127.0.0.1:4402/?theme={theme}&lang={lang}',wait_until='networkidle')
        page.evaluate('document.fonts.ready')
        page.screenshot(path=str(out/f'{name}.png'))
        log.append({'name':name,'viewport':[w,h],'theme':page.locator('html').get_attribute('data-bs-theme'),'errors':errors,'time':time.time(),'bodyHeight':page.locator('body').evaluate('(el)=>el.scrollHeight')})
        page.close()
    browser.close()
(out/'results.json').write_text(json.dumps(log,ensure_ascii=False,indent=2))
print(json.dumps(log,ensure_ascii=False))
