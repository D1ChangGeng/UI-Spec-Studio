from pathlib import Path
from playwright.sync_api import sync_playwright,expect
import json,time,hashlib
root=Path(__file__).resolve().parents[2];out=root/'evidence/final-captures';out.mkdir(exist_ok=False)
log={'revision':{n:hashlib.sha256((root/'app'/n).read_bytes()).hexdigest() for n in ['index.html','settings-controller.js','settings-store.js']},'conditions':[]}
long='跨城市田野研究协作小组 — Longitudinal everyday-mobility research programme'
def snap(page,folder,name):
 a=time.time();page.screenshot(path=str(folder/f'{name}.png'));return {'file':str((folder/f'{name}.png').relative_to(root)),'start':a,'end':time.time(),'scroll':page.evaluate('scrollY'),'focus':page.evaluate('document.activeElement.id'),'status':page.locator('#save-status').inner_text()}
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 for width,height in [(1440,900),(1280,600),(390,844)]:
  for theme in ['light','dark']:
   for lang in ['en','zh']:
    name=f'{width}x{height}-{theme}-{lang}';folder=out/name;folder.mkdir()
    page=b.new_page(viewport={'width':width,'height':height},device_scale_factor=1)
    page.goto(f'http://127.0.0.1:4402/?theme={theme}&lang={lang}&fail=once',wait_until='networkidle');page.evaluate('document.fonts.ready')
    assert page.locator('.btn-floating').count()==0
    frames=[snap(page,folder,'initial')]
    page.locator('#business-name').fill(long);page.locator('#business-name').press('Home')
    frames.append(snap(page,folder,'long-content'))
    page.locator('#business-name').fill('')
    page.locator('#save-settings').click();expect(page.locator('#save-status')).to_have_attribute('data-state','invalid')
    frames.append(snap(page,folder,'invalid-focus'))
    page.locator('#business-name').fill(long)
    page.locator('#save-settings').click();expect(page.locator('#save-status')).to_have_attribute('data-state','pending')
    frames.append(snap(page,folder,'pending'))
    expect(page.locator('#save-status')).to_have_attribute('data-state','error');frames.append(snap(page,folder,'failed'))
    page.locator('#save-settings').click();expect(page.locator('#save-status')).to_have_attribute('data-state','success');frames.append(snap(page,folder,'success'))
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
    log['conditions'].append({'name':name,'frames':frames,'result':'pass'})
    (out/'results.json').write_text(json.dumps(log,ensure_ascii=False,indent=2))
    print(name+' captured',flush=True);page.close()
 b.close()
assert (root/'app/settings-store.js').read_bytes()==(root/'evidence/baseline/settings-store.js').read_bytes()
log['authoritative_store_unchanged']=True
(out/'results.json').write_text(json.dumps(log,ensure_ascii=False,indent=2))
print('Final capture and source-integrity check passed.')
