from pathlib import Path
from playwright.sync_api import sync_playwright
import json
root=Path(__file__).resolve().parents[2];out=root/'evidence/narrow-diagnosis';out.mkdir(exist_ok=True)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':390,'height':844})
 page.goto('http://127.0.0.1:4402/?theme=light&lang=en',wait_until='networkidle')
 page.evaluate("window.events=[];for(const n of ['pointerdown','pointerup','click','blur','focus','submit']) document.addEventListener(n,e=>events.push({type:n,id:e.target.id,related:e.relatedTarget?.id,time:performance.now(),saveY:document.querySelector('#save-settings').getBoundingClientRect().top}),true)")
 for id,val in [('business-name',''),('email','bad'),('business-id','x'*181),('location','x'*101)]:page.locator('#'+id).fill(val)
 page.locator('#save-settings').scroll_into_view_if_needed()
 page.screenshot(path=str(out/'before-click.png'))
 page.locator('#save-settings').click();page.wait_for_timeout(100)
 page.screenshot(path=str(out/'after-click.png'))
 data=page.evaluate("({events,status:document.querySelector('#save-status').dataset.state,styles:Object.fromEntries(['save-status','email-error','business-name'].map(id=>{let s=getComputedStyle(document.getElementById(id));return[id,{color:s.color,background:s.backgroundColor,border:s.borderColor,boxShadow:s.boxShadow}]}))})")
 (out/'results.json').write_text(json.dumps(data,indent=2));print(json.dumps(data,indent=2));b.close()
