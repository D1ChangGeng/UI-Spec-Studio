from pathlib import Path
from playwright.sync_api import sync_playwright,expect
import json,time,hashlib
root=Path(__file__).resolve().parents[2];out=root/'evidence/focus-recheck';out.mkdir(exist_ok=False)
log={'revision':{n:hashlib.sha256((root/'app'/n).read_bytes()).hexdigest() for n in ['index.html','settings-controller.js','settings-store.js']},'runs':[]}
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 for width,height,theme,lang in [(1280,600,'light','en'),(1280,600,'dark','zh'),(390,844,'light','en'),(390,844,'dark','zh')]:
  name=f'{width}-{theme}-{lang}';folder=out/name;folder.mkdir()
  page=b.new_page(viewport={'width':width,'height':height},device_scale_factor=1)
  page.goto(f'http://127.0.0.1:4402/?theme={theme}&lang={lang}&fail=once',wait_until='networkidle')
  page.keyboard.press('Tab');page.keyboard.press('Enter')
  for i in range(30):
   if page.evaluate('document.activeElement.id')=='business-name':break
   page.keyboard.press('Tab');page.wait_for_timeout(80)
  assert page.evaluate('document.activeElement.id')=='business-name'
  page.keyboard.press('Control+A');page.keyboard.type('Lin / 林玫')
  for i in range(12):
   if page.evaluate('document.activeElement.id')=='save-settings':break
   page.keyboard.press('Tab');page.wait_for_timeout(80)
  assert page.evaluate('document.activeElement.id')=='save-settings'
  page.wait_for_timeout(450);page.screenshot(path=str(folder/'01-focused-save.png'))
  page.keyboard.press('Enter');expect(page.locator('#save-status')).to_have_attribute('data-state','pending')
  page.screenshot(path=str(folder/'02-pending.png'))
  expect(page.locator('#save-status')).to_have_attribute('data-state','error')
  assert page.evaluate('document.activeElement.id')=='save-settings'
  page.screenshot(path=str(folder/'03-focused-retry.png'))
  page.keyboard.press('Enter');expect(page.locator('#save-status')).to_have_attribute('data-state','success')
  assert page.evaluate('document.activeElement.id')=='save-settings'
  page.screenshot(path=str(folder/'04-focused-success.png'))
  page.locator('#business-name').fill('submitted')
  page.locator('#save-settings').click()
  page.locator('#business-name').fill('newer draft')
  expect(page.locator('#save-status')).to_have_attribute('data-state','success')
  assert page.evaluate('document.activeElement.id')=='business-name'
  assert page.evaluate('window.fieldnotes.readSettings().displayName')=='submitted'
  assert page.locator('#business-name').input_value()=='newer draft'
  colors=page.locator('#save-status').evaluate("el=>{const c=document.createElement('canvas').getContext('2d');const rgb=v=>{c.clearRect(0,0,1,1);c.fillStyle=v;c.fillRect(0,0,1,1);return [...c.getImageData(0,0,1,1).data]};const s=getComputedStyle(el);return{fg:rgb(s.color),bg:rgb(s.backgroundColor)}}")
  log['runs'].append({'name':name,'result':'pass','focusReturnedAfterFailure':True,'retryByImmediateEnter':True,'focusReturnedAfterSuccess':True,'newerEditFocusPreserved':True,'colors':colors})
  print(name+' passed',flush=True);page.close()
 b.close()
(out/'results.json').write_text(json.dumps(log,ensure_ascii=False,indent=2))
print('Focused retry and no-focus-steal checks passed.')
