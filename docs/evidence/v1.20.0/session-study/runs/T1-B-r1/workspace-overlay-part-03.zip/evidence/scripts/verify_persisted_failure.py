from pathlib import Path
from playwright.sync_api import sync_playwright,expect
import json,time
root=Path(__file__).resolve().parents[2];out=root/'evidence/persisted-failure';out.mkdir(exist_ok=False)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900})
 page.goto('http://127.0.0.1:4402/?theme=light&lang=en',wait_until='networkidle')
 page.locator('#business-name').fill('Li');page.locator('#save-settings').click()
 expect(page.locator('#save-status')).to_have_attribute('data-state','success')
 saved=page.evaluate("localStorage.getItem('fieldnotes-settings-v1')")
 page.locator('#business-name').fill('Pending bilingual draft / 待保存草稿')
 page.evaluate('window.fieldnotes.setFailureMode(true)')
 page.locator('#save-settings').click();expect(page.locator('#save-status')).to_have_attribute('data-state','pending')
 t=time.time();page.locator('#language-toggle').press('Enter')
 expect(page.locator('html')).to_have_attribute('lang','zh-CN')
 during_locale=page.locator('#save-status').get_attribute('data-state')
 page.locator('#theme-toggle').press('Enter');expect(page.locator('html')).to_have_attribute('data-bs-theme','dark')
 during_theme=page.locator('#save-status').get_attribute('data-state')
 expect(page.locator('#save-status')).to_have_attribute('data-state','error')
 assert page.evaluate("localStorage.getItem('fieldnotes-settings-v1')")==saved
 assert page.locator('#business-name').input_value()=='Pending bilingual draft / 待保存草稿'
 page.locator('#save-settings').scroll_into_view_if_needed();page.screenshot(path=str(out/'failed-preserved.png'))
 page.locator('#save-settings').press('Enter');expect(page.locator('#save-status')).to_have_attribute('data-state','success')
 assert page.evaluate('window.fieldnotes.readSettings().displayName')=='Pending bilingual draft / 待保存草稿'
 page.locator('#business-name').fill('x'*101);page.locator('#save-settings').click()
 expect(page.locator('#save-status')).to_have_attribute('data-state','invalid')
 assert page.locator('#business-name-error').inner_text()=='请使用不超过 100 个字符。'
 assert page.evaluate('window.fieldnotes.readSettings().displayName')=='Pending bilingual draft / 待保存草稿'
 result={'savedValuePreservedAcrossFailure':True,'draftPreserved':True,'localeSwitchState':during_locale,'themeSwitchState':during_theme,'retrySavedDraft':True,'name101RejectedWithoutMutation':True}
 assert during_locale=='pending' and during_theme=='pending'
 (out/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False));b.close()
