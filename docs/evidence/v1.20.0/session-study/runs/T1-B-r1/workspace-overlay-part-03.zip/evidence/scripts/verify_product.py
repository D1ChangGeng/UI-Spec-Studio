from pathlib import Path
import json,time,hashlib,traceback
from playwright.sync_api import sync_playwright, expect

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'evidence/final-run-01';OUT.mkdir(exist_ok=False)
LONG='跨城市田野研究协作小组 — Longitudinal everyday-mobility research programme'
report={'source':{n:hashlib.sha256((ROOT/'app'/n).read_bytes()).hexdigest() for n in ['index.html','settings-controller.js','settings-store.js']},'conditions':[], 'episodes':[], 'errors':[]}
def capture(page,folder,name):
    before=time.time()
    page.screenshot(path=str(folder/f'{name}.png'))
    return {'frame':str((folder/f'{name}.png').relative_to(ROOT)), 'captureStart':before,'captureEnd':time.time(),'scrollY':page.evaluate('scrollY'),'activeElement':page.evaluate('document.activeElement.id'),'status':page.locator('#save-status').inner_text()}

try:
  with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
    for width,height in [(1440,900),(1280,600),(390,844)]:
      for theme in ['light','dark']:
        for lang in ['en','zh']:
          label=f'{width}x{height}-{theme}-{lang}'
          folder=OUT/label;folder.mkdir()
          context=browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1)
          page=context.new_page()
          page.on('pageerror',lambda error:report['errors'].append(str(error)))
          page.goto(f'http://127.0.0.1:4402/?theme={theme}&lang={lang}&fail=once',wait_until='networkidle')
          page.evaluate('document.fonts.ready')
          expect(page.locator('html')).to_have_attribute('data-bs-theme',theme)
          frames=[capture(page,folder,'01-initial')]
          assert page.evaluate('document.documentElement.scrollWidth <= innerWidth'),label+' overflows'
          page.locator('#business-name').fill(LONG)
          page.locator('#business-name').press('Home')
          frames.append(capture(page,folder,'02-long-name'))
          # Every store field error, real submit, no storage mutation.
          page.locator('#business-name').fill('')
          page.locator('#email').fill('incomplete')
          page.locator('#business-id').fill('x'*181)
          page.locator('#location').fill('x'*101)
          page.locator('#save-settings').click()
          expect(page.locator('#save-status')).to_have_attribute('data-state','invalid')
          assert page.evaluate('document.activeElement.id')=='business-name'
          assert page.locator('.is-invalid').count()==4
          assert page.evaluate("localStorage.getItem('fieldnotes-settings-v1')") is None
          for id in ['business-name','business-id','location','email']:
            expect(page.locator('#'+id)).to_have_attribute('aria-invalid','true')
            assert id+'-error' in page.locator('#'+id).get_attribute('aria-describedby')
          frames.append(capture(page,folder,'03-invalid'))
          page.locator('#business-name').fill(LONG)
          page.locator('#business-id').fill('Fieldnotes Research / 城市日常研究小组')
          page.locator('#location').fill('Singapore / 新加坡')
          page.locator('#email').fill('mei.lin@example.invalid')
          page.locator('#weekly-digest').uncheck()
          page.locator('#public-profile').check()
          submitted=page.evaluate('window.fieldnotes.draft()')
          started=time.time();page.locator('#save-settings').click()
          expect(page.locator('#save-status')).to_have_attribute('data-state','pending')
          assert page.locator('#cancel-settings').is_disabled()
          frames.append(capture(page,folder,'04-pending'))
          expect(page.locator('#save-status')).to_have_attribute('data-state','error')
          assert page.evaluate("localStorage.getItem('fieldnotes-settings-v1')") is None
          assert page.evaluate('window.fieldnotes.draft()')==submitted
          frames.append(capture(page,folder,'05-failure'))
          page.locator('#save-settings').click()
          expect(page.locator('#save-status')).to_have_attribute('data-state','success')
          assert page.evaluate('window.fieldnotes.readSettings()')==submitted
          frames.append(capture(page,folder,'06-retry-success'))
          # A submitted snapshot must not overwrite a newer edit.
          page.locator('#business-name').fill('Li')
          page.locator('#save-settings').click()
          expect(page.locator('#save-status')).to_have_attribute('data-state','pending')
          page.locator('#business-name').fill('Lin / 林玫 — newer draft')
          expect(page.locator('#save-status')).to_have_attribute('data-state','success')
          assert page.evaluate('window.fieldnotes.readSettings().displayName')=='Li'
          assert page.locator('#business-name').input_value()=='Lin / 林玫 — newer draft'
          assert ('newer' in page.locator('#save-status').inner_text()) if lang=='en' else ('新编辑' in page.locator('#save-status').inner_text())
          page.locator('#save-settings').scroll_into_view_if_needed()
          frames.append(capture(page,folder,'07-snapshot-success-new-draft'))
          before=page.evaluate('window.fieldnotes.draft()')
          page.locator('#language-toggle').click();page.locator('#theme-toggle').click()
          assert page.evaluate('window.fieldnotes.draft()')==before
          page.locator('#language-toggle').click();page.locator('#theme-toggle').click()
          assert page.evaluate('window.fieldnotes.draft()')==before
          page.locator('#cancel-settings').click()
          assert page.locator('#business-name').input_value()=='Li'
          assert page.locator('.is-invalid').count()==0
          page.reload(wait_until='networkidle')
          assert page.locator('#business-name').input_value()=='Li'
          assert page.locator('#weekly-digest').is_checked() is False
          assert page.locator('#public-profile').is_checked() is True
          page.locator('a[href="#privacy-heading"]').click()
          assert page.evaluate('document.activeElement.id')=='privacy-heading'
          page.locator('a[href="#profile-heading"]').click()
          assert page.evaluate('document.activeElement.id')=='profile-heading'
          frames.append(capture(page,folder,'08-return-profile'))
          report['conditions'].append({'label':label,'frames':frames,'result':'pass','checks':['all-field-errors','focus','no-invalid-persistence','failure-retains-draft','retry','snapshot-vs-new-edits','locale-theme-draft-retention','cancel','reload','navigation-return','no-horizontal-page-overflow']})
          (OUT/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
          print(label+' passed',flush=True)
          context.close()
    # Keyboard-only route from skip link through edit, invalid, failed save and retry.
    context=browser.new_context(viewport={'width':1280,'height':600},device_scale_factor=1)
    page=context.new_page();page.goto('http://127.0.0.1:4402/?theme=dark&lang=zh&fail=once',wait_until='networkidle')
    folder=OUT/'keyboard';folder.mkdir()
    steps=[]
    def tab_to(id):
      for i in range(55):
        current=page.evaluate('document.activeElement.id')
        steps.append(current)
        if current==id:return
        page.keyboard.press('Tab')
      raise AssertionError('Keyboard could not reach '+id)
    page.keyboard.press('Tab');page.keyboard.press('Enter')
    tab_to('business-name')
    page.keyboard.press('Control+A');page.keyboard.press('Backspace');page.keyboard.press('Enter')
    expect(page.locator('#save-status')).to_have_attribute('data-state','invalid')
    assert page.evaluate('document.activeElement.id')=='business-name'
    keyframes=[capture(page,folder,'01-invalid-focus')]
    page.keyboard.type('Lin')
    tab_to('email');page.keyboard.press('Control+A');page.keyboard.type('lin@example.invalid')
    tab_to('weekly-digest');page.keyboard.press('Space')
    tab_to('public-profile');page.keyboard.press('Space')
    tab_to('save-settings');keyframes.append(capture(page,folder,'02-save-focus'))
    page.keyboard.press('Enter')
    expect(page.locator('#save-status')).to_have_attribute('data-state','error')
    keyframes.append(capture(page,folder,'03-error'))
    tab_to('save-settings');page.keyboard.press('Enter')
    expect(page.locator('#save-status')).to_have_attribute('data-state','success')
    assert page.evaluate('window.fieldnotes.readSettings().displayName')=='Lin'
    keyframes.append(capture(page,folder,'04-success'))
    report['keyboard']={'result':'pass','focusSequence':steps,'frames':keyframes}
    context.close();browser.close()
except Exception as e:
  report['failure']={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
  print(traceback.format_exc())
finally:
  (OUT/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
  print(json.dumps({'conditions':len(report['conditions']),'errors':report['errors'],'failure':report.get('failure'),'keyboard':report.get('keyboard',{}).get('result')},ensure_ascii=False))
if report.get('failure'):raise SystemExit(1)
