from pathlib import Path
from playwright.sync_api import sync_playwright,expect
import json,hashlib,time
root=Path(__file__).resolve().parents[2];out=root/'evidence/state-presentation-final';out.mkdir(exist_ok=False)
log={'revision':{n:hashlib.sha256((root/'app'/n).read_bytes()).hexdigest() for n in ['index.html','settings-controller.js','settings-store.js']},'runs':[]}
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 for w,h,theme,lang in [(1440,900,'light','en'),(1280,600,'dark','zh'),(390,844,'light','zh'),(390,844,'dark','en')]:
  name=f'{w}-{theme}-{lang}';folder=out/name;folder.mkdir()
  page=b.new_page(viewport={'width':w,'height':h})
  page.goto(f'http://127.0.0.1:4402/?theme={theme}&lang={lang}&fail=once',wait_until='networkidle')
  page.locator('#business-name').fill('');page.locator('#save-settings').click();expect(page.locator('#save-status')).to_have_attribute('data-state','invalid')
  rect=page.locator('#business-name').bounding_box()
  assert rect['y']>=0 and rect['y']+rect['height']<h
  assert page.evaluate('document.activeElement.id')=='business-name'
  page.screenshot(path=str(folder/'invalid-visible-focus.png'))
  page.locator('#business-name').fill('Lin / 林玫');page.locator('#save-settings').click();expect(page.locator('#save-status')).to_have_attribute('data-state','pending')
  assert page.locator('#save-settings span').evaluate("el=>getComputedStyle(el).opacity")=='0'
  page.screenshot(path=str(folder/'pending-spinner.png'))
  expect(page.locator('#save-status')).to_have_attribute('data-state','error');assert page.evaluate('document.activeElement.id')=='save-settings'
  page.keyboard.press('Enter');expect(page.locator('#save-status')).to_have_attribute('data-state','success')
  assert page.evaluate('document.activeElement.id')=='save-settings'
  log['runs'].append({'name':name,'result':'pass','invalidFocusRect':rect,'pendingLabelOpacity':0,'retryByEnter':True})
  print(name+' passed',flush=True);page.close()
 b.close()
(out/'results.json').write_text(json.dumps(log,ensure_ascii=False,indent=2))
