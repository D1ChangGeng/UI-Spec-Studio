import asyncio,json,hashlib,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=BROWSER,headless=True,args=['--no-sandbox'])
  page=await browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
  await page.goto('http://127.0.0.1:4403/?theme=light&lang=en')
  await page.evaluate('document.fonts.ready')
  await page.screenshot(path=str(ROOT/'evidence/baseline-light-en.png'))
  print(json.dumps({'viewport':[1440,900],'url':page.url,'title':await page.title(),'theme':await page.locator('html').get_attribute('data-bs-theme'),'h1':await page.locator('h1').all_text_contents(),'scrollHeight':await page.evaluate('document.documentElement.scrollHeight'),'sha256':hashlib.sha256((ROOT/'app/index.html').read_bytes()).hexdigest()}))
  await page.set_viewport_size({'width':390,'height':844})
  await page.screenshot(path=str(ROOT/'evidence/baseline-narrow-en.png'))
  await browser.close()
asyncio.run(main())
