import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
  for theme in ['light','dark']:
   c=await b.new_context(viewport={'width':1280,'height':600});page=await c.new_page();await page.goto(f'http://127.0.0.1:4403/?theme={theme}');await page.wait_for_function('window.fieldnotes')
   print(json.dumps(await page.evaluate('''() => {
    const ctx=document.createElement('canvas').getContext('2d');
    const rgb=css=>{ctx.clearRect(0,0,1,1);ctx.fillStyle=css;ctx.fillRect(0,0,1,1);return [...ctx.getImageData(0,0,1,1).data].slice(0,3)};
    const lum=a=>a.map(v=>v/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4).reduce((s,v,i)=>s+v*[.2126,.7152,.0722][i],0);
    const base=rgb(getComputedStyle(document.querySelector('#settings-form').closest('.card')).backgroundColor);
    const ratio=c=>{const [a,b]=[lum(c),lum(base)].sort((a,b)=>b-a);return (a+.05)/(b+.05)};
    const status=document.querySelector('#save-status');const rows=[];
    for(const state of ['info','danger','success']) {
      status.className=`alert alert-minor alert-${state} mb-3`;const before=rgb(getComputedStyle(status).color);
      status.classList.add(`text-${state}-emphasis`);const after=rgb(getComputedStyle(status).color);
      rows.push({state,before,after,background:base,before_ratio:ratio(before),after_ratio:ratio(after)});
    }
    return {theme:document.documentElement.dataset.bsTheme,kind:'temporary source-class color comparison, no product mutation',rows};
   }''')))
   await c.close()
  await b.close()
asyncio.run(main())
