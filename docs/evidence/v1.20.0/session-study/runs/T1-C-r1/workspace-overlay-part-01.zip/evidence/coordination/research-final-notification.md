# Fieldnotes settings — research report

Saved report: [FINAL.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w03/evidence/research/FINAL.md)  
Visual inspection account: [VISUAL-REVIEW.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w03/evidence/research/VISUAL-REVIEW.md)

## Decision-useful outcome

The supplied Tabler settings page remains a suitable mature foundation. The consequential gaps are feedback placement, accurate save semantics, field association, and compact navigation. The evidence supports completing those relationships with Tabler’s existing alert, validation, button, grid, and collapse families. No replacement visual system is indicated by this bounded inquiry. Final product decisions and integrated acceptance remain with the primary designer.

## Actual observations

These observations concern the **pre-repair app**, captured at **20:30 UTC on 31 October 2026**. The command record begins at 20:29:59.758692 UTC, and the first screenshot epoch converts to 20:30:00.935471 UTC. The HTTP server log’s unqualified 16:30 timestamp was not UTC; the earlier report interpretation was corrected without changing original evidence. These observations do not describe the parent’s subsequent implementation.

| Observed relationship | Evidence and implication |
|---|---|
| At 1280×600, Save is in a separate card footer; status remains near the form heading. | After an invalid Save click, the browser had scrolled to y=543. The status rectangle was y=-284 to -264, entirely above the viewport. The viewed frame showed no error. Feedback placement therefore obstructed recovery even though status text changed correctly. |
| Invalid display name retained ordinary field styling and no error association. | Captured DOM had no `is-invalid`, `aria-invalid`, or described error. Focus stayed on Save. The service supplied the validation fact, but the UI did not identify the field. |
| Pending, failure, and retry success differed little at the reading position. | The ordered, actually viewed frames show disabled Save during pending, followed by an ordinary enabled button after failure and success. Status remained above the viewport. These are sampled states, not proof of uninterrupted temporal smoothness. |
| New editing during save was permitted but not represented in the result message. | The real service persisted “Saved snapshot”; the current field contained “New edit during pending”; status still said changes were saved. Preserve the service snapshot contract and distinguish later unsaved edits. |
| Switching language reloaded the page and lost an unsaved draft. | After entering the long representative name and activating language, the draft became the previously stored “Saved snapshot.” The parent reports an in-place language repair; this research does not independently verify it. |
| At 390×844 dark/Chinese, settings navigation consumes most of the first screen. | The first viewed frame places the account form heading around y=600; the first editable field is below the viewport. The sidebar’s two groups and the avatar/fixture-control row delay entry into the task. The lower frame confirms the footer is reachable through document scrolling. |
| The original official page has a coherent, restrained family. | The locally rendered official snapshot shows a quarter-width navigation column, shared card surface, consistent section spacing, aligned labels/inputs, and a footer with neutral secondary and blue primary actions. This is direct source-render observation using the supplied 1.7.1 assets. Portrait assets were unavailable. |

The bilingual organization value extends past the visible width of its one-third-width input at 1280. This supports revisiting source grid composition for longer values. It does not establish that every long value must be fully displayed in an unfocused single-line input. The narrow “long” capture did not reveal the input itself; narrow long-field presentation remains for the parent’s integrated check.

## Source-supported candidates and adoption paths

### Persistent form alert versus toast

**Persistent in-flow alert:** Tabler documents ordinary error alerts, an action link, and `alert-minor` for reduced emphasis. The retained exact-tag implementation, `sources/shared/ui/Alert.astro`, supplies the icon, heading, description, optional list, action, and close-button structure. Installed 1.7.1 CSS contains `alert-minor`, `alert-heading`, and `alert-description`. This is the lower-integration-cost candidate for feedback beside Save. Final footer height and wrapping still require direct inspection. [Official alert documentation](https://docs.tabler.io/ui/components/alert). genui{"citation":{"ref":"turn14view2"}}

**Toast:** The supplied `sources/shared/components/demo/Toast.astro` distinguishes polite status from urgent alert and sets autohide false. Its source-defined header, avatar, timestamp, body, and dismiss control introduce a separate notification hierarchy. Official guidance says actionable toasts must not disappear automatically, and the sole recovery action must not exist only inside a toast. A toast therefore remains a supplementary mechanism; it does not remove the need for field errors or a persistent recovery location. No live toast demonstration was successfully viewed in this research. [Official toast documentation](https://docs.tabler.io/ui/components/toast). genui{"citation":{"ref":"turn14view1"}}

**Research judgment:** For this short settings transaction, one persistent footer alert keeps outcome and next action associated without creating a second notification destination. This is a recommendation, not a final product decision. The parent independently reports adopting this route.

### Validation and pending state

Use the authoritative store’s `fieldErrors` with the existing `form-control is-invalid` and sibling `invalid-feedback` pattern. Tabler documents `aria-invalid`, `aria-describedby`, useful correction text, and focus on the first failed field. Bootstrap independently documents associating feedback IDs and permits multiple described-by IDs. Keep validation semantics at the store rather than changing rules to match browser defaults. [Tabler validation](https://docs.tabler.io/ui/forms/validation) · [Bootstrap validation](https://getbootstrap.com/docs/5.3/forms/validation/). genui{"citation":{"refs":["turn12view4","turn12view6"]}}

Tabler’s `btn-loading` hides its label and draws a spinner. Its documented contract also requires an actual disabled control and `aria-busy`; pointer-event suppression alone does not prevent keyboard activation. A spinner beside readable text is another documented candidate. Both relevant CSS classes are present locally. This establishes an available mechanism, not the parent’s final focus or announcement quality. [Tabler buttons](https://docs.tabler.io/ui/components/button). genui{"citation":{"ref":"turn12view5"}}

### Compact navigation and fixture controls

The original settings layout is already a responsive `col-12 col-md-3` / `col-12 col-md-9` composition with a transparent list group. Keep that source responsibility.

Materially different compact candidates within the family are a disclosed list using existing collapse behavior, smaller `list-group-sm` entries, or horizontal list composition. The list documentation supports compact and horizontal variants. Horizontal labels introduce a different wrapping question with the existing longer navigation names and were not trialed here. The parent’s reported `collapse d-md-block` choice preserves the list itself and merits checking disclosure state, keyboard access, section navigation, and the 768px breakpoint. [List group documentation](https://docs.tabler.io/ui/components/list-group). genui{"citation":{"ref":"turn14view0"}}

Moving language/theme fixture controls into the existing page header has a source-supported composition path: Tabler page headers use a title column, action column, and `btn-list`. Preserve the established button scale and heading/action relationship. [Page headers](https://docs.tabler.io/ui/layout/page-headers). genui{"citation":{"ref":"turn14view3"}}

## Provenance and evidence maturity

The foundation is `@tabler/core@1.7.1`, MIT, tag commit `07f60c07da13d8ff957a370434b7ef5c86f5ab94`. The official compiled settings snapshot has SHA-256 `ed80162e38d7667bfe020b5d16d228c4adc64f301233cfbeeeae6f606697a06e`; its public deployment commit is not exposed. The local source render used that exact snapshot, inserted only a base URL to resolve existing local assets, and blocked the external advertising request.

The pre-repair app identities recorded before interaction were:

| File | SHA-256 |
|---|---|
| `app/index.html` | `554e6ffa8165bc3a3bba31ec50a59741716c963a4caf4716206a774a093b2080` |
| `app/settings-controller.js` | `e60170f1f3bdd6b9495c20bd08dc8e5870287dda877266c58c5184ca6942a952` |
| `app/settings-store.js` | `32139de23b4ad411c402620e84d5592f7ccfbcf68cece1a123946c29b63c2da0` |
| `app/dist/css/tabler.min.css` | `dcf84d7b4319c29ab33450bfe2a7bbf607458d994ef71023f7509e912cafdbd5` |

Source possession, class presence, documented behavior, actual baseline operation, and viewed rendering are separate evidence. Current documentation supplies guidance; retained versioned implementation and local CSS govern compatibility. This research child adopted no additional resource, changed no product files, and made no original visual construction.

## Limits and next useful verification

Public live demo inspection failed with `ERR_CERT_AUTHORITY_INVALID`. A separate verified-HTTPS fetch returned HTTP 403, and the connected Browser tool reported no originating browser context. These attempts and returned errors are retained. No TLS verification was disabled. The official snapshot local render is the actual visual reference; public current-document appearance and live alert/toast behavior remain unobserved.

The source-render attempt initially searched for the product label “Save changes”; the original source label is “Submit.” The failed trace, original script, corrected attempt, and separate screenshots are retained.

The parent’s final task is to inspect the integrated repair across requested themes/locales and viewports, including first-invalid focus, pending edit ownership, failure/retry, language/theme switching, reload/return, disclosure, and footer visibility at compact height. This research supplies no final acceptance claim or assistive-technology test.

## Evidence locations

All paths below are under `/workspace/scratch/708e8b7f118e/ui-study/worksets/w03/evidence/research/`.

- `capture-index.json`: source identities, viewport, locale/theme, capture brackets, and current-app frame order.
- `commands/004-browser-inspection/`: original stdout/stderr for real validation, pending, failure, retry, snapshot/draft, and language-switch experiments.
- `screenshots/current-1280-en-invalid.png`: invisible feedback at the actual action position.
- `screenshots/current-390-zh-initial.png` and `current-390-zh-footer.png`: narrow first encounter and scrolled footer.
- `screenshots/original-settings-1440.png` and `original-settings-1280-footer-attempt02.png`: viewed local rendering of the official source.
- `search-001.json`, `web-002.json` through `web-005.json`: original public search/read outputs.
- `commands/001-guidance-search/`, `commands/003-guidance-forms/`: prescribed current guidance search and retrieved forms guide.
- `browser-001.json`, `commands/005-fetch-official/`, `commands/006-render-original/`, and `commands/007-render-original-retry/`: access failures and corrected source-render attempt.
- `source-compatibility-tool.json`: direct local class-presence check.
- `view-*.json`: exact returned image-tool records for every claimed viewed frame.
- `VISUAL-REVIEW.md`: scoped visual inspection account; existence verified.

The isolated research server on port 4133 was stopped. The parent’s port 4403 server was not touched.
