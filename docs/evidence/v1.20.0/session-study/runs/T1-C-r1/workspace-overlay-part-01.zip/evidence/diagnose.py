import asyncio,json
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
  page=await b.new_page();page.on('pageerror',lambda e:print('PAGEERROR',str(e)));page.on('console',lambda e:print('CONSOLE',e.type,e.text))
  await page.goto('http://127.0.0.1:4403/?theme=light&lang=en');await page.wait_for_timeout(300)
  print(await page.evaluate('({api:typeof window.fieldnotes,form:!!document.querySelector("#settings-form"),inputs:[...document.querySelectorAll("#settings-form input,#settings-form textarea")].map(e=>[e.id,e.value]),status:document.querySelector("#save-status").outerHTML})'))
  await page.screenshot(path='evidence/diagnostic.png');await b.close()
asyncio.run(main())
