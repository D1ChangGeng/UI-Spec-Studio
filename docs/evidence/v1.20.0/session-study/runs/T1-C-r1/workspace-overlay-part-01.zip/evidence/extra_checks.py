import asyncio,json,time,hashlib
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'evidence/final-v4';OUT.mkdir(exist_ok=True)
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
LONG='跨城市田野研究协作小组 — Longitudinal everyday-mobility research programme'
log=[]
async def snap(page,name):
 await page.wait_for_timeout(220);before=time.time();await page.screenshot(path=str(OUT/(name+'.png')))
 log.append({'capture':name,'epoch_bracket':[before,time.time()],'scrollY':await page.evaluate('scrollY'),'focus':await page.evaluate('document.activeElement.id'),'status':await page.locator('#save-status').text_content()})
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=BROWSER,headless=True,args=['--no-sandbox'])
  for theme in ['light','dark']:
   for lang in ['en','zh']:
    label=f'390-844-{theme}-{lang}';c=await b.new_context(viewport={'width':390,'height':844});page=await c.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    await page.goto(f'http://127.0.0.1:4403/?theme={theme}&lang={lang}&fail=once');await page.wait_for_function('window.fieldnotes');await page.evaluate('document.fonts.ready')
    await snap(page,label+'-initial')
    assert not await page.locator('.settings').is_visible()
    await page.locator('#business-name').fill(LONG);await page.locator('#business-id').fill(LONG)
    await page.locator('#weekly-digest').press('Space');await page.locator('#public-profile').press('Space')
    assert not await page.locator('#weekly-digest').is_checked();assert await page.locator('#public-profile').is_checked()
    await page.locator('#language-toggle').click();await page.locator('#theme-toggle').click()
    assert await page.locator('#business-name').input_value()==LONG
    assert not await page.locator('#weekly-digest').is_checked();assert await page.locator('#public-profile').is_checked()
    await page.locator('#language-toggle').click();await page.locator('#theme-toggle').click()
    await page.locator('#business-name').scroll_into_view_if_needed();await snap(page,label+'-long')
    await page.locator('#save-settings').click();await page.wait_for_function('document.querySelector("#save-status").dataset.state==="error"')
    await snap(page,label+'-error')
    assert await page.evaluate('window.fieldnotes.readSettings().weeklyDigest')==True
    assert await page.evaluate('window.fieldnotes.readSettings().publicProfile')==False
    await page.locator('#save-settings').click();await page.locator('#language-toggle').click()
    await page.wait_for_function('document.querySelector("#save-status").dataset.state==="success"')
    assert await page.evaluate('window.fieldnotes.readSettings().weeklyDigest')==False
    assert await page.evaluate('window.fieldnotes.readSettings().publicProfile')==True
    await page.locator('#language-toggle').click();await page.locator('#save-settings').scroll_into_view_if_needed();await snap(page,label+'-success')
    await page.reload();await page.wait_for_function('window.fieldnotes')
    assert await page.locator('#business-name').input_value()==LONG
    assert not await page.locator('#weekly-digest').is_checked();assert await page.locator('#public-profile').is_checked()
    await page.locator('#settings-nav-toggle').click();await page.locator('a[href="#privacy-heading"]').click()
    await page.wait_for_function('!document.querySelector("#settings-nav-panel").classList.contains("show") && !document.querySelector("#settings-nav-panel").classList.contains("collapsing")')
    await snap(page,label+'-return')
    assert await page.evaluate('document.activeElement.id')=='privacy-heading'
    assert not errors,errors
    log.append({'scenario':label+'-switches-theme-locale-pending-reload-return','pass':True,'page_errors':errors});await c.close()
  c=await b.new_context(viewport={'width':768,'height':600});page=await c.new_page();await page.goto('http://127.0.0.1:4403/');await page.wait_for_function('window.fieldnotes')
  assert await page.locator('#settings-section-nav').is_visible();assert not await page.locator('#settings-nav-toggle').is_visible()
  await page.set_viewport_size({'width':767,'height':600});assert not await page.locator('#settings-section-nav').is_visible();assert await page.locator('#settings-nav-toggle').is_visible()
  assert await page.evaluate('document.documentElement.scrollWidth <= innerWidth')
  log.append({'scenario':'767-768-collapse-breakpoint','pass':True})
  await page.evaluate('localStorage.setItem("fieldnotes-settings-v1", "broken-fixture")');await page.reload();await page.wait_for_function('window.fieldnotes')
  assert await page.locator('#save-settings').is_disabled();assert await page.locator('#save-status').get_attribute('data-state')=='readError'
  assert await page.evaluate('localStorage.getItem("fieldnotes-settings-v1")')=='broken-fixture'
  log.append({'scenario':'unreadable-storage-preserved','pass':True});await c.close();await b.close()
try:asyncio.run(main())
finally:
 (OUT/'results.json').write_text(json.dumps({'source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'app/index.html',ROOT/'app/settings-controller.js',ROOT/'app/settings-store.js']},'observations':log},ensure_ascii=False,indent=2))
 print(json.dumps({'scenarios_passed':sum(x.get('pass',False) for x in log),'captures':sum('capture' in x for x in log)}))
