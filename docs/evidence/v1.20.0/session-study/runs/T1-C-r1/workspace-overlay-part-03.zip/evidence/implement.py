from pathlib import Path
p=Path('app/index.html'); s=p.read_text()
a=s.index('          <!-- BEGIN PAGE HEADER -->',s.index('<main id="content"'))
b=s.index('        </main>',a)
s=s[:a]+'''          <!-- BEGIN PAGE HEADER -->
          <div class="page-header d-print-none">
            <div class="container-xl">
              <div class="row g-2 align-items-center">
                <div class="col"><h1 class="page-title" data-i18n="accountSettings">Account settings</h1></div>
                <div class="col-auto ms-auto"><div class="btn-list">
                  <button type="button" class="btn btn-sm" id="language-toggle" lang="zh-CN">中文</button>
                  <button type="button" class="btn btn-sm" id="theme-toggle">Use dark theme</button>
                </div></div>
              </div>
            </div>
          </div>
          <!-- END PAGE HEADER -->
          <!-- BEGIN PAGE BODY -->
          <div class="page-body"><div class="container-xl"><div class="card"><div class="row g-0">
            <!-- The original SettingsLayout grid/list family; collapse is narrow-only. -->
            <div class="col-12 col-md-3 border-end">
              <div class="card-body">
                <button class="btn w-100 d-md-none" type="button" id="settings-nav-toggle" data-bs-toggle="collapse" data-bs-target="#settings-nav-panel" aria-expanded="false" aria-controls="settings-nav-panel" data-i18n="sections">Settings sections</button>
                <div class="collapse d-md-block" id="settings-nav-panel">
                  <h2 class="subheader mt-3 mt-md-0" data-i18n="businessSettings">Business settings</h2>
                  <nav aria-label="Settings sections" data-i18n-aria="sections" class="list-group list-group-transparent" id="settings-section-nav">
                    <a href="#profile-heading" class="list-group-item list-group-item-action active d-flex align-items-center" aria-current="location" data-i18n="myAccount">My account</a>
                    <a href="#notifications-heading" class="list-group-item list-group-item-action d-flex align-items-center" data-i18n="myNotifications">My notifications</a>
                    <a href="#privacy-heading" class="list-group-item list-group-item-action d-flex align-items-center" data-i18n="privacy">Privacy</a>
                    <a href="./settings-plan.html" class="list-group-item list-group-item-action d-flex align-items-center" data-i18n="plans">Plans</a>
                    <a href="#" class="list-group-item list-group-item-action d-flex align-items-center" data-i18n="billing">Billing &amp; invoices</a>
                  </nav>
                  <h2 class="subheader mt-4" data-i18n="experience">Experience</h2>
                  <nav aria-label="Experience" data-i18n-aria="experience" class="list-group list-group-transparent">
                    <a href="#" class="list-group-item list-group-item-action" data-i18n="feedback">Give feedback</a>
                  </nav>
                </div>
              </div>
            </div>
            <form id="settings-form" class="col-12 col-md-9 d-flex flex-column" novalidate>
              <div class="card-body">
                <div class="row align-items-center mb-4">
                  <div class="col-auto"><span class="avatar avatar-lg" aria-hidden="true">ML</span></div>
                  <div class="col"><h2 class="mb-1" id="profile-heading" tabindex="-1" data-i18n="myAccount">My account</h2><p class="text-secondary mb-0" data-i18n="localHint">Settings are saved only in this browser.</p></div>
                </div>
                <h3 class="card-title" data-i18n="profileDetails">Profile details</h3>
                <div class="row g-3">
                  <div class="col-12">
                    <label class="form-label required" for="business-name" data-i18n="displayName">Display name</label>
                    <textarea class="form-control" id="business-name" name="displayName" autocomplete="name" rows="1" required aria-describedby="name-help name-error" data-autogrow></textarea>
                    <div class="form-hint" id="name-help" data-i18n="nameHint">Required · up to 100 characters</div><div class="invalid-feedback" id="name-error"></div>
                  </div>
                  <div class="col-12">
                    <label class="form-label" for="business-id" data-i18n="organization">Organization</label>
                    <textarea class="form-control" id="business-id" name="organization" autocomplete="organization" rows="1" aria-describedby="organization-help organization-error" data-autogrow></textarea>
                    <div class="form-hint" id="organization-help" data-i18n="organizationHint">Optional · up to 180 characters</div><div class="invalid-feedback" id="organization-error"></div>
                  </div>
                  <div class="col-md-6">
                    <label class="form-label" for="location" data-i18n="location">Location</label>
                    <input type="text" class="form-control" id="location" name="location" autocomplete="address-level2" aria-describedby="location-help location-error" />
                    <div class="form-hint" id="location-help" data-i18n="locationHint">Optional · up to 100 characters</div><div class="invalid-feedback" id="location-error"></div>
                  </div>
                  <div class="col-md-6">
                    <label class="form-label required" for="email" data-i18n="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" autocomplete="email" inputmode="email" autocapitalize="off" spellcheck="false" required aria-describedby="email-help email-error" />
                    <div class="form-hint" id="email-help" data-i18n="emailHint">Receives workspace notifications. Always private.</div><div class="invalid-feedback" id="email-error"></div>
                  </div>
                </div>
                <h3 class="card-title mt-4" id="notifications-heading" tabindex="-1" data-i18n="notifications">Notifications</h3>
                <p class="card-subtitle" id="digest-help" data-i18n="digestHint">Receive a weekly digest of research notes shared with your workspace.</p>
                <label class="form-check form-switch form-switch-lg mb-0">
                  <input class="form-check-input" type="checkbox" id="weekly-digest" name="weeklyDigest" aria-describedby="digest-help" />
                  <span class="form-check-label" data-i18n="weeklyDigest">Weekly digest</span>
                </label>
                <h3 class="card-title mt-4" id="privacy-heading" tabindex="-1" data-i18n="privacy">Privacy</h3>
                <p class="card-subtitle" id="privacy-help" data-i18n="privacyHint">Let members of this research workspace find your profile. Your email stays private.</p>
                <label class="form-check form-switch form-switch-lg mb-0">
                  <input class="form-check-input" type="checkbox" id="public-profile" name="publicProfile" aria-describedby="privacy-help" />
                  <span class="form-check-label" data-i18n="publicProfile">Public profile</span>
                </label>
              </div>
              <div class="card-footer bg-transparent mt-auto">
                <div id="save-status" class="alert alert-minor alert-info mb-3" role="status" aria-live="polite" aria-atomic="true" data-state="idle"></div>
                <div class="btn-list justify-content-end">
                  <button type="button" class="btn" id="cancel-settings" data-i18n="cancel">Cancel</button>
                  <button type="submit" class="btn btn-primary" id="save-settings">Save changes</button>
                </div>
              </div>
            </form>
          </div></div></div></div>
          <!-- END PAGE BODY -->
''' + s[b:]
s=s.replace('content="Premium and Open Source dashboard template with responsive and high quality UI."','content="Fieldnotes profile, notification and privacy settings. Local browser demo."')
p.write_text(s)
