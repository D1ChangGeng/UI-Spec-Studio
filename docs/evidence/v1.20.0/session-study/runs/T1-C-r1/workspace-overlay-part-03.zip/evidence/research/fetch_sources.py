import urllib.request, json, hashlib, datetime
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w03/evidence/research/sources')
targets=[('alert','https://docs.tabler.io/ui/components/alert'),('toast','https://docs.tabler.io/ui/components/toast'),('validation','https://docs.tabler.io/ui/forms/validation'),('list-group','https://docs.tabler.io/ui/components/list-group'),('page-headers','https://docs.tabler.io/ui/layout/page-headers')]
def run(row):
    name,url=row
    for ext in ['.md','.html']:
        target=url+'.md' if ext=='.md' else url
        try:
            with urllib.request.urlopen(target,timeout=30) as response:
                data=response.read()
                (ROOT/(name+ext)).write_bytes(data)
                record={'url':target,'status':response.status,'final_url':response.url,'headers':dict(response.headers),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
                (ROOT/(name+ext+'.response.json')).write_text(json.dumps(record,indent=2))
                print(json.dumps(record),flush=True)
        except Exception as error:
            print(json.dumps({'url':target,'error':str(error)}),flush=True)
with ThreadPoolExecutor(max_workers=3) as ex:
    list(ex.map(run,targets))
