import asyncio, json, hashlib, time, traceback
from pathlib import Path
from playwright.async_api import async_playwright

ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w03')
OUT=ROOT/'evidence/research'
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'

async def capture(page, name, notes):
    before=time.time()
    path=OUT/'screenshots'/f'{name}.png'
    await page.screenshot(path=str(path), animations='allow')
    after=time.time()
    row={'name':name,'url':page.url,'capture_bracket_epoch':[before,after],'viewport':page.viewport_size,'notes':notes}
    row['page']=await page.evaluate('''() => ({title:document.title,scrollY,theme:document.documentElement.dataset.bsTheme,lang:document.documentElement.lang,active:document.activeElement?.id,contentHeight:document.documentElement.scrollHeight,contentWidth:document.documentElement.scrollWidth})''')
    print(json.dumps(row,ensure_ascii=False),flush=True)
    return row

async def main():
    records=[]
    digests={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['app/index.html','app/settings-controller.js','app/settings-store.js','app/dist/css/tabler.min.css']}
    print(json.dumps({'source_digests':digests}),flush=True)
    async with async_playwright() as pw:
        browser=await pw.chromium.launch(executable_path=BROWSER)
        context=await browser.new_context(viewport={'width':1280,'height':600},device_scale_factor=1)
        page=await context.new_page()
        await page.goto('http://127.0.0.1:4133/?theme=light&lang=en&fail=once',wait_until='networkidle')
        await page.evaluate('document.fonts.ready')
        records.append(await capture(page,'current-1280-en-initial','Current app, initial state.'))
        await page.locator('#business-name').fill('')
        await page.locator('#save-settings').click()
        await page.wait_for_timeout(100)
        records.append(await capture(page,'current-1280-en-invalid','Actual invalid Save click; browser scrolled the Save button into view.'))
        print(json.dumps({'invalid_state':await page.evaluate('''() => ({status:document.querySelector('#save-status').textContent,statusRect:document.querySelector('#save-status').getBoundingClientRect().toJSON(),field:document.querySelector('#business-name').outerHTML,active:document.activeElement?.id})''')},ensure_ascii=False),flush=True)
        long='跨城市田野研究协作小组 — Longitudinal everyday-mobility research programme'
        await page.locator('#business-name').fill(long)
        await page.locator('#save-settings').click()
        records.append(await capture(page,'current-1280-en-pending','Valid save while service delay runs; failure-once fixture active.'))
        await page.wait_for_timeout(850)
        records.append(await capture(page,'current-1280-en-failure','First valid save failed through actual local service.'))
        await page.locator('#save-settings').click()
        await page.wait_for_timeout(850)
        records.append(await capture(page,'current-1280-en-retry','Retry succeeded through actual local service.'))
        await page.locator('#business-name').fill('Saved snapshot')
        await page.locator('#save-settings').click()
        await page.locator('#business-name').fill('New edit during pending')
        await page.wait_for_timeout(850)
        print(json.dumps({'pending_edit':await page.evaluate('''() => ({status:document.querySelector('#save-status').textContent,draft:window.fieldnotes.draft(),persisted:window.fieldnotes.readSettings()})''')},ensure_ascii=False),flush=True)
        await page.locator('#business-name').fill(long)
        await page.locator('#language-toggle').click()
        await page.wait_for_load_state('networkidle')
        print(json.dumps({'locale_switch':await page.evaluate('''() => ({lang:document.documentElement.lang,draft:window.fieldnotes.draft(),persisted:window.fieldnotes.readSettings()})''')},ensure_ascii=False),flush=True)
        await context.close()
        context=await browser.new_context(viewport={'width':390,'height':844},device_scale_factor=1)
        page=await context.new_page()
        await page.goto('http://127.0.0.1:4133/?theme=dark&lang=zh',wait_until='networkidle')
        await page.evaluate('document.fonts.ready')
        records.append(await capture(page,'current-390-zh-initial','Current dark Chinese narrow first encounter.'))
        await page.locator('#business-name').fill(long)
        await page.locator('#business-name').blur()
        records.append(await capture(page,'current-390-zh-long','Narrow long name in the actual editable field.'))
        await page.locator('#save-settings').scroll_into_view_if_needed()
        records.append(await capture(page,'current-390-zh-footer','Current narrow footer after actual scroll.'))
        await context.close()
        context=await browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
        page=await context.new_page()
        for slug in ['alert','toast','list-group']:
            url=f'https://docs.tabler.io/ui/components/{slug}'
            try:
                response=await page.goto(url,wait_until='domcontentloaded',timeout=30000)
                await page.wait_for_timeout(1500)
                await page.evaluate('document.fonts.ready')
                (OUT/'sources'/f'docs-{slug}-rendered.html').write_text(await page.content())
                heads=await page.locator('h1,h2,h3').all_text_contents()
                print(json.dumps({'source':url,'status':response.status if response else None,'headings':heads,'iframes':await page.locator('iframe').evaluate_all('(els)=>els.map(e=>e.src)')},ensure_ascii=False),flush=True)
                heading=page.get_by_role('heading',name={'alert':'Default markup','toast':'Basic','list-group':'Basic list group'}[slug],exact=False)
                if await heading.count():
                    await heading.first.scroll_into_view_if_needed()
                else:
                    await page.locator('h1').first.scroll_into_view_if_needed()
                records.append(await capture(page,f'docs-{slug}','Original live official documentation; no styles injected.'))
            except Exception as e:
                print(json.dumps({'source':url,'error':str(e)}),flush=True)
        try:
            url='https://docs.tabler.io/ui/forms/validation'
            response=await page.goto(url,wait_until='domcontentloaded',timeout=30000)
            await page.wait_for_timeout(1500)
            await page.locator('h1').first.scroll_into_view_if_needed()
            records.append(await capture(page,'docs-validation','Original live official validation demonstration.'))
            (OUT/'sources/docs-validation-rendered.html').write_text(await page.content())
            print(json.dumps({'source':url,'status':response.status,'headings':await page.locator('h1,h2,h3').all_text_contents()},ensure_ascii=False),flush=True)
        except Exception as e:
            print(json.dumps({'source':url,'error':str(e)}),flush=True)
        await context.close()
        await browser.close()
    (OUT/'capture-index.json').write_text(json.dumps({'source_digests':digests,'captures':records},ensure_ascii=False,indent=2))

asyncio.run(main())
