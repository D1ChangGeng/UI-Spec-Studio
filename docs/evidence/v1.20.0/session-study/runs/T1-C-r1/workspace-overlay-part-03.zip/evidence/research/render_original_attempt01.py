import asyncio,json,hashlib,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w03')
OUT=ROOT/'evidence/research'
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
    data=(ROOT/'sources/official-settings-snapshot.html').read_bytes()
    (OUT/'sources/official-settings-snapshot.html').write_bytes(data)
    html=data.decode().replace('<head>','<head><base href="http://127.0.0.1:4133/">',1)
    print(json.dumps({'source':'sources/official-settings-snapshot.html','sha256':hashlib.sha256(data).hexdigest(),'adaptation':'Only base URL inserted for local asset resolution; external requests blocked; original body unchanged.'}),flush=True)
    async with async_playwright() as pw:
        browser=await pw.chromium.launch(executable_path=BROWSER)
        page=await browser.new_page(viewport={'width':1440,'height':900})
        external=[]
        async def route_handler(route):
            if route.request.url.startswith('http://127.0.0.1:4133/'):
                await route.continue_()
            else:
                external.append(route.request.url)
                await route.abort()
        await page.route('**/*',route_handler)
        await page.goto('http://127.0.0.1:4133/')
        await page.set_content(html,wait_until='load')
        await page.evaluate('document.fonts.ready')
        await page.screenshot(path=str(OUT/'screenshots/original-settings-1440.png'),animations='allow')
        await page.set_viewport_size({'width':1280,'height':600})
        await page.get_by_text('Save changes',exact=True).last.scroll_into_view_if_needed()
        await page.screenshot(path=str(OUT/'screenshots/original-settings-1280-footer.png'),animations='allow')
        print(json.dumps({'external_requests_blocked':external,'title':await page.title(),'source_role':'Original official snapshot rendered locally with retained 1.7.1 CSS. Portrait/remote asset requests unavailable.','captured_at_epoch':time.time()}),flush=True)
        await browser.close()
asyncio.run(main())
