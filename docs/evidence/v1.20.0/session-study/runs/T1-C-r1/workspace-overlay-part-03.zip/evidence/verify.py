import asyncio,json,time,hashlib
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence/final-v5';OUT.mkdir(exist_ok=True)
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
LONG='跨城市田野研究协作小组 — Longitudinal everyday-mobility research programme'
results=[]
async def capture(page,name):
 if not name.endswith('-pending'): await page.wait_for_timeout(220)
 before=time.time()
 await page.screenshot(path=str(OUT/f'{name}.png'))
 results.append({'capture':name,'epoch_bracket':[before,time.time()],'scroll':await page.evaluate('window.scrollY'),'state':await page.locator('#save-status').get_attribute('data-state'),'focus':await page.evaluate('document.activeElement.id')})
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=BROWSER,headless=True,args=['--no-sandbox'])
  for w,h in [(1440,900),(1280,600),(390,844)]:
   for theme in ['light','dark']:
    for lang in ['en','zh']:
     label=f'{w}-{h}-{theme}-{lang}'
     context=await browser.new_context(viewport={'width':w,'height':h},device_scale_factor=1)
     page=await context.new_page()
     errors=[];requests=[]
     page.on('pageerror',lambda e:errors.append(str(e)))
     page.on('request',lambda r:requests.append(r.url))
     await page.goto(f'http://127.0.0.1:4403/?theme={theme}&lang={lang}&fail=once')
     await page.wait_for_function('window.fieldnotes && document.querySelector("#business-name").value')
     await page.evaluate('document.fonts.ready')
     assert await page.locator('html').get_attribute('data-bs-theme')==theme
     assert await page.locator('#weekly-digest').is_checked()
     assert not await page.locator('#public-profile').is_checked()
     assert await page.evaluate('document.documentElement.scrollWidth <= innerWidth')
     await capture(page,label+'-initial')
     await page.locator('#business-name').fill(LONG)
     await page.locator('#business-id').fill(LONG)
     await page.locator('#business-name').scroll_into_view_if_needed()
     await capture(page,label+'-long')
     for key in ['business-name','business-id']:
      assert await page.locator('#'+key).evaluate('(e)=>e.scrollHeight <= e.clientHeight+1'),key
     await page.locator('#save-settings').scroll_into_view_if_needed()
     await capture(page,label+'-footer')
     if w in [1280,390]:
      await page.locator('#business-name').fill('   ')
      await page.locator('#business-id').fill('x'*181)
      await page.locator('#location').fill('x'*101)
      await page.locator('#email').fill('incomplete')
      await page.locator('#save-settings').click()
      assert await page.locator('#save-status').get_attribute('data-state')=='invalid'
      assert await page.evaluate('document.activeElement.id')=='business-name'
      for key in ['business-name','business-id','location','email']:
       assert await page.locator('#'+key).get_attribute('aria-invalid')=='true'
      await capture(page,label+'-invalid')
      await page.locator('#business-name').fill(LONG)
      await page.locator('#business-id').fill(LONG)
      await page.locator('#location').fill('Singapore / 新加坡')
      await page.locator('#email').fill('mei.lin@example.invalid')
      await page.locator('#save-settings').click()
      assert await page.locator('#save-settings').is_disabled()
      assert await page.locator('#cancel-settings').is_disabled()
      assert await page.evaluate('window.fieldnotes.readSettings().displayName')=='Mei Lin · 林玫'
      await capture(page,label+'-pending')
      await page.locator('#location').fill('Taipei / 台北')
      await page.wait_for_function('document.querySelector("#save-status").dataset.state === "error"')
      assert await page.locator('#business-name').input_value()==LONG
      assert await page.evaluate('window.fieldnotes.readSettings().displayName')=='Mei Lin · 林玫'
      await page.locator('#save-settings').scroll_into_view_if_needed()
      await capture(page,label+'-error')
      await page.locator('#save-settings').click()
      await page.wait_for_function('document.querySelector("#save-status").dataset.state === "success"')
      assert await page.evaluate('window.fieldnotes.readSettings().location')=='Taipei / 台北'
      await capture(page,label+'-success')
      await page.locator('#business-name').fill('Mei')
      await page.locator('#save-settings').click()
      await page.locator('#business-name').fill(LONG)
      await page.wait_for_function('document.querySelector("#save-status").dataset.state === "savedNewer"')
      assert await page.evaluate('window.fieldnotes.readSettings().displayName')=='Mei'
      assert await page.locator('#business-name').input_value()==LONG
      await page.locator('#save-settings').scroll_into_view_if_needed()
      await capture(page,label+'-saved-newer')
      await page.locator('#cancel-settings').click()
      assert await page.locator('#business-name').input_value()=='Mei'
      await page.locator('#business-name').fill(LONG)
      old=await page.locator('#business-name').input_value()
      await page.locator('#language-toggle').click()
      assert await page.locator('#business-name').input_value()==old
      await page.locator('#language-toggle').click()
      await page.locator('#cancel-settings').click()
      await page.reload()
      await page.wait_for_function('window.fieldnotes')
      assert await page.locator('#business-name').input_value()=='Mei'
      if w==390:
       assert not await page.locator('#settings-section-nav').is_visible()
       await page.locator('#settings-nav-toggle').click()
       await page.locator('a[href="#privacy-heading"]').click()
       await page.wait_for_function('!document.querySelector("#settings-nav-panel").classList.contains("show") && !document.querySelector("#settings-nav-panel").classList.contains("collapsing")')
       assert await page.evaluate('document.activeElement.id')=='privacy-heading'
       assert await page.locator('#settings-nav-toggle').get_attribute('aria-expanded')=='false'
       await capture(page,label+'-nav-return')
     external=[r for r in requests if not r.startswith('http://127.0.0.1:4403/')]
     assert not errors,errors
     assert not external,external
     results.append({'scenario':label,'pass':True,'page_errors':errors,'external_requests':external})
     await context.close()
  # Fully keyboard-operated path. No focus(), locator clicks or fill() used in this episode.
  context=await browser.new_context(viewport={'width':1280,'height':600})
  page=await context.new_page()
  await page.goto('http://127.0.0.1:4403/?theme=dark&lang=zh&fail=once')
  await page.wait_for_function('window.fieldnotes')
  path=[]
  for _ in range(100):
   await page.keyboard.press('Tab')
   active=await page.evaluate('document.activeElement.id')
   path.append(active)
   if active=='business-name': break
  assert active=='business-name',path
  await page.keyboard.press('Control+A');await page.keyboard.insert_text('Mei')
  await capture(page,'keyboard-name-focus')
  for _ in range(7): await page.keyboard.press('Tab')
  assert await page.evaluate('document.activeElement.id')=='save-settings'
  await capture(page,'keyboard-save-focus')
  await page.keyboard.press('Enter')
  await page.wait_for_function('document.querySelector("#save-status").dataset.state === "error"')
  await capture(page,'keyboard-failure')
  await page.keyboard.press('Enter')
  await page.wait_for_function('document.querySelector("#save-status").dataset.state === "success"')
  assert await page.evaluate('window.fieldnotes.readSettings().displayName')=='Mei'
  results.append({'scenario':'keyboard-only-dark-zh','pass':True,'tab_path':path})
  await context.close();await browser.close()
try: asyncio.run(main())
finally:
 (OUT/'results.json').write_text(json.dumps({'source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'app/index.html',ROOT/'app/settings-controller.js',ROOT/'app/settings-store.js']},'observations':results},ensure_ascii=False,indent=2))
 print(json.dumps({'scenarios_passed':sum(bool(x.get('pass')) for x in results),'captures':sum('capture' in x for x in results)},ensure_ascii=False))
