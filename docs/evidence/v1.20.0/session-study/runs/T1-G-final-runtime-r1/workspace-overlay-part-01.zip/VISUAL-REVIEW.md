# Visual review

## Responsibility and observation boundary

The main agent made the product decisions, implemented the integration and personally opened real Chromium PNG captures with `view_image`. Exact image-tool responses are retained in `evidence/tools/`. One independent observer checked bounded behavior and visual episodes; its historical report remains unchanged. No natural-time video was watched. These observations establish static appearance and ordered controlled states, not motion quality, screen-reader speech or real-device behavior.

## Source and baseline

Personally viewed baseline desktop, compact-bottom and narrow views, and the supplied official settings HTML rendered locally with the supplied matching CSS/JS (`evidence/baseline/`). The local official snapshot render had external resources blocked; it is not a complete live deployment observation. The inherited Tabler card, left settings navigation, typography, switch size and theme surfaces form the product's visual foundation.

Baseline problems: the three-column profile fields constrained multilingual content; email occupied a narrow separate section; save status sat away from the footer actions. The integrated version retains the source family while composing the editable identity in a two-column grid, moving action feedback into the existing footer, and locating language/theme controls in the page header.

## Iteration and actual repairs

The first integrated narrow long-content image visibly clipped textarea content (78 px content versus 58 px available height). Bundled Tabler Autosize now grows both long identity fields. The duplicate floating Customize shortcut overlapped narrow content; its source visibility utility now hides it below the medium breakpoint while the original menu entry remains.

The independent observer found abandoned Save focus after its temporary disabled state. The adapter now restores focus only when Save previously owned it and focus is still on BODY, preserving continued editing. A later main-agent multi-error mouse check found that blur feedback displaced Save between pointer events. Error feedback now occupies the helper-text slot, and Save/Cancel transitions defer validation to their own actions. The retained failed run and diagnosis explain this repair.

The source info-alert text measured 2.83:1 in light and 4.47:1 in dark against its tinted background. Applying the existing `text-body` utility produced 9.59:1 and 10.85:1 respectively. This measurement covers that status text and background only; it is not a complete accessibility certification.

## Final appearance personally inspected

- Desktop and compact integrated frames across English/Chinese and light/dark: source card proportions and typography remain coherent, fields have clear labels and feedback, and footer feedback stays adjacent to actions. The later changes only repair validation layout and alert text color; final revision renders are retained for all 12 combinations.
- Final invalid and error frames in all four language/theme combinations at 1280 × 600: field errors identify the relevant inputs, first-invalid focus is visible, and failure leaves a clear retry action and preserved form values.
- Final narrow settled field frames in all four language/theme combinations at 390 × 844: the complete bilingual long value wraps across three lines without clipping; names, organization, location, email and switch labels remain readable. Final dark/Chinese action frame shows readable wrapped status and reachable Cancel/Save controls.
- Final light/English pending and dark/Chinese success frames were explicitly reopened at closing: pending feedback describes the submitted snapshot and allows continued editing; success has the source green treatment and visible restored Save focus. Pending captures occur inside a controlled episode and can include an in-progress source border transition; no animation-quality claim follows.

The exact closing views are `evidence/tools/w04-settled-*-fields.json` and `w04-closing-*.json`. Earlier complete desktop/compact observation exports are `w04-view-final-*`; state exports are `w04-state-*`. The initial final-render narrow long frames sampled inherited smooth scrolling before settling, so the additional `evidence/narrow-settled/` checkpoints, using native instant positioning, are the stable narrow-layout evidence.

## Verification and remaining limits

The final source hashes appear in `evidence/final-source.json` and in final render/state facts. Twelve viewport/theme/language combinations have no page errors, horizontal overflow or clipped long textarea content. The main behavior suite passed 68 assertions before the final presentation-only alert utility change; final state frames rechecked invalid, pending, failure and success on the delivery source. The independent observer's 27 passing assertions concern its recorded earlier source hashes; its then-open main validation issue was subsequently closed by `final-behavior-02`.

The inherited navigation makes narrow pages long, requiring scrolling or section anchors. Outer Tabler gallery navigation/footer remain English and their unrelated routes remain outside scope. No real mobile browser, Safari, Firefox, screen-reader speech or natural-time playback was tested. No unresolved core settings defect was found in the scoped checks.
