from playwright.sync_api import sync_playwright
import json
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 data=[]
 for theme in ['light','dark']:
  page=b.new_page();page.goto('http://127.0.0.1:4404/?theme='+theme,wait_until='networkidle')
  data.append(page.evaluate('''()=>{const e=document.querySelector('#save-status'),s=getComputedStyle(e),c=getComputedStyle(e.closest('.card'));return {theme:document.documentElement.dataset.bsTheme,color:s.color,background:s.backgroundColor,card:c.backgroundColor};}'''))
 print(json.dumps(data,indent=2));b.close()
