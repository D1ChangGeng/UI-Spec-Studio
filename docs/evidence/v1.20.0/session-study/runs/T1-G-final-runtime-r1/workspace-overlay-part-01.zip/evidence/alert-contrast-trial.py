from playwright.sync_api import sync_playwright
import json
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 data=[]
 for theme in ['light','dark']:
  page=b.new_page();page.goto('http://127.0.0.1:4404/?theme='+theme,wait_until='networkidle')
  data.append(page.evaluate('''()=>{const e=document.querySelector('#save-status');const canvas=document.createElement('canvas');canvas.width=canvas.height=1;const ctx=canvas.getContext('2d');const rgb=c=>{ctx.clearRect(0,0,1,1);ctx.fillStyle=c;ctx.fillRect(0,0,1,1);return [...ctx.getImageData(0,0,1,1).data].slice(0,3);};const lum=rgb=>rgb.map(v=>v/255).map(v=>v<=0.04045?v/12.92:((v+0.055)/1.055)**2.4).reduce((a,v,i)=>a+v*[0.2126,0.7152,0.0722][i],0);const facts=()=>{const s=getComputedStyle(e),fg=rgb(s.color),bg=rgb(s.backgroundColor),a=lum(fg),b=lum(bg);return {color:s.color,background:s.backgroundColor,fg,bg,contrast:(Math.max(a,b)+0.05)/(Math.min(a,b)+0.05)};};const before=facts();e.classList.add('text-body');return {theme:document.documentElement.dataset.bsTheme,before,bodyTextTrial:facts()};}'''))
 print(json.dumps(data,indent=2));b.close()
