from pathlib import Path
import json, time, hashlib
from playwright.sync_api import sync_playwright
root=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w04')
out=root/'evidence/baseline'
browser_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=browser_path,headless=True,args=['--no-sandbox'])
    facts=[]
    for label,width,height,theme,lang in [('desktop',1440,900,'light','en'),('compact',1280,600,'dark','zh'),('narrow',390,844,'light','en')]:
        context=browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1)
        page=context.new_page()
        page.goto(f'http://127.0.0.1:4404/?theme={theme}&lang={lang}',wait_until='networkidle')
        page.evaluate('document.fonts.ready')
        page.screenshot(path=str(out/f'{label}.png'))
        facts.append({'label':label,'viewport':{'width':width,'height':height},'theme':theme,'lang':lang,'at':time.time(),'dimensions':page.evaluate('({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,scrollHeight:document.documentElement.scrollHeight})'),'save':page.locator('#save-settings').bounding_box()})
        if label=='compact':
            page.locator('#save-settings').scroll_into_view_if_needed()
            page.screenshot(path=str(out/'compact-bottom.png'))
        context.close()
    context=browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
    page=context.new_page()
    page.route('**/*',lambda route: route.abort() if not route.request.url.startswith('http://127.0.0.1:4404') else route.continue_())
    page.goto('http://127.0.0.1:4404/?theme=light',wait_until='networkidle')
    page.set_content((root/'sources/official-settings-snapshot.html').read_text(),wait_until='networkidle')
    page.screenshot(path=str(out/'official-snapshot-local.png'))
    facts.append({'label':'official snapshot local render','source_sha256':hashlib.sha256((root/'sources/official-settings-snapshot.html').read_bytes()).hexdigest(),'conditions':'HTML unchanged via set_content at local origin; local matching CSS/JS; external requests aborted; portraits may be unavailable'})
    (out/'facts.json').write_text(json.dumps(facts,indent=2))
    browser.close()
print(json.dumps(facts,indent=2))
