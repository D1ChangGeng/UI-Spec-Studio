from pathlib import Path
from playwright.sync_api import sync_playwright
import json,time,hashlib
root=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w04')
out=root/'evidence/final-render';out.mkdir(exist_ok=False)
long='跨城市田野研究协作小组 — Longitudinal everyday-mobility research programme'
records=[]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
    for width,height in [(1440,900),(1280,600),(390,844)]:
        for theme in ['light','dark']:
            for lang in ['en','zh']:
                context=browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1)
                page=context.new_page(); errors=[]
                page.on('pageerror',lambda e: errors.append(str(e)))
                page.goto(f'http://127.0.0.1:4404/?theme={theme}&lang={lang}',wait_until='networkidle')
                page.evaluate('document.fonts.ready')
                name=f'{width}-{theme}-{lang}'
                page.screenshot(path=str(out/f'{name}-top.png'))
                page.locator('#business-name').fill(long)
                page.locator('#business-id').fill(long)
                page.locator('#business-name').scroll_into_view_if_needed()
                page.screenshot(path=str(out/f'{name}-long.png'))
                record={'name':name,'viewport':{'width':width,'height':height},'theme':theme,'lang':lang,'at':time.time(),'errors':errors,'textareas':page.locator('textarea').evaluate_all('(els)=>els.map(e=>({id:e.id,clientHeight:e.clientHeight,scrollHeight:e.scrollHeight,value:e.value}))'),'overflow':page.evaluate('document.documentElement.scrollWidth > innerWidth')}
                page.locator('#save-settings').scroll_into_view_if_needed()
                page.screenshot(path=str(out/f'{name}-bottom.png'))
                record['status']=page.locator('#save-status').inner_text()
                records.append(record)
                context.close()
    browser.close()
(out/'facts.json').write_text(json.dumps({'source':{f:hashlib.sha256((root/'app'/f).read_bytes()).hexdigest() for f in ['index.html','settings-controller.js','settings-store.js']},'records':records},ensure_ascii=False,indent=2))
print(json.dumps({'combinations':len(records),'page_errors':sum(len(r['errors']) for r in records),'overflow':any(r['overflow'] for r in records),'all_long_text_fits':all(t['scrollHeight']<=t['clientHeight'] for r in records for t in r['textareas'])},indent=2))
