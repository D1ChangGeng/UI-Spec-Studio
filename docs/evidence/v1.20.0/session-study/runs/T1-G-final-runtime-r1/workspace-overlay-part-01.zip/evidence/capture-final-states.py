from playwright.sync_api import sync_playwright,expect
from pathlib import Path
import json,hashlib
root=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w04');out=root/'evidence/final-state-view';out.mkdir(exist_ok=False)
records=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 for theme in ['light','dark']:
  for lang in ['en','zh']:
   ctx=b.new_context(viewport={'width':1280,'height':600});page=ctx.new_page();name=f'{theme}-{lang}'
   page.goto(f'http://127.0.0.1:4404/?theme={theme}&lang={lang}&fail=once',wait_until='networkidle')
   def snap(state):
    start=page.evaluate('performance.now()');page.screenshot(path=str(out/f'{name}-{state}.png'));end=page.evaluate('performance.now()')
    records.append({'variant':name,'state':state,'start_ms':start,'end_ms':end,'clock':'performance.now','focus':page.evaluate('document.activeElement.id || document.activeElement.tagName'),'text':page.locator('#save-status').inner_text()})
   page.locator('#business-name').fill('');page.locator('#email').fill('broken');page.locator('#save-settings').click()
   expect(page.locator('#business-name')).to_be_focused();page.wait_for_timeout(600);snap('invalid')
   page.locator('#business-name').fill('Mei / 林玫');page.locator('#email').fill('mei.lin@example.invalid');page.locator('#save-settings').click()
   expect(page.locator('#save-status')).to_have_attribute('data-state','pending');snap('pending')
   expect(page.locator('#save-status')).to_have_attribute('data-state','error');snap('error')
   page.locator('#save-settings').press('Enter');expect(page.locator('#save-status')).to_have_attribute('data-state','success');snap('success')
   ctx.close()
 b.close()
(out/'frames.json').write_text(json.dumps({'source':{f:hashlib.sha256((root/'app'/f).read_bytes()).hexdigest() for f in ['index.html','settings-controller.js','settings-store.js']},'frames':records},ensure_ascii=False,indent=2))
print(json.dumps({'captured_frames':len(records),'variants':4},indent=2))
