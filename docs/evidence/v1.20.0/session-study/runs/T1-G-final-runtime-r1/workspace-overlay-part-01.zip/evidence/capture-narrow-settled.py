from playwright.sync_api import sync_playwright
from pathlib import Path
import json,hashlib
root=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w04');out=root/'evidence/narrow-settled';out.mkdir(exist_ok=False)
records=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 for theme in ['light','dark']:
  for lang in ['en','zh']:
   ctx=b.new_context(viewport={'width':390,'height':844});page=ctx.new_page();name=f'{theme}-{lang}'
   page.goto(f'http://127.0.0.1:4404/?theme={theme}&lang={lang}',wait_until='networkidle')
   long='跨城市田野研究协作小组 — Longitudinal everyday-mobility research programme'
   page.locator('#business-name').fill(long);page.locator('#business-id').fill(long)
   page.locator('#profile-heading').evaluate("e=>e.scrollIntoView({block:'start',behavior:'instant'})")
   page.screenshot(path=str(out/f'{name}-fields.png'))
   page.locator('#save-settings').evaluate("e=>e.scrollIntoView({block:'end',behavior:'instant'})")
   page.screenshot(path=str(out/f'{name}-actions.png'))
   records.append({'variant':name,'viewport':[390,844],'scroll':'native instant scrollIntoView to specified checkpoints; not motion evidence','textareaGeometry':page.locator('textarea').evaluate_all('(els)=>els.map(e=>({id:e.id,clientHeight:e.clientHeight,scrollHeight:e.scrollHeight,value:e.value}))')})
   ctx.close()
 b.close()
(out/'facts.json').write_text(json.dumps({'source':{f:hashlib.sha256((root/'app'/f).read_bytes()).hexdigest() for f in ['index.html','settings-controller.js']},'records':records},ensure_ascii=False,indent=2))
print(json.dumps({'viewports':len(records),'checkpoints':8},indent=2))
