from pathlib import Path
from playwright.sync_api import sync_playwright
import json
p=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w04')
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1280,'height':600})
 page.goto('http://127.0.0.1:4404/?theme=light&lang=en',wait_until='networkidle')
 page.evaluate('''()=>{window.focusAudit=[];for(const e of ['focusin','focusout','click','submit'])document.addEventListener(e,v=>focusAudit.push({event:e,target:v.target.id,active:document.activeElement.id,at:performance.now()}),true);const proto=HTMLElement.prototype;const old=proto.focus;proto.focus=function(...args){focusAudit.push({event:'focus-call',target:this.id,stack:Error().stack,at:performance.now()});return old.apply(this,args);};}''')
 page.locator('#business-name').fill('');page.locator('#email').fill('invalid');page.locator('#save-settings').click();page.wait_for_timeout(800)
 result=page.evaluate('({events:focusAudit,active:document.activeElement.id,draft:fieldnotes.draft(),status:document.querySelector("#save-status").dataset.state})')
 (p/'evidence/focus-diagnosis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
 print(json.dumps(result,ensure_ascii=False,indent=2));b.close()
