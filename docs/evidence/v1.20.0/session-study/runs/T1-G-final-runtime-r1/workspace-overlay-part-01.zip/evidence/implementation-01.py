from pathlib import Path
p=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w04/app/index.html')
s=p.read_text()
s=s.replace('<h1 class="page-title">Account Settings</h1>','<h1 class="page-title" data-i18n="accountSettings">Account Settings</h1>')
s=s.replace('''                  <h1 class="page-title" data-i18n="accountSettings">Account Settings</h1>
                </div>''','''                  <h1 class="page-title" data-i18n="accountSettings">Account Settings</h1>
                </div>
                <div class="col-auto"><div class="btn-list">
                  <button type="button" class="btn" id="language-toggle" lang="zh-CN">中文</button>
                  <button type="button" class="btn" id="theme-toggle">Dark theme</button>
                </div></div>''')
start=s.index('                  <div class="col-12 col-md-9 d-flex flex-column">')
end=s.index('''                </div>
              </div>
            </div>
          </div>
          <!-- END PAGE BODY -->''',start)
s=s[:start]+'''                  <form id="settings-form" class="col-12 col-md-9 d-flex flex-column" novalidate action="#" method="post" aria-labelledby="profile-heading">
                    <div class="card-body">
                      <h2 class="mb-4" id="profile-heading" tabindex="-1" data-i18n="myAccount">My Account</h2>
                      <div class="row align-items-center mb-4">
                        <div class="col-auto"><span class="avatar avatar-lg" aria-hidden="true">ML</span></div>
                        <div class="col">
                          <h3 class="card-title mb-1" data-i18n="profileDetails">Profile details</h3>
                          <p class="text-secondary mb-0" data-i18n="profileIntro">Your identity in the research workspace.</p>
                        </div>
                      </div>
                      <div class="row g-3">
                        <div class="col-md-6">
                          <label class="form-label required" for="business-name" data-i18n="displayName">Display name</label>
                          <textarea class="form-control" id="business-name" name="displayName" autocomplete="name" rows="2" required aria-describedby="name-help business-name-error"></textarea>
                          <div class="invalid-feedback" id="business-name-error"></div>
                          <div class="form-hint" id="name-help" data-i18n="nameHelp">Required · up to 100 characters</div>
                        </div>
                        <div class="col-md-6">
                          <label class="form-label" for="business-id" data-i18n="organization">Organization</label>
                          <textarea class="form-control" id="business-id" name="organization" autocomplete="organization" rows="2" aria-describedby="org-help business-id-error"></textarea>
                          <div class="invalid-feedback" id="business-id-error"></div>
                          <div class="form-hint" id="org-help" data-i18n="orgHelp">Optional · up to 180 characters</div>
                        </div>
                        <div class="col-md-6">
                          <label class="form-label" for="location" data-i18n="location">Location</label>
                          <input type="text" class="form-control" id="location" name="location" autocomplete="address-level2" aria-describedby="location-help location-error" />
                          <div class="invalid-feedback" id="location-error"></div>
                          <div class="form-hint" id="location-help" data-i18n="locationHelp">Optional · up to 100 characters</div>
                        </div>
                        <div class="col-md-6">
                          <label class="form-label required" for="email" data-i18n="email">Email</label>
                          <input type="email" class="form-control" id="email" name="email" autocomplete="email" autocapitalize="off" spellcheck="false" required aria-describedby="email-help email-error" />
                          <div class="invalid-feedback" id="email-error"></div>
                          <div class="form-hint" id="email-help" data-i18n="emailHelp">Receives workspace notifications. Always private.</div>
                        </div>
                      </div>
                      <h3 class="card-title mt-4" id="notifications-heading" tabindex="-1" data-i18n="notifications">Notifications</h3>
                      <p class="card-subtitle" id="notifications-help" data-i18n="notificationHelp">Receive a weekly digest of research notes shared with your workspace.</p>
                      <div>
                        <label class="form-check form-switch form-switch-lg">
                          <input class="form-check-input" type="checkbox" id="weekly-digest" name="weeklyDigest" aria-describedby="notifications-help" />
                          <span class="form-check-label form-check-label-on" data-i18n="weeklyOn">Weekly digest is enabled</span>
                          <span class="form-check-label form-check-label-off" data-i18n="weeklyOff">Weekly digest is disabled</span>
                        </label>
                      </div>
                      <h3 class="card-title mt-4" id="privacy-heading" tabindex="-1" data-i18n="publicProfile">Public profile</h3>
                      <p class="card-subtitle" id="privacy-help" data-i18n="privacyHelp">Allow other members of this research workspace to find your profile. Your email remains private.</p>
                      <div>
                        <label class="form-check form-switch form-switch-lg">
                          <input class="form-check-input" type="checkbox" id="public-profile" name="publicProfile" aria-describedby="privacy-help" />
                          <span class="form-check-label form-check-label-on" data-i18n="publicOn">Your profile will be visible</span>
                          <span class="form-check-label form-check-label-off" data-i18n="publicOff">Your profile will be private</span>
                        </label>
                      </div>
                    </div>
                    <div class="card-footer bg-transparent mt-auto">
                      <div id="save-status" class="alert alert-info mb-3" role="status" aria-live="polite" aria-atomic="true" data-state="idle">Changes are saved only in this browser.</div>
                      <div class="btn-list justify-content-end">
                        <button type="button" class="btn" id="cancel-settings" data-i18n="cancel">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="save-settings">Save changes</button>
                      </div>
                    </div>
                  </form>
'''+s[end:]
# Scope localized labels to the existing settings navigation, preserving its structure.
start=s.index('                  <!-- BEGIN SETTINGS NAV -->')
end=s.index('                  <!-- END SETTINGS NAV -->',start)
nav=s[start:end]
for label,key in {'Business settings':'businessSettings','My Account':'myAccount','My Notifications':'myNotifications','Privacy':'privacy','Plans':'plans','Billing & Invoices':'billing','Experience':'experience','Give Feedback':'feedback'}.items():
    nav=nav.replace('>'+label+'<',' data-i18n="'+key+'">'+label+'<')
nav=nav.replace('class="list-group list-group-transparent"','class="list-group list-group-transparent" data-settings-nav')
nav=nav.replace('class="list-group-item list-group-item-action active','aria-current="location" class="list-group-item list-group-item-action active')
s=s[:start]+nav+s[end:]
s=s.replace('<meta name="description" content="Premium and Open Source dashboard template with responsive and high quality UI." />','<meta name="description" content="Fieldnotes profile, notification and privacy settings, saved in this browser." />')
p.write_text(s)
