# Fieldnotes settings — independent observer report

## Scope and current result

The bounded observer inquiry exercised the actual local settings page and browser-local store. It did not modify product code or choose a new design foundation. The main agent retains design decisions, source-fidelity judgment and final acceptance.

Final observer run `run-04` completed 27 scoped assertions with no failed assertions, scenario failures, page errors or captured console errors. The earlier loss of keyboard focus after a failed save was reproduced, reported, repaired by the main agent, and independently rechecked. These results do not certify untested conditions.

**Additional issue and repair reported by the main agent:** after this run, the main agent reported that its simultaneous empty-name/invalid-email mouse submission did not advance and left focus on Save. Its event trace subsequently attributed the symptom to email blur feedback moving the footer between pointer down and pointer up, so Save never submitted. The main agent reports a repair that reuses the existing helper slot for errors and skips blur validation during Save/Cancel focus transitions; its exact four-variant mouse matrix is being rerun. This condition and repair were not independently rechecked by this observer. The observer's single empty-name keyboard checks passed on the hashes below. The later mouse-path result remains pending in this report and belongs to the main agent's evidence; it must not be inferred from the 27 earlier passes.

## Conditions and source identity

- Entry: `http://127.0.0.1:4404/`; fresh isolated Playwright browser contexts; no shared desktop session.
- Browser: registered Chromium headless shell 143.0.7499.4, Playwright 1.57.0, device pixel ratio 1, browser-default zoom.
- Font environment: `FONTCONFIG_FILE=/tmp/ui-spec-fonts/fonts.conf`; registered Noto CJK configuration.
- Final run: 2026-11-01 08:46:54–08:47:22 UTC. Source hashes were unchanged from the start to the end of that run.
- Main sequence: 1440×900 English/light, followed by in-page Chinese/dark switching with an unsaved draft.
- Keyboard sequences: 1280×600 Chinese/dark and 390×844 English/light. Supplementary `run-03` inspected narrow Chinese/dark and English/dark invalid-email translation on its separately recorded controller revision.
- Content included `Mei`, the supplied initial bilingual values, and `跨城市田野研究协作小组 — Longitudinal everyday-mobility research programme` in both name and organization fields.

Foundation identity is supplied by `SOURCE-MANIFEST.json`: Tabler `@tabler/core@1.7.1`, MIT, tagged revision `07f60c07da13d8ff957a370434b7ef5c86f5ab94`. The preserved official deployed settings HTML reports 1.7.1 and has SHA-256 `ed80162e38d7667bfe020b5d16d228c4adc64f301233cfbeeeae6f606697a06e`; its exact deployment commit is not advertised. This observer did not perform a fresh upstream-demo comparison.

Final observed product identities:

| File | SHA-256 in run-04 |
|---|---|
| `app/index.html` | `5aae297ad9e43d97ca16a33ea980653a5fb4a65d45ca962a937339a37d99199c` |
| `app/settings-controller.js` | `6d51e037c81a03ceeb9a1fae833f8ed037f22e0f60412f1458b10338527dc001` |
| `app/settings-store.js` | `32139de23b4ad411c402620e84d5592f7ccfbcf68cece1a123946c29b63c2da0` |

## Observed findings and reproduction

| Inquiry | Steps and observed outcome | Evidence |
|---|---|---|
| Submitted snapshot versus continued edits | Enter `Snapshot A`, activate Save, then enter `Continued draft B` during the real pending interval. Storage commits A; the editor retains B and its focus. The visible message distinguishes the submitted changes from newer unsaved edits. | `run-04/observations.json`; `run-04/03-snapshot-saved-continued-draft-visible.png` |
| Failure and retry | Change organization and both switches, enable the supplied one-failure fixture, and Save. Error preserves the latest draft and the previous serialized stored value. Retry commits the draft. No simulated persistence replacement was used. | `run-04/04-failed-save-retained-draft.png`; state records and checks in `run-04/observations.json` |
| Cancel and return | After a successful retry, change name and switches, then Cancel. All fields return to the last persisted settings; reload reads that same saved value. Compact and narrow keyboard Cancel also restore the saved name. | `run-04/06-cancel-return.png`; `run-04/09-narrow-en-light-cancel.png` |
| Language/theme while editing | Edit an unsaved name and organization, then activate language and theme controls. Both current draft and existing persistence remain unchanged. The in-page labels and document language update. | `run-04/07-language-theme-draft-preserved.png`; state assertions |
| Keyboard failure recovery | Tab to Save and press Enter with `?fail=once`. Earlier runs lost focus to BODY, and the next Tab went to the footer Documentation link. In the repaired run, focus returns to the visible Retry button in both smaller viewports; Enter retries successfully. | Historical `run-02/*-after-error-next-tab.png`; final `run-04/08-compact-zh-dark-error.png` and `run-04/09-narrow-en-light-error.png` |
| Single-field validation | Clear only the display name, Tab to Save and press Enter. `business-name` receives focus and `aria-invalid=true`; the localized inline error is present. This does not cover the main agent's subsequently reported simultaneous-error condition. | `run-04/*-invalid-name-focused.png`; state assertions |
| Invalid-email translation | In narrow Chinese/dark, enter `broken` in email and submit. The error is Chinese and linked through `aria-describedby="email-help email-error"`. Switch to English: the draft stays intact and the error becomes English. | `run-03/observations.json`; `run-03/03-narrow-en-dark-translated-error.png` |
| Long values and narrow layout | Enter the long bilingual string in both textareas. At 1280 px each has 58 px content height and scroll height; at 390 px each has 78 px content height and scroll height. The viewed narrow checkpoint shows three readable lines, with no internal text clipping. Document width equals viewport width in both smaller keyboard journeys. | `run-04/08-compact-zh-dark-long-values.png`; `run-04/09-narrow-en-light-long-organization.png`; measured dimensions |

The viewed final captures retain the Tabler form, switch, alert and button family. The footer groups the outcome message with Cancel and Save/Retry. The narrow layout requires document scrolling because the inherited settings navigation precedes the form. After scroll settling, the action row is reachable and its keyboard outline is visible. This is a scoped appearance and operability observation, not an assessment of every upstream gallery control.

## Evidence history and actual viewing

`commands-01` through `commands-04` retain original subprocess arguments, stdout/stderr, timestamps and exit status. `checks-01.py` through `checks-04.py` retain the executed scripts. Each run directory preserves its original screenshots, source identities, state observations and failures.

Two initial `run-01` Save-visibility assertions sampled a still-moving scroll position immediately after rapid Tab presses. `run-02` introduced 80 ms spacing between Tabs and a 600 ms settling interval at the target; both settled Save-visibility checks passed. Those initial failures remain preserved and are not treated as persistent unreachable-control defects. The separate focus-loss defect in `run-02` was real and was rechecked after repair.

I actually opened 23 consequential captures using `view_image`. Exact tool responses are preserved as `w04_observer_view_01.json` through `w04_observer_view_23.json`. Final-revision viewed captures, exports 16–23, cover: saved snapshot with newer draft, failed save, Cancel return, compact Chinese retry focus, compact long values, narrow long organization, narrow retry focus and narrow Cancel focus. Earlier viewed captures cover pending feedback, validation, translated errors and the original keyboard defect. Other captured images remain available but are not all claimed as individually viewed.

## Limits and remaining responsibility

- The main agent's later mouse-click-displacement repair and four-variant recheck remain outside the observer's demonstrated pass and are explicitly scoped above.
- This is an isolated Chromium desktop/headless test with viewport emulation. No real mobile virtual keyboard, touch hardware, Safari/Firefox or screen reader was exercised. Accessible attributes and keyboard operation do not establish assistive-technology announcement quality.
- The observer sampled named theme/locale/viewport combinations; it did not test every Cartesian combination or all validation boundaries. It did not exercise corrupted storage, multiple tabs or storage quota exhaustion.
- Screenshots and recorded state progression were inspected. No natural-time video playback was watched. Sparse captures, planned waits and tool-inclusive timings do not establish motion smoothness, pacing, frame delivery or human comprehension.
- The locale/theme switch capture can occur during source CSS transitions; settled snapshots and state checks support the stated draft-retention claim, not an uninterrupted theme-transition quality claim.
- Original task/control/allocation instructions, the bounded observer role, UI Spec Studio's eight common references, integration, evidence-map and evidence-action guidance were read. No product, method, input or role files were modified by this observer.

Any further product revision needs only the affected recheck; historical captures must keep their original revision identity. Final whole-product acceptance remains with the main agent.
