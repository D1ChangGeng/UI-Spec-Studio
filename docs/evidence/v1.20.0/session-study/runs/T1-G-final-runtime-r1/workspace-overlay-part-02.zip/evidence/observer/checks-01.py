import asyncio, datetime, hashlib, json, os, sys, time, traceback
from pathlib import Path
from playwright.async_api import async_playwright

ROOT = Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w04')
OUT = ROOT / 'evidence/observer/run-01'
BROWSER = '/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
BASE = 'http://127.0.0.1:4404/'
LONG = '跨城市田野研究协作小组 — Longitudinal everyday-mobility research programme'
FIELDS = {'displayName':'business-name','organization':'business-id','location':'location','email':'email','weeklyDigest':'weekly-digest','publicProfile':'public-profile'}
REPORT = {'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'checks':[], 'frames':[], 'episodes':[], 'console':[], 'failures':[]}

def log(kind, data):
    print(json.dumps({'kind':kind, **data},ensure_ascii=False), flush=True)

def check(name, condition, detail=None):
    item={'name':name,'passed':bool(condition),'detail':detail}
    REPORT['checks'].append(item); log('check', item)

async def state(page):
    return await page.evaluate('''(fields) => {
      const draft=Object.fromEntries(Object.entries(fields).map(([k,id])=>{const e=document.getElementById(id); return [k,e.type==='checkbox'?e.checked:e.value]}));
      const a=document.activeElement,r=a?.getBoundingClientRect(),cs=a?getComputedStyle(a):null;
      const status=document.querySelector('#save-status');
      return {draft,stored:localStorage.getItem('fieldnotes-settings-v1'),status:{text:status?.innerText,state:status?.dataset.state,role:status?.getAttribute('role')},
        save:{disabled:document.querySelector('#save-settings').disabled,text:document.querySelector('#save-settings').innerText},cancelDisabled:document.querySelector('#cancel-settings').disabled,
        active:{id:a?.id,tag:a?.tagName,text:a?.innerText?.slice(0,160),focusVisible:a?.matches(':focus-visible'),rect:r?{x:r.x,y:r.y,width:r.width,height:r.height}:null,outline:cs?.outline,boxShadow:cs?.boxShadow},
        theme:document.documentElement.dataset.bsTheme,lang:document.documentElement.lang,url:location.href,scroll:{x:scrollX,y:scrollY,width:document.documentElement.scrollWidth,height:document.documentElement.scrollHeight},viewport:{width:innerWidth,height:innerHeight},now:performance.now()};
    }''', FIELDS)

async def capture(page,name):
    start=time.monotonic(); before=await state(page)
    path=OUT/(name+'.png')
    await page.screenshot(path=str(path),full_page=False,animations='allow',caret='initial')
    after=await state(page)
    item={'name':name,'path':str(path),'capture_start_monotonic':start,'capture_end_monotonic':time.monotonic(),'before':before,'after':after}
    REPORT['frames'].append(item); log('frame', {'name':name,'state':after})
    return after

def persisted(s):
    return json.loads(s['stored'])['settings'] if s['stored'] else None

async def settle(page):
    await page.wait_for_function("document.querySelector('#save-status').dataset.state !== 'pending'",timeout=5000)
    return await state(page)

async def open_page(browser,viewport,query):
    ctx=await browser.new_context(viewport=viewport,device_scale_factor=1,locale='en-US')
    page=await ctx.new_page()
    page.on('pageerror',lambda e: REPORT['console'].append({'type':'pageerror','message':str(e)}))
    page.on('console',lambda e: REPORT['console'].append({'type':e.type,'message':e.text}) if e.type=='error' else None)
    await page.goto(BASE+query,wait_until='networkidle')
    await page.evaluate('document.fonts.ready')
    return ctx,page

async def desktop(browser):
    ctx,page=await open_page(browser,{'width':1440,'height':900},'?theme=light&lang=en')
    await capture(page,'01-desktop-initial-en-light')
    await page.locator('#business-name').fill('Snapshot A')
    await page.locator('#save-settings').click()
    pending=await state(page)
    check('save exposes pending',pending['status']['state']=='pending',pending)
    await page.locator('#business-name').fill('Continued draft B')
    await capture(page,'02-pending-with-continued-edit')
    final=await settle(page)
    check('submitted snapshot persisted separately from continued draft',persisted(final)['displayName']=='Snapshot A' and final['draft']['displayName']=='Continued draft B',final)
    await capture(page,'03-snapshot-saved-continued-draft-visible')
    await page.locator('#business-id').fill(LONG)
    await page.locator('#weekly-digest').uncheck()
    await page.locator('#public-profile').check()
    await page.evaluate('window.fieldnotes.setFailureMode(true)')
    before=await state(page)
    await page.locator('#save-settings').click()
    error=await settle(page)
    check('failure preserves draft and previous persisted snapshot',error['status']['state']=='error' and error['draft']==before['draft'] and error['stored']==before['stored'],error)
    await capture(page,'04-failed-save-retained-draft')
    await page.locator('#save-settings').click()
    retried=await settle(page)
    check('retry persists current draft',retried['status']['state']=='success' and persisted(retried)==before['draft'],retried)
    await capture(page,'05-retry-success')
    saved=retried['draft']
    await page.locator('#business-name').fill('Discard me')
    await page.locator('#weekly-digest').check()
    await page.locator('#public-profile').uncheck()
    await page.locator('#cancel-settings').click()
    returned=await state(page)
    check('Cancel restores last persisted settings',returned['draft']==saved and persisted(returned)==saved,returned)
    await capture(page,'06-cancel-return')
    await page.reload(wait_until='networkidle')
    loaded=await state(page)
    check('reload restores persisted settings',loaded['draft']==saved,loaded)
    await page.locator('#business-name').fill('Draft 林玫')
    await page.locator('#business-id').fill(LONG)
    switching=await state(page)
    await page.locator('#language-toggle').click()
    await page.wait_for_timeout(100)
    language=await state(page)
    check('language change preserves unsaved draft and persistence',language['draft']==switching['draft'] and language['stored']==switching['stored'],language)
    await page.locator('#theme-toggle').click()
    themed=await state(page)
    check('theme change preserves unsaved draft and persistence',themed['draft']==switching['draft'] and themed['stored']==switching['stored'],themed)
    await capture(page,'07-language-theme-draft-preserved')
    await ctx.close()

async def tab_until(page,target,limit=100):
    path=[]
    for n in range(limit):
        await page.keyboard.press('Tab')
        s=await state(page); a=s['active']; path.append({'step':n+1,**a,'scroll':s['scroll']})
        if a['id']==target:
            REPORT['episodes'].append({'name':'tab-to-'+target,'path':path})
            return s
    REPORT['episodes'].append({'name':'tab-to-'+target,'path':path})
    raise RuntimeError('Keyboard did not reach '+target)

async def keyboard_case(browser,width,height,lang,theme,prefix):
    ctx,page=await open_page(browser,{'width':width,'height':height},f'?theme={theme}&lang={lang}&fail=once')
    await capture(page,prefix+'-initial')
    named=await tab_until(page,'business-name')
    check(prefix+' keyboard reaches name with visible focus',named['active']['focusVisible'],named)
    await page.keyboard.press('Control+a'); await page.keyboard.press('Backspace')
    await capture(page,prefix+'-name-focused')
    await tab_until(page,'save-settings')
    savefocus=await capture(page,prefix+'-save-focused')
    r=savefocus['active']['rect']
    check(prefix+' save focus visible within viewport',savefocus['active']['focusVisible'] and r['y']>=0 and r['y']+r['height']<=height,savefocus)
    await page.keyboard.press('Enter')
    invalid=await state(page)
    check(prefix+' invalid name focus and field association',invalid['active']['id']=='business-name' and await page.locator('#business-name').get_attribute('aria-invalid')=='true',invalid)
    await capture(page,prefix+'-invalid-name-focused')
    await page.keyboard.press('Control+a'); await page.keyboard.type('Mei')
    await tab_until(page,'business-id')
    await page.keyboard.press('Control+a'); await page.keyboard.insert_text(LONG)
    await tab_until(page,'save-settings')
    await page.keyboard.press('Enter')
    error=await settle(page)
    check(prefix+' keyboard valid attempt fails once',error['status']['state']=='error',error)
    await capture(page,prefix+'-error')
    if (await state(page))['active']['id']!='save-settings':
        await tab_until(page,'save-settings')
    await page.keyboard.press('Enter')
    success=await settle(page)
    check(prefix+' keyboard retry succeeds',success['status']['state']=='success' and persisted(success)['displayName']=='Mei',success)
    await capture(page,prefix+'-retry-success')
    check(prefix+' no document horizontal overflow',success['scroll']['width']<=width,success)
    await page.locator('#business-name').fill('Cancelled keyboard draft')
    await tab_until(page,'cancel-settings')
    await page.keyboard.press('Enter')
    cancel=await state(page)
    check(prefix+' keyboard Cancel restores saved name',cancel['draft']['displayName']=='Mei',cancel)
    await capture(page,prefix+'-cancel')
    await ctx.close()

async def main():
    OUT.mkdir(parents=True,exist_ok=False)
    REPORT['source']={'foundation':json.loads((ROOT/'SOURCE-MANIFEST.json').read_text()),'files':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'app/index.html',ROOT/'app/settings-controller.js',ROOT/'app/settings-store.js']},'browser':BROWSER,'fontconfig':os.environ.get('FONTCONFIG_FILE'),'base_url':BASE,'pixel_ratio':1,'zoom':'browser default; no zoom manipulation'}
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path=BROWSER,headless=True,args=['--no-sandbox'])
        REPORT['browser_version']=browser.version
        for name,operation in [('desktop',lambda:desktop(browser)),('compact',lambda:keyboard_case(browser,1280,600,'zh','dark','08-compact-zh-dark')),('narrow',lambda:keyboard_case(browser,390,844,'en','light','09-narrow-en-light'))]:
            try: await operation()
            except Exception as e:
                item={'scenario':name,'error':str(e),'traceback':traceback.format_exc()}; REPORT['failures'].append(item); log('scenario-failure',item)
        await browser.close()
    REPORT['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    (OUT/'observations.json').write_text(json.dumps(REPORT,ensure_ascii=False,indent=2)+'\n')
    log('summary',{'checks':len(REPORT['checks']),'failed_checks':sum(not c['passed'] for c in REPORT['checks']),'scenario_failures':len(REPORT['failures']),'frames':len(REPORT['frames']),'output':str(OUT)})

asyncio.run(main())
