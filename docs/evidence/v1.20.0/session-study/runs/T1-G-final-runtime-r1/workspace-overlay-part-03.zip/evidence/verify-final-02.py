from pathlib import Path
import json,time,hashlib
from playwright.sync_api import sync_playwright, expect
root=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w04');out=root/'evidence/final-behavior-02';out.mkdir(exist_ok=False)
long='跨城市田野研究协作小组 — Longitudinal everyday-mobility research programme'
results=[]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 for theme in ['light','dark']:
  for lang in ['en','zh']:
   name=f'{theme}-{lang}';run={'name':name,'checks':[],'frames':[],'pageErrors':[]};results.append(run)
   ctx=browser.new_context(viewport={'width':1280,'height':600},device_scale_factor=1)
   page=ctx.new_page();page.on('pageerror',lambda err:run['pageErrors'].append(str(err)))
   page.goto(f'http://127.0.0.1:4404/?theme={theme}&lang={lang}&fail=once',wait_until='networkidle')
   page.evaluate('document.fonts.ready')
   page.evaluate("async()=>{window.auditEvents=[];const m=await import('./settings-store.js');m.subscribeSettings(e=>auditEvents.push({status:e.status,operationId:e.operationId,at:performance.now(),settings:e.settings||null,snapshot:e.snapshot||null,fieldErrors:e.fieldErrors||null}));}")
   def snap(label):
    before=page.evaluate('performance.now()');page.screenshot(path=str(out/f'{name}-{label}.png'));after=page.evaluate('performance.now()')
    run['frames'].append({'label':label,'before':before,'after':after,'clock':'performance.now ms','focus':page.evaluate('document.activeElement.id || document.activeElement.tagName'),'status':page.locator('#save-status').inner_text()})
   def check(label,condition):
    run['checks'].append({'label':label,'pass':bool(condition)});assert condition,label
   try:
    page.locator('#business-name').fill('');page.locator('#email').fill('incomplete')
    page.locator('#save-settings').click();expect(page.locator('#save-status')).to_have_attribute('data-state','invalid')
    page.wait_for_timeout(600)
    check('validation focuses first invalid field',page.evaluate('document.activeElement.id')=='business-name')
    check('field errors have ARIA association',page.locator('#business-name').get_attribute('aria-invalid')=='true' and 'business-name-error' in page.locator('#business-name').get_attribute('aria-describedby'))
    check('validation writes no storage',page.evaluate("localStorage.getItem('fieldnotes-settings-v1')") is None)
    snap('invalid')
    page.locator('#business-name').fill('N'*101);page.locator('#business-id').fill('O'*181);page.locator('#location').fill('L'*101);page.locator('#email').fill('mei.lin@example.invalid')
    page.locator('#save-settings').click();expect(page.locator('#save-status')).to_have_attribute('data-state','invalid')
    check('all authoritative character limits surface inline',all(page.locator('#'+v).get_attribute('aria-invalid')=='true' for v in ['business-name','business-id','location']))
    page.locator('#business-name').fill('林玫' if lang=='zh' else 'Mei');page.locator('#business-id').fill(long);page.locator('#location').fill('Singapore / 新加坡')
    page.locator('#weekly-digest').uncheck();page.locator('#public-profile').check()
    page.locator('#save-settings').click();expect(page.locator('#save-status')).to_have_attribute('data-state','pending')
    check('pending exposes busy and blocks duplicate commit/cancel',page.locator('#save-settings').is_disabled() and page.locator('#cancel-settings').is_disabled() and page.locator('#save-settings').get_attribute('aria-busy')=='true')
    snap('pending')
    expect(page.locator('#save-status')).to_have_attribute('data-state','error')
    check('failure preserves previous storage',page.evaluate("localStorage.getItem('fieldnotes-settings-v1')") is None)
    check('failure retains complete submitted draft',page.locator('#business-id').input_value()==long and page.locator('#public-profile').is_checked() and not page.locator('#weekly-digest').is_checked())
    check('failure restores Save retry focus',page.evaluate('document.activeElement.id')=='save-settings')
    snap('error')
    page.locator('#save-settings').press('Enter');expect(page.locator('#save-status')).to_have_attribute('data-state','success')
    saved=page.evaluate('window.fieldnotes.readSettings()')
    check('keyboard retry persists switches and text',saved['organization']==long and saved['publicProfile'] and not saved['weeklyDigest'])
    snap('success')
    page.locator('#business-name').fill('Submitted snapshot')
    page.locator('#save-settings').click();expect(page.locator('#save-status')).to_have_attribute('data-state','pending')
    page.locator('#business-name').fill('Newer editable draft / 更新后的草稿')
    expect(page.locator('#save-status')).to_have_attribute('data-state','success')
    check('snapshot committed while newer draft stays editable',page.evaluate('window.fieldnotes.readSettings().displayName')=='Submitted snapshot' and page.locator('#business-name').input_value()=='Newer editable draft / 更新后的草稿')
    check('success does not steal continued field focus',page.evaluate('document.activeElement.id')=='business-name')
    check('success accurately names newer unsaved edits',('newer edits' in page.locator('#save-status').inner_text()) if lang=='en' else ('仍需保存' in page.locator('#save-status').inner_text()))
    page.wait_for_timeout(600);snap('newer-draft')
    page.locator('#language-toggle').click();check('language switch keeps draft',page.locator('#business-name').input_value()=='Newer editable draft / 更新后的草稿')
    page.locator('#theme-toggle').click();check('theme switch keeps draft',page.locator('#business-name').input_value()=='Newer editable draft / 更新后的草稿')
    page.locator('#cancel-settings').click();check('Cancel returns to last committed snapshot',page.locator('#business-name').input_value()=='Submitted snapshot')
    run['events']=page.evaluate('window.auditEvents')
    page.reload(wait_until='networkidle');check('reload returns real persisted settings',page.locator('#business-name').input_value()=='Submitted snapshot' and page.locator('#public-profile').is_checked())
    check('no JS page errors',not run['pageErrors'])
    run['pass']=True
   except Exception as e:
    run['pass']=False;run['error']=str(e);snap('failed-check')
   finally:
    ctx.close();(out/'results.json').write_text(json.dumps({'source':{f:hashlib.sha256((root/'app'/f).read_bytes()).hexdigest() for f in ['index.html','settings-controller.js','settings-store.js']},'runs':results},ensure_ascii=False,indent=2))
 browser.close()
print(json.dumps([{'name':r['name'],'pass':r.get('pass'), 'checks':len(r['checks']),'error':r.get('error')} for r in results],ensure_ascii=False,indent=2))
assert all(r.get('pass') for r in results)
