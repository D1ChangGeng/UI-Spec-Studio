// The supplied URL selects the content condition; keep controls in that language.
const zh = new URLSearchParams(location.search).get('lang') === 'zh';
export const copy = zh ? {
  input: '消息', placeholder: '继续提问…', send: '发送消息', stop: '停止生成',
  cancelSending: '取消发送', latest: '回到最新内容', retry: '重新生成',
  copy: '复制', edit: '编辑', cancel: '取消', update: '更新',
  addFile: '添加本地文件名', files: '已附加的文件名', filenameOnly: '仅文件名',
  remove: (name: string) => `移除 ${name}`,
  fileDisclosure: '仅保留文件名；不会读取或上传文件内容。',
  welcome: '想研究什么问题？',
} : {
  input: 'Message input', placeholder: 'Ask a follow-up…', send: 'Send message', stop: 'Stop generating',
  cancelSending: 'Cancel sending', latest: 'Return to latest', retry: 'Regenerate response',
  copy: 'Copy', edit: 'Edit', cancel: 'Cancel', update: 'Update',
  addFile: 'Attach local filenames', files: 'Attached filenames', filenameOnly: 'Filename only',
  remove: (name: string) => `Remove ${name}`,
  fileDisclosure: 'Only filenames are kept. File contents are never read or uploaded.',
  welcome: 'What would you like to research?',
};
