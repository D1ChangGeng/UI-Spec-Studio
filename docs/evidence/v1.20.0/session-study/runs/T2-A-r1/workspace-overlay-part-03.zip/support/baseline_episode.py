import asyncio,json,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
 out=ROOT/'evidence'/'baseline-episode';out.mkdir(parents=True,exist_ok=True)
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=CHROME,headless=True,args=['--no-sandbox'])
  page=await browser.new_page(viewport={'width':1280,'height':600})
  await page.goto('http://127.0.0.1:4405/?theme=light&lang=en')
  await page.evaluate('document.fonts.ready')
  records=[];start=time.monotonic()
  async def record(name):
   d=await page.evaluate("""() => {const v=document.querySelector('[data-slot="aui_thread-viewport"]'); const m=[...document.querySelectorAll('[data-slot="aui_assistant-message-content"]')].at(-1); return {top:v.scrollTop,height:v.clientHeight,scrollHeight:v.scrollHeight,textLength:m?.textContent.length,focus:document.activeElement?.outerHTML.slice(0,200),jumpVisible:!!document.querySelector('.aui-thread-scroll-to-bottom:not([disabled])')}}""")
   d.update(name=name,t=round(time.monotonic()-start,3));records.append(d)
   await page.screenshot(path=str(out/(name+'.png')))
  await page.get_by_role('textbox',name='Message input').fill('Show the long synthesis.')
  await page.get_by_role('button',name='Send message',exact=True).click();await page.wait_for_timeout(1500);await record('01-stream')
  await page.mouse.move(850,240);await page.mouse.wheel(0,-700);await page.wait_for_timeout(300);await record('02-away')
  await page.wait_for_timeout(1300);await record('03-away-growth')
  jump=page.get_by_role('button',name='Scroll to bottom',exact=True)
  if await jump.is_visible(): await jump.click()
  await page.wait_for_timeout(400);await record('04-return')
  await page.wait_for_timeout(800);await record('05-follow')
  stop=page.get_by_role('button',name='Stop generating',exact=True)
  if await stop.is_visible():await stop.click()
  await record('06-stopped');await page.wait_for_timeout(500);await record('07-stop-hold')
  (out/'episode.json').write_text(json.dumps(records,indent=2))
  print(json.dumps(records,indent=2))
  await browser.close()
asyncio.run(main())

