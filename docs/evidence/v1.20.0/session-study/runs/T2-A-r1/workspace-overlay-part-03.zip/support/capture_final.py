import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence'/'settled-final';OUT.mkdir(parents=True,exist_ok=True)
NAMES=['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','accessibility-interview-observations-comparative-research-final-revision.txt','reading-continuity-field-notes-follow-up-draft.txt']
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
  c=await b.new_context();page=await c.new_page()
  for theme,lang in [('light','en'),('dark','zh')]:
   for w,h in [(1440,900),(1280,600),(390,844)]:
    await page.set_viewport_size({'width':w,'height':h});await page.goto(f'http://127.0.0.1:4405/?theme={theme}&lang={lang}');await page.evaluate('document.fonts.ready')
    inp=page.locator('.aui-composer-input')
    await inp.fill('请比较这些资料。\n区分观察与解释。\n城市交通研究 notes\n保留不确定性。\n列出七个主题。\n最后提出后续问题。' if lang=='zh' else 'Please compare these materials.\nSeparate observations from interpretation.\n城市交通研究 notes\nKeep caveats visible.\nInclude seven themes.\nThen suggest next questions.')
    async with page.expect_file_chooser() as info:await page.locator('.aui-composer-add-attachment').click()
    await(await info.value).set_files([{'name':n,'mimeType':'text/plain','buffer':b'fixture'} for n in NAMES])
    await page.mouse.move(300,80);await inp.focus();await page.wait_for_timeout(450);await page.screenshot(path=str(OUT/f'{theme}-{lang}-{w}x{h}.png'))
  await b.close()
 print('Captured six settled final expanded-composer conditions.')
asyncio.run(main())
