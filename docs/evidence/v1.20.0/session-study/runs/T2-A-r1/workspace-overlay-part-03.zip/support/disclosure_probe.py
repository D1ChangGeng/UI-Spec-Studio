import asyncio,json,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence'/'disclosure-probe';OUT.mkdir(parents=True,exist_ok=True)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
  page=await b.new_page(viewport={'width':1280,'height':600})
  await page.goto('http://127.0.0.1:4405/?theme=light&lang=en');await page.evaluate('document.fonts.ready')
  async with page.expect_file_chooser() as info:await page.get_by_role('button',name='Attach local filenames',exact=True).click()
  name='城市出行访谈摘要_2026-10-31_final-revised-notes.txt'
  await (await info.value).set_files({'name':name,'mimeType':'text/plain','buffer':b'fixture'})
  group=page.get_by_role('group',name=name,exact=True)
  records=[]
  for action in ['focus','hover','keyboard','click']:
   if action=='focus':await group.focus()
   if action=='hover':await group.hover()
   if action=='keyboard':
    await page.get_by_role('textbox',name='Message input').focus();await page.keyboard.press('Shift+Tab');await page.keyboard.press('Shift+Tab')
   if action=='click':await group.click(position={'x':80,'y':15})
   await page.wait_for_timeout(300)
   records.append({'action':action,'dom':await page.locator('body').evaluate('(e)=>e.innerHTML.slice(-16000)'),'popups':await page.locator('[data-slot="tooltip-content"]').all_text_contents(),'roles':await page.get_by_role('tooltip').all_text_contents(),'focus':await page.evaluate('document.activeElement.outerHTML')})
   await page.screenshot(path=str(OUT/(action+'.png')))
  (OUT/'results.json').write_text(json.dumps(records,ensure_ascii=False,indent=2));print(json.dumps([{k:v for k,v in x.items() if k!='dom'} for x in records],ensure_ascii=False,indent=2))
  await b.close()
asyncio.run(main())

