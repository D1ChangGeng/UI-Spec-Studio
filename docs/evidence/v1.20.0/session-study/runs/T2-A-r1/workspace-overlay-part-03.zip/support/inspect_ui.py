import asyncio, json, os, time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
    out=ROOT/'evidence'/'baseline'; out.mkdir(parents=True,exist_ok=True)
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path=CHROME,headless=True,args=['--no-sandbox'])
        page=await browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
        logs=[]; page.on('pageerror',lambda e:logs.append(str(e)))
        await page.goto('http://127.0.0.1:4405/?theme=light&lang=en'); await page.evaluate('document.fonts.ready'); await page.wait_for_timeout(500)
        await page.screenshot(path=str(out/'desktop.png'))
        await page.set_viewport_size({'width':1280,'height':600})
        await page.locator('textarea').first.fill('Please compare these materials.\nSeparate observations from interpretation.\n城市交通研究 notes\nKeep caveats visible.\nInclude seven themes.\nThen suggest next questions.')
        async with page.expect_file_chooser() as chooser_info:
            await page.get_by_role('button',name='Add Attachment',exact=True).click()
        chooser=await chooser_info.value
        names=['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','accessibility-interview-observations-comparative-research-final-revision.txt','reading-continuity-field-notes-follow-up-draft.txt']
        await chooser.set_files([{'name':n,'mimeType':'text/plain','buffer':b'demo only'} for n in names])
        await page.wait_for_timeout(400); await page.screenshot(path=str(out/'compact-expanded.png'))
        geometry=await page.evaluate("""() => [...document.querySelectorAll('textarea, [data-slot="aui_composer-shell"], [data-slot="aui_thread-viewport"], .aui-attachment-root')].map(e=>({class:e.className,rect:e.getBoundingClientRect().toJSON(),scrollHeight:e.scrollHeight,clientHeight:e.clientHeight}))""")
        (out/'observations.json').write_text(json.dumps({'geometry':geometry,'pageerrors':logs,'captured_at':time.time()},ensure_ascii=False,indent=2))
        await browser.close()
asyncio.run(main())

