import asyncio,json,time,urllib.request
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence'/'product-reference';OUT.mkdir(parents=True,exist_ok=True)
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
def fetch(url):
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=18) as r:
  return r.status,{k:v for k,v in r.headers.items() if k.lower() not in ['transfer-encoding','content-length','content-encoding','connection']},r.read()
async def main():
 records=[];start=time.monotonic()
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=CHROME,headless=True,args=['--no-sandbox'])
  context=await browser.new_context(viewport={'width':1440,'height':900})
  async def route_request(route):
   if route.request.method!='GET': return await route.abort()
   try:
    status,headers,data=await asyncio.to_thread(fetch,route.request.url)
    await route.fulfill(status=status,headers=headers,body=data)
   except: await route.abort()
  await context.route('https://**/*',route_request)
  page=await context.new_page()
  try:
   await page.goto('https://huggingface.co/chat/',wait_until='domcontentloaded',timeout=45000);await page.wait_for_timeout(1000)
   start_button=page.get_by_role('button',name='Start chatting',exact=True)
   if await start_button.is_visible():await start_button.click()
   await page.wait_for_timeout(300)
   await page.screenshot(path=str(OUT/'01-entry.png'))
   records.append({'name':'entry after welcome dismissal','t':time.monotonic()-start})
   textarea=page.locator('textarea').first
   await textarea.fill('Compare the research materials.')
   await page.screenshot(path=str(OUT/'02-one-line.png'))
   records.append({'name':'one line draft','t':time.monotonic()-start,'bounds':await textarea.bounding_box()})
   await textarea.fill('Compare the research materials.\nKeep observations separate.\n城市交通与 accessibility.\nPreserve caveats.\nIdentify open questions.\nSuggest a next step.')
   await page.screenshot(path=str(OUT/'03-six-lines.png'))
   records.append({'name':'six line draft','t':time.monotonic()-start,'bounds':await textarea.bounding_box()})
   await page.set_viewport_size({'width':1280,'height':600});await page.screenshot(path=str(OUT/'04-compact.png'))
   records.append({'name':'compact six-line draft','t':time.monotonic()-start,'bounds':await textarea.bounding_box()})
  except Exception as e:records.append({'error':str(e)})
  await context.close();await browser.close()
 (OUT/'episode.json').write_text(json.dumps({'source':'https://huggingface.co/chat/','method':'Original resources over verified TLS; public logged-out compose surface only. No question submitted.','events':records},indent=2))
 print(json.dumps(records,indent=2))
asyncio.run(main())

