import asyncio, json, os, time, urllib.request, hashlib
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
    out=ROOT/'evidence'/'public'; out.mkdir(parents=True,exist_ok=True)
    urls={
      'aui-composer-registry':'https://r.assistant-ui.com/elements-composer.json',
      'aui-composer-base':'https://r.assistant-ui.com/base/elements-composer.json',
      'ai-elements-attachments':'https://elements.ai-sdk.dev/api/registry/attachments.json',
      'ai-elements-conversation':'https://elements.ai-sdk.dev/api/registry/conversation.json',
    }
    records=[]
    for key,url in urls.items():
      try:
        with urllib.request.urlopen(url,timeout=20) as response:
          data=response.read(); (out/(key+'.json')).write_bytes(data)
          records.append({'url':url,'final_url':response.url,'status':response.status,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'date':response.headers.get('date')})
      except Exception as e: records.append({'url':url,'error':str(e)})
    async with async_playwright() as p:
      browser=await p.chromium.launch(executable_path=CHROME,headless=True,args=['--no-sandbox'])
      page=await browser.new_page(viewport={'width':1440,'height':1000})
      for key,url in [('aui-demo','https://www.assistant-ui.com/elements/composer-attachments'),('ai-elements-demo','https://elements.ai-sdk.dev/components/attachments'),('ai-chatbot','https://elements.ai-sdk.dev/examples/chatbot')]:
        try:
          await page.goto(url,wait_until='domcontentloaded',timeout=25000)
          await page.wait_for_timeout(2000)
          await page.screenshot(path=str(out/(key+'.png')))
          (out/(key+'.txt')).write_text(await page.locator('body').inner_text())
          records.append({'url':url,'title':await page.title(),'capture':key+'.png'})
          if key=='ai-elements-demo':
            await page.get_by_role('heading',name='Inline Variant',exact=True).scroll_into_view_if_needed()
            await page.screenshot(path=str(out/'ai-elements-inline.png'))
          if key=='aui-demo':
            await page.wait_for_timeout(3500); await page.screenshot(path=str(out/'aui-demo-settled.png'))
        except Exception as e: records.append({'url':url,'browser_error':str(e)})
      await browser.close()
    (out/'acquisition.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
    print(json.dumps(records,ensure_ascii=False,indent=2))
asyncio.run(main())

