import asyncio, json, urllib.request, urllib.error, hashlib, time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
OUT=ROOT/'evidence'/'public-verified'; OUT.mkdir(parents=True,exist_ok=True)
records=[]
def fetch(url):
    req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
    with urllib.request.urlopen(req,timeout=18) as r:
        data=r.read()
        return r.status,{k:v for k,v in r.headers.items() if k.lower() not in ['transfer-encoding','content-length','content-encoding','connection']},data
async def route_request(route):
    url=route.request.url
    if route.request.method!='GET':
        records.append({'url':url,'method':route.request.method,'action':'aborted; read-only research'})
        return await route.abort()
    try:
        status,headers,data=await asyncio.to_thread(fetch,url)
        records.append({'url':url,'status':status,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
        await route.fulfill(status=status,headers=headers,body=data)
    except Exception as e:
        records.append({'url':url,'error':str(e)})
        await route.abort()
async def main():
    for name,url in [('aui-composer.tsx','https://raw.githubusercontent.com/assistant-ui/assistant-ui/ff654d8156680b839774296ef644b57ab1078425/packages/ui/src/components/react/assistant-ui/elements/composer.tsx'),('aui-composer.aui.tsx','https://raw.githubusercontent.com/assistant-ui/assistant-ui/ff654d8156680b839774296ef644b57ab1078425/packages/ui/src/components/react/assistant-ui/elements/composer.aui.tsx')]:
        try:
            status,headers,data=await asyncio.to_thread(fetch,url)
            (OUT/name).write_bytes(data); records.append({'url':url,'status':status,'sha256':hashlib.sha256(data).hexdigest(),'file':name})
        except Exception as e:records.append({'url':url,'error':str(e)})
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path=CHROME,headless=True,args=['--no-sandbox'])
        context=await browser.new_context(viewport={'width':1440,'height':1000})
        await context.route('https://**/*',route_request)
        page=await context.new_page()
        for key,url in [('aui-demo','https://www.assistant-ui.com/elements/composer-attachments'),('ai-elements-demo','https://elements.ai-sdk.dev/components/attachments'),('ai-chatbot','https://elements.ai-sdk.dev/examples/chatbot'),('huggingchat','https://huggingface.co/chat/')]:
            try:
                await page.goto(url,wait_until='domcontentloaded',timeout=45000)
                await page.wait_for_timeout(3000)
                await page.screenshot(path=str(OUT/(key+'.png')))
                (OUT/(key+'.txt')).write_text(await page.locator('body').inner_text())
                if key=='aui-demo':
                    await page.wait_for_timeout(2000); await page.screenshot(path=str(OUT/'aui-demo-settled.png'))
                if key=='ai-elements-demo':
                    await page.get_by_role('heading',name='Inline Variant',exact=True).scroll_into_view_if_needed(timeout=3000)
                    await page.screenshot(path=str(OUT/'ai-elements-inline.png'))
                    await page.get_by_role('heading',name='List Variant',exact=True).scroll_into_view_if_needed(timeout=3000)
                    await page.screenshot(path=str(OUT/'ai-elements-list.png'))
                if key=='huggingchat' and await page.locator('textarea').count():
                    await page.locator('textarea').first.fill('Compare these research notes.\nKeep observations separate.\n城市交通与 accessibility.\nPreserve caveats.\nIdentify open questions.\nSuggest a next step.')
                    await page.screenshot(path=str(OUT/'huggingchat-draft.png'))
            except Exception as e:records.append({'page':url,'error':str(e)})
        await context.close(); await browser.close()
    (OUT/'requests.json').write_text(json.dumps({'method':'Original public bytes fetched with urllib TLS verification; browser routes fulfilled without content editing. No HTTPS validation disabled. POST requests blocked.','records':records},ensure_ascii=False,indent=2))
    print(json.dumps({'requests':len(records),'errors':[r for r in records if 'error' in r]},ensure_ascii=False,indent=2))
asyncio.run(main())

