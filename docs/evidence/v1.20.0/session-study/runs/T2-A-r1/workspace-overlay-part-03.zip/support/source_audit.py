import json,hashlib,urllib.request,difflib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence'/'provenance';OUT.mkdir(parents=True,exist_ok=True)
manifest=json.loads((ROOT/'SOURCE-MANIFEST.json').read_text());rev=manifest['revision'];records=[]
for f in manifest['source_files']:
 p=ROOT/'app'/f['app_path']
 digest=hashlib.sha256(p.read_bytes()).hexdigest()
 rec={'file':str(p.relative_to(ROOT)),'original_path':f['upstream_path'],'original_sha256':f['sha256'],'current_sha256':digest,'changed':digest!=f['sha256']}
 if rec['changed']:
  url=f'https://raw.githubusercontent.com/assistant-ui/assistant-ui/{rev}/{f["upstream_path"]}'
  try:
   with urllib.request.urlopen(url,timeout=20) as r:data=r.read()
   orig=OUT/(p.name+'.original');orig.write_bytes(data)
   rec.update(source_url=url,acquired_sha256=hashlib.sha256(data).hexdigest(),matches_declared_original=hashlib.sha256(data).hexdigest()==f['sha256'])
   (OUT/(p.name+'.diff')).write_text(''.join(difflib.unified_diff(data.decode().splitlines(keepends=True),p.read_text().splitlines(keepends=True),fromfile=f['upstream_path'],tofile=str(p.relative_to(ROOT)))))
  except Exception as e:rec['error']=str(e)
 records.append(rec)
extras=['app/src/components/assistant-ui/elements/attachment-chip.tsx','app/src/locale.ts','app/src/vite-env.d.ts','app/tsconfig.json','app/package-lock.json','app/src/synthetic.ts']
result={'upstream':manifest['repository'],'revision':rev,'source_files':records,'other_files':[{'file':f,'sha256':hashlib.sha256((ROOT/f).read_bytes()).hexdigest()} for f in extras]}
(OUT/'source-audit.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'unchanged':sum(not r['changed'] for r in records),'changed':[r for r in records if r['changed']]},indent=2))

