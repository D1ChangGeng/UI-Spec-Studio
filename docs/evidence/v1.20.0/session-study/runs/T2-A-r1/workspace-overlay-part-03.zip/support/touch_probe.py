import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence'/'touch-probe';OUT.mkdir(parents=True,exist_ok=True)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
  c=await b.new_context(viewport={'width':390,'height':844},has_touch=True);page=await c.new_page();await page.goto('http://127.0.0.1:4405')
  async with page.expect_file_chooser() as info:await page.get_by_role('button',name='Attach local filenames',exact=True).click()
  await(await info.value).set_files({'name':'城市出行访谈摘要_2026-10-31_final-revised-notes.txt','mimeType':'text/plain','buffer':b'x'})
  await page.evaluate('''()=>{window.events=[];for(const t of ['pointerdown','pointerup','click','focusin','focusout'])document.addEventListener(t,e=>events.push({type:t,target:e.target.outerHTML.slice(0,300),at:performance.now()}),true);new MutationObserver(ms=>{for(const m of ms)if(m.target.matches?.('[role=group]'))events.push({mutation:m.attributeName,value:m.target.getAttribute(m.attributeName),at:performance.now()})}).observe(document.body,{attributes:true,subtree:true})}''')
  group=page.get_by_role('group').last;await group.tap();await page.wait_for_timeout(800)
  data=await page.evaluate('()=>({events,groups:[...document.querySelectorAll("[role=group]")].map(e=>e.outerHTML),tooltips:[...document.querySelectorAll("[role=tooltip]")].map(e=>e.outerHTML),active:document.activeElement.outerHTML})')
  (OUT/'result.json').write_text(json.dumps(data,ensure_ascii=False,indent=2));await page.screenshot(path=str(OUT/'touch.png'));print(json.dumps(data,ensure_ascii=False));await b.close()
asyncio.run(main())
