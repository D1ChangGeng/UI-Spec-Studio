import asyncio,json,traceback
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence'/'details-final';OUT.mkdir(parents=True,exist_ok=True)
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
NAMES=['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','accessibility-interview-observations-comparative-research-final-revision.txt','reading-continuity-field-notes-follow-up-draft.txt']
DRAFT='请比较这些资料。\n区分观察与解释。\n城市交通研究 notes\n保留不确定性。\n列出七个主题。\n最后提出后续问题。'
async def main():
 checks=[];errors=[]
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=CHROME,headless=True,args=['--no-sandbox'])
  c=await b.new_context(viewport={'width':1440,'height':900});page=await c.new_page()
  try:
   await page.goto('http://127.0.0.1:4405/?theme=dark&lang=zh');await page.evaluate('document.fonts.ready')
   inp=page.get_by_role('textbox',name='消息',exact=True);await inp.fill('保留这份草稿')
   user=page.locator('[data-slot="aui_user-message-root"]').last;await user.hover()
   editButton=page.locator('.aui-user-action-edit').last
   checks.append({'name':'Source edit affordance available after message hover','pass':await editButton.is_visible()})
   await editButton.click(timeout=3000)
   edit=page.locator('.aui-edit-composer-input');await edit.fill('修改后的问题')
   await page.screenshot(path=str(OUT/'01-editing.png'))
   await page.get_by_role('button',name='取消',exact=True).focus();await page.keyboard.press('Enter')
   checks.append({'name':'Cancel edit retains draft and restores focus','pass':await inp.input_value()=='保留这份草稿' and await inp.evaluate('(e)=>document.activeElement===e')})
   await page.screenshot(path=str(OUT/'02-edit-return.png'))
   await user.hover();await editButton.click(timeout=3000);await edit.fill('修改后的研究问题');await page.get_by_role('button',name='更新',exact=True).click()
   await page.get_by_role('button',name='停止生成',exact=True).wait_for(state='visible')
   checks.append({'name':'Update edit changes question and starts response','pass':'修改后的研究问题' in await page.locator('[data-slot="aui_user-message-root"]').last.inner_text()})
   await page.get_by_role('button',name='停止生成',exact=True).click();await page.wait_for_timeout(200)
   checks.append({'name':'Updating another message preserves main draft','pass':await inp.input_value()=='保留这份草稿'})
   await page.screenshot(path=str(OUT/'03-edit-update.png'))
   await page.emulate_media(reduced_motion='reduce')
   checks.append({'name':'Reduced motion disables smooth scrolling','pass':await page.locator('[data-slot="aui_thread-viewport"]').evaluate('(e)=>getComputedStyle(e).scrollBehavior')=='auto'})
  except Exception:errors.append(traceback.format_exc())
  for w,h in [(1440,900),(1280,600),(390,844)]:
   try:
    await page.set_viewport_size({'width':w,'height':h});await page.goto('http://127.0.0.1:4405/?theme=dark&lang=zh');await page.evaluate('document.fonts.ready')
    await page.get_by_role('textbox',name='消息',exact=True).fill(DRAFT)
    async with page.expect_file_chooser() as info:await page.get_by_role('button',name='添加本地文件名',exact=True).click()
    await(await info.value).set_files([{'name':n,'mimeType':'text/plain','buffer':b'fixture'} for n in NAMES])
    await page.screenshot(path=str(OUT/f'expanded-{w}x{h}.png'))
    checks.append({'name':f'Chinese expanded composer contains controls at {w}x{h}','pass':await page.locator('.aui-composer-cancel,.aui-composer-send').last.evaluate('(e)=>{const r=e.getBoundingClientRect();return r.bottom<=innerHeight&&r.right<=innerWidth&&r.left>=0}')})
   except Exception:errors.append(traceback.format_exc())
  await c.close()
  try:
   tc=await b.new_context(viewport={'width':390,'height':844},has_touch=True)
   tp=await tc.new_page();await tp.goto('http://127.0.0.1:4405/?theme=light&lang=en');await tp.evaluate('document.fonts.ready')
   async with tp.expect_file_chooser() as info:await tp.get_by_role('button',name='Attach local filenames',exact=True).click()
   await(await info.value).set_files({'name':NAMES[1],'mimeType':'text/plain','buffer':b'fixture'})
   await tp.get_by_role('group',name=NAMES[1],exact=True).tap();await tp.wait_for_timeout(150)
   checks.append({'name':'Touch tap discloses the full filename','pass':await tp.get_by_role('tooltip').filter(has_text=NAMES[1]).is_visible()})
   await tp.screenshot(path=str(OUT/'touch-disclosure.png'));await tc.close()
  except Exception:errors.append(traceback.format_exc())
  await b.close()
 result={'checks':checks,'errors':errors};(OUT/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
asyncio.run(main())

