import asyncio, json, time, traceback
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
OUT=ROOT/'evidence'/'final';OUT.mkdir(parents=True,exist_ok=True)
NAMES=['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','accessibility-interview-observations-comparative-research-final-revision.txt','reading-continuity-field-notes-follow-up-draft.txt']
DRAFT='Please compare these materials.\nSeparate observations from interpretation.\n城市交通研究 notes\nKeep caveats visible.\nInclude seven themes.\nThen suggest next questions.'
async def main():
 records=[];checks=[];errors=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=CHROME,headless=True,args=['--no-sandbox'])
  context=await browser.new_context(viewport={'width':1280,'height':600},device_scale_factor=1,record_video_dir=str(OUT/'video'),record_video_size={'width':1280,'height':600})
  page=await context.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
  start=time.monotonic()
  async def record(name,screenshot=True):
   d=await page.evaluate("""() => {const v=document.querySelector('[data-slot="aui_thread-viewport"]'); const m=[...document.querySelectorAll('[data-slot="aui_assistant-message-content"]')].at(-1); const i=document.querySelector('.aui-composer-input'); const c=document.querySelector('[data-slot="aui_composer-shell"]');return {top:v?.scrollTop,height:v?.clientHeight,scrollHeight:v?.scrollHeight,textLength:m?.textContent.length,focus:document.activeElement?.tagName,inputHeight:i?.getBoundingClientRect().height,inputScroll:i?.scrollHeight,composer:c?.getBoundingClientRect().toJSON(),horizontalOverflow:document.documentElement.scrollWidth>innerWidth,attachmentCount:document.querySelectorAll('.aui-composer-attachments .aui-attachment-root').length}}""")
   d.update(name=name,t=round(time.monotonic()-start,3));records.append(d)
   if screenshot:await page.screenshot(path=str(OUT/(name+'.png')))
   return d
  async def attach():
   async with page.expect_file_chooser() as info:
    await page.get_by_role('button',name='Attach local filenames',exact=True).click()
   await (await info.value).set_files([{'name':n,'mimeType':'text/plain','buffer':b'synthetic fixture'} for n in NAMES])
  try:
   await page.goto('http://127.0.0.1:4405/?theme=light&lang=en');await page.evaluate('document.fonts.ready')
   await record('01-initial-compact')
   inp=page.get_by_role('textbox',name='Message input',exact=True)
   await inp.fill(DRAFT);await attach();await page.wait_for_timeout(150)
   await record('02-expanded-files')
   await page.get_by_role('group',name=NAMES[1],exact=True).focus();await page.wait_for_timeout(150)
   await record('03-filename-disclosure')
   checks.append({'name':'Full filename disclosed on keyboard focus','pass':await page.get_by_role('tooltip').filter(has_text=NAMES[1]).is_visible()})
   await page.get_by_role('button',name='Remove notes.txt',exact=True).click()
   checks.append({'name':'Remove returns focus to composer','pass':await inp.evaluate('(e)=>document.activeElement===e')})
   await inp.fill('\n'.join([DRAFT]*8));await record('04-long-draft')
   checks.append({'name':'Long draft scrolls within height cap','pass':await inp.evaluate('(e)=>e.scrollHeight>e.clientHeight && e.clientHeight<=150')})
   await inp.fill('Show the long synthesis.')
   await page.get_by_role('button',name='Send message',exact=True).click();await page.wait_for_timeout(850);await record('05-stream')
   await page.mouse.move(850,220);await page.mouse.wheel(0,-850);await page.wait_for_timeout(180);away=await record('06-away')
   await page.wait_for_timeout(700);held=await record('07-away-growth')
   checks.append({'name':'Manual reading position holds while answer grows','pass':abs(held['top']-away['top'])<=2 and held['textLength']>away['textLength']})
   await page.get_by_role('button',name='Return to latest',exact=True).click();await page.wait_for_timeout(250);returned=await record('08-return')
   await page.wait_for_timeout(500);following=await record('09-following')
   checks.append({'name':'Return resumes latest following','pass':following['scrollHeight']-following['height']-following['top']<10})
   await page.mouse.move(850,220);await page.mouse.wheel(0,-650);await page.wait_for_timeout(200);away2=await record('10-away-again')
   await page.wait_for_timeout(500);held2=await record('11-hold-again')
   checks.append({'name':'Scrolling away again stops following','pass':abs(away2['top']-held2['top'])<=2 and held2['textLength']>away2['textLength']})
   await page.get_by_role('button',name='Stop generating',exact=True).click()
   await page.get_by_role('button',name='Stop generating',exact=True).wait_for(state='hidden')
   await page.wait_for_timeout(500);stopped=await record('12-stopped')
   await page.wait_for_timeout(700);stopheld=await record('13-stop-hold')
   checks.append({'name':'Stopped output remains stable after renderer settles','pass':stopped['textLength']==stopheld['textLength']})
   checks.append({'name':'Stop returns focus to composer','pass':await inp.evaluate('(e)=>document.activeElement===e')})
   await inp.fill('Recovery question [fail]');await inp.press('Enter')
   await page.locator('.aui-message-error-root').wait_for(state='visible');await record('14-failure')
   await page.get_by_role('button',name='Regenerate response',exact=True).last.click()
   await page.get_by_role('button',name='Stop generating',exact=True).wait_for(state='visible')
   await page.get_by_role('button',name='Stop generating',exact=True).wait_for(state='hidden',timeout=15000)
   await page.wait_for_timeout(300);await record('15-retry-complete')
   checks.append({'name':'Retry completes all seven themes','pass':'Observation theme 7' in await page.locator('[data-slot="aui_assistant-message-content"]').last.inner_text() and await page.locator('.aui-message-error-root').count()==0})
   await inp.fill('Recovery question [fail]');await inp.press('Enter')
   await page.get_by_role('button',name='Stop generating',exact=True).wait_for(state='visible')
   await page.wait_for_timeout(900);await record('16-repeat-question')
   checks.append({'name':'Same failed question can continue during session','pass':await page.locator('.aui-message-error-root').count()==0})
   await page.get_by_role('button',name='Stop generating',exact=True).click();await page.wait_for_timeout(300)
   # IME contract through actual events, without a physical IME.
   await inp.fill('尚未完成的中文')
   await inp.dispatch_event('keydown',{'key':'Enter','code':'Enter','isComposing':True,'keyCode':229,'bubbles':True})
   checks.append({'name':'IME confirming Enter does not submit','pass':await inp.input_value()=='尚未完成的中文'})
   await inp.press('Shift+Enter');checks.append({'name':'Shift+Enter inserts newline','pass':'\n' in await inp.input_value()})
   for theme,lang in [('light','en'),('dark','zh')]:
    for width,height in [(1440,900),(1280,600),(390,844)]:
     await page.set_viewport_size({'width':width,'height':height})
     await page.goto(f'http://127.0.0.1:4405/?theme={theme}&lang={lang}');await page.evaluate('document.fonts.ready');await page.wait_for_timeout(150)
     d=await record(f'view-{theme}-{lang}-{width}x{height}')
     checks.append({'name':f'No page horizontal overflow {theme}/{lang}/{width}x{height}','pass':not d['horizontalOverflow']})
   await page.goto('http://127.0.0.1:4405/?theme=light&lang=en');await page.evaluate('document.fonts.ready')
   await page.get_by_role('textbox',name='Message input',exact=True).fill(DRAFT);await attach();await record('17-mobile-expanded')
   region=page.get_by_role('region',name='Attached filenames',exact=True)
   await region.hover();await page.mouse.wheel(0,450);await page.wait_for_timeout(150);await record('18-mobile-files-scrolled')
   checks.append({'name':'Mobile attachment region scrolls to remaining files','pass':await region.evaluate('(e)=>e.scrollTop>0')})
  except Exception as e:
   errors.append(traceback.format_exc())
   await page.screenshot(path=str(OUT/'failure.png'))
  finally:
   await context.close();await browser.close()
   result={'viewport':{'width':1280,'height':600},'browser':'Chromium headless shell 143.0.7499.4','devicePixelRatio':1,'clock':'monotonic, seconds from browser ready','records':records,'checks':checks,'errors':errors,'video_note':'Recorded at 1280x600; later viewport changes may be scaled. PNGs retain requested viewport sizes.'}
   (OUT/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
   print(json.dumps({'checks':checks,'errors':errors},ensure_ascii=False,indent=2))
asyncio.run(main())

