import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence'/'touch-release';OUT.mkdir(parents=True,exist_ok=True)
async def main():
 checks=[]
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
  c=await b.new_context(viewport={'width':390,'height':844},has_touch=True);page=await c.new_page();await page.goto('http://127.0.0.1:4405');await page.evaluate('document.fonts.ready')
  name='城市出行访谈摘要_2026-10-31_final-revised-notes.txt'
  async with page.expect_file_chooser() as info:await page.get_by_role('button',name='Attach local filenames',exact=True).click()
  await(await info.value).set_files({'name':name,'mimeType':'text/plain','buffer':b'x'})
  group=page.get_by_role('group',name=name,exact=True);tip=page.get_by_role('tooltip').filter(has_text=name);inp=page.get_by_role('textbox',name='Message',exact=True)
  await group.tap();await page.wait_for_timeout(400);checks.append({'name':'Touch tap keeps filename visible','pass':await tip.is_visible()});await page.screenshot(path=str(OUT/'01-touch.png'))
  await inp.tap();await page.wait_for_timeout(250);checks.append({'name':'Touch outside dismisses disclosure','pass':not await tip.is_visible()})
  await group.focus();await page.wait_for_timeout(150);checks.append({'name':'Keyboard focus reveals filename','pass':await tip.is_visible()});await page.keyboard.press('Escape');await page.wait_for_timeout(250);checks.append({'name':'Escape dismisses disclosure','pass':not await tip.is_visible()})
  await page.get_by_role('button',name='Remove '+name,exact=True).tap();checks.append({'name':'Touch remove restores composer focus','pass':await group.count()==0 and await inp.evaluate('(e)=>document.activeElement===e')})
  await b.close()
 result={'checks':checks};(OUT/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
asyncio.run(main())
