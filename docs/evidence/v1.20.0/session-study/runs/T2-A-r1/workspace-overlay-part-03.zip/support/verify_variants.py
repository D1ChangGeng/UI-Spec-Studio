import asyncio,json,time,traceback
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence'/'variants';OUT.mkdir(parents=True,exist_ok=True)
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
NAMES=['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','accessibility-interview-observations-comparative-research-final-revision.txt','reading-continuity-field-notes-follow-up-draft.txt']
DRAFT='请比较这些资料。\n区分观察与解释。\n城市交通研究 notes\n保留不确定性。\n列出七个主题。\n最后提出后续问题。'
async def main():
 checks=[];records=[];errors=[];start=time.monotonic()
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=CHROME,headless=True,args=['--no-sandbox'])
  c=await b.new_context(viewport={'width':1280,'height':600},device_scale_factor=1)
  page=await c.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
  async def snap(name):
   d=await page.evaluate("""() => {const v=document.querySelector('[data-slot="aui_thread-viewport"]');const m=[...document.querySelectorAll('[data-slot="aui_assistant-message-content"]')].at(-1);return {top:v.scrollTop,height:v.clientHeight,scrollHeight:v.scrollHeight,text:m?.textContent,focus:document.activeElement.tagName}}""")
   d.update(name=name,t=round(time.monotonic()-start,3));records.append(d)
   await page.screenshot(path=str(OUT/(name+'.png')));return d
  async def attach():
   async with page.expect_file_chooser() as info:await page.get_by_role('button',name='添加本地文件名',exact=True).click()
   await(await info.value).set_files([{'name':n,'mimeType':'text/plain','buffer':b'fixture'} for n in NAMES])
  try:
   await page.goto('http://127.0.0.1:4405/?theme=dark&lang=zh');await page.evaluate('document.fonts.ready')
   inp=page.get_by_role('textbox',name='消息',exact=True)
   await inp.fill(DRAFT);await attach();await snap('01-zh-expanded')
   await page.get_by_role('group',name=NAMES[1],exact=True).focus();await snap('02-zh-disclosure')
   checks.append({'name':'Chinese filename disclosure and privacy copy','pass':await page.get_by_role('tooltip').filter(has_text='不会读取或上传').is_visible()})
   await inp.fill('请给出完整研究综合。');await inp.press('Enter');await page.wait_for_timeout(180);await snap('03-zh-stream')
   await page.mouse.move(850,220);await page.mouse.wheel(0,-650);await page.wait_for_timeout(100);away=await snap('04-zh-away')
   await page.wait_for_timeout(180);held=await snap('05-zh-held')
   checks.append({'name':'Chinese streaming preserves manual reading point','pass':abs(held['top']-away['top'])<=2 and len(held['text'])>len(away['text'])})
   await page.get_by_role('button',name='回到最新内容',exact=True).click();await page.wait_for_timeout(150);await snap('06-zh-return')
   await page.wait_for_timeout(180);follow=await snap('07-zh-follow')
   checks.append({'name':'Chinese return follows latest text','pass':follow['scrollHeight']-follow['height']-follow['top']<=10})
   stop=page.get_by_role('button',name='停止生成',exact=True)
   if await stop.is_visible():
    await stop.focus();await snap('08-zh-keyboard-stop-focus');await stop.press('Space')
   else:
    await inp.fill('再继续一次');await inp.press('Enter');await stop.wait_for(state='visible');await stop.focus();await stop.press('Space')
   await stop.wait_for(state='hidden');await page.wait_for_timeout(200);stopped=await snap('09-zh-stopped')
   await page.wait_for_timeout(300);heldstop=await snap('10-zh-stop-hold')
   checks.append({'name':'Chinese keyboard stop restores composer focus and stops text','pass':heldstop['focus']=='TEXTAREA' and stopped['text']==heldstop['text']})
   await inp.fill('测试恢复 [fail]');await inp.press('Enter');await page.locator('.aui-message-error-root').wait_for(state='visible');await snap('11-zh-failure')
   await page.get_by_role('button',name='重新生成',exact=True).last.click()
   await page.get_by_role('button',name='停止生成',exact=True).wait_for(state='visible')
   await page.get_by_role('button',name='停止生成',exact=True).wait_for(state='hidden',timeout=15000);await snap('12-zh-retry')
   checks.append({'name':'Chinese failure/retry completes all seven themes','pass':'观察主题 7' in await page.locator('[data-slot="aui_assistant-message-content"]').last.inner_text() and await page.locator('.aui-message-error-root').count()==0})
   await inp.fill('保留这份草稿');await page.get_by_role('button',name='编辑',exact=True).last.click()
   edit=page.locator('.aui-edit-composer-input');await edit.fill('修改后的问题')
   await page.get_by_role('button',name='取消',exact=True).focus();await page.keyboard.press('Enter')
   checks.append({'name':'Cancel editing restores existing draft and focus','pass':await inp.input_value()=='保留这份草稿' and await inp.evaluate('(e)=>document.activeElement===e')})
   await snap('13-edit-return')
   await page.emulate_media(reduced_motion='reduce')
   checks.append({'name':'Reduced motion disables smooth scrolling','pass':await page.locator('[data-slot="aui_thread-viewport"]').evaluate('(e)=>getComputedStyle(e).scrollBehavior')=='auto'})
   for w,h in [(1440,900),(390,844)]:
    await page.set_viewport_size({'width':w,'height':h});await page.goto('http://127.0.0.1:4405/?theme=dark&lang=zh');await page.evaluate('document.fonts.ready')
    await page.get_by_role('textbox',name='消息',exact=True).fill(DRAFT);await attach();await snap(f'14-expanded-{w}x{h}')
   await c.close()
   # Touch is supplementary and separately emulated; no claim about a physical keyboard.
   tc=await b.new_context(viewport={'width':390,'height':844},has_touch=True)
   tp=await tc.new_page();await tp.goto('http://127.0.0.1:4405/?theme=light&lang=en');await tp.evaluate('document.fonts.ready')
   async with tp.expect_file_chooser() as info:await tp.get_by_role('button',name='Attach local filenames').click()
   await(await info.value).set_files({'name':NAMES[1],'mimeType':'text/plain','buffer':b'fixture'})
   await tp.get_by_role('group',name=NAMES[1],exact=True).tap();await tp.wait_for_timeout(150)
   checks.append({'name':'Touch tap discloses the full filename','pass':await tp.get_by_role('tooltip').filter(has_text=NAMES[1]).is_visible()})
   await tp.screenshot(path=str(OUT/'15-touch-disclosure.png'));await tc.close()
  except Exception:errors.append(traceback.format_exc())
  finally:
   await b.close()
   (OUT/'results.json').write_text(json.dumps({'checks':checks,'records':records,'errors':errors},ensure_ascii=False,indent=2))
   print(json.dumps({'checks':checks,'errors':errors},ensure_ascii=False,indent=2))
asyncio.run(main())

