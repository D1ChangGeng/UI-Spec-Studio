# Meridian — composer and reading continuity completed

The runnable application and rebuilt `app/dist` now include persistent filename rows, full-name disclosure, bounded composer growth, and user-controlled following of streamed answers. The supplied assistant-ui workspace remains the visual and behavioral foundation. The long deterministic responses, stop behavior, intentional `[fail]` path, and filename-only adapter remain intact.

## What changed

- **Files are identifiable before sending.** The existing assistant-ui File components now show a filename and “Filename only” beneath it. Click, tap or press Enter on a file to open its complete name and the local-only explanation in the existing Dialog. Removal is a separate control, and focus returns to the draft.
- **The composer stays usable at compact height.** The original autosizing input and stable action row remain. Input height is capped at the smaller of 12rem and 25dvh; extra text scrolls inside the input. The same limit applies while editing a sent message.
- **Reading position follows the user's action.** Scrolling upward pauses following while the answer continues. “Return to latest” resumes following subsequent chunks. The first top-anchor trial failed that second part; the final implementation uses the runtime's supported bottom-anchor configuration and passed the complete episode. genui{"citation":{"ref":"turn24view1"}}
- **Continuation works through interruption and recovery.** Stop prevents later chunks and returns focus to the composer. Full-name disclosure restores focus after closing. Retry, edit/update and another question remain operable. Main task controls have Chinese labels in the Chinese condition. On touch-primary devices, Enter inserts a newline and the visible send button submits.

![Final compact workspace with six-line input and filename strip](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w06/evidence/captures/run-03/final-1280x600-light-en-grown.png)

## Why this source choice

The observed alternatives offered different space tradeoffs: Vercel AI Elements' inline attachments wrap into extra rows; its list variant uses larger metadata rows; Ant Design X exposes an attachment header that can collapse above the draft. The existing assistant-ui File family supplied the needed filename hierarchy with the smallest adaptation to this workspace. Its outline, icon, type, secondary metadata and trailing action relationships remain visible in the result. genui{"citation":{"ref":"turn24view0"}}

The strip intentionally stays one row high. Several long filenames require horizontal scrolling, and truncated names open into the full-name Dialog. That preserves reading height while making file identity available. The independent candidates remain research references; their code was not copied into the product. The exact source, comparisons, adopted locations and remaining costs are recorded in [ADOPTION.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w06/ADOPTION.md).

## Verification

| Check | Actual result |
|---|---|
| Production build and TypeScript | Pass. Starter TypeScript 7 configuration/CSS declaration issues were repaired; original failures are retained. |
| 1440×900, 1280×600 and 390×844 | English/light and Chinese/dark tested; all six initial and expanded layouts personally viewed. |
| One-line, six-line and long mixed input | Growth bounds, reachable actions and absence of page-wide horizontal overflow verified. |
| Multiple long filenames | Full-name Dialog, settled focus return, removal and draft retention pass in all six conditions. |
| Streaming in English and Chinese | Manual scroll-away holds position while text grows; explicit return stays at the bottom during further growth. |
| Stop, deliberate failure, retry, repeat | Pass through actual controls in both locales; stop also returns keyboard focus. |
| Keyboard continuation | Fourth attachment reached through horizontal focus scrolling; Enter/Escape disclosure, removal, stop and edit/update pass. |
| Coupled draft/file growth while reading away | ScrollTop remained 26px while answer text grew from 2324 to 2823 characters and the footer expanded upward. The draft survived stopping. |
| Touch emulation | Enter newline, tap-to-send and tap-to-stop pass at 390×844. |

The primary designer opened the final PNGs and the ordered streaming, interruption and recovery frames. [VISUAL-REVIEW.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w06/VISUAL-REVIEW.md) distinguishes viewed pixels, measured behavior and sampled temporal evidence. The final structured run is [verification-03.json](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w06/evidence/verification-03.json); command exports, source digests, failed attempts and corrected captures remain under `evidence/`.

## Run the product

```bash
cd /workspace/scratch/708e8b7f118e/ui-study/worksets/w06/app
python3 -m http.server 4406 --bind 127.0.0.1 --directory dist
```

Open `http://127.0.0.1:4406/?theme=light&lang=en` or `http://127.0.0.1:4406/?theme=dark&lang=zh` from a browser that can reach this executor. Rebuild with `npm run build`; develop with `npm run dev -- --host 127.0.0.1 --port 4406`.

## Limits carried forward

The product remains local and synthetic: reload resets the seeded conversation, file contents are never read or uploaded, and no real model service is connected. Header/sidebar and some auxiliary upstream labels remain English. Horizontal attachment scrolling remains necessary with several files.

The evidence covers the dedicated Chrome runtime, controlled timestamped frames and touch emulation. It does not establish natural-time video quality, physical mobile keyboard behavior, real IME operation, screen-reader user comprehension, Safari/Firefox behavior or production deployment. Vite retains a bundle-size warning for the complete upstream application. No blocker remains in the exercised scope; owner acceptance is separate from these checks.

The cohesive scope is documented in [SPEC.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w06/SPEC.md), with the independent [RESEARCH-REPORT.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w06/evidence/research/RESEARCH-REPORT.md) and [DELEGATION.json](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w06/DELEGATION.json) retaining research and coordination provenance.
