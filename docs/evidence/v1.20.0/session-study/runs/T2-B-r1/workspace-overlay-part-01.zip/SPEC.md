# SPEC 01 — Composition and reading continuity

## Overview

Meridian is a local conversation workspace for asking, reading, revisiting, and continuing research questions. This working-product increment keeps composer size, filename disclosure, answer growth, and user-controlled reading position together. The source is assistant-ui at `ff654d8156680b839774296ef644b57ab1078425` (MIT), with the supplied deterministic adapter and pinned dependencies. No cloud history, file content upload, or real model service is added.

The formal scope owns the input contour/type/action hierarchy; one-line, six-line and mixed-language growth; identification and removal of multiple attachments; streaming/stop/retry; manual reading away from the latest answer; keyboard return; and short/narrow viewport integrity. Sidebar and message layout remain a contextual regression scope. This is one SPEC because footer size, available reading area, focus, and scrolling share one experience.

## Initial questions and evidence plan

1. **Attachment identity (L1/L3/L4):** baseline document tiles show only a file icon. Can users distinguish selected filenames without hover? Inspect multiple long names, then trial the existing source `File.Root/Icon/Name` family within the current attachment state owner. Research independent integrated alternatives before a final choice.
2. **Growth (L2/L3/L4):** does the inherited textarea's 192px maximum consume too much of a 600px viewport when files grow? Capture current six-line state, configure an appropriate viewport-dependent limit if needed, and recheck reading area and action row. Keep the mature autosize implementation and its older-browser fallback.
3. **Reading intent (L1/L2/L5):** inherited `turnAnchor="top"` defaults to no auto-follow. Test manual scroll-away during growth and the explicit latest control. Use the source's public viewport properties if follow needs adjustment; do not add competing scroll ownership.
4. **Complete state (L1/L3/L5):** run failure/retry, cancellation, repeated question, focused remove, and return. Localize important composer/reading controls for the Chinese condition while preserving user text.

## Source and visual responsibilities

| Responsibility | Candidate and current status | Retain |
|---|---|---|
| Workspace, reading measure, neutral themes | Supplied assistant-ui cloud composition; viewed compact baseline | Sidebar/header anchors, 44rem content measure, source tokens and self-hosted type |
| Input and action row | Supplied Thread composer and `ComposerPrimitive.Input`; source inspected, baseline viewed | Rounded source shell, border/focus relation, 16px/24px input, stable plus/send/stop row |
| File metadata | Existing assistant-ui File family; source inspected and original demo viewed, composition adopted | Outline row, icon/name hierarchy, existing remove action and attachment runtime |
| Scroll and focus | assistant-ui viewport/footer and composer primitives | One scroll owner, measured sticky footer, user interruption, explicit return |
| Independent alternatives | Vercel inline/list attachments and Ant Sender/Header observed; comparison in ADOPTION.md | Compare useful relationships and integration cost; reference-only findings stay reference-only |

No original visual mechanism is authorized or planned. Responsive constraints, labels, state wiring and composition use existing source families. A gap that cannot be resolved by them remains explicit.

## Conditions and evidence

Primary viewports: 1440×900 and 1280×600. Supplementary: 390×844. English/light and Chinese/dark in all three; theme and locale are query-selected fixtures. Font-ready Chrome headless, DPR 1, with the prescribed CJK font configuration. Actual screenshots must be opened with `view_image`; interactions and timestamped snapshots establish sampled episodes, not natural-speed video viewing.

Original evidence belongs in `evidence/`. Initial capture: `captures/baseline-compact.png`. The first test failed because it selected react-textarea-autosize's hidden measurement field; `commands/003-baseline` retains that failure, and `004-baseline` is the corrected visible-control attempt.

## Maturity

Current: implemented and inspected at the local synthetic boundary. `ADOPTION.md` is the current decision record, `VISUAL-REVIEW.md` records personally viewed final pixels and sampled episodes, and `FINAL.md` is the delivery. The final viewport uses the source-supported bottom policy after the top policy failed resumed-follow testing. Both locales pass scroll-away, further growth after return, cancellation, failure/retry, repeat and edit continuity. The six viewport/variant layouts, settled details focus, keyboard file access and touch emulation are checked. Natural-time playback, physical devices, IME, additional browsers and user acceptance remain outside the demonstrated scope. Owner approval has not been inferred from execution authority.
