# Visual review — SPEC 01

## Observer, object and conditions

The primary package designer personally opened the baseline, important external reference captures, local trial and final integrated PNGs through `view_image`. Full actual returned objects, including image payloads, are retained in `evidence/view-*.json`. Files saved without an image-open call are not counted as viewed here.

Final integrated source is identified by `evidence/source-changes.json` and `evidence/final-build-digests.json`. Build output uses `index-BvJlpQMp.js` and `index-C0wGjqVZ.css`. Tests loaded the actual built app on the dedicated local port 4406. Chrome headless 143.0.7499.4, DPR 1, CSS viewports 1440×900, 1280×600 and 390×844; English/light and Chinese/dark; font readiness awaited and `FONTCONFIG_FILE=/tmp/ui-spec-fonts/fonts.conf` supplied to browser processes.

The integrated state matrix is in `evidence/verification-03.json`; its exact command/stdout/stderr in `evidence/commands/012-verification-focus/`. Captures are under `evidence/captures/run-03/`. Main streaming episodes used reduced-motion preference; the coupled-growth run and keyboard run used normal motion. Touch behavior used mobile/touch browser emulation, not a physical device or a displayed software keyboard.

## Actually viewed static result

I viewed all six `final-*-initial.png` and all six `final-*-grown.png` images in run-03. I also viewed the narrow Chinese filename dialog, keyboard filename focus, Chinese edit state, coupled expanded composer, and touch-send result.

**Whole workspace.** The supplied sidebar/header anchors and centered reading column remain. Wide screens retain the open source spacing around the reading surface. At compact height the latest position naturally shows the end of the seeded answer, with older material above the scroll boundary. At 390px the sidebar is hidden by the existing responsive family; the input remains full-width inside the source margins. No page-wide horizontal overflow occurred in the measured conditions.

**Input and actions.** The composer keeps the original rounded contour, understated border, neutral surface, 16px/24px text and aligned add/send or stop row. Six-line mixed content is readable and the actions stay at the bottom edge of the input shell. The compact full footer measured 298px tall with files and a six-line draft; the 150px input bound leaves the rest of the viewport available to reading. A longer mixed-language draft scrolls internally, capped at 192px on tall screens and 150px at 600px height. The bounds were measured; the six-line captures provide the direct visual review.

**Attachment identity.** The File rows preserve the original demo's icon/name/secondary-information/trailing-action relationship. Short names are immediately readable. Long names are visibly truncated; the next card is partly visible at the strip edge, showing that more content extends horizontally. This is a deliberate density tradeoff, not a claim that every name is fully visible. In keyboard use, the last file moved into view and received a visible source focus outline. A transient removal tooltip from the preceding focus target appears in that capture; the actual focused target and subsequent dialog behavior are recorded separately.

**Full-name disclosure.** The dark 390px Dialog fits the viewport, wraps the complete Chinese/English filename, and clearly separates the name from the statement that only the name is attached. The close control remains reachable. Settled close restores focus to the originating details control in all six conditions. Removal restores the input and preserves its draft.

**Type and themes.** English, Chinese and mixed input render as actual glyphs with consistent line rhythm. The light source surface remains quiet; dark file rows retain visible boundaries against the darker input surface. The existing dark sidebar icon color remains unchanged. Chinese task controls are localized; inherited header/sidebar labels remain English. No claim of complete application localization is made.

## Actually viewed episodes

For each locale I opened the ordered run-03 frames `start`, `away`, `growth`, `latest`, `cancelled`, `failure`, and `retry-complete`. Capture brackets use Python monotonic timestamps, and DOM snapshots use `performance.now()`. These are controlled timestamped samples, not a viewed continuous recording.

| Episode | Pixel observation and independent runtime evidence |
|---|---|
| Start and growth | Source streaming dot and stop control are visible. The initial Chinese start frame catches the source entrance fade; later text is fully readable. |
| Manual scroll-away | The away/growth images retain the same visible paragraph and footer despite continued response growth. In both locales scrollTop was unchanged while text length increased. |
| Explicit return | The latest frame shows a later response section and the source streaming dot. Subsequent measurements keep bottomGap at zero while text length grows. |
| Stop | The dot/stop control is replaced by source settled actions and send. Text stops changing during the subsequent observation interval; focus is back on the composer. Partial text remains rather than being concealed. |
| Failure and retry | The partial answer and source red error surface remain visible above the composer. The retry action is operable under its localized accessible name. The successful retry displays a complete long result and source branch count. |
| Repeated question | A further question starts another run through the actual composer. This is asserted in both locale runs. |
| Coupled growth | The normal-motion capture shows older material above the expanded six-line composer and two named files. ScrollTop remained 26px while answer text grew 2324→2823 characters and the footer moved upward from y=482 to y=302. Stopping retained the draft. |
| Keyboard continuation | Shift+Tab revealed the fourth attachment at scrollLeft 398; Enter opened details; Escape returned to the same trigger. Tab/Enter removal retained the draft. Keyboard stop returned focus, and editing/updating a sent message started a new response in both locales. |
| Touch-primary entry | The mobile-emulation capture shows a two-line submitted Chinese question. Enter inserted a newline; tapping Send and Stop operated. |

The first trial's top-anchor configuration failed resumed follow. I personally viewed its `episode-en-latest.png` and read the metrics: after return the bottom gap grew from 194 to 516px while scrollTop stayed 1709. That failure, the corrective source configuration, and final passing result remain separately traceable.

## Reference and retained craft review

I opened original assistant-ui File, corrected Vercel inline Attachments, Vercel list Attachments, and Ant Sender attachment-header open/closed six-line captures. The first Vercel inline filename was misleading: its pixels showed a documentation section during page movement. That original remains historical; `vercel-attachments-inline-stable.jpg` is the actual inline specimen. I reported the mismatch before using the corrected capture.

The File source offers the closest existing type/material hierarchy and the lowest adaptation burden. The Vercel inline variant is denser but grows by wrapping; the list variant spends more height; Ant's explicit header separates attachment management but adds an open/close mode and more open-state height. Those remain comparative references. Only the existing assistant-ui source supplies the delivered visual implementation.

## Verification boundary and remaining limits

Build, TypeScript and the described browser assertions pass. There were no browser page errors in the final six-condition and two-episode run. Failure logs from the hidden textarea selector, the top-anchor follow mismatch, a test path typo, and starter TypeScript compatibility checks remain in the evidence archive with their corrections.

This review does not establish natural-time video quality, physical mobile keyboard behavior, real IME operation, screen-reader user comprehension, Safari/Firefox behavior, or a real upload/model service. Horizontal file scrolling remains necessary with several filenames. The complete upstream bundle retains Vite's size warning. These are reported limits; no owner approval or production deployment is inferred.
