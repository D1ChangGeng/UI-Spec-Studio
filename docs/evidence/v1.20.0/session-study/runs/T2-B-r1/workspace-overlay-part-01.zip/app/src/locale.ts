// Product copy for the query-selected local demonstration locale.
export const isChinese = new URLSearchParams(location.search).get('lang') === 'zh';
export const copy = (en: string, zh: string) => isChinese ? zh : en;
