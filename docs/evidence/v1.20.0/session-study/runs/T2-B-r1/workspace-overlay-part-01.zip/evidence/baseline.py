import asyncio, json, os, time
from pathlib import Path
from playwright.async_api import async_playwright

ROOT=Path(__file__).resolve().parent
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path=BROWSER,headless=True,args=['--no-sandbox'],env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
        page=await b.new_page(viewport={'width':1280,'height':600},device_scale_factor=1)
        errors=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        await page.goto('http://127.0.0.1:4406/?theme=light&lang=en')
        await page.evaluate('document.fonts.ready')
        await page.wait_for_timeout(500)
        await page.screenshot(path=str(ROOT/'captures/baseline-compact.png'))
        ta=page.get_by_role('textbox',name='Message input')
        await ta.fill('Compare these notes.\nKeep the original observations.\nShow unresolved questions.\n请保留中文引述。\nExplain the follow-up.\nLeave room to continue reading.')
        async with page.expect_file_chooser() as fc:
            await page.get_by_role('button',name='Add Attachment',exact=True).click()
        await (await fc.value).set_files([{'name':n,'mimeType':'text/plain','buffer':b'local fixture'} for n in ['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','accessibility-research-interview-session-14-transcript-revised-final.txt']])
        await page.wait_for_timeout(500)
        await page.screenshot(path=str(ROOT/'captures/baseline-grown-attachments.png'))
        state=await page.evaluate('''() => ({textarea:[...document.querySelectorAll('textarea')].map(e=>({value:e.value,box:e.getBoundingClientRect().toJSON(),scrollHeight:e.scrollHeight})),buttons:[...document.querySelectorAll('button')].map(e=>({text:e.textContent,label:e.getAttribute('aria-label')})),width:document.documentElement.scrollWidth,errors:[]})''')
        state['errors']=errors
        (ROOT/'baseline.json').write_text(json.dumps(state,ensure_ascii=False,indent=2))
        print(json.dumps(state,ensure_ascii=False))
        await b.close()
asyncio.run(main())
