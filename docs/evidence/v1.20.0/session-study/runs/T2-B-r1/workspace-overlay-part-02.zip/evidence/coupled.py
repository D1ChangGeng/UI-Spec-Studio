import asyncio,json,os,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent; CAP=ROOT/'captures'/'coupled';CAP.mkdir(exist_ok=True)
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
report={}
async def measure(page):
 return await page.evaluate('''() => {let v=document.querySelector('[data-slot="aui_thread-viewport"]'),f=document.querySelector('.aui-thread-viewport-footer');return {time:performance.now(),scrollTop:v.scrollTop,height:v.scrollHeight,footerTop:f.getBoundingClientRect().top,footerBottom:f.getBoundingClientRect().bottom,textLength:document.querySelector('[data-slot="aui_message-group"]').textContent.length}}''')
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=BROWSER,headless=True,args=['--no-sandbox'],env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
  ctx=await b.new_context(viewport={'width':1280,'height':600})
  page=await ctx.new_page();page.set_default_timeout(5000)
  await page.goto('http://127.0.0.1:4406/?theme=light&lang=en');await page.evaluate('document.fonts.ready')
  ta=page.locator('.aui-composer-input');await ta.fill('Test coupled reading and continued composition');await ta.press('Enter')
  await page.locator('.aui-composer-cancel').wait_for();await page.wait_for_timeout(800)
  await page.locator('[data-slot="aui_thread-viewport"]').hover();await page.mouse.wheel(0,-900);await page.wait_for_timeout(300)
  report['away_before']=await measure(page)
  await ta.fill('Continue the comparison.\n保留当前阅读位置。\nSeparate facts and interpretations.\nCheck the evidence.\nKeep unresolved questions.\nDraft the next question.')
  async with page.expect_file_chooser() as fc: await page.locator('.aui-composer-add-attachment').click()
  await (await fc.value).set_files([{'name':'城市出行访谈摘要_2026-10-31_final-revised-notes.txt','mimeType':'text/plain','buffer':b'fixture'},{'name':'research-review-final-transcript-with-long-filename.txt','mimeType':'text/plain','buffer':b'fixture'}])
  await page.wait_for_timeout(350)
  report['away_after_growth']=await measure(page)
  await page.screenshot(path=str(CAP/'manual-reading-expanded-composer.png'))
  assert abs(report['away_before']['scrollTop']-report['away_after_growth']['scrollTop'])<3
  assert report['away_after_growth']['textLength']>report['away_before']['textLength']
  assert report['away_after_growth']['footerBottom']<=601
  await page.locator('.aui-composer-cancel').click();await page.wait_for_timeout(100)
  report['draft_preserved_after_stop']=await ta.input_value()
  assert '保留当前阅读位置' in report['draft_preserved_after_stop']
  await ctx.close()
  ctx=await b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=1)
  page=await ctx.new_page();await page.goto('http://127.0.0.1:4406/?theme=dark&lang=zh');await page.evaluate('document.fonts.ready')
  ta=page.locator('.aui-composer-input');await ta.tap();await ta.fill('手机输入第一行');await ta.press('Enter');await ta.type('第二行继续写')
  report['touch_enter_value']=await ta.input_value();assert '\n' in report['touch_enter_value']
  await page.locator('.aui-composer-send').tap();await page.locator('.aui-composer-cancel').wait_for()
  await page.wait_for_timeout(300);await page.screenshot(path=str(CAP/'touch-send.png'))
  await page.locator('.aui-composer-cancel').tap()
  report['touch_send_stop']=True
  await ctx.close();await b.close()
 (ROOT/'coupled.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False))
try:asyncio.run(main())
except Exception:
 (ROOT/'coupled-failed.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));raise
