import asyncio,json,os,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent
CAP=ROOT/'captures'/'keyboard'; CAP.mkdir(exist_ok=True)
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
FILES=['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','accessibility-research-interview-session-14-transcript-revised-final.txt','访谈记录_第四次修订_保留未验证问题.txt']
report=[]
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=BROWSER,headless=True,args=['--no-sandbox'],env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
  for theme,lang in [('light','en'),('dark','zh')]:
   ctx=await b.new_context(viewport={'width':1280,'height':600},device_scale_factor=1)
   page=await ctx.new_page(); page.set_default_timeout(6000)
   r={'theme':theme,'lang':lang}; report.append(r)
   await page.goto(f'http://127.0.0.1:4406/?theme={theme}&lang={lang}')
   await page.evaluate('document.fonts.ready')
   ta=page.locator('.aui-composer-input'); await ta.fill('Keyboard continuation draft · 保留草稿')
   async with page.expect_file_chooser() as fc: await page.locator('.aui-composer-add-attachment').click()
   await (await fc.value).set_files([{'name':n,'mimeType':'text/plain','buffer':b'fixture'} for n in FILES])
   await ta.click(); await page.keyboard.press('Shift+Tab'); await page.keyboard.press('Shift+Tab')
   r['keyboard_target']=await page.evaluate('document.activeElement.getAttribute("aria-label")')
   assert FILES[-1] in r['keyboard_target']
   r['strip_scroll_left']=await page.locator('.aui-composer-attachments').evaluate('(e)=>e.scrollLeft')
   assert r['strip_scroll_left']>0
   await page.screenshot(path=str(CAP/f'{lang}-keyboard-filename.png'))
   await page.keyboard.press('Enter'); await page.get_by_role('dialog').wait_for()
   await page.screenshot(path=str(CAP/f'{lang}-keyboard-dialog.png'))
   await page.keyboard.press('Escape'); await page.get_by_role('dialog').wait_for(state='hidden'); await page.wait_for_timeout(150)
   r['dialog_focus']=await page.evaluate('document.activeElement.getAttribute("aria-label")')
   assert r['dialog_focus']==r['keyboard_target']
   await page.keyboard.press('Tab'); await page.keyboard.press('Enter'); await page.wait_for_timeout(100)
   r['removed_count']=await page.locator('.aui-composer-attachments [data-slot="file-root"]').count()
   r['draft_retained']=await ta.input_value()=='Keyboard continuation draft · 保留草稿'
   assert r['removed_count']==3 and r['draft_retained']
   await ta.press('Enter'); await page.locator('.aui-composer-cancel').wait_for(); await page.wait_for_timeout(250)
   await ta.press('Tab'); await page.keyboard.press('Tab')
   r['stop_keyboard_target']=await page.evaluate('document.activeElement.getAttribute("aria-label")')
   assert r['stop_keyboard_target'] in ['Stop generating','停止生成']
   await page.keyboard.press('Enter'); await page.wait_for_timeout(150)
   r['stop_focus']=await page.evaluate('document.activeElement.className')
   assert 'aui-composer-input' in r['stop_focus']
   await page.locator('[data-slot="aui_user-message-root"]').last.hover()
   await page.locator('.aui-user-action-edit').last.click()
   edit=page.locator('.aui-edit-composer-input'); await edit.wait_for()
   await edit.fill('Edited follow-up · 修改后的问题')
   await page.screenshot(path=str(CAP/f'{lang}-edit.png'))
   await page.get_by_role('button',name='Update' if lang=='en' else '更新',exact=True).click()
   await page.locator('.aui-composer-cancel').wait_for()
   await page.locator('.aui-composer-cancel').click(); await page.wait_for_timeout(100)
   r['edit_result']=await page.get_by_text('Edited follow-up · 修改后的问题',exact=True).is_visible()
   assert r['edit_result']
   await ctx.close()
  await b.close()
 (ROOT/'keyboard.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False))
try: asyncio.run(main())
except Exception:
 (ROOT/'keyboard-failed.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
 raise
