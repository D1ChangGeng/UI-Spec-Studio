import asyncio, json, os, time, pathlib, traceback
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).parent
EXE="/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell"
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=EXE,headless=True,args=["--no-sandbox"])
  ctx=await browser.new_context(viewport={"width":1440,"height":900},device_scale_factor=1)
  report=[]
  targets=[
   ("vercel-attachments","https://elements.ai-sdk.dev/components/attachments"),
   ("ant-attachments","https://ant-design-x.antgroup.com/components/attachments"),
   ("vercel-chatbot","https://elements.ai-sdk.dev/examples/chatbot"),
   ("assistant-composer-attachments","https://www.assistant-ui.com/elements/composer-attachments"),
   ("local-baseline","http://127.0.0.1:4406/?theme=light&lang=en")]
  for key,url in targets:
   page=await ctx.new_page()
   item={"key":key,"url":url,"started_at":time.time(),"viewport":{"width":1440,"height":900}}
   try:
    response=await page.goto(url,wait_until="domcontentloaded",timeout=35000)
    await page.wait_for_timeout(2500)
    item.update({"status":response.status if response else None,"final_url":page.url,"title":await page.title()})
    (ROOT/(key+".txt")).write_text(await page.locator("body").inner_text())
    (ROOT/(key+".html")).write_text(await page.content())
    await page.screenshot(path=str(ROOT/(key+"-initial.png")),full_page=False)
    item["buttons"]=await page.get_by_role("button").all_text_contents()
    if key=="vercel-attachments":
     for label in ["Inline Variant","List Variant"]:
      h=page.get_by_role("heading",name=label,exact=True)
      if await h.count():
       await h.scroll_into_view_if_needed()
       await page.evaluate("window.scrollBy(0,-100)")
       await page.screenshot(path=str(ROOT/(key+"-"+label.split()[0].lower()+".png")))
    if key=="ant-attachments":
     item["ids"]=await page.locator("[id]").evaluate_all("(els)=>els.map(e=>e.id).filter(v=>/attachments-demo/.test(v))")
     for token in ["#components-attachments-demo-overflow","#components-attachments-demo-with-sender"]:
      loc=page.locator(token)
      if await loc.count():
       await loc.scroll_into_view_if_needed()
       await page.screenshot(path=str(ROOT/(key+"-"+token.split("-")[-1]+".png")))
    if key=="vercel-chatbot":
     item["textareas"]=await page.locator("textarea").count()
    if key=="assistant-composer-attachments":
     for n in range(3):
      if n: await page.mouse.wheel(0,600); await page.wait_for_timeout(400)
      await page.screenshot(path=str(ROOT/(key+"-view"+str(n)+".png")))
    print(json.dumps(item),flush=True)
   except Exception as e:
    item["error"]=str(e);print(json.dumps(item),flush=True)
   report.append(item)
   await page.close()
  (ROOT/"public-observation-log.json").write_text(json.dumps(report,indent=2))
  await browser.close()
asyncio.run(main())

