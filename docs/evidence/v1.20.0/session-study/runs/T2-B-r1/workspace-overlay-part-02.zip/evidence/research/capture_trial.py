import asyncio,json,time,pathlib
from playwright.async_api import async_playwright
R=pathlib.Path(__file__).parent
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path="/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell",args=["--no-sandbox"])
  page=await b.new_page(viewport={"width":1280,"height":600})
  await page.goto("http://127.0.0.1:4406/?theme=dark&lang=zh")
  await page.locator("textarea.aui-composer-input").fill("请比较研究中的差异。\n保留观察与解释。\nKeep original context.\n关注阅读连续性。\n列出仍需验证的问题。\n给出下一步。")
  async with page.expect_file_chooser() as fc:
   await page.get_by_role("button",name="添加附件",exact=True).click()
  chooser=await fc.value
  await chooser.set_files([{"name":n,"mimeType":"text/plain","buffer":b""} for n in ["notes.txt","城市出行访谈摘要_2026-10-31_final-revised-notes.txt","participant-notes-comparison-final-reviewed.txt"]])
  await page.wait_for_timeout(700)
  await page.screenshot(path=str(R/"local-trial-six-line-three-files.png"))
  log={"url":page.url,"viewport":{"width":1280,"height":600},"text":await page.locator("body").inner_text(),"buttons":await page.get_by_role("button").all_text_contents()}
  await page.get_by_role("button",name="查看附件详情：notes.txt",exact=True).click()
  await page.wait_for_timeout(400)
  await page.screenshot(path=str(R/"local-trial-details.png"))
  log["dialog"]=await page.get_by_role("dialog").inner_text()
  await page.keyboard.press("Escape")
  log["focus_return"]=await page.evaluate("document.activeElement?.getAttribute('aria-label')")
  (R/"local-trial-log.json").write_text(json.dumps(log,ensure_ascii=False,indent=2))
  print(json.dumps(log,ensure_ascii=False))
  await b.close()
asyncio.run(main())

