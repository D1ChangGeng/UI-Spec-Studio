import asyncio, json, os, time, hashlib
from pathlib import Path
from playwright.async_api import async_playwright

ROOT=Path(__file__).resolve().parent
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
FILES=['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','accessibility-research-interview-session-14-transcript-revised-final.txt','访谈记录_第四次修订_保留未验证问题.txt']
SIX='Compare these notes.\nKeep the original observations.\nShow unresolved questions.\n请保留中文引述。\nExplain the follow-up.\nLeave room to continue reading.'
report={'runs':[],'errors':[],'checks':[]}

async def metrics(page):
    return await page.evaluate('''() => { const v=document.querySelector('[data-slot="aui_thread-viewport"]'), t=document.querySelector('.aui-composer-input'), f=document.querySelector('.aui-thread-viewport-footer'); return {time:performance.now(),scrollTop:v.scrollTop,scrollHeight:v.scrollHeight,clientHeight:v.clientHeight,bottomGap:v.scrollHeight-v.clientHeight-v.scrollTop,footer:f.getBoundingClientRect().toJSON(),input:t.getBoundingClientRect().toJSON(),inputScrollHeight:t.scrollHeight,textLength:document.querySelector('[data-slot="aui_message-group"]').textContent.length,focused:document.activeElement.className,docWidth:document.documentElement.scrollWidth,innerWidth:innerWidth}; }''')

async def snap(page,name,records):
    start=time.monotonic()
    await page.screenshot(path=str(ROOT/'captures'/f'{name}.png'))
    records.append({'capture':f'captures/{name}.png','monotonic_before':start,'monotonic_after':time.monotonic(),'metrics':await metrics(page)})

async def attach(page):
    async with page.expect_file_chooser() as c:
        await page.locator('.aui-composer-add-attachment').click()
    await (await c.value).set_files([{'name':n,'mimeType':'text/plain','buffer':b'not read'} for n in FILES])
    await page.wait_for_timeout(200)

async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path=BROWSER,headless=True,args=['--no-sandbox'],env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
        for w,h in [(1440,900),(1280,600),(390,844)]:
            for theme,lang in [('light','en'),('dark','zh')]:
                context=await b.new_context(viewport={'width':w,'height':h},device_scale_factor=1)
                page=await context.new_page()
                page.set_default_timeout(7000)
                page.on('pageerror',lambda e:report['errors'].append(str(e)))
                run={'viewport':[w,h],'theme':theme,'lang':lang,'frames':[]}
                report['runs'].append(run)
                await page.goto(f'http://127.0.0.1:4406/?theme={theme}&lang={lang}')
                await page.evaluate('document.fonts.ready')
                await page.wait_for_timeout(250)
                key=f'{w}x{h}-{theme}-{lang}'
                await snap(page,f'final-{key}-initial',run['frames'])
                ta=page.locator('.aui-composer-input')
                await ta.fill('One line question' if lang=='en' else '一行问题')
                run['one_line']=await metrics(page)
                await ta.fill(SIX)
                await attach(page)
                await snap(page,f'final-{key}-grown',run['frames'])
                run['attachment_count']=await page.locator('.aui-composer-attachments [data-slot="file-root"]').count()
                await page.get_by_role('button',name=('View attachment details: ' if lang=='en' else '查看附件详情：')+FILES[1],exact=True).click()
                await page.get_by_role('dialog').wait_for()
                run['full_filename_visible']=await page.get_by_role('dialog').get_by_text(FILES[1],exact=True).is_visible()
                await page.screenshot(path=str(ROOT/'captures'/f'final-{key}-details.png'))
                await page.keyboard.press('Escape')
                run['dialog_focus_returned']=await page.evaluate('document.activeElement.getAttribute("aria-label")')
                await page.get_by_role('button',name=('Remove ' if lang=='en' else '移除 ')+FILES[0],exact=True).click()
                await page.wait_for_timeout(100)
                run['remove_focus']=await page.evaluate('document.activeElement.className')
                run['remaining_attachments']=await page.locator('.aui-composer-attachments [data-slot="file-root"]').count()
                assert run['remaining_attachments']==3
                assert run['full_filename_visible']
                assert 'aui-composer-input' in run['remove_focus']
                assert (await ta.input_value())==SIX
                await ta.fill(('Long mixed-language question — 研究摘要与原始笔记。 '*50))
                run['long_input']=await metrics(page)
                assert run['long_input']['input']['height'] <= min(192,h*.25)+1
                assert run['long_input']['footer']['bottom']<=h+1
                assert run['long_input']['docWidth']<=w
                await context.close()

        for theme,lang in [('light','en'),('dark','zh')]:
            context=await b.new_context(viewport={'width':1280,'height':600},device_scale_factor=1,reduced_motion='reduce')
            page=await context.new_page(); page.set_default_timeout(8000)
            page.on('pageerror',lambda e:report['errors'].append(str(e)))
            episode={'theme':theme,'lang':lang,'viewport':[1280,600],'frames':[]}
            report.setdefault('episodes',[]).append(episode)
            await page.goto(f'http://127.0.0.1:4406/?theme={theme}&lang={lang}')
            await page.evaluate('document.fonts.ready')
            ta=page.locator('.aui-composer-input')
            await ta.fill('Show a full research synthesis. 研究综合。')
            await ta.press('Shift+Enter')
            assert '\n' in await ta.input_value()
            await ta.press('Enter')
            await page.locator('.aui-composer-cancel').wait_for()
            await snap(page,f'episode-{lang}-start',episode['frames'])
            await page.wait_for_timeout(1100)
            await page.locator('[data-slot="aui_thread-viewport"]').hover()
            await page.mouse.wheel(0,-850)
            await page.wait_for_timeout(350)
            episode['away_before']=await metrics(page)
            await snap(page,f'episode-{lang}-away',episode['frames'])
            await page.wait_for_timeout(900)
            episode['away_after']=await metrics(page)
            await snap(page,f'episode-{lang}-growth',episode['frames'])
            episode['manual_scroll_stable']=abs(episode['away_after']['scrollTop']-episode['away_before']['scrollTop'])<3
            episode['answer_grew_while_away']=episode['away_after']['textLength']>episode['away_before']['textLength']
            assert episode['manual_scroll_stable']
            assert episode['answer_grew_while_away']
            await page.locator('.aui-thread-scroll-to-bottom').click()
            await page.wait_for_timeout(450)
            episode['return_before']=await metrics(page)
            await page.wait_for_timeout(700)
            episode['return_after']=await metrics(page)
            await snap(page,f'episode-{lang}-latest',episode['frames'])
            episode['follow_latest']=episode['return_after']['bottomGap']<3
            assert episode['follow_latest']
            await page.locator('.aui-composer-cancel').click()
            await page.wait_for_timeout(150)
            stopped=await metrics(page)
            await page.wait_for_timeout(700)
            after=await metrics(page)
            episode['cancel_stopped_chunks']=after['textLength']==stopped['textLength']
            assert episode['cancel_stopped_chunks']
            await snap(page,f'episode-{lang}-cancelled',episode['frames'])
            await ta.fill('[fail] Retry this local example')
            await ta.press('Enter')
            await page.locator('.aui-message-error-root').wait_for()
            await snap(page,f'episode-{lang}-failure',episode['frames'])
            episode['error_text']=await page.locator('.aui-message-error-root').inner_text()
            await page.get_by_role('button',name='Retry response' if lang=='en' else '重试回答',exact=True).last.click()
            await page.locator('.aui-composer-cancel').wait_for()
            await page.locator('.aui-composer-cancel').wait_for(state='hidden',timeout=20000)
            episode['retry_completed']=await page.locator('.aui-message-error-root').count()==0
            assert episode['retry_completed']
            if await page.locator('.aui-thread-scroll-to-bottom').is_enabled():
                await page.locator('.aui-thread-scroll-to-bottom').click()
            await snap(page,f'episode-{lang}-retry-complete',episode['frames'])
            await ta.fill('Continue with another question')
            await ta.press('Enter')
            await page.locator('.aui-composer-cancel').wait_for()
            await page.wait_for_timeout(250)
            episode['repeat_question_running']=await page.locator('.aui-composer-cancel').is_visible()
            await page.locator('.aui-composer-cancel').click()
            await context.close()
        await b.close()
    (ROOT/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps(report,ensure_ascii=False))

try:
    asyncio.run(main())
except Exception:
    import traceback
    (ROOT/'verification-failed.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    traceback.print_exc()
    raise
