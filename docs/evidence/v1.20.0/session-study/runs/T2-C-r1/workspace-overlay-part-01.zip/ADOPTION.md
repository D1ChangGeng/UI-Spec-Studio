# Adopted resources and responsibilities

## Chosen foundation
The supplied assistant-ui cloud-template family remains the governing visual and functional system. Exact source: https://github.com/assistant-ui/assistant-ui at ff654d8156680b839774296ef644b57ab1078425, MIT; original application templates/cloud/app/assistant.tsx. Original path/digest/notice records remain in SOURCE-MANIFEST.json, app/LICENSE, FONT-SOURCES.json, and app/public/fonts/. SOURCE-ADOPTION.json records actual current hashes and the three modified copied source files. Original pre-change copies and exact diffs are in evidence/source-before/ and evidence/source-diffs/.

## Actual adoption
| Responsibility | Implementation retained/adopted | Focused changes and rationale |
|---|---|---|
| Workspace, reading measure, typography, surfaces, icons, sidebar | Existing assistant-ui template, Inter/IBM Plex Mono, Lucide, existing semantic theme tokens | Kept the 44rem thread measure, user/assistant hierarchy, source spacing, composer material, actions, and theme system. |
| Named document attachments | Existing elements/file.tsx: fileVariants(sm, outline), File.Icon, File.Name; existing AttachmentPrimitive state and remove action | Compose the actual file-row implementation for non-image attachments; cap each row at 16rem; keep composer horizontal overflow; wrap sent attachment rows so all four remain reachable. No fabricated byte size, contents, or download. |
| Complete filename disclosure | Existing ui/dialog.tsx and File.Root | Source dialog overlay, surface, title, description, close and focus behavior. Wrap full filenames. State the real metadata-only boundary. Preserve image preview path. Removal returns focus to composer without scrolling. |
| Reading continuity | Existing ThreadPrimitive.Viewport, ViewportFooter, ScrollToBottom and upstream auto-scroll controller | Configure bottom anchoring; remove repeated smooth-scroll restarts; explicit return uses instant behavior. Existing controller still owns interruption and subsequent following. Return Button uses existing opaque background/border tokens and default button size. |
| Input growth | Existing ComposerPrimitive.Input autosizing and IME guard | Keep the 12rem upper limit but bound it by 30dvh in short windows; retain minimum height and all runtime semantics. |
| Streaming/stop consistency | Existing MarkdownTextPrimitive with defer and smooth public options | Enable smooth text reveal while the message is running; settle already received text on stop/end. No new animator or state owner. |
| Task copy | Existing component typography and locale query contract | Chinese composer, add/remove, full-name details, return, edit and retry labels. Other inherited chrome/action labels remain English. |
| Build compatibility | Existing Vite/TypeScript setup | Remove TypeScript 7's removed baseUrl option and include vite/client CSS declarations. No dependency or lockfile changes. |

## Comparison and primary choice
The main agent personally viewed the actual assistant-ui File original-demo capture and AI Elements' inline attachments and full six-line chatbot captures returned by the research child. File's source-native small outline rows carry the needed icon/name hierarchy without a second state system. AI Elements supplies visible named wrapping badges and a stable composer footer, but wrapping consumes additional vertical space and its state/API contract would require broader integration. It was retained as a design reference, not imported or reconstructed. prompt-kit access failures remain documented; no unseen quality claim or adoption is made.

Original construction exceptions: none requested or used. These are source configuration, coherent composition, localization and compatibility/behavior repairs. The governing family, material, type and state presentation remain the adopted implementation.

## Trial findings and corrections
1. Baseline anonymous document tiles → named file-row trial. At 1280×600 with six lines/four files, composer height changed 270px → 248px while retaining the source's 24px line rhythm and lower action row.
2. Baseline return did not resume following. Main baseline had a 942px gap after additional active growth; independent child baseline ended 299px short in a different timed run. These are separate runs, not interchangeable measurements.
3. Bottom-anchor trial still chased a smooth-scroll target every 60ms. Configure auto/instant scroll; final sampled return gap is 0 in both language/theme conditions.
4. Renderer smoothing continued to reveal buffered text after adapter cancellation. Adapter abort test already passed; configure its smooth prop from message running state. Final stop display checks pass without shortening or altering the synthetic response.
5. Final pixel review found light return text blending with the paragraph beneath. Inherit the source's opaque background/border treatment in both themes and its default-size Button. Rebuilt and rechecked in final-05.

Final runtime evidence is evidence/final-05/report.json, continuation-02/report.json, commands/adapter-01/, commands/build-final-02/, and commands/typecheck-final/. Detailed viewing scope is VISUAL-REVIEW.md. No reference screenshot is represented as the product implementation.
