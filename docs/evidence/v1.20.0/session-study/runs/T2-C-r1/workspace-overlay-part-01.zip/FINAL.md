# Meridian composer and reading continuity — delivered

The application is implemented and built in the assigned package. It preserves the assistant-ui workspace and improves the complete compose → attach → stream → revisit → return → continue experience.

## What changed

- **Identifiable attachments:** documents now use the supplied assistant-ui File row, showing a filename beside its icon. Click or keyboard-open a row to read the complete long filename in the supplied Dialog. Closing restores focus; removal returns focus to the composer. Sent files remain visible as wrapping rows. Contents are never read or transmitted.
- **Controlled reading position:** manual scroll-away keeps the earlier passage in place while the response grows. “Return to latest” resumes following through the existing runtime. The visible return button uses an opaque inherited surface so it remains legible over message text.
- **Predictable stop:** the synthetic adapter aborts future chunks; the existing Markdown reveal now settles received text when generation stops. Smooth reveal remains enabled during generation.
- **Bounded growth:** the source autosizing input remains intact, with a short-viewport height bound. Six lines and four attachments use 248px at 1280×600, compared with the baseline's 270px, while the action row stays reachable.
- **Task-level Chinese labels:** composer, attachment details/removal, return, edit and retry labels follow the supplied locale query. The broader inherited navigation still uses English.

The source choice is documented in [ADOPTION.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/ADOPTION.md). I personally inspected the original assistant-ui File demonstration, AI Elements' independently authored attachment badges and full chatbot, the local trials, and final product captures. The existing File/Dialog family provided the required visual relationships without introducing a second component/state system. No original visual-construction exception was used.

## Run the built product

From `/workspace/scratch/708e8b7f118e/ui-study/worksets/w07`:

```bash
python3 -m http.server 4407 --bind 127.0.0.1 --directory app/dist
```

Open `http://127.0.0.1:4407/?theme=light&lang=en` or `http://127.0.0.1:4407/?theme=dark&lang=zh` in the executor's browser. The connected user browser cannot reach this executor's localhost. Rebuild with `cd app` followed by `npm run build`.

The supplied synthetic contract is intact: fixed long responses, `[fail]` followed by successful retry, in-memory threads, and metadata-only local attachments. The source, frozen lockfile, notices, and built `app/dist/` are retained.

## Verification

| Check | Result |
|---|---|
| 1440×900, 1280×600, 390×844 in light/English and dark/Chinese | Captured and checked with real content |
| Single/multiple lines, long mixed-language draft, long filenames, full-name disclosure, removal/focus | Passed |
| Manual scroll-away, growth, explicit return, subsequent follow, stop, failure/retry, repeated question | Passed |
| Sent-file disclosure, edit cancellation, draft growth while reading, draft preservation on stop | Passed |
| Browser assertions | 53 in final-05 plus 7 continuation assertions; all passed; no page errors |
| Production adapter boundary | Abort prevents next yield; filename retained; file contents never read |
| Production build and TypeScript | Passed |

The final source-family build retains its bundle-size advisory. The meaningful verification evidence is [final-05/report.json](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/final-05/report.json), [continuation-02/report.json](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/continuation-02/report.json), and [VISUAL-REVIEW.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/VISUAL-REVIEW.md). Earlier failed selectors, timing assumptions, and real trial defects remain preserved with their actual outputs and subsequent corrections.

## Review the result

- [Compact composer with named attachments](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/final-05/light-en-1280x600-six-lines-files.png)
- [Narrow Chinese full-filename disclosure](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/final-05/dark-zh-390x844-filename-dialog.png)
- [Earlier reading position during streaming](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/final-05/light-en-episode-03-growing-away.png)
- [Formal SPEC](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/SPEC.md)
- [Research report](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/research/RESEARCH-REPORT.md)
- [Source adoption and hashes](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/SOURCE-ADOPTION.json)
- [Delegation record](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/DELEGATION.json)

No product defect remains in the exercised scope. The evidence is local Chromium operation and personally viewed static/ordered frames. It does not establish physical mobile keyboard/touch behavior, native OS IME, other browser engines, screen-reader use, a user study, or natural-time video playback. Owner acceptance remains separate from the implemented and verified result.
