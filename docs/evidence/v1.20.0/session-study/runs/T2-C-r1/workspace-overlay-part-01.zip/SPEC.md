# SPEC 01 — Compose, disclose, read, return

## Overall goal and current product
Meridian is a local conversation workspace for asking, attaching filenames, reading a long synthetic response, revisiting earlier passages, and continuing. The complete assistant-ui cloud template at revision ff654d8156680b839774296ef644b57ab1078425 supplies the mature visual and runtime foundation. Real uploads, real models, persistent history, and new branding are outside this increment.

This single formal SPEC owns the coupled composer/attachment/answer/scroll episode. Splitting by components would hide the effect of composer growth on reading space and the distinction between following a stream and reading earlier text. Primary design stays with the main agent; the independent child investigates sources only.

## Quality and review boundaries
- Keep the template's 44rem thread measure, typography, rounded composer material, action hierarchy, sidebar, message spacing, theme system, and runtime ownership.
- Make selected document identities recognizable and reveal a complete long filename without reading or uploading contents.
- Grow and cap the composer while retaining a reachable action row at 1440×900, 1280×600, and supplementary 390×844.
- Follow latest content when the person is at the latest; stop following on manual scroll-away; resume on an explicit return. Preserve draft and reading position as content grows.
- Exercise one-line, six-line, long mixed-language, many filenames, send/stop, failure/retry, keyboard disclosure/return, and repeat questions in light/English and dark/Chinese.

## Evidence map / current decisions
L0: a reader controls their position in a continuous conversation. L1: compose → attach/review → send → read → scroll away → return → stop/retry → continue. L2: inherited workspace/header/sidebar with one bounded conversation viewport. L3: inherited composer, file component, dialog, message actions, viewport footer. L4: inherited type, measure, subdued surfaces and primary send/stop; document labels and short return wording clarify objects/actions. L5: source manifest, actual pre-change captures, source copies, mature component configuration, browser episodes, final viewed captures.

### D1 — Document identity and disclosure (trial)
Observed baseline evidence/baseline-02/02-compact-six-lines-files.png and 03-narrow-files.png: four documents have identical 56px tiles with no filename at rest. Tooltip semantics expose names on hover/focus, but no persistent identity or touch disclosure is visible. The supplied File component already supplies an outline/muted named row and the supplied Dialog supplies modal focus/dismiss/return. Research child confirms official File docs expose this composition. Trial those mature components for metadata-only documents, leaving image presentation intact. Preserve horizontal attachment flow, bound each row width, reveal complete names in the source dialog, and return keyboard focus after dismissal/removal. This is supported composition and behavior wiring, not original visual construction. Compare against AI Elements/prompt-kit research when returned.

### D2 — Explicit return resumes following (supported configuration)
Actual baseline English episode in evidence/baseline-scroll-01/events.json: manual scroll-away stays at scrollTop 0 while height grows from 1471 to 1871. After return, top remains 1386/1387 while the bottom gap grows from 323 to 942 during an active run. The source Thread uses turnAnchor=top, whose autoScroll default is false; upstream source confirms holdFollow for an active top anchor. Trial turnAnchor=bottom, the existing runtime's classic following configuration. Retain its wheel/follow state owner; do not write a competing scroll handler. Reuse the source Button and existing scroll action with a visible return label. Inspect away, explicit return, subsequent growth, cancellation, and repeated input.

### D3 — Growth, language, and focus (focused adaptation)
Baseline six lines plus four tiles occupy 270px at 600px high; input is readable and actions reachable. Keep the source autosizing input (including upstream IME protection and its fallback); constrain max height responsively through its existing CSS limit. Localize task-critical composer, attachment, return, retry labels in the Chinese condition. The general sidebar remains inherited. Check compact and narrow shapes, Shift+Enter, IME-confirming Enter, modal close, removal focus, and actual stop behavior. Current modern-web-guidance retrieval is retained in evidence/commands/guide-retrieve-01; source autosizing/IME implementation is already stronger than replacing it with a new CSS-only mechanism.

## Open before trial
- Named row width and overflow must preserve usable reading area in the compact and narrow conditions.
- Bottom-follow and manual scroll-away must both pass together.
- Child reference observation and final assembled visual review are pending.
- No owner approval or natural-time playback is claimed from automated captures.

## Final current decisions and outcome
D1 adopted: source File small outline rows + existing Dialog, with horizontal composer overflow and wrapped sent rows. Main personally inspected three returned source demonstrations. The alternative AI Elements named badge family remains a reference; prompt-kit remains unassessed due access failures. Source responsibility and code locations are in ADOPTION.md and SOURCE-ADOPTION.json.

D2 adopted after two real trials: bottom anchor alone did not settle the moving smooth-scroll target. The final viewport uses auto scroll behavior and the source return action uses instant behavior. The final source Button has an opaque surface and inherited border in both themes. Final held-position and return-follow assertions pass in both conditions; no competing scrolling implementation was added.

D3 adopted: input max height min(12rem,30dvh), source autosizing and IME behavior retained, scoped task-label localization, dialog focus return and removal focus verified at six view/locale combinations. Compact six-line/four-file composer height is 248px versus baseline 270px. A separate continuation episode held scrollTop 343 while a six-line mixed draft grew during a response, then retained that draft through cancellation.

D4 discovered during integrated verification: the adapter stopped future chunks correctly, but the Markdown smooth reveal drained received text after stop. Configure the public smooth option from the actual message running state, keeping deferred parsing constant. Final display stability and raw adapter abortion both pass.

Verification: final-05 has 53 passing browser assertions and no page errors; continuation-02 has 7 passing assertions and no page errors. Build and TypeScript checks pass. Adapter checks confirm cancellation before next yield and filename-only metadata without reading file contents. Source/lockfile boundary is retained. Earlier failures, including selector and locale-timing mistakes, remain in the evidence archive with their actual outputs.

No product defect remained in the exercised scope. Remaining evidence limits: local Chromium 143 only; viewport emulation is not a physical mobile keyboard/touch test; synthetic IME events are not OS-level IME operation; no screen-reader/user study; ordered frame inspection, not natural-time video playback; broader inherited English chrome remains. Public reference captures have different viewports and are qualitative comparisons. Product acceptance by the owner is pending and is distinct from this delivery.
