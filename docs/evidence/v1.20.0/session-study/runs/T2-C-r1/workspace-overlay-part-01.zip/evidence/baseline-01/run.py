import asyncio,json,time,datetime
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence'/'baseline-01';OUT.mkdir(parents=True,exist_ok=False)
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=BROWSER,headless=True,args=['--no-sandbox'])
  context=await browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
  page=await context.new_page();logs=[];errors=[]
  page.on('pageerror',lambda e: errors.append(str(e)))
  async def snap(label):
   before=time.monotonic();await page.screenshot(path=str(OUT/f'{label}.png'))
   geom=await page.evaluate('''() => {const v=document.querySelector('[data-slot="aui_thread-viewport"]'),c=document.querySelector('[data-slot="aui_composer-shell"]'),i=document.querySelector('textarea');return {viewport:{w:innerWidth,h:innerHeight},scroll:v?{top:v.scrollTop,height:v.scrollHeight,client:v.clientHeight}:null,composer:c?.getBoundingClientRect().toJSON(),input:i?.getBoundingClientRect().toJSON(),documentWidth:document.documentElement.scrollWidth,active:document.activeElement?.outerHTML.slice(0,300)}}''')
   logs.append({'label':label,'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'capture_start':before,'capture_end':time.monotonic(),'geometry':geom})
  try:
   await page.goto('http://127.0.0.1:4407/?theme=light&lang=en');await page.evaluate('document.fonts.ready');await page.wait_for_timeout(400);await snap('01-light-initial')
   await page.set_viewport_size({'width':1280,'height':600})
   await page.locator('textarea').fill('Compare the research notes.\nKeep observations separate.\nInclude the source dates.\n城市出行和阅读连续性。\nWhat needs verification?\nSuggest the next question.')
   async with page.expect_file_chooser() as info: await page.get_by_role('button',name='Add Attachment',exact=True).click()
   chooser=await info.value
   await chooser.set_files([{'name':n,'mimeType':'text/plain','buffer':b'synthetic fixture'} for n in ['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','research_interviews_accessibility_comparison_long_filename.txt','collaboration_notes_final_version_with_revisions.txt']])
   await page.wait_for_timeout(300);await snap('02-compact-six-lines-files')
   await page.set_viewport_size({'width':390,'height':844});await page.wait_for_timeout(200);await snap('03-narrow-files')
   await page.goto('http://127.0.0.1:4407/?theme=dark&lang=zh');await page.set_viewport_size({'width':1280,'height':600});await page.evaluate('document.fonts.ready');await page.wait_for_timeout(200);await snap('04-dark-initial')
   await page.locator('textarea').fill('请给出长回答。');await page.get_by_role('button',name='Send message',exact=True).click();await page.wait_for_timeout(750);await snap('05-stream-start')
   viewport=page.locator('[data-slot="aui_thread-viewport"]');await viewport.hover();await page.mouse.wheel(0,-1200);await page.wait_for_timeout(250);await snap('06-scroll-away')
   await page.wait_for_timeout(1600);await snap('07-growth-while-away')
   await page.get_by_role('button',name='Scroll to bottom',exact=True).click();await page.wait_for_timeout(450);await snap('08-return-latest')
   stop=page.get_by_role('button',name='Stop generating',exact=True)
   if await stop.count():await stop.click()
   await snap('09-stopped')
  finally:
   (OUT/'observations.json').write_text(json.dumps({'logs':logs,'page_errors':errors},ensure_ascii=False,indent=2));print(json.dumps({'captures':len(logs),'page_errors':errors,'output':str(OUT)},ensure_ascii=False));await context.close();await browser.close()
asyncio.run(main())
