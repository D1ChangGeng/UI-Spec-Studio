Research is complete. The full report and visual review ledger are saved:

- [RESEARCH-REPORT.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/research/RESEARCH-REPORT.md)
- [VISUAL-REVIEW.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/research/VISUAL-REVIEW.md)
- [Evidence inventory](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/research/evidence-file-manifest.json)

No product code was changed by this researcher. The findings concern the original baseline and inspected public sources; your subsequent integrated fixes remain separately verified work.

## Open these three source screenshots

| Capture | What it establishes |
|---|---|
| [assistant-ui File](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/research/public-captures/w07-assistant-ui-file-final.png) | Existing source carries compact icon/name hierarchy, quiet outlines, muted variants, and several sizes. |
| [AI Elements inline attachments](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/research/public-captures/w07-ai-elements-inline.png) | A materially different reference: visible named badges, with three on one row and the fourth wrapping. |
| [AI Elements chatbot with six-line draft](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/research/public-captures/w07-ai-elements-chatbot-six-lines-settled.png) | Independent complete chatbot composition: growing text field, stable bottom actions, reduced conversation height. |

These PNGs are format conversions of the actual captured JPEGs. Original JPEG bytes, accessibility output, and complete local image-tool response objects are retained.

## Research findings

### The supplied File composition is a strong fit

The existing assistant-ui family provides a practical adoption path for metadata-only attachments. The exact supplied `File.Root`, `File.Icon`, and `File.Name` parts already carry the visual relationships needed here. The official rendered examples show names beside type icons, compact spacing, and an unobtrusive outlined or muted surface. Its documentation explicitly demonstrates composing those parts in the small size. genui{"citation":{"ref":"turn21view2"}}

This makes the main trial—existing File composition inside the existing attachment/runtime context, with the supplied Dialog for complete metadata disclosure—well supported by source provenance. It avoids importing a second state system to obtain a filename row.

The remaining integration question is disclosure quality. `File.Name` truncates, so a row alone does not resolve very long, similar filenames. Keyboard and touch access to the full name, focus return after closing the dialog, and independent remove targets need integrated verification. The metadata-only adapter provides no basis for showing invented size, download, or file content.

### The baseline’s constraint is the whole composer height

At 1280×600, the original six-line, four-file composer measured:

| Region | Measured size |
|---|---:|
| Thread viewport | 1022×536 |
| Composer | 672×270 |
| Text area | 654×152 |
| Attachment strip | 654×56 |

The composer consumed roughly half the available conversation height. Its separate lower action row worked well: add/send remained available and the six lines retained a comfortable 24-pixel line rhythm. The pressure came from the combined height of attachments, text, actions, and spacing.

The four resting document tiles were visually indistinguishable: each was a 56-pixel square with the same document icon. Source and accessibility inspection confirmed filenames were present for assistive technology and in hover tooltips, but the resting visual layout did not support comparison. Metadata-only documents also had no image source to activate the image-preview path.

Relevant local evidence:

- [Six-line/four-file baseline](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/research/baseline-six-lines-files-1280.png)
- [Measured geometry](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/research/baseline-geometry.json)

### The baseline preserved reading position but did not sustain return-to-latest

During the original streaming episode, after a user wheel interruption, `scrollTop` stayed at 2 through samples 5–13 while `scrollHeight` increased from 2003 to 3397. That supports stable reading position at the sampled moments.

After explicit return during streaming, the viewport advanced, but its final geometry was:

- `scrollHeight`: 3928
- `clientHeight`: 536
- `scrollTop`: 3093
- Remaining distance: **299 pixels**

The final screenshot still showed the return control. The installed source explains why the configuration deserved scrutiny: `autoScroll` defaults to false when `turnAnchor` is `"top"`, and explicit return delegates to the existing controller. Official documentation describes the same default. genui{"citation":{"ref":"turn22search0"}}

This finding identifies the original configuration risk. It does **not** claim that a single prop fixes every timing interaction, nor does it contradict your later passing hold/return trial. The report explicitly separates those evidence scopes.

- [Earlier passage during streaming](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/research/baseline-stream-13.png)
- [Settled baseline after return](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/research/baseline-stream-23.png)
- [Timestamped samples](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/research/baseline-stream-samples.json)

## Comparison of adoption candidates

| Candidate | Observed strengths | Practical path and limitation |
|---|---|---|
| Existing assistant-ui attachment tiles | Fixed-height compact strip; supplied remove affordance; accessible names; hover disclosure. | Retain context/remove behavior and genuine image previews. Anonymous document appearance is the primary weakness. |
| Existing assistant-ui File parts | Directly viewed compact row hierarchy, readable name, quiet surfaces; supplied code already available. | Lowest integration burden. Compose actual metadata, preserve full-name disclosure, and bound growth at narrow/short sizes. |
| Vercel AI Elements attachments and full chatbot | Independent rendered implementation. Named badges expose identity; full chatbot separates growing text from lower actions. | Viable larger family adoption if the supplied family were unsuitable. Different attachment/state contracts add integration cost; wrapping badges still consume height. |
| prompt-kit | Independent repository and official documentation discovered. | Rendered quality remains unassessed: docs retrieval returned 403 and local browser encountered certificate-trust failure. No adoption recommendation from this inquiry. |

The AI Elements docs offer grid, inline, and list attachment variants. Its inline example made filenames visible immediately, but the fourth item wrapped below the first three. That demonstrates both the identity benefit and the potential height cost. genui{"citation":{"ref":"turn20search0"}}

In its full chatbot, filling six mixed-script lines expanded the composer upward while the bottom action row stayed in place. The conversation viewport became shorter. This is a useful independently authored reference for the relationship between composition and reading space; public cancellation, retry, upload, and streaming behavior were not exercised.

The current source also visibly announces a move to shadcn/ui and deprecation at the end of November 2026. A fresh adoption would therefore need a pinned, migration-aware choice. The repository LICENSE identifies Apache-2.0. genui{"citation":{"refs":["turn19search1","turn23view0"]}} The supplied assistant-ui source remains pinned in the package to `ff654d8156680b839774296ef644b57ab1078425` with its MIT notice.

## A useful distinction in the scroll reference

The assistant-ui Scroll anchor page was directly viewed. Its small demonstration is a scripted explanatory sequence; it can intentionally unpin and automatically return to demonstrate the pill. The runtime documentation separately describes user interruption and explicit return.

That scripted automatic return should not become workspace behavior. The relevant reusable source is the runtime controller and its supported configuration; the task’s reader-control contract determines when following resumes. The report does not treat the scripted preview as proof of a real streaming episode.

## Remaining questions for integrated acceptance

The research narrows the source choice and explains the baseline risks. These final questions belong to the integrated result:

1. Can all four long filenames be distinguished and fully disclosed by keyboard and touch, with reliable focus return and removal, while retaining useful reading height?
2. Does explicit return reach the actual bottom and continue following through completion, and does a fresh user interruption stop following? Your newer verification is the appropriate evidence for that result.
3. Do composer growth, cancel, failure/retry, and repeated questions preserve those relationships in short desktop and narrow dark/Chinese states?

The public captures use approximately 1348×926; the File page capture is 1353×929. They support qualitative comparison rather than same-viewport geometry. The local streamed frames and timestamps support sampled position conclusions, not an animation-smoothness judgment.

All successful evidence, original failed attempts, source outputs, exact search/open responses, captured image bytes, and observation limitations are retained in the research folder.
