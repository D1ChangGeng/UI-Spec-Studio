import asyncio,json,time,datetime,sys
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];TAG=sys.argv[1] if len(sys.argv)>1 else 'final-01'
OUT=ROOT/'evidence'/TAG;OUT.mkdir(parents=True,exist_ok=False)
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
NAMES=['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','research_interviews_accessibility_comparison_long_filename.txt','collaboration_notes_final_version_with_revisions.txt']
async def main():
 report={'tag':TAG,'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':[],'captures':[],'page_errors':[],'evidence_kind':'controlled_real_browser_episodes','natural_time_playback_viewed':False}
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=CHROME,headless=True,args=['--no-sandbox'])
  context=await browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
  page=await context.new_page();page.on('pageerror',lambda e:report['page_errors'].append(str(e)))
  inp=page.locator('textarea.aui-composer-input');vp=page.locator('[data-slot="aui_thread-viewport"]')
  def check(name,passed,details=None):report['checks'].append({'name':name,'pass':bool(passed),'details':details})
  async def geom():return await page.evaluate('''()=>{const v=document.querySelector('[data-slot="aui_thread-viewport"]'),c=document.querySelector('[data-slot="aui_composer-shell"]'),i=document.querySelector('.aui-composer-input');return {top:v.scrollTop,height:v.scrollHeight,client:v.clientHeight,gap:v.scrollHeight-v.clientHeight-v.scrollTop,composer:c.getBoundingClientRect().toJSON(),input:i.getBoundingClientRect().toJSON(),active:document.activeElement?.getAttribute('aria-label'),docWidth:document.documentElement.scrollWidth,width:innerWidth,heightViewport:innerHeight}}''')
  async def snap(name):
   start=time.monotonic();await page.screenshot(path=str(OUT/f'{name}.png'));report['captures'].append({'name':name,'capture_start_monotonic':start,'capture_end_monotonic':time.monotonic(),'geometry':await geom()})
  async def load(theme,lang,size):
   await page.set_viewport_size({'width':size[0],'height':size[1]});await page.goto(f'http://127.0.0.1:4407/?theme={theme}&lang={lang}');await page.evaluate('document.fonts.ready');await page.wait_for_timeout(200)
  async def files():
   async with page.expect_file_chooser() as fc:await page.locator('.aui-composer-add-attachment').click()
   await (await fc.value).set_files([{'name':n,'mimeType':'text/plain','buffer':b'Synthetic fixture only'} for n in NAMES])
   await page.wait_for_timeout(100)
  try:
   for theme,lang in [('light','en'),('dark','zh')]:
    for w,h in [(1440,900),(1280,600),(390,844)]:
     await load(theme,lang,(w,h));prefix=f'{theme}-{lang}-{w}x{h}';await snap(prefix+'-initial')
     await inp.fill('Compare the notes.\nKeep observation separate.\nCheck the dates.\n城市出行和阅读连续性。\nWhat is uncertain?\nWhat comes next?');await files();await snap(prefix+'-six-lines-files')
     g=await geom();check(prefix+' composer/action within viewport',g['composer']['bottom']<=h and g['composer']['top']>64 and g['docWidth']<=w,g)
     target=page.locator('.aui-composer-attachments button[aria-haspopup="dialog"]').nth(1);await target.focus();await page.keyboard.press('Enter');await page.get_by_role('dialog').wait_for();await snap(prefix+'-filename-dialog');check(prefix+' full filename disclosed',NAMES[1] in await page.get_by_role('dialog').inner_text());await page.keyboard.press('Escape');await page.wait_for_timeout(120);check(prefix+' dialog restores trigger focus',await target.evaluate('(e)=>document.activeElement===e'))
     await page.locator('.aui-composer-attachments .aui-attachment-tile-remove').nth(1).focus();await page.keyboard.press('Enter');await page.wait_for_timeout(120);check(prefix+' removal returns focus to composer',await inp.evaluate('(e)=>document.activeElement===e'));check(prefix+' removes selected file',await page.locator('.aui-composer-attachments .aui-attachment-root').count()==3)
     await inp.fill(('Long mixed-language question — 城市出行资料，keep facts separate from interpretation.\n')*20);await snap(prefix+'-long-input');g=await geom();check(prefix+' input is capped',g['input']['height']<=min(192,h*.3)+1 and g['composer']['top']>64,g)
    # Complete behavioral episode in the compact desktop condition, for each variant.
    await load(theme,lang,(1280,600));prefix=theme+'-'+lang+'-episode'
    await inp.fill('IME test 城市');await inp.dispatch_event('keydown',{'key':'Enter','code':'Enter','isComposing':True,'keyCode':229});await page.wait_for_timeout(100);check(prefix+' IME Enter does not send',await page.locator('.aui-composer-cancel').count()==0 and await inp.input_value()=='IME test 城市')
    await inp.press('Shift+Enter');check(prefix+' Shift Enter inserts newline','\n' in await inp.input_value())
    await inp.fill('A long response, please.');await inp.press('Enter');await page.locator('.aui-composer-cancel').wait_for();await page.wait_for_timeout(450);await snap(prefix+'-01-running')
    await vp.hover();await page.mouse.wheel(0,-2200);await page.wait_for_timeout(150);a=await geom();await snap(prefix+'-02-away');await page.wait_for_timeout(550);b=await geom();await snap(prefix+'-03-growing-away');check(prefix+' manual reading position held',abs(a['top']-b['top'])<=2 and b['height']>a['height'],{'before':a,'after':b})
    await page.locator('.aui-thread-scroll-to-bottom').click();await page.wait_for_timeout(400);await snap(prefix+'-04-return');await page.wait_for_timeout(400);c=await geom();await snap(prefix+'-05-following');check(prefix+' return follows subsequent growth',c['gap']<=3,c)
    await page.locator('.aui-composer-cancel').click();await page.locator('.aui-composer-send').wait_for();length1=await page.locator('[data-slot="aui_assistant-message-root"]').last.inner_text() if await page.locator('[data-slot="aui_assistant-message-root"]').count() else await page.locator('.aui-assistant-message-root').last.inner_text();await page.wait_for_timeout(250);length2=await page.locator('[data-slot="aui_assistant-message-root"]').last.inner_text() if await page.locator('[data-slot="aui_assistant-message-root"]').count() else await page.locator('.aui-assistant-message-root').last.inner_text();check(prefix+' stop prevents later chunks',length1==length2);await snap(prefix+'-06-stopped')
    # Same actual question repeated after stop.
    await inp.fill('A long response, please.');await inp.press('Enter');await page.locator('.aui-composer-cancel').wait_for();await page.wait_for_timeout(120);check(prefix+' repeat question starts another response',await page.locator('.aui-composer-cancel').count()==1);await page.locator('.aui-composer-cancel').click();await page.locator('.aui-composer-send').wait_for()
    await inp.fill('[fail] Please retry this local question.');await inp.press('Enter');await page.locator('.aui-message-error-root').wait_for();await snap(prefix+'-07-failure');check(prefix+' failure message visible',await page.locator('.aui-message-error-root').is_visible());retry=page.get_by_role('button',name='Retry response' if lang=='en' else '重试回答',exact=True).last;await retry.click();await page.locator('.aui-composer-cancel').wait_for();await page.locator('.aui-composer-send').wait_for(timeout=20000);await snap(prefix+'-08-retry-complete');check(prefix+' retry completes all seven sections',await page.locator('.aui-message-error-root').count()==0 and ('Observation theme 7' if lang=='en' else '观察主题 7') in await page.locator('.aui-assistant-message-root').last.inner_text())
   await page.emulate_media(reduced_motion='reduce');check('reduced motion turns off smooth scrolling',await vp.evaluate('(e)=>getComputedStyle(e).scrollBehavior')=='auto')
  except Exception as e:
   report['error']=str(e);check('suite completed',False,str(e));await page.screenshot(path=str(OUT/'failure-state.png'));raise
  finally:
   report['ended']=datetime.datetime.now(datetime.timezone.utc).isoformat();(OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({'output':str(OUT),'checks':len(report['checks']),'failed':[c for c in report['checks'] if not c['pass']],'page_errors':report['page_errors']},ensure_ascii=False));await context.close();await browser.close()
asyncio.run(main())
