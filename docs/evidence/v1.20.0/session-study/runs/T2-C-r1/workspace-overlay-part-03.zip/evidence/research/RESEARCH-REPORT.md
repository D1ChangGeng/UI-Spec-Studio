# Meridian UI source and experience research

Research date: 2026-11-01. Scope: the w07 package, its original baseline, supplied source, and relevant public implementations. Research only: no product code was changed by this researcher and no final product design decision is claimed.

## Decision-useful findings

The supplied assistant-ui family is a credible adoption path for this problem. Its existing `File.Root`, `File.Icon`, and `File.Name` composition directly supports identifiable metadata-only document attachments. The official rendered File examples show the visual relationship already carried by that source: a type icon, readable name, quiet outline or muted surface, and compact spacing. The task does not require borrowing another design system to obtain this relationship. A separate, independently authored full chatbot from Vercel AI Elements provides a useful comparison: it keeps the growing text field above a stable tool/send footer, and offers named inline attachment badges rather than anonymous square tiles. These findings support a source-based local trial; they do not establish that the integrated trial passes.

The consequential behavioral finding is that the baseline preserves the reader's earlier position while content grows, but an explicit return during streaming did not stay at the eventual bottom. The installed controller makes `autoScroll` false by default when `turnAnchor` is `top`. This is a configuration and integration question worth resolving before any visual polish. A return control must re-enter following behavior, while a subsequent user scroll must still interrupt it.

## Inquiry and evidence scope

I read the assigned role, TASK, INPUT, RUN-CONTROL, the complete UI Spec method and its eight common references, plus evidence instructions. The inquiry began with attachment identity and short-viewport pressure, then expanded to the return/follow transition when the baseline episode exposed it. I inspected the existing source before considering replacements, searched official primary sources, and directly viewed their rendered previews. Current web guidance was also searched and retrieved; its content-sizing guidance did not justify replacing the existing mature composer behavior, and its initial-scroll primitive does not address continuous streaming.

Local observations use the supplied deterministic adapter, Chromium 143, installed Playwright, task font configuration, and `http://127.0.0.1:4407`. The principal local episode is 1280×600, light/English. A 390×844 dark/Chinese settled reading state was also viewed. The public browser screenshots are approximately 1348×925; they are qualitative references, not same-viewport geometric comparisons. No real prompt was submitted to an external model and no file contents were uploaded externally.

## Baseline: observed relationships

At 1280×600, six lines of mixed English/Chinese text plus four document attachments produced a 672×270 composer, with a 654×152 text area and a 654×56 attachment strip. The thread viewport was 1022×536. Thus the composer consumed roughly half the available vertical conversation area. The source's separate action row kept add/send controls available, the text retained a comfortable 24-pixel line rhythm, and the surface remained quiet. The pressure comes from the aggregate height of attachments, text, actions, and surrounding spacing, not merely the text area's maximum height.

The four document tiles were visually indistinguishable at rest. Each was a 56-pixel square with a generic document icon. Source and accessibility output show filenames available to assistive technology and in hover tooltips; the visible resting layout does not let a sighted user compare similarly named files. Metadata-only documents have no image source, so the image preview dialog does not provide a document detail path. That makes a visible name plus a full-name disclosure a better trial candidate than merely enlarging the tiles.

The streaming episode used the baseline's normal submit action, a wheel scroll away from the latest answer, then its existing return control. At sample 5 the viewport reached scrollTop 2; it remained at 2 through sample 13 while scrollHeight increased from 2003 to 3397. That is evidence of stable reader position at the sampled moments. After return at sample 14, scrollTop moved to 2170, then 3058, and eventually 3093. Final scrollHeight was 3928 and clientHeight 536: the view finished 299 pixels above the bottom. The screenshots visibly retain the return control in the settled final state. This episode supports a follow-transition defect; it is not a measured animation-smoothness evaluation.

The corresponding installed source in `useThreadViewportAutoScroll.ts` explicitly selects `autoScroll ?? state.turnAnchor !== "top"`, holds following while a top anchor is active, and delegates explicit return to the existing controller. This explains why the top-anchor configuration deserves scrutiny. It does not prove that changing one prop alone fixes all timing interactions. Main's later integrated trial and its smooth-scroll findings are separate evidence, not observations claimed by this researcher.

## Source candidates and practical paths

| Candidate | Actual evidence and carried relationship | Adoption path | Tradeoff or unresolved limit |
|---|---|---|---|
| Supplied assistant-ui attachment tiles | Existing assembled app and source inspected; compact fixed-height strip, remove affordance, accessible filename, hover disclosure. | Retain its attachment context and remove control; useful for genuine image previews. | Anonymous document icons prevent at-rest comparison. Hover-only full identity is weak for touch and similar filenames. |
| Supplied assistant-ui File composition | Official File preview viewed; outlined/muted compact rows preserve icon/name hierarchy. The exact supplied module already exposes Root/Icon/Name and a small size. | Compose those existing parts for metadata-only files inside the supplied attachment/runtime context. Use existing Dialog family for a complete name where necessary. Preserve metadata truth: no fabricated size, payload, or download. | `File.Name` truncates. Full-name access still needs explicit focus/touch behavior. Row wrapping or stacking can consume the short viewport; integrated width and height limits require validation. |
| Vercel AI Elements named inline attachments and complete chatbot | Independent official inline preview and full chatbot viewed. Filename badges wrap across rows; six-line input expands upward while the tool/send footer stays in place. Reading viewport gives up height. | A viable larger source-family adoption if the current family were unsuitable. Official source is available; use its full attachment/context and Conversation contracts rather than recreating a screenshot. | Different state model and file API; integration work is materially greater than using supplied parts. Wrapping badges can still create height pressure. Public streaming interruption/return was not exercised. Source currently announces migration to shadcn/ui and deprecation at the end of November 2026, so any fresh adoption requires a pinned migration-aware source choice. |
| prompt-kit | Official docs and repository discovered; documentation fetch returned 403, and local rendered capture failed certificate trust before any page inspection. | Keep as a possible independent candidate if another source is needed later. | Not visually evaluated; no claim about its rendered quality or behavior and no recommendation to adopt it from this inquiry. |

The current assistant-ui source is pinned in the package to revision `ff654d8156680b839774296ef644b57ab1078425` under its supplied MIT notice. AI Elements is publicly Apache-2.0 according to its repository LICENSE, inspected during this session. The AI Elements public preview was current rather than revision-pinned; it is reference evidence, not a frozen adopted dependency. No public asset, third-party logo, or example content was imported into the product.

## Public source observations and limits

The AI Elements inline example shows names immediately beside type/thumbnail cues. Three badges fit in the first row and a fourth wraps below. This solves the baseline's visual identity gap in the reference state, while also demonstrating why unrestricted wrapping is costly in a 600-pixel-tall window. The full chatbot independently illustrates a bounded conversation region, suggestions above the composer, and controls in a footer beneath the text field. Filling six mixed-script lines moved the top of the composer upward and reduced visible reading area without moving the bottom action row. I did not test its file transfer, cancellation, retry, or streaming semantics.

The assistant-ui Scroll anchor page was also directly viewed. Its compact demonstration is a scripted explanatory sequence, and its docs distinguish this illustration from runtime wiring. The demo can intentionally unpin and later automatically return to illustrate the pill. That scripted auto-return should not be copied as product behavior: the required workspace contract leaves the reader in control. The useful source lesson is the existing runtime's interruption/return mechanism, not the illustration's timer.

## Next verification questions for the main owner

1. In the integrated source composition, can all four long filenames be distinguished, opened by keyboard and touch, and fully read without losing draft text or consuming an unbounded share of the short viewport? Confirm dialog focus return and independent remove targets.
2. With frequent streaming growth, does explicit return reach the actual bottom and continue following through completion? Does a fresh wheel/touch interruption stop following immediately? Verify this through a time-bearing episode, not only final screenshots.
3. Does the selected source configuration preserve the same relationships across short desktop, narrow dark/Chinese, long mixed-script drafts, cancel, failure/retry, and repeated questions? These are integrated acceptance questions, not covered by the public demos.

The evidence is sufficient to narrow the source choice and explain the baseline risks. It does not establish a final visual-quality or full-interaction acceptance judgment. Original construction was not needed or undertaken.

## Evidence and source index

Open these three comparison captures first:

- `public-captures/w07-assistant-ui-file-final.png`: source-native file row hierarchy and available variants.
- `public-captures/w07-ai-elements-inline.png`: materially different named badges, including visible wrapping.
- `public-captures/w07-ai-elements-chatbot-six-lines-settled.png`: full independent chatbot with a grown composer and stable action footer.

Local priority captures are `baseline-six-lines-files-1280.png`, `baseline-stream-13.png`, and `baseline-stream-23.png`. Raw local episode samples are in `baseline-stream-samples.json`, geometry in `baseline-geometry.json`, and original browser stdout/stderr/command metadata in `browser-run-003/`. Earlier failed selector attempts remain in `browser-run-001/` and `browser-run-002/`; their failures are not passes. The final capture script is retained in `scripts/capture.py`. The source output is in `source-read-001/` and `source-scroll-002/`. Public AX output and actual screenshot bytes are in `public-captures/`; original search/open responses and local image tool responses are in `tool-responses/`. `VISUAL-REVIEW.md` distinguishes viewed captures from saved-only artifacts.

Primary sources:

- [assistant-ui File](https://www.assistant-ui.com/elements/file): rendered source variants and actual composition API.
- [assistant-ui Scroll anchor](https://www.assistant-ui.com/elements/scroll-anchor): scripted demo, runtime behavior and configuration descriptions.
- [assistant-ui Attachment primitive](https://www.assistant-ui.com/docs/primitives/attachment): runtime attachment context, name and remove semantics.
- [AI Elements Attachments](https://elements.ai-sdk.dev/components/attachments): grid, inline and list options.
- [AI Elements Chatbot](https://elements.ai-sdk.dev/examples/chatbot): complete rendered example and source integration.
- [AI Elements Conversation](https://elements.ai-sdk.dev/components/conversation): documented following and explicit return contracts; not behaviorally verified here.
- [AI Elements Prompt Input](https://elements.ai-sdk.dev/components/prompt-input): composer parts and current migration notice.
- [AI Elements LICENSE](https://github.com/vercel/ai-elements/blob/main/LICENSE): Apache-2.0 identification, inspected directly.
- [prompt-kit repository](https://github.com/ibelick/prompt-kit): discovered independent candidate; rendered comparison remains unresolved.

Access limitations: local public-browser captures encountered `ERR_CERT_AUTHORITY_INVALID`, preserved in each source's `*-meta.json`; no certificate check was disabled. The supported cloud browser successfully displayed assistant-ui and AI Elements. prompt-kit web retrieval returned 403; its cause is unknown. These failures are access limits, not evidence of source inadequacy.
