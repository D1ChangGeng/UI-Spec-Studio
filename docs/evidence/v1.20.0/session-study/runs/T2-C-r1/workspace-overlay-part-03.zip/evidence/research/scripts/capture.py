import asyncio,json,time,traceback
from pathlib import Path
from playwright.async_api import async_playwright
OUT=Path("/workspace/scratch/708e8b7f118e/ui-study/worksets/w07/evidence/research")
CHROME="/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell"
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=CHROME,headless=True,args=["--no-sandbox"])
  page=await browser.new_page(viewport={"width":1280,"height":600},device_scale_factor=1)
  logs=[]
  page.on("console",lambda m: logs.append({"type":m.type,"text":m.text}))
  await page.goto("http://127.0.0.1:4407/?theme=light&lang=en")
  await page.evaluate("document.fonts.ready")
  await page.screenshot(path=str(OUT/"baseline-initial-1280.png"))
  (OUT/"baseline-initial-aria.txt").write_text(await page.locator("body").aria_snapshot())
  await page.locator("textarea").first.fill("Compare the research findings.\nKeep evidence separate from inference.\nExplain the exceptions.\n给出中文摘要与英文对照。\nPreserve uncertainty.\nFinish with practical next steps.")
  async with page.expect_file_chooser() as fc:
   await page.get_by_role("button",name="Add Attachment",exact=True).click()
  chooser=await fc.value
  await chooser.set_files([{"name":n,"mimeType":"text/plain","buffer":b""} for n in ["notes.txt","城市出行访谈摘要_2026-10-31_final-revised-notes.txt","城市出行访谈摘要_2026-10-31_final-revised-notes-part-2.txt","Meridian_research_evidence_review_2026-10-31_revision-final.txt"]])
  await page.wait_for_timeout(400)
  await page.screenshot(path=str(OUT/"baseline-six-lines-files-1280.png"))
  (OUT/"baseline-files-aria.txt").write_text(await page.locator("body").aria_snapshot())
  await page.locator(".aui-attachment-tile").nth(1).hover(position={"x":12,"y":42})
  await page.wait_for_timeout(800)
  await page.screenshot(path=str(OUT/"baseline-long-filename-hover-1280.png"))
  geometry=await page.evaluate("""() => Object.fromEntries(['.aui-composer-input','.aui-composer-root','.aui-composer-attachments','[data-slot="aui_thread-viewport"]'].map(s=>{const e=document.querySelector(s),r=e.getBoundingClientRect();return [s,{x:r.x,y:r.y,width:r.width,height:r.height,scrollHeight:e.scrollHeight,scrollWidth:e.scrollWidth,clientHeight:e.clientHeight,scrollTop:e.scrollTop}]}))""")
  (OUT/"baseline-geometry.json").write_text(json.dumps(geometry,indent=2))
  await page.get_by_role("button",name="Send message",exact=True).click()
  samples=[]
  for i in range(24):
   if i==4:
    await page.locator('[data-slot="aui_thread-viewport"]').hover()
    await page.mouse.wheel(0,-700)
   if i==14:
    btn=page.get_by_role("button",name="Scroll to bottom",exact=True)
    if await btn.is_visible(): await btn.click()
   samples.append({"t":time.monotonic(),"i":i,"state":await page.evaluate("""() => {const e=document.querySelector('[data-slot="aui_thread-viewport"]');return {top:e.scrollTop,height:e.scrollHeight,client:e.clientHeight,active:document.activeElement?.getAttribute('aria-label'),textLength:document.body.innerText.length,stop:!!document.querySelector('.aui-composer-cancel')}}""")})
   if i in [0,3,5,10,13,15,23]: await page.screenshot(path=str(OUT/("baseline-stream-%02d.png"%i)))
   await page.wait_for_timeout(350)
  stop=page.get_by_role("button",name="Stop",exact=True)
  if await stop.count() and await stop.is_visible(): await stop.click()
  (OUT/"baseline-stream-samples.json").write_text(json.dumps(samples,indent=2))
  await page.goto("http://127.0.0.1:4407/?theme=dark&lang=zh")
  await page.evaluate("document.fonts.ready")
  await page.screenshot(path=str(OUT/"baseline-dark-zh-1280.png"))
  await page.set_viewport_size({"width":390,"height":844})
  await page.screenshot(path=str(OUT/"baseline-dark-zh-390.png"))
  (OUT/"baseline-console.json").write_text(json.dumps(logs,indent=2))
  await page.close()
  async def public_capture(name,url):
   p=await browser.new_page(viewport={"width":1440,"height":900},device_scale_factor=1)
   record={"url":url,"started":time.time()}
   try:
    await p.goto(url,wait_until="domcontentloaded",timeout=35000)
    await p.wait_for_timeout(1800)
    record["title"]=await p.title()
    record["urlFinal"]=p.url
    await p.screenshot(path=str(OUT/(name+"-initial.png")))
    (OUT/(name+"-aria.txt")).write_text(await p.locator("body").aria_snapshot())
    (OUT/(name+"-text.txt")).write_text(await p.locator("body").inner_text())
   except Exception as e: record["error"]=str(e)
   (OUT/(name+"-meta.json")).write_text(json.dumps(record,indent=2))
   await p.close()
  await asyncio.gather(*[public_capture(n,u) for n,u in [
   ("ai-elements-attachments","https://elements.ai-sdk.dev/components/attachments"),
   ("ai-elements-chatbot","https://elements.ai-sdk.dev/examples/chatbot"),
   ("prompt-kit-chat","https://www.prompt-kit.com/blocks/chat"),
   ("assistant-ui-file","https://www.assistant-ui.com/elements/file")
  ]])
  await browser.close()
asyncio.run(main())

