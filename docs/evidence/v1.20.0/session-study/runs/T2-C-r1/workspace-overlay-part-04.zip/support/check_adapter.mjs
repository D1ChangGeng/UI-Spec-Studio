// Exercise the exact production adapter at its declared local boundary.
globalThis.location = {search: '?lang=en'};
const {syntheticModel,filenameAttachments}=await import('../app/src/synthetic.ts');
const controller=new AbortController();
const stream=syntheticModel.run({messages:[{role:'user',content:[{type:'text',text:'abort probe'}]}],abortSignal:controller.signal});
const first=await stream.next();controller.abort();const next=await stream.next();
if(first.done || !next.done) throw new Error('Adapter yielded after abort.');
const file={name:'城市出行访谈摘要_2026-10-31_final-revised-notes.txt',type:'text/plain',arrayBuffer(){throw new Error('Contents read');},text(){throw new Error('Contents read');}};
const attachment=await filenameAttachments.add({file});const sent=await filenameAttachments.send(attachment);
if(sent.name!==file.name || sent.status.type!=='complete') throw new Error('Attachment metadata contract failed.');
console.log(JSON.stringify({abort_before_next_yield:true,attachment_filename_retained:true,contents_never_read:true,network_calls:'none in production adapter source',first_chunk_characters:first.value.content[0].text.length}));
