import asyncio,json,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence'/'baseline-scroll-01';OUT.mkdir(parents=True,exist_ok=False)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
  page=await b.new_page(viewport={'width':1280,'height':600});events=[]
  async def record(label):
   v=await page.locator('[data-slot="aui_thread-viewport"]').evaluate('(e)=>({top:e.scrollTop,height:e.scrollHeight,client:e.clientHeight,gap:e.scrollHeight-e.clientHeight-e.scrollTop})')
   events.append({'label':label,'t':time.monotonic(),'scroll':v,'running':await page.get_by_role('button',name='Stop generating',exact=True).count()});await page.screenshot(path=str(OUT/f'{label}.png'))
  await page.goto('http://127.0.0.1:4407/?theme=light&lang=en');await page.evaluate('document.fonts.ready')
  await page.locator('textarea.aui-composer-input').fill('Long answer for scroll continuity.');await page.get_by_role('button',name='Send message',exact=True).click();await page.wait_for_timeout(800);await record('01-start')
  await page.locator('[data-slot="aui_thread-viewport"]').hover();await page.mouse.wheel(0,-800);await page.wait_for_timeout(300);await record('02-away')
  await page.wait_for_timeout(750);await record('03-growing-away')
  await page.get_by_role('button',name='Scroll to bottom',exact=True).click();await page.wait_for_timeout(600);await record('04-return')
  await page.wait_for_timeout(1300);await record('05-after-return-growth')
  stop=page.get_by_role('button',name='Stop generating',exact=True)
  if await stop.count():await stop.click()
  await record('06-stop');(OUT/'events.json').write_text(json.dumps(events,indent=2));print(json.dumps(events));await b.close()
asyncio.run(main())
