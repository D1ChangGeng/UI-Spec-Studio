import asyncio,json,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence'/'continuation-02';OUT.mkdir(parents=True,exist_ok=False)
async def main():
 result={'checks':[],'captures':[],'errors':[]}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox']);page=await b.new_page(viewport={'width':1280,'height':600});page.on('pageerror',lambda e:result['errors'].append(str(e)))
  def check(name,passed,details=None):result['checks'].append({'name':name,'pass':bool(passed),'details':details})
  async def snap(name):
   await page.screenshot(path=str(OUT/f'{name}.png'));result['captures'].append({'name':name,'monotonic':time.monotonic()})
  try:
   await page.goto('http://127.0.0.1:4407/?theme=light&lang=en');await page.evaluate('document.fonts.ready');inp=page.locator('.aui-composer-input');vp=page.locator('[data-slot="aui_thread-viewport"]')
   names=['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','research_interviews_accessibility_comparison_long_filename.txt','collaboration_notes_final_version_with_revisions.txt']
   async with page.expect_file_chooser() as fc:await page.locator('.aui-composer-add-attachment').click()
   await (await fc.value).set_files([{'name':n,'mimeType':'text/plain','buffer':b'fixture'} for n in names]);await inp.fill('Please compare these four local filenames.');await inp.press('Enter');await page.locator('.aui-composer-cancel').wait_for();await page.wait_for_timeout(150);await page.locator('.aui-composer-cancel').click();await page.locator('.aui-composer-send').wait_for();await page.wait_for_timeout(200);await snap('01-files-sent')
   sent=page.locator('.aui-user-message-attachments-end').last;check('all four sent attachments remain visible objects',await sent.locator('.aui-attachment-root').count()==4);check('composer clears submitted attachments',await page.locator('.aui-composer-attachments .aui-attachment-root').count()==0)
   fourth=sent.get_by_role('button',name='Details for '+names[3],exact=True);await fourth.click();await page.wait_for_timeout(200);await snap('02-sent-file-details');check('sent attachment can disclose full fourth filename',names[3] in await page.get_by_role('dialog').inner_text());await page.keyboard.press('Escape');await page.wait_for_timeout(250)
   # Actual edit and cancellation, then another response.
   edit=page.get_by_role('button',name='Edit message',exact=True).last;await edit.click();editor=page.locator('.aui-edit-composer-input');await editor.wait_for();original=await editor.input_value();await editor.fill(original+' amended');await snap('03-editing');cancel=page.get_by_role('button',name='Cancel',exact=True);await cancel.click();check('edit cancel retains original sent question',await page.get_by_text('Please compare these four local filenames.',exact=True).count()>0)
   await inp.fill('Continue with a long response.');await inp.press('Enter');await page.locator('.aui-composer-cancel').wait_for();await page.wait_for_timeout(600);await vp.hover();await page.mouse.wheel(0,-600);await page.wait_for_timeout(180);top1=await vp.evaluate('(e)=>e.scrollTop');await inp.fill('Draft line one\nDraft line two\n第三行，保留阅读位置。\nFourth line\nFifth line\nSixth line');await page.wait_for_timeout(400);top2=await vp.evaluate('(e)=>e.scrollTop');await snap('04-draft-while-reading-away');check('draft growth retains manual reading position',abs(top2-top1)<=2,{'before':top1,'after':top2});check('draft remains editable during streaming','第三行' in await inp.input_value());await page.locator('.aui-composer-cancel').click();await page.locator('.aui-composer-send').wait_for();check('cancellation preserves next-question draft','第三行' in await inp.input_value());await snap('05-draft-after-stop')
  except Exception as e:
   result['failure']=str(e);await page.screenshot(path=str(OUT/'failure.png'));raise
  finally:
   (OUT/'report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False));await b.close()
asyncio.run(main())
