# Source adoption and decisions

## Kept foundation

The product retains the assistant-ui cloud template at revision `ff654d8156680b839774296ef644b57ab1078425`, with its original MIT provenance in SOURCE-MANIFEST.json. Locked installed versions include @assistant-ui/react 0.15.32, @assistant-ui/react-markdown 0.14.24 and @base-ui/react 1.9.0. SOURCE-MANIFEST.json, FONT-SOURCES.json, package-lock.json and the synthetic adapter are preserved. `evidence/protected-final.json` records the lockfile and adapter hashes.

## Candidate comparison and observation scope

| Resource | Evidence and useful distinction | Decision |
| --- | --- | --- |
| Supplied assistant-ui Thread, File and Dialog | Exact local source, baseline renders, five integration trials and final bilingual episodes. Existing File composition supplies filename, icon, size and surface; Dialog supplies full-name disclosure and keyboard return. | Adopt within the same family. Preserve composer border, radius, prose measure, icon actions and typography. |
| assistant-ui Composer Attachments / scroll-anchor documentation | Official public documentation retrieved; original live demos failed browser certificate validation. Describes filename chips, attachment lifecycle and viewport options. | Supports source choice; no claim of live-demo visual observation. |
| Vercel AI Elements chatbot, prompt-input, attachments, conversation | Independent child's primary-source investigation: bounded prompt height, metadata chips and conditional latest control. Public sources retained in evidence/research. | Useful comparison, but not visually trialed in this host. Do not import another runtime or reconstruct its appearance. |
| MUI X chat / shadcn chatbot kit | Child's candidate-level documentation inspection; no integrated or visual trial. | Unselected; insufficient observation for adoption. |

Primary official references include https://www.assistant-ui.com/elements/composer-attachments, https://www.assistant-ui.com/elements/scroll-anchor, https://elements.ai-sdk.dev/components/attachments and https://elements.ai-sdk.dev/examples/chatbot. Original tool responses are `evidence/web-001-assistant-ui.json`, `evidence/web-002-candidates.json`, and `evidence/research/public-sources.json`. Child report: `evidence/research/REPORT.md`. Primary personally opened the child's `w13_six.png` (view-016), confirming six lines expand the supplied composer substantially. No exceptional visual reference was reconstructed without code.

## Final adaptations and their reasons

1. Compose document attachments from existing File, Button and Dialog components. A visible truncated filename distinguishes files; activating it reveals the exact complete name and truthful filename-only description. Keep the established attachment removal control. Wrap sent attachments and retain horizontal scrolling for the draft row. Restore `relative` on the attachment root, which keeps absolute accessible labels inside their source containing block and eliminates unintended thread overflow.
2. Keep the runtime textarea autosizer. At viewport heights at most 650px, cap its content height at 96px (four 24px lines); taller viewports retain the source 192px maximum. Six-line draft plus files measures 219px overall at 1280×600, with the entire draft retained and internally scrollable.
3. Configure the supported viewport with bottom anchoring and autoScroll, and the existing latest control with `behavior="instant"`. Runtime scrolling still pauses when a reader wheels away. A deliberate return reaches the current end and follows subsequent growth. Top-anchor trials and smooth-return trials remained behind a growing answer and were rejected; no custom scroll engine remains.
4. Configure MarkdownTextPrimitive with `smooth={false}`. Diagnosis showed its reveal buffer continued displaying text briefly after the adapter aborted. This source-supported option makes visible Stop match the adapter's actual streamed chunks; all seven sections remain unchanged.
5. Return focus to the input after Stop and removal, preserve Dialog's own Escape/focus behavior, and localize the task's composer, disclosure, return, retry and edit controls. This is scoped localization, not a claim that every upstream utility is translated.
6. Remove obsolete tsconfig baseUrl and add Vite's client type declaration so the pinned TypeScript 7 build can typecheck imported CSS. No dependency or lockfile change.

Changed product files: elements/attachment.aui.tsx, elements/thread.aui.tsx, elements/markdown-text.tsx, ui/dialog.tsx, src/lib/locale.ts, src/styles.css, tsconfig.json and src/vite-env.d.ts. The adapter, seeded response content, fonts, theme tokens and source licenses stay as supplied.

## Retained failures and corrections

All command attempts remain separate. Root sandbox launch failed and the existing nonprivileged account succeeded with sandbox enabled. Public HTTPS browser failures were not bypassed. Trial 002/003 top-anchor changes failed; trial 004 smooth return failed; trial 005 bottom + instant passed. Final 001 exposed post-Stop reveal buffering; diagnosis 018 confirmed it. Layout diagnosis 019 identified the absolute-label overflow. Final 002 failed a test that compared untrimmed draft whitespace against normalized sent text; final 003 compares against the actual sent question and passes without altering that product behavior. Build/typecheck compatibility failures are also retained.

The researcher request had one capacity failure before success. DELEGATION.json preserves both actual requests and IDs. The dispatched prompt matched all substantive characters but omitted the source file's terminal newline; this discrepancy is explicitly recorded. Requested backend was gpt-6.1-terra, fresh context; resolved backend, native role, tokens and cost are unknown. No child changed product code.
