// Product copy follows the query-selected content locale. User text is untouched.
export const uiText = (english: string, chinese: string) =>
  new URLSearchParams(location.search).get("lang") === "zh" ? chinese : english;
