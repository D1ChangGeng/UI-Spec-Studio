import asyncio,json,time,hashlib
from pathlib import Path
from playwright.async_api import async_playwright

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'final-001'
OUT.mkdir(exist_ok=True)
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
FILES=['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','research_observations_accessibility_and_reading_continuity_final.txt','collaboration_notes_round_two_revised_for_review.txt']
events=[]; checks=[]; errors=[]

async def metrics(page):
 return await page.evaluate('''() => {const v=document.querySelector('[data-slot="aui_thread-viewport"]');const c=document.querySelector('[data-slot="aui_composer-shell"]');const t=document.querySelector('.aui-composer-input');const r=e=>({y:e.getBoundingClientRect().y,height:e.getBoundingClientRect().height,scrollTop:e.scrollTop,scrollHeight:e.scrollHeight,clientHeight:e.clientHeight});return {viewport:r(v),composer:r(c),textarea:r(t),active:document.activeElement?.getAttribute('aria-label')||document.activeElement?.tagName,activeSlot:document.activeElement?.getAttribute('data-slot'),bodyOverflow:document.documentElement.scrollWidth>innerWidth,attachments:document.querySelectorAll('.aui-composer-attachments .aui-document-attachment').length,scrollBehavior:getComputedStyle(v).scrollBehavior}}''')

def save():
 (OUT/'results.json').write_text(json.dumps({'events':events,'checks':checks,'page_errors':errors,'browser':'Chrome headless shell 143.0.7499.4','sandbox':True,'pixel_ratio':1,'capture':'actual ordered states; native scrollbars enabled; no natural-speed playback claim'},ensure_ascii=False,indent=2))

async def snap(page,label):
 a=time.monotonic()
 await page.screenshot(path=str(OUT/f'{label}.png'))
 m=await metrics(page)
 events.append({'label':label,'start_monotonic':a,'end_monotonic':time.monotonic(),'url':page.url,'viewport_size':page.viewport_size,'data':m})
 save();return m

def check(label,value,detail=None):
 checks.append({'label':label,'pass':bool(value),'detail':detail});save()
 if not value: raise AssertionError(label+': '+str(detail))

async def add(page,names,zh):
 async with page.expect_file_chooser() as fc:
  await page.get_by_role('button',name='附加本地文件名' if zh else 'Attach local filenames',exact=True).click()
 await (await fc.value).set_files([{'name':n,'mimeType':'text/plain','buffer':b'local metadata fixture'} for n in names])

async def ready(page,theme,lang):
 await page.goto(f'http://127.0.0.1:4413/?theme={theme}&lang={lang}')
 await page.evaluate('document.fonts.ready')
 await page.locator('.aui-composer-input').wait_for()
 await page.wait_for_timeout(180)

async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=CHROME,headless=True,chromium_sandbox=True,ignore_default_args=['--hide-scrollbars'])
  context=await browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
  page=await context.new_page();page.on('pageerror',lambda e: errors.append(str(e)))
  for theme,lang in [('light','en'),('dark','zh')]:
   zh=lang=='zh'
   for width,height in [(1440,900),(1280,600),(390,844)]:
    await page.set_viewport_size({'width':width,'height':height})
    await ready(page,theme,lang)
    tag=f'{theme}-{lang}-{width}x{height}'
    m=await snap(page,tag+'-initial');check(tag+' initial no page overflow',not m['bodyOverflow'])
    await add(page,FILES,zh)
    text='\n'.join([f'{i+1}. '+('请保留观察与解释的区别。Compare the source notes carefully.' if zh else 'Compare observations and interpretation; 保留原始语境。') for i in range(6)])
    await page.locator('.aui-composer-input').fill(text)
    await page.locator('.aui-composer-input').press('Control+End')
    await page.mouse.move(10,10);await page.wait_for_timeout(220)
    m=await snap(page,tag+'-draft-attachments')
    check(tag+' draft no page overflow',not m['bodyOverflow'])
    check(tag+' all attachments retained',m['attachments']==4,m['attachments'])
    if height==600:check(tag+' compact cap and internal scroll',m['textarea']['height']<=96 and m['textarea']['scrollHeight']>m['textarea']['clientHeight'],m['textarea'])
    if width==390 and zh:
     await page.get_by_role('button',name='查看文件名 '+FILES[1],exact=True).click();await page.wait_for_timeout(180)
     await snap(page,tag+'-filename-dialog')
     await page.keyboard.press('Escape');await page.wait_for_timeout(200)
     await page.get_by_role('button',name='发送消息',exact=True).click();await page.wait_for_timeout(150)
     await page.get_by_role('button',name='停止生成',exact=True).click();await page.wait_for_timeout(120)
     m=await snap(page,tag+'-sent-attachments');check(tag+' sent attachments no page overflow',not m['bodyOverflow'])
  await context.close()

  for theme,lang in [('light','en'),('dark','zh')]:
   zh=lang=='zh';tag=f'episode-{theme}-{lang}'
   context=await browser.new_context(viewport={'width':1280,'height':600},device_scale_factor=1,record_video_dir=str(OUT/'videos'),record_video_size={'width':1280,'height':600})
   await context.tracing.start(screenshots=True,snapshots=True,sources=True)
   page=await context.new_page();page.on('pageerror',lambda e: errors.append(str(e)))
   await ready(page,theme,lang)
   t=page.locator('.aui-composer-input')
   send=page.get_by_role('button',name='发送消息' if zh else 'Send message',exact=True)
   stop=page.get_by_role('button',name='停止生成' if zh else 'Stop generating',exact=True)
   check(tag+' empty send disabled',await send.is_disabled())
   await t.fill('One line — 一行问题');await t.press('Shift+Enter')
   check(tag+' Shift Enter inserts line break','\n' in await t.input_value())
   await add(page,FILES[:1],zh);await page.wait_for_timeout(200);await snap(page,tag+'-single-file')
   await add(page,FILES[1:],zh);await page.wait_for_timeout(200)
   name=('查看文件名 ' if zh else 'View filename ')+FILES[1]
   await page.get_by_role('button',name=name,exact=True).click();await page.wait_for_timeout(160)
   check(tag+' complete filename disclosed',await page.get_by_role('dialog').get_by_text(FILES[1],exact=True).count()==1)
   await snap(page,tag+'-filename-dialog')
   await page.keyboard.press('Escape');await page.wait_for_timeout(220)
   check(tag+' dialog returns focus',await page.evaluate('document.activeElement?.getAttribute("aria-label")')==name)
   await page.get_by_role('button',name=('移除 ' if zh else 'Remove ')+FILES[0],exact=True).click();await page.wait_for_timeout(100)
   check(tag+' remove restores input focus',await t.evaluate('(e)=>e===document.activeElement'))
   await t.fill('请比较阅读连续性。 Keep the source notes distinct from interpretation.');await t.press('Enter')
   await stop.wait_for();await page.wait_for_timeout(280)
   await snap(page,tag+'-streaming')
   v=page.locator('[data-slot="aui_thread-viewport"]');await v.hover();await page.mouse.wheel(0,-900);await page.wait_for_timeout(120)
   before=await snap(page,tag+'-reading-away');await page.wait_for_timeout(350)
   after=await snap(page,tag+'-growth-away')
   check(tag+' reading position held',abs(after['viewport']['scrollTop']-before['viewport']['scrollTop'])<2,{'before':before['viewport'],'after':after['viewport']})
   check(tag+' content grew while away',after['viewport']['scrollHeight']>before['viewport']['scrollHeight'])
   await page.get_by_role('button',name='回到最新内容' if zh else 'Return to latest',exact=True).click();await page.wait_for_timeout(120)
   latest=await snap(page,tag+'-return-latest');await page.wait_for_timeout(220)
   followed=await metrics(page);v=followed['viewport'];gap=v['scrollHeight']-v['clientHeight']-v['scrollTop']
   check(tag+' latest continues following',gap<=2,followed)
   if await stop.count():await stop.click()
   await page.wait_for_timeout(100)
   last=page.locator('[data-slot="aui_assistant-message-root"]').last
   cancelled=await last.inner_text();await page.wait_for_timeout(240)
   check(tag+' stop aborts later chunks',cancelled==await last.inner_text())
   check(tag+' stop returns input focus',await t.evaluate('(e)=>e===document.activeElement'))
   await snap(page,tag+'-stopped')
   await t.fill('[fail] retry-path-'+lang);await send.click()
   await page.locator('.aui-message-error-root').last.wait_for()
   await snap(page,tag+'-failure')
   await page.get_by_role('button',name='重试回答' if zh else 'Retry response',exact=True).last.click()
   await stop.wait_for();await stop.wait_for(state='hidden',timeout=20000)
   check(tag+' retry succeeds',await page.locator('.aui-message-error-root').count()==0)
   answer=await page.locator('[data-slot="aui_assistant-message-root"]').last.inner_text()
   check(tag+' complete long answer retained',('观察主题 7' if zh else 'Observation theme 7') in answer)
   await snap(page,tag+'-retry-complete')
   long='Mixed-language follow-up: 请保留城市访谈的原始语境。 ' * 18
   await t.fill(long);await t.press('Control+End');await snap(page,tag+'-long-mixed-draft')
   check(tag+' long draft retained',await t.input_value()==long)
   await send.click();await stop.wait_for();await page.wait_for_timeout(120);await stop.click();await page.wait_for_timeout(100)
   user=page.locator('[data-slot="aui_user-message-root"]').last;await user.hover()
   await user.get_by_role('button',name='编辑' if zh else 'Edit',exact=True).click()
   edit=page.locator('.aui-edit-composer-input');await edit.fill('Revised follow-up — 修订问题')
   await page.get_by_role('button',name='取消' if zh else 'Cancel',exact=True).click()
   check(tag+' edit cancellation retains question',long in await page.locator('[data-slot="aui_user-message-root"]').last.inner_text())
   await page.locator('[data-slot="aui_user-message-root"]').last.hover()
   await page.locator('[data-slot="aui_user-message-root"]').last.get_by_role('button',name='编辑' if zh else 'Edit',exact=True).click()
   await page.locator('.aui-edit-composer-input').fill('Revised follow-up — 修订问题')
   await page.get_by_role('button',name='更新' if zh else 'Update',exact=True).click();await stop.wait_for();await page.wait_for_timeout(120);await stop.click();await page.wait_for_timeout(100)
   check(tag+' edit update continues runtime', 'Revised follow-up — 修订问题' in await page.locator('[data-slot="aui_user-message-root"]').last.inner_text())
   await snap(page,tag+'-repeat-edit-return')
   await context.tracing.stop(path=str(OUT/(tag+'-trace.zip')))
   await context.close()
  context=await browser.new_context(viewport={'width':390,'height':844},reduced_motion='reduce')
  page=await context.new_page();await ready(page,'dark','zh')
  m=await metrics(page);check('reduced-motion scroll behavior',m['scrollBehavior']=='auto',m['scrollBehavior'])
  await context.close();await browser.close()
 check('no browser page errors',len(errors)==0,errors)
 print(json.dumps({'checks':len(checks),'passed':sum(x['pass'] for x in checks),'captures':len(events),'page_errors':errors},ensure_ascii=False))

try:asyncio.run(main())
finally:save()
