import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',chromium_sandbox=True,headless=True,ignore_default_args=['--hide-scrollbars'])
  page=await b.new_page(viewport={'width':1280,'height':600})
  await page.goto('http://127.0.0.1:4413/?theme=light&lang=en')
  async with page.expect_file_chooser() as f: await page.get_by_role('button',name='Attach local filenames',exact=True).click()
  await (await f.value).set_files([{'name':('long-file-name-to-test-'+str(i)+'.txt'),'mimeType':'text/plain','buffer':b'x'} for i in range(4)])
  await page.locator('.aui-composer-input').fill('line\n'*6);await page.wait_for_timeout(300)
  data=await page.evaluate('''() => [...document.querySelectorAll('*')].filter(e=>e.scrollWidth>e.clientWidth+1 && e.clientWidth>0).map(e=>({tag:e.tagName,cls:e.className,slot:e.getAttribute('data-slot'),scrollWidth:e.scrollWidth,clientWidth:e.clientWidth,rect:e.getBoundingClientRect().toJSON(),overflow:getComputedStyle(e).overflow,minWidth:getComputedStyle(e).minWidth}))''')
  Path('evidence/layout-diagnosis.json').write_text(json.dumps(data,ensure_ascii=False,indent=2));print(json.dumps(data,ensure_ascii=False))
  await b.close()
asyncio.run(main())
