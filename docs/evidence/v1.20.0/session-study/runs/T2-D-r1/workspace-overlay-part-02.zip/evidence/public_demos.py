import asyncio,json,time,os
from pathlib import Path
from playwright.async_api import async_playwright
OUT=Path(__file__).resolve().parent/'public-demos'
OUT.mkdir(exist_ok=True)
async def main():
 async with async_playwright() as p:
  proxy={'server':os.environ['HTTPS_PROXY']} if os.environ.get('HTTPS_PROXY') else None
  browser=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,chromium_sandbox=True,proxy=proxy)
  context=await browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
  page=await context.new_page()
  events=[]
  for name,url in [('assistant-chips','https://www.assistant-ui.com/elements/composer-attachments'),('assistant-scroll','https://www.assistant-ui.com/elements/scroll-anchor'),('ai-elements-attachments','https://elements.ai-sdk.dev/components/attachments')]:
   try:
    r=await page.goto(url,wait_until='domcontentloaded',timeout=30000)
    await page.wait_for_timeout(800)
    h=page.locator('h1').first
    if await h.count(): await h.scroll_into_view_if_needed()
    for i in range(3):
     t=time.monotonic()
     await page.screenshot(path=str(OUT/f'{name}-{i}.png'))
     events.append({'name':name,'url':url,'status':r.status if r else None,'frame':i,'capture_start':t,'capture_end':time.monotonic()})
     await page.wait_for_timeout(1200)
    (OUT/f'{name}.txt').write_text(await page.locator('body').inner_text())
   except Exception as e:
    events.append({'name':name,'url':url,'error':str(e)})
   (OUT/'events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2))
  await context.close()
  await browser.close()
 print(json.dumps(events,ensure_ascii=False))
asyncio.run(main())
