from playwright.sync_api import sync_playwright
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell', headless=True, chromium_sandbox=True)
 page=b.new_page(viewport={'width':1280,'height':600})
 page.goto('http://127.0.0.1:4413/?theme=light&lang=en');page.wait_for_timeout(500)
 with page.expect_file_chooser() as fc:
  page.get_by_role('button',name='Add Attachment').click()
 fc.value.set_files([{'name':'城市出行访谈摘要_2026-10-31_final-revised-notes.txt','mimeType':'text/plain','buffer':b'x'},{'name':'城市出行访谈摘要_2026-10-31_another-version.txt','mimeType':'text/plain','buffer':b'x'},{'name':'short.txt','mimeType':'text/plain','buffer':b'x'}]);page.wait_for_timeout(500)
 page.screenshot(path='/tmp/w13_attachments.png');print('tiles',page.locator('.aui-attachment-tile').count());print('labels',page.locator('.aui-attachment-tile').evaluate_all('(els)=>els.map(e=>e.getAttribute("aria-label"))'))
 page.get_by_role('textbox',name='Message input').fill('A question');page.get_by_role('button',name='Send message').click();page.wait_for_timeout(1200);print('stop',page.get_by_role('button',name='Stop').count());page.screenshot(path='/tmp/w13_stream.png')
 b.close()
