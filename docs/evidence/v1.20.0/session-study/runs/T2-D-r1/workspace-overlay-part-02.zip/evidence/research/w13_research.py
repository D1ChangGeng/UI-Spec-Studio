from playwright.sync_api import sync_playwright
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell', headless=True, chromium_sandbox=True)
 page=b.new_page(viewport={'width':1280,'height':600})
 page.goto('http://127.0.0.1:4413/?theme=light&lang=en')
 page.wait_for_timeout(1000)
 page.screenshot(path='/tmp/w13_initial.png')
 print('title',page.title());print('textareas',page.get_by_role('textbox',name='Message input').count());print('buttons',page.get_by_role('button').all_text_contents())
 page.get_by_role('textbox',name='Message input').fill('\n'.join(['A longer research question about the interview']*6))
 page.screenshot(path='/tmp/w13_six.png')
 print('textarea',page.get_by_role('textbox',name='Message input').bounding_box())
 b.close()
