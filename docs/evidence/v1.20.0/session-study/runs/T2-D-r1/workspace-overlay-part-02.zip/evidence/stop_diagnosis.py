import asyncio,json,time
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',chromium_sandbox=True,headless=True)
  page=await browser.new_page(viewport={'width':1280,'height':600})
  await page.goto('http://127.0.0.1:4413/?theme=light&lang=en')
  await page.locator('.aui-composer-input').fill('Check cancellation')
  await page.get_by_role('button',name='Send message',exact=True).click()
  await page.wait_for_timeout(800)
  await page.get_by_role('button',name='Stop generating',exact=True).click()
  out=[]
  for delay in [0,100,240,500]:
   await page.wait_for_timeout(delay)
   e=page.locator('[data-slot="aui_assistant-message-root"]').last
   out.append({'time':time.monotonic(),'text':await e.inner_text(),'html':await e.inner_html(),'active':await page.evaluate('document.activeElement.tagName')})
  Path('evidence/stop-diagnosis.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
  print(json.dumps([{'time':x['time'],'length':len(x['text']),'tail':x['text'][-200:],'active':x['active']} for x in out]))
  await browser.close()
asyncio.run(main())
