import asyncio, json, time, os
from pathlib import Path
from playwright.async_api import async_playwright

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'trial-003'
OUT.mkdir(exist_ok=True)
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
events=[]

async def record(page,label):
    before=time.monotonic()
    await page.screenshot(path=str(OUT/f'{label}.png'))
    data=await page.evaluate('''() => {const v=document.querySelector('[data-slot="aui_thread-viewport"]');const c=document.querySelector('[data-slot="aui_composer-shell"]');const t=document.querySelector('textarea');const r=x=>x?({x:x.getBoundingClientRect().x,y:x.getBoundingClientRect().y,width:x.getBoundingClientRect().width,height:x.getBoundingClientRect().height,scrollTop:x.scrollTop,scrollHeight:x.scrollHeight,clientHeight:x.clientHeight}):null;return {viewport:r(v),composer:r(c),textarea:r(t),active:document.activeElement?.outerHTML.slice(0,300),buttons:[...document.querySelectorAll('button')].map(x=>({name:x.getAttribute('aria-label')||x.textContent,disabled:x.disabled})),bodyOverflow:document.body.scrollWidth>innerWidth}}''')
    events.append({'label':label,'start_monotonic':before,'end_monotonic':time.monotonic(),'data':data})
    (OUT/'events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2))

async def main():
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path=CHROME,headless=True,chromium_sandbox=True,ignore_default_args=['--hide-scrollbars'])
        context=await browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
        page=await context.new_page()
        page.on('pageerror',lambda e: print('PAGEERROR',str(e)))
        await page.goto('http://127.0.0.1:4413/?theme=light&lang=en')
        await page.evaluate('document.fonts.ready')
        await record(page,'01-light-en-1440-initial')
        await page.set_viewport_size({'width':1280,'height':600})
        await page.get_by_role('textbox',name='Message input',exact=True).fill('\n'.join(['Please compare the reading continuity evidence.' for _ in range(6)]))
        async with page.expect_file_chooser() as fc:
            await page.get_by_role('button',name='Attach local filenames',exact=True).click()
        chooser=await fc.value
        await chooser.set_files([{'name':name,'mimeType':'text/plain','buffer':b'filename-only fixture'} for name in ['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','research_observations_accessibility_and_reading_continuity_final.txt','collaboration_notes_round_two_revised_for_review.txt']])
        await page.wait_for_timeout(300)
        await record(page,'02-light-en-1280-six-lines-attachments')
        await page.get_by_role('button',name='View filename 城市出行访谈摘要_2026-10-31_final-revised-notes.txt',exact=True).click()
        await page.wait_for_timeout(150)
        await record(page,'02b-filename-dialog')
        await page.keyboard.press('Escape')
        await page.wait_for_timeout(200)
        await record(page,'02c-dialog-focus-return')
        await page.get_by_role('button',name='Send message',exact=True).click()
        await page.wait_for_timeout(1500)
        await record(page,'03-stream-start')
        v=page.locator('[data-slot="aui_thread-viewport"]')
        await v.hover()
        await page.mouse.wheel(0,-1000)
        await page.wait_for_timeout(300)
        await record(page,'04-manual-scroll-away')
        await page.wait_for_timeout(1800)
        await record(page,'05-growth-while-away')
        await page.get_by_role('button',name='Return to latest',exact=True).click()
        await page.wait_for_timeout(500)
        await record(page,'06-return-to-latest')
        await page.wait_for_timeout(1000)
        await record(page,'06b-follow-after-return')
        stop=page.get_by_role('button',name='Stop generating',exact=True)
        if await stop.count(): await stop.click()
        await page.wait_for_timeout(100)
        await record(page,'07-stopped')
        await page.goto('http://127.0.0.1:4413/?theme=dark&lang=zh')
        await page.evaluate('document.fonts.ready')
        await record(page,'08-dark-zh-1280-initial')
        await page.set_viewport_size({'width':390,'height':844})
        await record(page,'09-dark-zh-390-initial')
        await context.close()
        await browser.close()
    print(json.dumps({'captures':len(events),'events':str(OUT/'events.json')},ensure_ascii=False))

asyncio.run(main())
