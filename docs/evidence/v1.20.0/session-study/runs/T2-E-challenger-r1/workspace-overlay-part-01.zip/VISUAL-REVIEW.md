# Visual review — Meridian T2

Main designer personally opened the actual view_image results retained as evidence/view-001 through view-016. These are actual tool responses, not declared viewing.

## Viewed objects
Baseline light desktop (001), baseline compact dark attachments (002), baseline old-content reading (003); public assistant-ui named-chip demo (004) and independently authored AI Elements list demo (005); first named-chip trial (006); failed long-question scroll sequence (007/008); final 390 dark composer (009), 1280 dark composer (010), 1440 light (011), 1440 dark (012), 1280 light (013), 390 light (014), final mobile keyboard attachment focus (015), and mobile filename dialog entering (016).

## Perceptual findings
The supplied 44rem column, Inter typography, rounded input, restrained surfaces and stable header/sidebar remain coherent. Named chips group icon, filename, explicit filename-only metadata and removal without changing the source action hierarchy. The horizontal band clearly exposes another chip at its edge; full names remain intentionally truncated until disclosure. On both narrow themes the input and controls remain inside the viewport; mixed Chinese/English wraps naturally. Six compact desktop lines are fully visible after the152px cap correction. Long drafts retain internal scrolling.

The final focused mobile chip is fully visible with a clear focus ring (015), resolving the challenger's clipped-origin finding. The first dialog capture016 occurred during the source100ms entry fade; it supports entering-state geometry, not settled opacity. A separate250ms settled capture and edit check are recorded under evidence/settled and command016; its visual status is stated separately at close.

The source bottom/smooth combination visibly jumped from the submitted long question to answer theme4 (007/008). Native bottom/auto holds in repeated controlled tests and independent viewed frames. The main final episode logs verify manual pause, explicit return during growth, second pause, and Stop stability in both languages. No separate scroll controller was introduced.

## Boundaries
Controlled real-time browser operations and timestamped ordered captures were used. No natural-time video playback, screen-reader study, native phone keyboard, touch-device performance, other browser-engine test, or owner visual approval is claimed. Public reference quality, source adoption, automated assertions and final visual judgment retain separate scopes.

## Close
The settled dialog capture was acquired but not personally opened before the time bound. The associated edit/update probe failed to locate the upstream Edit control; editing remains unverified, not passed. All failures remain intact. Product work closed at 2026-11-01T11:52:55.436367+00:00.
