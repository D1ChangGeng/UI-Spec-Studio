// Product copy only. Locale is initialized by main.tsx before the first render.
export const copy = (en: string, zh: string) =>
  document.documentElement.lang.startsWith("zh") ? zh : en;
