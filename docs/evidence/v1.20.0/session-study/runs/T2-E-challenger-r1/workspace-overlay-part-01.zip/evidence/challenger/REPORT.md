# Independent challenge: composer, attachment identity and reading continuity

## Judgment

**Retain the assistant-ui family and bottom-following configuration provisionally, with the viewport's CSS scrolling changed to auto. Revise the claim that horizontal named chips already preserve complete keyboard-visible identity at 390px.** The long-question reading jump is real, but a controlled comparison supports a narrow source/runtime integration repair. It does not presently justify replacing the composer or adding a second pause/follow state machine.

This is independent research advice. It does not set formal SPEC scope, accept the final product, or authorize any original visual construction. No product files were changed by this inquiry.

## What the favored choice actually promises

The combined choice aims to keep filename identity recognizable without consuming a tall slice of the answer viewport; keep a bounded growing composer; let users leave a growing answer voluntarily; and resume following after an explicit Return to latest. A named chip alone does not establish full-name disclosure, a dialog alone does not establish focus visibility in its originating strip, and a supported bottom-anchor API alone does not establish reliable interruption.

I read TASK.md, INPUT.md, RUN-CONTROL.md, method/SKILL.md, all eight common method references, evidence-map and evidence-actions. Required text was read in bounded follow-ups where outputs truncated. The original public comparison corpus was supplied; I personally opened its assistant-ui chip and AI Elements list images, as well as the relevant baseline/trial and new probe images.

## Reading continuity: observed counterexample and discrimination

Conditions: Chromium headless shell 143, sandbox enabled under oai, FONTCONFIG_FILE set, CSS viewport 1280×600, dark/Chinese, real wheel input −1200, fixed synthetic streaming adapter. The main package was being edited concurrently; recorded timestamps distinguish historical runs. The second probe explicitly pins the tested CSS property per case so that the source class change cannot confound that comparison.

| Observation | Actual evidence | Consequence |
|---|---|---|
| Original long-message trial loses the reader's location | Personally viewed ../trial/06-scrolled-away.png and 07-scrolled-away-growth.png. The viewport changes from the long question to answer theme 4. trial_check.py uses a real wheel gesture. | This is a visible reading discontinuity, not merely a change in numeric scrollTop or a scripted assignment. |
| Independent first reproduction agrees | events.json, 11:39:46.850–49.179 UTC: top 422→1967; tracked paragraph Y146→−1399. | A repeatable failure under the long-message condition. |
| Short-question comparison holds | events.json: top71 and tracked paragraph Y137 remain fixed while total height2103→3278. | Evidence argues against a universally broken wheel-pause mechanism. |
| Controlled CSS smooth reproduces the failure | events2.json, 11:41:21.817–23.465 UTC: top417→2017; paragraph Y143→−1457; total2799→3974. | The smooth behavior remains a consequential causal candidate. |
| Controlled CSS auto holds twice | events2.json, 11:41:25.686–27.355 and 29.532–31.301 UTC: top847 stays847; total2799→3974. No content-visibility override. | Supports the parent's narrow scroll-auto repair while preserving native controller ownership. |

I personally viewed auto-away2.png and auto-after2.png: the same long-question portion remains visible in the same position while response growth completes. The generic paragraph selector did not select an anchor in these two auto cases, so their evidence is fixed scrollTop plus viewed corresponding frames, not a successful paragraph-Y measurement. Ordered captures and 150ms samples support the reported stability window; no natural-time playback judgment is claimed.

A separate first-probe content-visibility:visible override also held. That intervention changed more rendering conditions, and its anchor was absent. It remains a provisional diagnostic lead, not a reason to remove containment: the later auto-only comparison succeeds without that change.

Source inspection finds the controller sets programmatic scroll intent and uses behavior auto at run start; wheel cancellation clears its pending intent/frame, while CSS smooth governs CSSOM scrolling behavior. The hypothesis is that the CSS animation and controller state can become misaligned during rapid growth after a long submission. The controlled comparison supports that explanation but does not prove every browser-level causal step.

Official Thread documentation describes manual pause and explicit resume, whereas top mode deliberately anchors the current turn. Those published contracts motivate the configuration; only local operation supports its fit here. Sources: https://www.assistant-ui.com/docs/primitives/thread and https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/scroll-behavior . Exact fresh retrieval is web-primary.json. Local implementation inspected: app/node_modules/@assistant-ui/store/src/utils/thread-viewport-auto-scroll.ts and @assistant-ui/react/src/primitives/thread/useThreadViewportAutoScroll.ts.

## Mobile filename identity: stronger than anonymous tiles, with a real focus defect

At390×844 light/English I selected notes.txt plus three long filenames. mobile-attached.png shows one complete named chip and part of the next inside a shallow horizontal strip. This leaves substantially more reading space than four or five stacked metadata rows would require. Names are visible, but only a subset is simultaneously inspectable. The partial next chip is a cue to additional content; it does not expose a reliable total count.

Actual keyboard operations in probe.py: focus the composer; use Shift+Tab eight times through four remove/name pairs; Enter opens the selected filename dialog; Escape returns to the originating name button; Tab then Enter removes that file and returns focus to the composer. All four filename triggers were reached. No file content was read or transmitted.

probe2.py repeats traversal at a slower200ms cadence to the long accessibility filename. mobile-long-dialog.png shows its complete title wrapped over two lines within the viewport, with a visible close button and accurate metadata-only description. Escape restores the same accessible filename trigger.

**Counterevidence:** mobile-focus-return.png clips the beginning of notes.txt after focus return; mobile-long-return.png leaves most of the focused long-name trigger outside the visible strip. This occurs even with slower keyboard traversal. The modal is usable, but the originating object is not reliably visible enough to recognize on return. A source-preserving horizontal reveal of the focused attachment is a justified next repair; it still requires a fresh keyboard/return capture.

Compared public pixels:
- assistant-ui named-chip original demo: ../research/captures/w14-research-aui-chip.jpg. It groups type icon, filename, secondary metadata and remove in compact two-line chips; its short demo names do not test this project's long-name condition.
- Independently authored AI Elements list: ../research/captures/w14-research-ai-list.jpg. Five full-width rows make each file and remove action simultaneously legible, at a large vertical cost.
- Sources: https://www.assistant-ui.com/elements/composer-attachments and https://elements.ai-sdk.dev/components/attachments .

The supported conclusion is that named horizontal chips improve identity over the supplied anonymous tiles while preserving reading height. **Superiority to AI Elements list at390px has not been established by a matched local comparison.** The list has a genuine scanability advantage; the strip has a genuine height advantage. This product's compact-height requirement supports the strip trial, provided focused objects reveal correctly and full-name disclosure stays operable.

## Next action and limits

1. Keep the bottom/auto candidate and recheck explicit Return to latest during continued growth, then a second upward scroll. My first run clicked Return only after generation had finished, so it cannot certify resuming future growth.
2. After the parent's focused-attachment reveal repair, repeat slow Tab/Shift+Tab → long-name dialog → Escape at390px, and inspect the complete focused chip rather than only activeElement.
3. Keep native controller ownership unless a reproduced failure remains. Keyboard PageUp, touch, native mobile keyboard, zoom, screen-reader output, reduced motion and other browser engines were not independently exercised here.
4. The compact152px input correction was reported by the parent during this inquiry. These probes do not certify its six-line visual fit, Stop-buffer behavior, failure/retry or complete final matrix.

## Evidence retained

- probe.py, events.json, command-001/: exact first scripted operations, timestamps, arguments, stdout/stderr and outcome.
- probe2.py, events2.json, command-002/: controlled smooth/auto/auto-repeat comparison and long-name modal episode.
- web-primary.json: exact original source-retrieval tool object.
- view-*.json: exact original view_image arguments/responses for all images actually opened.
- Viewed originals: trial06/07, public assistant-ui chip, public AI Elements list.
- Viewed new captures: mobile-attached, mobile-dialog, mobile-focus-return, long-away, long-after, auto-away2, auto-after2, mobile-long-dialog, mobile-long-return.
- Other captured PNGs remain captured evidence only; their existence does not imply separate visual inspection.

