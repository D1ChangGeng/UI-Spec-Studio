import json,time,datetime
from pathlib import Path
from playwright.sync_api import sync_playwright
OUT=Path(__file__).parent
events=[]
def rec(page,name):
    data=page.evaluate('''() => {const v=document.querySelector('[data-slot="aui_thread-viewport"]');const a=window._anchor;return {top:v.scrollTop,total:v.scrollHeight,gap:v.scrollHeight-v.clientHeight-v.scrollTop,anchor:a?.textContent.slice(0,100),anchorY:a?.getBoundingClientRect().y,focus:document.activeElement?.getAttribute('aria-label'),running:!!document.querySelector('.aui-composer-cancel'),attachmentScroll:document.querySelector('.aui-composer-attachments')?.scrollLeft}}''')
    events.append(dict(name=name,time=time.monotonic(),at=datetime.datetime.now(datetime.timezone.utc).isoformat(),**data))
def shot(page,name):
    rec(page,name+'-capture-start');page.screenshot(path=str(OUT/(name+'.png')));rec(page,name+'-capture-end')
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,chromium_sandbox=True)
    page=b.new_page(viewport={'width':1280,'height':600})
    for case, question, visible in [('short','Compare findings.',False),('long',('Mixed-language question: 请比较可达性和长回答阅读。\n')*30,False),('long-visible',('Mixed-language question: 请比较可达性和长回答阅读。\n')*30,True)]:
        page.goto('http://127.0.0.1:4414/?theme=dark&lang=zh');page.evaluate('document.fonts.ready');page.wait_for_timeout(350)
        if visible: page.add_style_tag(content='[data-slot="aui_user-message-root"],[data-slot="aui_assistant-message-root"],.aui-user-message-root,.aui-assistant-message-root {content-visibility:visible!important} [style]{}')
        page.locator('.aui-composer-input').fill(question);page.locator('.aui-composer-send').click();page.wait_for_timeout(900)
        page.locator('[data-slot="aui_thread-viewport"]').hover();page.mouse.wheel(0,-1200);page.wait_for_timeout(180)
        page.evaluate('''() => {window._anchor=[...document.querySelectorAll('p,[data-slot="aui_user-message-content"]')].find(x=>{const r=x.getBoundingClientRect();return r.y>65&&r.y<430})}''')
        shot(page,case+'-away')
        for i in range(14): page.wait_for_timeout(150);rec(page,case+'-growth-'+str(i))
        shot(page,case+'-after')
        btn=page.locator('.aui-thread-scroll-to-bottom')
        if btn.count() and btn.is_visible() and btn.is_enabled():
            btn.click();page.wait_for_timeout(400);rec(page,case+'-return');page.wait_for_timeout(700);rec(page,case+'-return-growth')
    page.set_viewport_size({'width':390,'height':844});page.goto('http://127.0.0.1:4414/?theme=light&lang=en');page.evaluate('document.fonts.ready');page.wait_for_timeout(350)
    names=['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','accessibility-comparison-working-draft-with-reviewed-comments-2026.txt','research-synthesis-field-notes-second-round-long-filename.txt']
    with page.expect_file_chooser() as fc:page.locator('.aui-composer-add-attachment').click()
    fc.value.set_files([{'name':n,'mimeType':'text/plain','buffer':b'fixture'} for n in names]);page.wait_for_timeout(350);page.locator('.aui-composer-input').focus();shot(page,'mobile-attached')
    for i in range(8):page.keyboard.press('Shift+Tab');rec(page,'mobile-shift-tab-'+str(i))
    page.keyboard.press('Enter');page.wait_for_timeout(250);shot(page,'mobile-dialog');events.append({'dialog':page.locator('[role="dialog"]').all_text_contents()})
    page.keyboard.press('Escape');page.wait_for_timeout(150);rec(page,'mobile-dialog-escape');shot(page,'mobile-focus-return')
    page.keyboard.press('Tab');page.keyboard.press('Enter');page.wait_for_timeout(150);rec(page,'mobile-remove');events.append({'remaining':page.locator('.aui-composer-attachments').inner_text()})
    b.close()
(OUT/'events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2));print(json.dumps(events,ensure_ascii=False,indent=2))
