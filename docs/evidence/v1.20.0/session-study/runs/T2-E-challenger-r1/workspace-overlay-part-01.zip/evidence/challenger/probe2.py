import json,time,datetime,hashlib
from pathlib import Path
from playwright.sync_api import sync_playwright
OUT=Path(__file__).parent; events=[]
def rec(p,n):
 d=p.evaluate('''()=>{const v=document.querySelector('[data-slot="aui_thread-viewport"]');return{top:v.scrollTop,total:v.scrollHeight,gap:v.scrollHeight-v.clientHeight-v.scrollTop,anchorY:window.a?.getBoundingClientRect().y,behavior:getComputedStyle(v).scrollBehavior,running:!!document.querySelector('.aui-composer-cancel'),focus:document.activeElement?.getAttribute('aria-label')}}''');events.append(dict(name=n,at=datetime.datetime.now(datetime.timezone.utc).isoformat(),time=time.monotonic(),**d))
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,chromium_sandbox=True);p=b.new_page(viewport={'width':1280,'height':600})
 for case in ['smooth','auto','auto-repeat']:
  p.goto('http://127.0.0.1:4414/?theme=dark&lang=zh');p.evaluate('document.fonts.ready');p.wait_for_timeout(350)
  p.add_style_tag(content='[data-slot="aui_thread-viewport"]{scroll-behavior:'+('smooth' if case=='smooth' else 'auto')+'!important}')
  p.locator('.aui-composer-input').fill(('Mixed-language question: 请比较可达性和长回答阅读。\n')*30);p.locator('.aui-composer-send').click();p.wait_for_timeout(900);p.locator('[data-slot="aui_thread-viewport"]').hover();p.mouse.wheel(0,-1200);p.wait_for_timeout(180)
  p.evaluate('''()=>{window.a=[...document.querySelectorAll('p,.aui-user-message-content')].find(x=>{let r=x.getBoundingClientRect();return r.y>65&&r.y<430})}''');rec(p,case+'-away');p.screenshot(path=str(OUT/(case+'-away2.png')))
  for i in range(10):p.wait_for_timeout(150);rec(p,case+'-'+str(i))
  p.screenshot(path=str(OUT/(case+'-after2.png')))
 p.set_viewport_size({'width':390,'height':844});p.goto('http://127.0.0.1:4414/?theme=light&lang=en');p.wait_for_timeout(350)
 names=['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','accessibility-comparison-working-draft-with-reviewed-comments-2026.txt','research-synthesis-field-notes-second-round-long-filename.txt']
 with p.expect_file_chooser() as fc:p.locator('.aui-composer-add-attachment').click()
 fc.value.set_files([{'name':n,'mimeType':'text/plain','buffer':b'fixture'}for n in names]);p.locator('.aui-composer-input').focus()
 for i in range(4):p.keyboard.press('Shift+Tab');p.wait_for_timeout(200)
 rec(p,'mobile-long-trigger');p.screenshot(path=str(OUT/'mobile-long-trigger.png'));p.keyboard.press('Enter');p.wait_for_timeout(250);p.screenshot(path=str(OUT/'mobile-long-dialog.png'));events.append({'dialog':p.locator('[role="dialog"]').all_text_contents()});p.keyboard.press('Escape');p.wait_for_timeout(200);rec(p,'mobile-long-return');p.screenshot(path=str(OUT/'mobile-long-return.png'))
 b.close()
(OUT/'events2.json').write_text(json.dumps(events,ensure_ascii=False,indent=2));print(json.dumps(events,ensure_ascii=False,indent=2))
