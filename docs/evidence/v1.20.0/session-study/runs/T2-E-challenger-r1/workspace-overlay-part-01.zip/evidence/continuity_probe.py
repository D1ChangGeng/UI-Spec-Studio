import json,time,datetime,sys
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w14')
out=root/'evidence'/sys.argv[1];out.mkdir(exist_ok=True)
events=[]
def record(page,name):
    result=page.evaluate("""() => {const v=document.querySelector('[data-slot="aui_thread-viewport"]');return {top:v.scrollTop,height:v.clientHeight,total:v.scrollHeight,gap:v.scrollHeight-v.clientHeight-v.scrollTop,focus:document.activeElement?.getAttribute('aria-label'),running:!!document.querySelector('.aui-composer-cancel'),chars:[...document.querySelectorAll('[data-slot="aui_assistant-message-content"]')].at(-1)?.textContent.length}}""")
    events.append({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'name':name,**result})
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,chromium_sandbox=True)
    page=b.new_page(viewport={'width':1280,'height':600})
    page.goto('http://127.0.0.1:4414/?theme=light&lang=en');page.evaluate('document.fonts.ready')
    page.locator('.aui-composer-input').fill('Investigate reading continuity.')
    page.locator('.aui-composer-send').click()
    page.wait_for_timeout(900);record(page,'before-return')
    page.locator('.aui-thread-scroll-to-bottom').click()
    page.wait_for_timeout(250);record(page,'after-return')
    page.screenshot(path=str(out/'01-after-return.png'))
    page.wait_for_timeout(700);record(page,'after-return-growth')
    page.screenshot(path=str(out/'02-after-return-growth.png'))
    page.locator('[data-slot="aui_thread-viewport"]').hover();page.mouse.wheel(0,-700);page.wait_for_timeout(200);record(page,'manual-away')
    page.wait_for_timeout(600);record(page,'manual-away-growth')
    page.screenshot(path=str(out/'03-manual-away-growth.png'))
    page.locator('.aui-composer-cancel').click();page.wait_for_timeout(120);record(page,'cancel')
    page.wait_for_timeout(500);record(page,'cancel-wait')
    page.screenshot(path=str(out/'04-stopped.png'))
    b.close()
(out/'events.json').write_text(json.dumps(events,indent=2))
print(json.dumps(events,indent=2))

