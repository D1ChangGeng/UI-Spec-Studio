import json, datetime, time, hashlib, traceback
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w14')
OUT=ROOT/'evidence/final2'
OUT.mkdir(exist_ok=True)
events=[]; failures=[]
def log(kind,**data):
    events.append(dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),monotonic=time.monotonic(),kind=kind,**data))
    (OUT/'events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2))
def check(value,name,**data):
    log('assertion',name=name,passed=bool(value),**data)
    if not value: failures.append(name)
def shot(page,name):
    log('capture-start',name=name)
    page.screenshot(path=str(OUT/(name+'.png')))
    log('capture-end',name=name)
def state(page):
    return page.evaluate("""() => {
      const v=document.querySelector('[data-slot="aui_thread-viewport"]');
      const c=document.querySelector('[data-slot="aui_composer-shell"]');
      const t=document.querySelector('.aui-composer-input');
      const m=[...document.querySelectorAll('[data-slot="aui_assistant-message-content"]')].at(-1);
      return {top:v.scrollTop,height:v.clientHeight,total:v.scrollHeight,gap:v.scrollHeight-v.clientHeight-v.scrollTop,
        composer:c.getBoundingClientRect().toJSON(),inputHeight:t.clientHeight,inputScroll:t.scrollHeight,
        focus:document.activeElement?.getAttribute('aria-label'),chars:m?.textContent.length,
        running:!!document.querySelector('.aui-composer-cancel'),overflow:document.documentElement.scrollWidth>innerWidth};
    }""")
names=['notes.txt','城市出行访谈摘要_2026-10-31_final-revised-notes.txt','accessibility-comparison-working-draft-with-reviewed-comments-2026.txt','research-synthesis-field-notes-second-round-long-filename.txt']
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,chromium_sandbox=True)
    context=b.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
    page=context.new_page()
    page.on('pageerror',lambda e: log('pageerror',error=str(e)))
    def navigate(theme,lang,width=1280,height=600):
        page.set_viewport_size({'width':width,'height':height})
        page.goto(f'http://127.0.0.1:4414/?theme={theme}&lang={lang}')
        page.evaluate('document.fonts.ready')
        page.wait_for_timeout(180)
    try:
        for theme,lang in [('light','en'),('dark','zh')]:
                tag=f'{width}x{height}-{theme}-{lang}'
                navigate(theme,lang,width,height)
                shot(page,tag+'-initial')
                check(not state(page)['overflow'],tag+' initial no horizontal page overflow')
                inp=page.locator('.aui-composer-input')
                inp.fill('One line.')
                check(state(page)['inputHeight']==40,tag+' one line size')
                inp.fill('\n'.join(['请比较观察与解释。Keep observation distinct.']*6))
                with page.expect_file_chooser() as chooser:
                    page.locator('.aui-composer-add-attachment').click()
                chooser.value.set_files([{'name':n,'mimeType':'text/plain','buffer':b'contents must not be read'} for n in names])
                page.wait_for_timeout(180)
                s=state(page);log('geometry',name=tag+' six lines attachments',state=s)
                check(s['composer']['bottom']<=height and not s['overflow'],tag+' composer reachable')
                check(page.locator('.aui-composer-attachments .aui-attachment-root').count()==4,tag+' four filenames')
                shot(page,tag+'-composer')
                prefix='View filename ' if lang=='en' else '查看文件名 '
                trigger=page.get_by_role('button',name=prefix+names[1],exact=True)
                before=state(page)['top']
                trigger.click()
                check(page.get_by_role('dialog').is_visible(),tag+' full filename dialog')
                check(page.get_by_role('dialog').inner_text().find(names[1])>=0,tag+' full filename present')
                if width==390 or (width==1280 and lang=='zh'):
                    shot(page,tag+'-filename-dialog')
                page.keyboard.press('Escape');page.wait_for_timeout(120)
                check(page.evaluate('document.activeElement?.getAttribute("aria-label")')==prefix+names[1],tag+' dialog focus return')
                check(abs(state(page)['top']-before)<=2,tag+' dialog reading position')
                if width==390:
                    inp.focus()
                    focused=[]
                    for _ in range(8):
                        page.keyboard.press('Shift+Tab');page.wait_for_timeout(40)
                        focus=page.evaluate("""() => {const e=document.activeElement;const chip=e.closest('.aui-attachment-root');const band=e.closest('.aui-composer-attachments');if(!chip||!band)return null;const a=chip.getBoundingClientRect(),r=band.getBoundingClientRect();return {name:e.getAttribute('aria-label')||e.textContent,visible:a.left>=r.left-1&&a.right<=r.right+1};}""")
                        if focus:focused.append(focus)
                    check(bool(focused) and all(x['visible'] for x in focused),tag+' complete focused chips',focuses=focused)
                    shot(page,tag+'-keyboard-attachments')
                remove='Remove '+names[0] if lang=='en' else '移除 '+names[0]
                page.get_by_role('button',name=remove,exact=True).click();page.wait_for_timeout(100)
                check(state(page)['focus']==('Message input' if lang=='en' else '消息输入'),tag+' remove focus')
                inp.fill(('Long mixed language question. 请比较阅读连续性。\n')*30)
                inp.press('Control+End')
                s=state(page)
                check(s['inputScroll']>s['inputHeight'],tag+' long input scrollable')
                check(s['composer']['bottom']<=height and not s['overflow'],tag+' long input keeps actions')
        for theme,lang in [('light','en'),('dark','zh')]:
            tag='episode-'+theme+'-'+lang
            navigate(theme,lang)
            inp=page.locator('.aui-composer-input')
            inp.fill('Line one');inp.press('Shift+Enter');inp.type('Line two')
            check(inp.input_value()=='Line one\nLine two',tag+' Shift Enter newline')
            inp.fill(('Long question about reading continuity. 长问题保留阅读位置。\n')*30)
            page.locator('.aui-composer-send').click()
            page.wait_for_timeout(250);log('episode-state',name=tag+' initial-follow',state=state(page))
            page.mouse.move(700,150);page.mouse.wheel(0,-1000)
            page.wait_for_timeout(160)
            a=state(page);shot(page,tag+'-away')
            page.wait_for_timeout(250)
            z=state(page);log('episode-state',name=tag+' away-growth',state=z)
            check(abs(a['top']-z['top'])<=2 and z['total']>a['total'],tag+' manual hold through growth',before=a,after=z)
            shot(page,tag+'-away-growth')
            page.locator('.aui-thread-scroll-to-bottom').click()
            page.wait_for_timeout(160);a=state(page)
            page.wait_for_timeout(180);z=state(page)
            check(z['gap']<80 and z['top']>a['top'],tag+' return follows future growth',before=a,after=z)
            shot(page,tag+'-returned')
            page.mouse.move(700,150);page.mouse.wheel(0,-500);page.wait_for_timeout(120)
            a=state(page);page.wait_for_timeout(200);z=state(page)
            check(abs(a['top']-z['top'])<=2,tag+' second upward scroll holds',before=a,after=z)
            if page.locator('.aui-composer-cancel').count()==0:
                inp.fill('Check cancellation.');inp.press('Enter');page.wait_for_timeout(160)
            page.locator('.aui-composer-cancel').click();page.wait_for_timeout(130)
            a=state(page);page.wait_for_timeout(550);z=state(page)
            check(not z['running'] and a['chars']==z['chars'],tag+' stop stable after acknowledgment',before=a,after=z)
            check(z['focus']==('Message input' if lang=='en' else '消息输入'),tag+' stop focus')
            shot(page,tag+'-stopped')
            navigate(theme,lang)
            inp=page.locator('.aui-composer-input')
            inp.fill('[fail] recovery-'+lang)
            inp.press('Enter')
            page.locator('.aui-message-error-root').wait_for(state='visible',timeout=5000)
            check(page.locator('.aui-message-error-root').is_visible(),tag+' failure visible')
            shot(page,tag+'-failure')
            retry='Retry response' if lang=='en' else '重试回答'
            page.get_by_role('button',name=retry,exact=True).click()
            page.locator('.aui-composer-cancel').wait_for(state='hidden',timeout=16000)
            page.wait_for_timeout(200)
            content=page.locator('[data-slot="aui_assistant-message-content"]').last.inner_text()
            heading='Observation theme 7' if lang=='en' else '观察主题 7'
            check(heading in content and page.locator('.aui-message-error-root').count()==0,tag+' retry full seven-theme answer')
            shot(page,tag+'-retry-complete')
            count=page.locator('[data-slot="aui_user-message-root"]').count()
            inp.fill('Continue the same thread.');inp.press('Enter');page.wait_for_timeout(180)
            check(page.locator('[data-slot="aui_user-message-root"]').count()==count+1,tag+' repeat question')
            inp.press('Escape');page.wait_for_timeout(120)
            check(not state(page)['running'],tag+' Escape stop')
        page.emulate_media(reduced_motion='reduce')
        navigate('dark','zh')
        check(page.locator('[data-slot="aui_thread-viewport"]').evaluate("e=>getComputedStyle(e).scrollBehavior")=='auto','reduced motion viewport')
        shot(page,'reduced-motion-dark-zh')
    except Exception as exc:
        log('exception',error=str(exc),trace=traceback.format_exc());failures.append('uncaught test exception')
    finally:
        log('summary',failures=failures,assertions=sum(e['kind']=='assertion' for e in events))
        context.close();b.close()
sources={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'app/src').rglob('*') if p.is_file()}
(OUT/'source-digests.json').write_text(json.dumps(sources,indent=2))
print(json.dumps({'failures':failures,'assertions':sum(e['kind']=='assertion' for e in events),'events':str(OUT/'events.json')},indent=2))
raise SystemExit(bool(failures))

