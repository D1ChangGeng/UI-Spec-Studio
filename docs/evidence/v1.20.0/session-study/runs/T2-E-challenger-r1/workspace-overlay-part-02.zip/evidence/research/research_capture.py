import asyncio, json, os, time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path("/workspace/scratch/708e8b7f118e/ui-study/worksets/w14/evidence/research")
CHROME="/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell"
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path=CHROME,headless=True,chromium_sandbox=True)
  context=await browser.new_context(viewport={"width":1440,"height":900},device_scale_factor=1)
  page=await context.new_page()
  targets=[
   ("baseline","http://127.0.0.1:4414/?theme=light&lang=en"),
   ("assistant-attachments","https://www.assistant-ui.com/elements/composer-attachments"),
   ("ai-elements-attachments","https://elements.ai-sdk.dev/components/attachments"),
   ("prompt-kit-input","https://prompt-kit.com/docs/prompt-input"),
   ("prompt-kit-chat","https://prompt-kit.com/docs/chat-container")
  ]
  log=[]
  for name,url in targets:
   item={"name":name,"url":url,"started":time.time()}
   try:
    response=await page.goto(url,wait_until="domcontentloaded",timeout=45000)
    await page.wait_for_timeout(1500)
    await page.screenshot(path=str(ROOT/"captures"/(name+"-initial.png")))
    body=await page.locator("body").inner_text()
    (ROOT/"sources"/(name+"-dom.txt")).write_text(body)
    item.update({"status":response.status if response else None,"actual_url":page.url,"body_excerpt":body[:1200],"inputs":await page.locator("textarea,input").evaluate_all("(els)=>els.map(e=>({tag:e.tagName,type:e.type,placeholder:e.getAttribute('placeholder')}))"),"buttons":await page.get_by_role("button").all_text_contents()})
   except Exception as e:item["error"]=repr(e)
   item["ended"]=time.time();log.append(item);print(json.dumps(item,ensure_ascii=False),flush=True)
  (ROOT/"sources"/"initial-observations.json").write_text(json.dumps(log,ensure_ascii=False,indent=2))
  await context.close();await browser.close()
asyncio.run(main())

