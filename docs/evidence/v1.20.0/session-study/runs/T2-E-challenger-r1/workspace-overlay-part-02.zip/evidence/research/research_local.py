import asyncio,json,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path("/workspace/scratch/708e8b7f118e/ui-study/worksets/w14/evidence/research")
CHROME="/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell"
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path=CHROME,headless=True,chromium_sandbox=True)
  page=await browser.new_page(viewport={"width":1280,"height":600},device_scale_factor=1)
  await page.goto("http://127.0.0.1:4414/?theme=dark&lang=zh",wait_until="networkidle")
  await page.locator(".aui-composer-input").fill("\n".join(["请比较城市交通访谈里的证据和解释。Keep observations separate from interpretation."]*6))
  async with page.expect_file_chooser() as fc:
   await page.get_by_role("button",name="Add Attachment",exact=True).click()
  chooser=await fc.value
  names=["notes.txt","城市出行访谈摘要_2026-10-31_final-revised-notes.txt","regional_mobility_study_supporting-observations-long-filename.txt","follow-up_questions_and_evidence_notes_2026-10-31.txt"]
  await chooser.set_files([{"name":n,"mimeType":"text/plain","buffer":b""} for n in names])
  await page.wait_for_timeout(600)
  await page.screenshot(path=str(ROOT/"captures"/"baseline-compact-attachments.png"))
  print(json.dumps({"timestamp":time.time(),"url":page.url,"viewport":{"width":1280,"height":600},"textarea":await page.locator(".aui-composer-input").bounding_box(),"composer":await page.locator(".aui-composer-root").bounding_box(),"tiles":await page.locator(".aui-attachment-tile").evaluate_all("(els)=>els.map(e=>({name:e.getAttribute('aria-label'),rect:e.getBoundingClientRect().toJSON(),text:e.innerText}))")},ensure_ascii=False),flush=True)
  await page.locator(".aui-attachment-tile").nth(1).focus()
  await page.wait_for_timeout(700)
  await page.screenshot(path=str(ROOT/"captures"/"baseline-compact-filename-focus.png"))
  print(json.dumps({"timestamp":time.time(),"focused_attachment":await page.locator(".aui-attachment-tile").nth(1).get_attribute("aria-label"),"visible_tooltips":await page.get_by_role("tooltip").all_text_contents()},ensure_ascii=False),flush=True)
  await browser.close()
asyncio.run(main())

