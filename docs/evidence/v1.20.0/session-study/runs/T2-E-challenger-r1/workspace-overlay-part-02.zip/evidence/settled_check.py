from pathlib import Path
import json
from playwright.sync_api import sync_playwright
out=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w14/evidence/settled')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,chromium_sandbox=True)
 page=b.new_page(viewport={'width':390,'height':844})
 page.goto('http://127.0.0.1:4414/?theme=dark&lang=zh');page.evaluate('document.fonts.ready')
 with page.expect_file_chooser() as fc:page.locator('.aui-composer-add-attachment').click()
 fc.value.set_files([{'name':'城市出行访谈摘要_2026-10-31_final-revised-notes.txt','mimeType':'text/plain','buffer':b''}])
 page.locator('.aui-composer-attachments [data-slot="dialog-trigger"]').click();page.wait_for_timeout(250)
 page.screenshot(path=str(out/'dialog.png'))
 page.keyboard.press('Escape');page.wait_for_timeout(150)
 page.locator('.aui-composer-input').fill('Edit check');page.locator('.aui-composer-send').click();page.wait_for_timeout(120)
 page.locator('.aui-composer-cancel').click();page.wait_for_timeout(120)
 page.locator('.aui-user-action-edit').last.click();page.locator('.aui-edit-composer-input').fill('Edited check')
 page.get_by_role('button',name='Update',exact=True).click();page.wait_for_timeout(150)
 assert 'Edited check' in page.locator('.aui-user-message-content').last.inner_text()
 page.locator('.aui-composer-cancel').click();print(json.dumps({'edit_update':True,'dialog_settle_wait_ms':250}))
 b.close()
