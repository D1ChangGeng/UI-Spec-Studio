# Source adoption and maintenance

The source family is https://github.com/assistant-ui/assistant-ui at ff654d8156680b839774296ef644b57ab1078425, MIT. Original paths/digests and font rights remain in SOURCE-MANIFEST.json, FONT-SOURCES.json and app/LICENSE. Lockfile is unchanged.

| Responsibility | Adopted implementation | Change and retained craft |
|---|---|---|
| Whole workspace, sidebar, header, message typography | Complete supplied cloud template | Retained composition, tokens, fonts, surfaces, reading width and mobile shell |
| Composer growth/actions | thread.aui.tsx with ComposerPrimitive | Retained 1-row start, automatic growth, 192px cap, source action row; task labels localized |
| Attachment identity | Existing file.tsx File.Root/Icon/Name | Composed into metadata attachment, size sm/max-width configuration; existing border, spacing, typography and icon family retained |
| Full filename | Existing ui/dialog.tsx | Composed title, file family, accurate description; source focus trap, Escape and trigger restoration retained; close label localized |
| Follow/hold/return | ThreadPrimitive.Viewport and ScrollToBottom | Native bottom mode/autoScroll, immediate scrolling; same owner, no duplicate listener/engine |
| Stop/completion display | Existing MarkdownTextPrimitive | Supported smooth option follows running state; existing markdown typography and defer retained |
| Disappearing controls | return-to-composer.ts | Project-owned behavior repair only: restore composer focus without moving reading position |

Three source files changed in the initial composition; the final configuration additionally changes markdown-text.tsx. The final integrity report is authoritative for current hashes. New utility contains no visual design. Exact diffs and rejected attempts are retained. Future source upgrades should recheck long filenames, dialog focus, manual scroll with footer growth, immediate return, abort/retry and text-reveal settlement together.

Independent references are not adopted code: AI Elements attachments demo (visual comparison; exact revision/license not traced), pinned Vercel chatbot (Apache-2.0 source comparison), and ChatGPT entry-page episode (reference-only, no implementation rights claimed). See CHILD-01-REPORT.md and original evidence. No original-construction exception was used.
