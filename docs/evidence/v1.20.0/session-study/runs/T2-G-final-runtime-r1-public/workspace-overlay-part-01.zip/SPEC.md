# SPEC T2 — Composer and reading continuity

## Current result
A working local conversation increment, implemented and inspected, with owner acceptance pending. The complete supplied assistant-ui family remains the foundation. Named attachments, full filename disclosure, source-native following/scroll-away/return, cancellation, retry, editing and keyboard focus are integrated. Synthetic content, metadata-only attachment boundary, failure injection and runtime ownership remain intact.

## Complete goal and cohesive scope
A researcher asks, checks attached filenames, reads an unfolding answer, revisits earlier passages, returns to latest, and continues. One SPEC owns composer growth, attachment disclosure, response growth and reading position because they share viewport space, footer inset, input, focus and runtime. The sidebar/header and message type system are inherited neighbors checked in the assembled UI. Research can inspect whole products without importing their unrelated features.

L0 is reading control and trustworthy local boundaries. L1 is draft → attach → send → read/scroll-away → return → stop/retry/edit/continue. L2 is the inherited workspace and thread scroll region. L3 is the source composer/file/dialog family and runtime controls. L4 preserves 44rem reading measure, Inter/Noto glyphs, 1rem composer radius, subtle material, icon family and action hierarchy. L5 connects pinned source, actual adopted components, configuration and recorded browser outcomes.

## D1 — Preserve the mature workspace; select its native following variant
Source: assistant-ui revision ff654d8156680b839774296ef644b57ab1078425 (MIT), plus frozen @assistant-ui/react 0.15.32 and @assistant-ui/react-markdown 0.14.24. Baseline actual screenshots and command 003 establish local appearance and manual scroll hold. The supplied top-anchor mode preserves the beginning of a turn but explicit return moved only once: command 006 recorded a constant scrollTop 1335 while bottom gap grew 374→1290px. A bounded release-anchor trial did not repair it (007), so it was rejected and retained under evidence/research.

Current choice: configure ThreadPrimitive.Viewport with its supported `turnAnchor="bottom"`, `autoScroll`, and `scroll-auto`. Bottom mode with inherited CSS smooth scrolling also lagged while content arrived (008); immediate native scrolling removes continuous retargeting (009). The native controller still owns follow state, manual interruption, footer insets and return. No additional scroll engine or forced-scroll loop was added. Tradeoff: new turns follow their latest text instead of pinning the question at the top. A reader scrolling away pauses following; explicit return resumes it.

Independent pinned Vercel chatbot source uses at-bottom/user-scrolling state to govern following, supporting this behavior model. It was read as a comparison, not imported. Actual current-product checks (010, 012, 013) show fixed reading scrollTop while content grows, and gap 0 while actively following after return.

## D2 — Compose named-file disclosure from the existing mature family
Baseline 56px anonymous tiles made multiple filename-only attachments visually indistinguishable. Actual AI Elements original demo views show compact named inline badges versus larger metadata rows; the list costs about 74px per file. Vercel's separately pinned complete chatbot uses 96px image tiles and a generic “File” label for non-images, which is a poorer fit here.

Adopt the supplied `File.Root/Icon/Name` family in `attachment.aui.tsx`, size `sm`, intrinsic width capped at 16rem. Keep the existing horizontal composer strip, independent source Remove/Button, and existing Dialog for full names. Sent attachments wrap within message width. This preserves the source file family's border/type/icon/spacing and the dialog's material/focus/dismissal; no copied screenshot is reconstructed. Exact full name and filename-only privacy boundary are available by keyboard, pointer and touch activation. No download or file-content preview is implied.

The six-line/three-file composer at 1280×600 measures 256px versus baseline 270px. The 152px six-line textarea and existing 192px maximum remain; no invented input design or extra control family is introduced. Long mixed-language drafts scroll internally while actions remain reachable. Horizontal overflow remains local to the attachment strip.

## D3 — Preserve state, focus and truthful stopping
Use the source actions and runtime. A new `return-to-composer.ts` schedules focus with `preventScroll` after removal or Stop removes its own trigger; it does not implement either action. Actual keyboard testing found body focus after removal before this repair. Dialog Escape already restored its trigger.

The source MarkdownTextPrimitive supports `smooth`. Configure it only while the message is running so a stopped/completed answer no longer continues revealing buffered text. Keep `defer` to preserve source rendering prioritization. The synthetic adapter is unchanged, including its 72-character/60ms chunks, abort checks, seven themes and first-attempt [fail] behavior.

Localize task controls in Chinese: message input, attachment add/view/remove, dialog title/description/close, send, stop, return, retry, copy, editing and branch navigation. Existing surrounding header/sidebar labels remain English as permitted in INPUT.md. User filenames and authored text remain exact.

## Research and implementation distinction
- Assistant-ui supplied original source: adopted and adapted; SOURCE-MANIFEST.json remains original provenance, with final changes in evidence/source-integrity-final.json.
- AI Elements original attachments demo: actually rendered and personally viewed as a comparison; no exact revision/license acquisition and no code adoption.
- Vercel chatbot c2f8235e1f3ea903ad8b7f61447c4f74164b5c58, Apache-2.0: source inspected, not adopted; live deployment unavailable.
- ChatGPT signed-out 1280×900 entry: actual empty/six-line/one-line episode viewed. Reference only, no reusable implementation and no external streaming observation.
- Claude: login blocked conversation viewing. Documented task reference only.

CHILD-01-REPORT.md preserves exact sources, meaningful alternatives and access limits. The primary designer personally opened pivotal independent images (view-008 through view-012) and all final assembled views. No original-construction exception is invoked.

## Verification boundary and evidence
Required primary views: 1440×900, 1280×600, supplementary 390×844, light/en and dark/zh. All six delivered views have no document-level horizontal overflow. Actual filenames, six lines, long mixed text, modal keyboard return, removal, streaming scroll-away, input growth while away, return during active growth, stop, fail/retry, repeat and edit/update were exercised. Detailed results remain in final-checks.json, recheck-final.json and cancel-boundary.json, with exact commands 001–018 and screenshots. The failed checks and rejected trials are retained; a successful build is not substituted for them.

Command 010 found real focus/reveal gaps and a test action that omitted source hover disclosure for Edit. Those were repaired or exercised correctly in 012/013. A late Chinese cancellation assertion in 013 incorrectly required theme 7 to be absent, even though the partial response was already in that section; its equal 2035-character samples are retained. Dedicated early cancellation in 016 establishes the actual contract in both languages: 211 characters remain unchanged across 700ms and input focus returns. Do not count failed historical runs as blanket passes.

Build 014 succeeds with the original large-chunk warning. No new dependency was added. Actual review is static views plus ordered timestamped samples and controlled UI episodes; natural-speed playback, physical mobile keyboard, assistive-technology usage and other browser engines remain unverified. There is no claim of user acceptance or real model/upload/persistent history support.

Final production verification: command 018 exercises failure/retry on the actual rebuilt dist, with all seven sections and the final bullet present in both languages; production-retry.json records 6889/2070 rendered characters and no page errors. Viewed production evidence 037–038 closes the final-text claim after the smooth option change. The temporary production server and the original dev server were stopped.
