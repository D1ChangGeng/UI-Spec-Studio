# SPEC T2 — Composer and reading continuity

## Overall goal and current product
Meridian is a working local conversation product with deterministic synthetic responses. The complete supplied assistant-ui cloud-template visual implementation remains its foundation. No real model, upload or persistent remote history is in scope. Source revision ff654d8156680b839774296ef644b57ab1078425, MIT; exact copied files remain recorded in SOURCE-MANIFEST.json.

## Cohesive increment
Keep composer growth, attachment identity/disclosure, send/cancel/retry, streamed reading, manual scroll and return together. They share the same viewport space, footer inset, input and runtime. The primary design scope is these connected regions. The sidebar/header/message typography are retained and checked as adjacent composition. Research studies whole conversation examples; it does not add their unrelated capabilities to this product.

## Experience model and evidence questions
A researcher asks, checks attached filenames, reads an unfolding answer, revisits earlier material, and returns to the current answer before continuing. L0 is reading control; L1 is draft → attachment → send → read/scroll-away → return → stop/retry/continue. L2 is the inherited workspace and single thread scroll region. L3 comprises source composer, file family, attachment/runtime and scroll affordance. L4 preserves the source's 44rem reading width, Inter/Noto fallback, 1rem composer radius, subdued fill, border/focus and small icon actions. L5 is source adoption, local adapter and actual viewport/episode evidence.

Questions: Can files be distinguished without hover? Can a full long filename be inspected by pointer and keyboard? How much reading space remains under six lines and multiple files at 1280×600? Does manual scroll stay stable during incoming text and composer growth? Does return-to-latest resume following? Do stopping, error/retry, editing and repeat questions retain a usable input?

## Initial observations and decision units
### D1 — Keep mature composer and scroll family
Actual baseline captures in evidence/screenshots/baseline and command 003. The 1440×900 light view gives a calm reading measure, clear user/assistant distinction and persistent bottom composer. At 1280×600, six input lines plus three file tiles use 270px, leaving approximately 242px between header and composer. Manual wheel scroll to top stays at scrollTop 0 while document height grows from 1707 to 2429 (English) and 2659 to 3486 (Chinese), sampled over 1.4 seconds. This is controlled sampling, not smoothness proof. Retain ThreadPrimitive and runtime ownership.

### D2 — Make attachment identity persistent using the supplied File family
Baseline attachment strip shows three identical document tiles. Full filenames are in tooltip/accessibility text but not persistently visible. Local trial will compose the supplied File.Root/Icon/Name visual family with AttachmentPrimitive and the supplied Dialog for full filename disclosure. This is source-supported composition: preserve existing type, spacing, border, icon and dialog family. Removal stays a separate source button. Keep the horizontal strip bounded so file count does not grow the footer without limit. Exact filename and filename-only boundary must remain available in a dialog via pointer/keyboard/touch.

Independent inquiry is comparing Vercel chatbot/AI Elements and a mature product reference. It can challenge this choice; no external candidate is adopted merely because it was researched. No original-construction exception is invoked.

### D3 — Bound input growth and focus continuity
Baseline source already uses automatic sizing and max-h-48. Current web guidance capture 002 endorses width stability and bounded height but warns new CSS features need fallbacks. Retain assistant-ui's existing resize mechanism and test its current result before any change. If compact height loses too much reading space, adapt max height responsively within this existing family. Focus after disappearing stop or attachment removal should return to usable composer/neighbor without forced scroll.

## Review conditions
1440×900, 1280×600, supplementary 390×844, light/en and dark/zh. One line, six lines, long mixed text, short and multiple long filenames. Exercise cancel, fail/retry, manual scroll during growth, return, focus, repeated question and editing. Keep actual snapshots plus timed state logs. Open final PNGs personally; distinguish static inspection, ordered samples and natural-time viewing.

## Current evidence and pending responsibilities
Baseline viewed frames: view-001 through view-004. An independent child supplies research only, recorded in DELEGATION.json. Upcoming: named-file local trial, actual original candidate source/demo comparison, full interaction checks and final captures. Owner approval is not implied by presentation or test results.
