from playwright.sync_api import sync_playwright
from pathlib import Path
import json,time,os
OUT=Path('evidence/screenshots/baseline'); OUT.mkdir(parents=True,exist_ok=True)
logs=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'],env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
 page.on('pageerror',lambda e:logs.append({'pageerror':str(e)}))
 for theme,lang in [('light','en'),('dark','zh')]:
  page.goto(f'http://127.0.0.1:4408/?theme={theme}&lang={lang}')
  page.locator('textarea').first.wait_for(); page.evaluate('document.fonts.ready');page.wait_for_timeout(400)
  for w,h in [(1440,900),(1280,600),(390,844)]:
   page.set_viewport_size({'width':w,'height':h});page.wait_for_timeout(200)
   page.screenshot(path=str(OUT/f'{theme}-{lang}-{w}x{h}.png'))
  page.set_viewport_size({'width':1280,'height':600})
  q='Line one: Compare the evidence.\n第二行：保持阅读位置。\nLine three: Identify uncertainty.\n第四行：观察输入增长。\nLine five: Read previous passages.\n第六行：继续讨论。'
  page.locator('textarea').first.fill(q);page.wait_for_timeout(300)
  with page.expect_file_chooser() as fc:page.get_by_role('button',name='Add Attachment',exact=True).click()
  fc.value.set_files([{'name':'notes.txt','mimeType':'text/plain','buffer':b''},{'name':'城市出行访谈摘要_2026-10-31_final-revised-notes.txt','mimeType':'text/plain','buffer':b''},{'name':'interview-accessibility-reading-continuity-2026-long-notes-final.txt','mimeType':'text/plain','buffer':b''}])
  page.wait_for_timeout(400)
  page.screenshot(path=str(OUT/f'{theme}-{lang}-expanded-attachments.png'))
  logs.append({'condition':theme+'-'+lang,'textarea':page.locator('textarea').first.bounding_box(),'composer':page.locator('[data-slot="aui_composer-shell"]').bounding_box(),'tiles':page.locator('.aui-attachment-tile').count(),'text':page.locator('.aui-composer-attachments').inner_text()})
  page.get_by_role('button',name='Send message',exact=True).click();page.wait_for_timeout(1000)
  page.screenshot(path=str(OUT/f'{theme}-{lang}-stream-start.png'))
  vp=page.locator('[data-slot="aui_thread-viewport"]')
  vp.hover();page.mouse.wheel(0,-900);page.wait_for_timeout(300)
  old=vp.evaluate('(e)=>({top:e.scrollTop,height:e.scrollHeight,client:e.clientHeight})');page.screenshot(path=str(OUT/f'{theme}-{lang}-scroll-away.png'))
  page.wait_for_timeout(1400);new=vp.evaluate('(e)=>({top:e.scrollTop,height:e.scrollHeight,client:e.clientHeight})')
  page.screenshot(path=str(OUT/f'{theme}-{lang}-scroll-away-later.png'))
  logs.append({'condition':theme+'-'+lang,'scroll_away_before':old,'scroll_away_after':new})
  if page.get_by_role('button',name='Stop generating',exact=True).count():page.get_by_role('button',name='Stop generating',exact=True).click()
  page.wait_for_timeout(200)
 b.close()
Path('evidence/baseline.json').write_text(json.dumps(logs,ensure_ascii=False,indent=2));print(json.dumps(logs,ensure_ascii=False,indent=2))
