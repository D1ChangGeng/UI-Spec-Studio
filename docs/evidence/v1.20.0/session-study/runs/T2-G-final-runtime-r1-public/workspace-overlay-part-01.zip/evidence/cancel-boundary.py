from playwright.sync_api import sync_playwright
from pathlib import Path
import os,time,json,sys
out=Path('evidence/screenshots/cancel-boundary');out.mkdir(parents=True,exist_ok=True);checks=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'],env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
 for theme,lang in [('light','en'),('dark','zh')]:
  page=b.new_page(viewport={'width':1280,'height':600});page.goto(f'http://127.0.0.1:4408/?theme={theme}&lang={lang}');inp=page.locator('.aui-composer-input');inp.fill('Cancel this response early.');inp.press('Enter');btn=page.locator('.aui-composer-cancel');btn.wait_for();page.wait_for_timeout(150);btn.focus();before=time.monotonic();page.keyboard.press('Enter');btn.wait_for(state='detached');after=time.monotonic();page.wait_for_timeout(100)
  content=page.locator('[data-slot="aui_assistant-message-content"]').last;one=content.inner_text();page.wait_for_timeout(700);two=content.inner_text();ok=one==two and len(two)<1000 and inp.evaluate('(e)=>e===document.activeElement')
  checks.append({'condition':theme+'-'+lang,'pass':ok,'length_first':len(one),'length_later':len(two),'cancel_command_bracket':[before,after],'focus_on_composer':inp.evaluate('(e)=>e===document.activeElement'),'final_text':two});page.screenshot(path=str(out/f'{theme}-{lang}-early-stop.png'));page.close()
 b.close()
Path('evidence/cancel-boundary.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2));print(json.dumps(checks,ensure_ascii=False,indent=2));sys.exit(0 if all(x['pass'] for x in checks) else 1)
