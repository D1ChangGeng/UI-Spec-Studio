from playwright.sync_api import sync_playwright
from pathlib import Path
import json,os,time
out=Path('evidence/screenshots/delivered');out.mkdir(parents=True,exist_ok=True);records=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'],env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
 for theme,lang in [('light','en'),('dark','zh')]:
  page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
  page.goto(f'http://127.0.0.1:4408/?theme={theme}&lang={lang}');page.locator('.aui-composer-input').wait_for();page.evaluate('document.fonts.ready')
  for w,h in [(1440,900),(1280,600),(390,844)]:
   page.set_viewport_size({'width':w,'height':h});page.wait_for_timeout(100);path=out/f'{theme}-{lang}-{w}x{h}.png';t=time.monotonic();page.screenshot(path=str(path));records.append({'path':str(path),'time_bracket':[t,time.monotonic()],'viewport':[w,h],'horizontal_overflow':page.evaluate('document.documentElement.scrollWidth>innerWidth')})
  page.set_viewport_size({'width':1280,'height':600});page.locator('.aui-composer-input').fill('Compare the evidence.\n保留阅读位置。\nIdentify uncertainty.\n观察输入增长。\nRead previous passages.\n继续讨论。')
  with page.expect_file_chooser() as fc:page.locator('.aui-composer-add-attachment').click()
  fc.value.set_files([{'name':'notes.txt','mimeType':'text/plain','buffer':b''},{'name':'城市出行访谈摘要_2026-10-31_final-revised-notes.txt','mimeType':'text/plain','buffer':b''},{'name':'interview-accessibility-reading-continuity-2026-long-notes-final.txt','mimeType':'text/plain','buffer':b''}]);page.wait_for_timeout(100);page.screenshot(path=str(out/f'{theme}-{lang}-expanded.png'))
  records.append({'condition':theme+'-'+lang,'composer':page.locator('[data-slot="aui_composer-shell"]').bounding_box(),'textarea':page.locator('.aui-composer-input').bounding_box()})
  page.locator('.aui-composer-attachments [data-slot="dialog-trigger"]').nth(1).focus();page.keyboard.press('Enter');page.get_by_role('dialog').wait_for();page.screenshot(path=str(out/f'{theme}-{lang}-disclosure.png'));page.keyboard.press('Escape');page.wait_for_timeout(100)
  page.set_viewport_size({'width':390,'height':844});page.wait_for_timeout(100);page.screenshot(path=str(out/f'{theme}-{lang}-mobile-expanded.png'));page.close()
 b.close()
Path('evidence/delivered-surfaces.json').write_text(json.dumps(records,ensure_ascii=False,indent=2));print(json.dumps(records,ensure_ascii=False,indent=2))
