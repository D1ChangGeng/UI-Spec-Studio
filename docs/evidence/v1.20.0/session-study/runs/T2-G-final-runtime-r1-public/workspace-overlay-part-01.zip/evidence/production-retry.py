from playwright.sync_api import sync_playwright
from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from functools import partial
import threading,os,json,sys,time
class Handler(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',4408),partial(Handler,directory=str(Path('app/dist').resolve())))
threading.Thread(target=server.serve_forever,daemon=True).start()
out=Path('evidence/screenshots/production');out.mkdir(parents=True,exist_ok=True);results=[]
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'],env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
  for theme,lang in [('light','en'),('dark','zh')]:
   page=b.new_page(viewport={'width':1280,'height':600});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   page.goto(f'http://127.0.0.1:4408/?theme={theme}&lang={lang}');inp=page.locator('.aui-composer-input');inp.fill('[fail] Verify the production retry path');inp.press('Enter');page.locator('.aui-message-error-root').wait_for();page.wait_for_timeout(150);page.screenshot(path=str(out/f'{theme}-{lang}-failure.png'))
   page.get_by_role('button',name='Retry response' if lang=='en' else '重试回答',exact=True).last.click();page.locator('.aui-composer-cancel').wait_for();page.locator('.aui-composer-cancel').wait_for(state='detached',timeout=20000);page.wait_for_timeout(150)
   text=page.locator('[data-slot="aui_assistant-message-content"]').last.inner_text();end='Keep unresolved differences visible.' if lang=='en' else '保留尚未解决的分歧。';heading='Observation theme ' if lang=='en' else '观察主题 '
   ok=text.rstrip().endswith(end) and sum(heading+str(i) in text for i in range(1,8))==7 and not errors
   results.append({'condition':theme+'-'+lang,'pass':ok,'rendered_length':len(text),'all_seven_sections':all(heading+str(i) in text for i in range(1,8)),'ends_with_final_bullet':text.rstrip().endswith(end),'page_errors':errors,'artifact':'built app/dist','capture_monotonic':time.monotonic()});page.screenshot(path=str(out/f'{theme}-{lang}-retry-complete.png'));page.close()
  b.close()
finally:
 server.shutdown();server.server_close()
Path('evidence/production-retry.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(json.dumps(results,ensure_ascii=False,indent=2));sys.exit(0 if all(x['pass'] for x in results) else 1)
