from playwright.sync_api import sync_playwright
from pathlib import Path
import os,time,json,sys,traceback
out=Path('evidence/screenshots/recheck');out.mkdir(parents=True,exist_ok=True)
checks=[];events=[]
def ck(name,ok,detail=None):checks.append({'name':name,'pass':bool(ok),'detail':detail});print(json.dumps(checks[-1],ensure_ascii=False),flush=True)
def st(v):return v.evaluate('(e)=>({top:e.scrollTop,height:e.scrollHeight,client:e.clientHeight,gap:e.scrollHeight-e.clientHeight-e.scrollTop})')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'],env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
 for theme,lang in [('light','en'),('dark','zh')]:
  page=b.new_page(viewport={'width':1280,'height':600});page.set_default_timeout(7000);name=theme+'-'+lang
  try:
   page.goto(f'http://127.0.0.1:4408/?theme={theme}&lang={lang}');inp=page.locator('.aui-composer-input');inp.wait_for();page.evaluate('document.fonts.ready')
   with page.expect_file_chooser() as fc:page.locator('.aui-composer-add-attachment').click()
   fc.value.set_files([{'name':'notes.txt','mimeType':'text/plain','buffer':b''}]);r=page.get_by_role('button',name=('Remove ' if lang=='en' else '移除 ')+'notes.txt');r.focus();page.keyboard.press('Enter');page.wait_for_timeout(100);ck(name+' removal returns focus',inp.evaluate('(e)=>e===document.activeElement'))
   inp.fill('Please produce the complete long local answer.');inp.press('Enter');page.locator('.aui-composer-cancel').wait_for();page.wait_for_timeout(450)
   v=page.locator('[data-slot="aui_thread-viewport"]');v.hover();page.mouse.wheel(0,-500);page.wait_for_timeout(100);a=st(v);page.screenshot(path=str(out/(name+'-away-start.png')));page.wait_for_timeout(180);z=st(v);ck(name+' holds while streaming',abs(a['top']-z['top'])<2 and z['height']>a['height'],{'before':a,'after':z})
   page.locator('.aui-thread-scroll-to-bottom').click();page.wait_for_timeout(80);a=st(v);page.screenshot(path=str(out/(name+'-return-start.png')));page.wait_for_timeout(200);z=st(v);page.screenshot(path=str(out/(name+'-return-growing.png')));ck(name+' follows active growth after return',a['gap']<=2 and z['gap']<=2 and z['height']>a['height'],{'before':a,'after':z})
   cancel=page.locator('.aui-composer-cancel');cancel.focus();page.keyboard.press('Enter');cancel.wait_for(state='detached');page.wait_for_timeout(600)
   text=page.locator('[data-slot="aui_assistant-message-content"]').last.inner_text();page.wait_for_timeout(350);text2=page.locator('[data-slot="aui_assistant-message-content"]').last.inner_text();ck(name+' keyboard stop stabilizes incomplete answer',text==text2 and ('Observation theme 7' if lang=='en' else '观察主题 7') not in text,{'length':len(text),'later_length':len(text2)})
   ck(name+' keyboard stop returns focus',inp.evaluate('(e)=>e===document.activeElement'));page.screenshot(path=str(out/(name+'-stopped.png')))
   # Source action bar is revealed by the source message hover state.
   user=page.locator('[data-slot="aui_user-message-root"]').last;user.hover();page.locator('.aui-user-action-edit').last.click();edit=page.locator('.aui-edit-composer-input');edit.wait_for();edit.fill('Revised follow-up 修订后的问题');page.screenshot(path=str(out/(name+'-editing.png')))
   page.get_by_role('button',name='Update' if lang=='en' else '更新',exact=True).click();page.locator('.aui-composer-cancel').wait_for();page.wait_for_timeout(180);page.locator('.aui-composer-cancel').click();page.wait_for_timeout(700)
   ck(name+' edited question applied','Revised follow-up 修订后的问题' in page.locator('.aui-user-message-content').last.inner_text());page.screenshot(path=str(out/(name+'-edited.png')))
   inp.fill('Another question.');inp.press('Enter');page.locator('.aui-composer-cancel').wait_for();page.wait_for_timeout(160);page.locator('.aui-composer-cancel').click();page.wait_for_timeout(700);ck(name+' pointer stop and repeat question',page.locator('.aui-composer-cancel').count()==0 and 'Another question.' in page.locator('.aui-user-message-content').last.inner_text())
   page.screenshot(path=str(out/(name+'-continued.png')))
  except Exception as e:ck(name+' recheck completed',False,str(e));events.append(traceback.format_exc());page.screenshot(path=str(out/(name+'-exception.png')))
  page.close()
 b.close()
Path('evidence/recheck.json').write_text(json.dumps({'checks':checks,'events':events},ensure_ascii=False,indent=2));sys.exit(1 if any(not c['pass'] for c in checks) else 0)
