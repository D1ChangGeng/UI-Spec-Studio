import asyncio, json, os, time, urllib.request, pathlib
from playwright.async_api import async_playwright
root=pathlib.Path("/workspace/scratch/708e8b7f118e/ui-study/worksets/w08/evidence/research/child-01")
root.mkdir(parents=True,exist_ok=True)
def fetch(name,url):
    start=time.time()
    try:
      with urllib.request.urlopen(urllib.request.Request(url,headers={"User-Agent":"UI research"}),timeout=20) as r:
       b=r.read();(root/(name+".body")).write_bytes(b)
       meta={"url":url,"final_url":r.url,"status":r.status,"headers":dict(r.headers),"bytes":len(b),"elapsed":time.time()-start}
    except Exception as e: meta={"url":url,"error":repr(e),"elapsed":time.time()-start}
    (root/(name+".json")).write_text(json.dumps(meta,indent=2)); print(json.dumps(meta),flush=True)
async def browser():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path="/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell",headless=True)
  for name,url in [("vercel-demo","https://chat.vercel.ai"),("elements-attachments","https://ai-sdk.dev/elements/components/attachments"),("claude-product","https://claude.ai")]:
   page=await b.new_page(viewport={"width":1280,"height":900},device_scale_factor=1)
   started=time.time()
   try:
    response=await page.goto(url,wait_until="domcontentloaded",timeout=25000)
    await page.wait_for_timeout(1500)
    await page.screenshot(path=str(root/(name+".png")))
    content=await page.locator("body").inner_text()
    (root/(name+".txt")).write_text(content)
    forms=await page.locator("textarea,input,[contenteditable]").evaluate_all("(es)=>es.map(e=>({tag:e.tagName,placeholder:e.getAttribute('placeholder'),role:e.getAttribute('role')}))")
    result={"url":url,"final_url":page.url,"status":response.status if response else None,"elapsed":time.time()-started,"text":content[:1200],"forms":forms}
    if name=="vercel-demo":
      ta=page.locator("textarea").first
      if await ta.count():
       await ta.fill("Compare these documents.\nFocus on participant concerns.\nKeep evidence visible.\nExplain uncertainty.\nUse Chinese filenames.\nProvide next questions.")
       await page.screenshot(path=str(root/"vercel-six-lines.png"))
       result["textarea_geometry"]=await ta.bounding_box()
   except Exception as e: result={"url":url,"error":repr(e),"elapsed":time.time()-started}
   (root/(name+"-run.json")).write_text(json.dumps(result,indent=2)); print(json.dumps(result),flush=True)
   await page.close()
  await b.close()
fetch("vercel-head","https://api.github.com/repos/vercel/chatbot/commits/main")
fetch("vercel-license","https://raw.githubusercontent.com/vercel/chatbot/main/LICENSE")
asyncio.run(browser())

