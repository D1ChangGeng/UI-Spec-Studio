import asyncio,json,urllib.request,urllib.error,pathlib,time
from playwright.async_api import async_playwright
R=pathlib.Path("/workspace/scratch/708e8b7f118e/ui-study/worksets/w08/evidence/research/child-01")
N=R/"network02";N.mkdir(exist_ok=True)
counter=0
def fetch(n,url,method="GET",data=None,headers={}):
 start=time.time()
 try:
  req=urllib.request.Request(url,data=data,method=method,headers={k:v for k,v in headers.items() if k.lower() not in ["host","connection","accept-encoding","content-length"]})
  try: r=urllib.request.urlopen(req,timeout=12)
  except urllib.error.HTTPError as e:r=e
  b=r.read();meta={"url":url,"final_url":r.url,"status":r.status,"headers":dict(r.headers),"elapsed":time.time()-start}
  (N/(n+".body")).write_bytes(b);(N/(n+".json")).write_text(json.dumps(meta,indent=2))
  return r.status,{k:v for k,v in r.headers.items() if k.lower() not in ["content-encoding","transfer-encoding","content-length"]},b
 except Exception as e:
  (N/(n+".json")).write_text(json.dumps({"url":url,"error":repr(e)}));return 599,{},str(e).encode()
async def main():
 sha=json.loads((R/"vercel-head.body").read_text())["sha"]
 for name,path in [("multimodal","components/multimodal-input.tsx"),("preview-attachment","components/preview-attachment.tsx"),("messages","components/messages.tsx"),("scroll","hooks/use-scroll-to-bottom.tsx"),("prompt-input","components/ai-elements/prompt-input.tsx"),("attachments","components/ai-elements/attachments.tsx")]:
  result=await asyncio.to_thread(fetch,"source-"+name,"https://raw.githubusercontent.com/vercel/chatbot/"+sha+"/"+path)
  print(name,result[0],len(result[2]),flush=True)
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path="/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell",headless=True)
  ctx=await b.new_context(viewport={"width":1280,"height":900})
  async def route(route,request):
   global counter;counter+=1;n="req-%04d"%counter
   if request.url.startswith("http"):
    st,h,body=await asyncio.to_thread(fetch,n,request.url,request.method,request.post_data_buffer,request.headers)
    await route.fulfill(status=st,headers=h,body=body)
   else:await route.continue_()
  await ctx.route("**/*",route)
  for name,url in [("vercel02","https://chat.vercel.ai"),("elements02","https://ai-sdk.dev/elements/components/attachments"),("claude02","https://claude.ai")]:
   page=await ctx.new_page();info={"url":url,"transport":"Playwright route fulfilled with TLS-verifying urllib; original response bytes saved"}
   try:
    resp=await page.goto(url,wait_until="domcontentloaded",timeout=30000)
    await page.wait_for_timeout(1200)
    info.update({"status":resp.status,"final_url":page.url,"body":(await page.locator("body").inner_text())[:12000]})
    await page.screenshot(path=str(R/(name+".png")))
    info["forms"]=await page.locator("textarea,input,[contenteditable]").evaluate_all("(es)=>es.map(e=>({tag:e.tagName,placeholder:e.getAttribute('placeholder'),role:e.getAttribute('role')}))")
    if name=="vercel02" and await page.locator("textarea").count():
     ta=page.locator("textarea").first
     info["one"]=await ta.bounding_box()
     await ta.fill("Compare the files.\nExplain shared themes.\nKeep evidence visible.\nShow uncertainty.\nRespect reading position.\nSuggest next questions.")
     await page.wait_for_timeout(400); info["six"]=await ta.bounding_box()
     await page.screenshot(path=str(R/"vercel02-six.png"))
   except Exception as e:info["error"]=repr(e)
   (R/(name+"-run.json")).write_text(json.dumps(info,indent=2));print(name,json.dumps({k:v for k,v in info.items() if k!="body"}),info.get("body","")[:450],flush=True)
   await page.close()
  await ctx.close();await b.close()
asyncio.run(main())

