import asyncio,json,urllib.request,urllib.error,pathlib,time
from playwright.async_api import async_playwright
R=pathlib.Path("/workspace/scratch/708e8b7f118e/ui-study/worksets/w08/evidence/research/child-01")
N=R/"network04";N.mkdir(exist_ok=True);counter=0
def fetch(n,url,method="GET",data=None,headers={}):
 try:
  req=urllib.request.Request(url,data=data,method=method,headers={k:v for k,v in headers.items() if k.lower() not in ["host","connection","accept-encoding","content-length"]})
  try:r=urllib.request.urlopen(req,timeout=12)
  except urllib.error.HTTPError as e:r=e
  body=r.read();meta={"url":url,"final_url":r.url,"status":r.status,"headers":dict(r.headers)}
  (N/(n+".body")).write_bytes(body);(N/(n+".json")).write_text(json.dumps(meta,indent=2))
  return r.status,{k:v for k,v in r.headers.items() if k.lower() not in ["content-encoding","transfer-encoding","content-length"]},body
 except Exception as e:
  (N/(n+".json")).write_text(json.dumps({"url":url,"error":repr(e)}));return 599,{},str(e).encode()
async def main():
 for n,url in [("vercel-multimodal","https://raw.githubusercontent.com/vercel/chatbot/c2f8235e1f3ea903ad8b7f61447c4f74164b5c58/components/chat/multimodal-input.tsx"),("vercel-attachment","https://raw.githubusercontent.com/vercel/chatbot/c2f8235e1f3ea903ad8b7f61447c4f74164b5c58/components/chat/preview-attachment.tsx"),("prompt-readme","https://raw.githubusercontent.com/ibelick/prompt-kit/5a9496635cc0e1bf7679fe2a9e35d9b36b99c08a/README.md")]:
  st,h,b=await asyncio.to_thread(fetch,n,url);print(n,st,len(b),flush=True)
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path="/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell",headless=True)
  ctx=await browser.new_context(viewport={"width":1280,"height":900})
  async def route(route,request):
   global counter;counter+=1
   if request.url.startswith("http"):
    st,h,b=await asyncio.to_thread(fetch,"req-%04d"%counter,request.url,request.method,request.post_data_buffer,request.headers)
    await route.fulfill(status=st,headers=h,body=b)
   else:await route.continue_()
  await ctx.route("**/*",route)
  for name,url in [("elements04","https://elements.ai-sdk.dev/components/attachments"),("promptkit04","https://prompt-kit.com/blocks/prompt-inputs")]:
   page=await ctx.new_page();info={"url":url,"transport":"TLS-verified urllib response fulfillment"}
   try:
    rr=await page.goto(url,wait_until="domcontentloaded",timeout=25000);await page.wait_for_timeout(1000)
    info.update({"status":rr.status,"final_url":page.url,"body":(await page.locator("body").inner_text())[:20000]})
    await page.screenshot(path=str(R/(name+".png")))
    if name=="elements04":
     await page.get_by_text("Inline Variant",exact=True).first.scroll_into_view_if_needed()
     await page.screenshot(path=str(R/(name+"-inline.png")))
     await page.get_by_text("List Variant",exact=True).first.scroll_into_view_if_needed()
     await page.screenshot(path=str(R/(name+"-list.png")))
    info["textarea_count"]=await page.locator("textarea").count()
    if info["textarea_count"]:
     t=page.locator("textarea").first
     await t.scroll_into_view_if_needed();info["initial"]=await t.bounding_box()
     await t.fill("Compare documents.\nKeep uncertainty clear.\nExplain participant concerns.\nRetain the evidence.\nUse accurate filenames.\nSuggest next questions.")
     await page.wait_for_timeout(300);info["six_lines"]=await t.bounding_box()
     await page.screenshot(path=str(R/(name+"-six.png")))
     await t.fill("One line");await page.wait_for_timeout(300);info["return"]=await t.bounding_box()
     await page.screenshot(path=str(R/(name+"-return.png")))
   except Exception as e:info["error"]=repr(e)
   (R/(name+"-run.json")).write_text(json.dumps(info,indent=2));print(name,json.dumps({k:v for k,v in info.items() if k!="body"}),info.get("body","")[:250],flush=True)
   await page.close()
  await ctx.close();await browser.close()
asyncio.run(main())

