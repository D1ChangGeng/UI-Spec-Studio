from playwright.sync_api import sync_playwright
import os,json,time
from pathlib import Path
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'],env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
 page=b.new_page(viewport={'width':1280,'height':600});page.goto('http://127.0.0.1:4408/?theme=light&lang=en');page.locator('textarea').fill('Give me the long response');page.get_by_role('button',name='Send message',exact=True).click();page.wait_for_timeout(1700)
 v=page.locator('[data-slot="aui_thread-viewport"]');v.hover();page.mouse.wheel(0,-600);page.wait_for_timeout(400)
 page.get_by_role('button',name='Scroll to bottom',exact=True).click();page.wait_for_timeout(700)
 logs=[]
 for i in range(5):
  logs.append({'sample':i,'t':time.monotonic(),'state':v.evaluate('(e)=>({top:e.scrollTop,height:e.scrollHeight,client:e.clientHeight,bottomGap:e.scrollHeight-e.clientHeight-e.scrollTop})')});page.wait_for_timeout(500)
 page.screenshot(path='evidence/screenshots/trial/return-probe.png');b.close()
 print(json.dumps(logs,indent=2));Path('evidence/return-probe.json').write_text(json.dumps(logs,indent=2))
