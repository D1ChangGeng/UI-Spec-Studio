from playwright.sync_api import sync_playwright
from pathlib import Path
import json,os,time
out=Path('evidence/screenshots/trial');out.mkdir(parents=True,exist_ok=True)
logs=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'],env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
 for theme,lang in [('light','en'),('dark','zh')]:
  page=b.new_page(viewport={'width':1280,'height':600},device_scale_factor=1);page.on('pageerror',lambda e:logs.append({'error':str(e)}))
  page.goto(f'http://127.0.0.1:4408/?theme={theme}&lang={lang}');page.locator('textarea').first.wait_for();page.evaluate('document.fonts.ready')
  page.locator('textarea').first.fill('Line one: Compare the evidence.\n第二行：保持阅读位置。\nLine three: Identify uncertainty.\n第四行：观察输入增长。\nLine five: Read previous passages.\n第六行：继续讨论。')
  with page.expect_file_chooser() as fc:page.locator('.aui-composer-add-attachment').click()
  fc.value.set_files([{'name':'notes.txt','mimeType':'text/plain','buffer':b''},{'name':'城市出行访谈摘要_2026-10-31_final-revised-notes.txt','mimeType':'text/plain','buffer':b''},{'name':'interview-accessibility-reading-continuity-2026-long-notes-final.txt','mimeType':'text/plain','buffer':b''}]);page.wait_for_timeout(250)
  page.screenshot(path=str(out/f'{theme}-expanded.png'))
  triggers=page.locator('.aui-composer-attachments [data-slot="dialog-trigger"]')
  triggers.nth(1).click();page.wait_for_timeout(150);page.screenshot(path=str(out/f'{theme}-disclosure.png'))
  logs.append({'condition':theme,'dialog':page.get_by_role('dialog').inner_text(),'bodyWidth':page.evaluate('document.documentElement.scrollWidth'),'composer':page.locator('[data-slot="aui_composer-shell"]').bounding_box()})
  page.keyboard.press('Escape');page.wait_for_timeout(150)
  logs.append({'focus_return':page.evaluate('document.activeElement?.getAttribute("aria-label")')})
  page.set_viewport_size({'width':390,'height':844});page.wait_for_timeout(200);page.screenshot(path=str(out/f'{theme}-mobile-expanded.png'))
  page.close()
 b.close()
Path('evidence/trial.json').write_text(json.dumps(logs,ensure_ascii=False,indent=2));print(json.dumps(logs,ensure_ascii=False,indent=2))
