from playwright.sync_api import sync_playwright
from pathlib import Path
import json,time,os,traceback,sys
OUT=Path('evidence/screenshots/final');OUT.mkdir(parents=True,exist_ok=True)
logs=[];checks=[]
def check(name,ok,detail=None):
 checks.append({'name':name,'pass':bool(ok),'detail':detail});print(json.dumps(checks[-1],ensure_ascii=False),flush=True)
def state(v):return v.evaluate('(e)=>({top:e.scrollTop,height:e.scrollHeight,client:e.clientHeight,gap:e.scrollHeight-e.clientHeight-e.scrollTop})')
def shot(page,name):
 a=time.monotonic();page.screenshot(path=str(OUT/(name+'.png')));logs.append({'capture':name,'before_monotonic':a,'after_monotonic':time.monotonic(),'viewport':page.viewport_size})
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'],env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
 for theme,lang in [('light','en'),('dark','zh')]:
  name=theme+'-'+lang;page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
  page.on('pageerror',lambda e: logs.append({'pageerror':str(e)}))
  try:
   page.goto(f'http://127.0.0.1:4408/?theme={theme}&lang={lang}');inp=page.locator('.aui-composer-input');inp.wait_for();page.evaluate('document.fonts.ready')
   for w,h in [(1440,900),(1280,600),(390,844)]:
    page.set_viewport_size({'width':w,'height':h});page.wait_for_timeout(180);shot(page,f'{name}-{w}x{h}')
    check(f'{name} no document horizontal overflow {w}x{h}',page.evaluate('document.documentElement.scrollWidth <= innerWidth'))
   page.set_viewport_size({'width':1280,'height':600})
   six='Line one: Compare the evidence.\n第二行：保持阅读位置。\nLine three: Identify uncertainty.\n第四行：观察输入增长。\nLine five: Read previous passages.\n第六行：继续讨论。'
   inp.fill('One line');one=inp.bounding_box();inp.press('Shift+Enter');check(name+' Shift+Enter adds newline', '\n' in inp.input_value())
   inp.fill(six)
   with page.expect_file_chooser() as fc:page.locator('.aui-composer-add-attachment').click()
   files=[{'name':'notes.txt','mimeType':'text/plain','buffer':b''},{'name':'城市出行访谈摘要_2026-10-31_final-revised-notes.txt','mimeType':'text/plain','buffer':b''},{'name':'interview-accessibility-reading-continuity-2026-long-notes-final.txt','mimeType':'text/plain','buffer':b''}]
   fc.value.set_files(files);page.wait_for_timeout(200);shot(page,name+'-six-lines-attachments')
   check(name+' six-line growth',inp.bounding_box()['height']>one['height'],inp.bounding_box())
   triggers=page.locator('.aui-composer-attachments [data-slot="dialog-trigger"]');triggers.nth(1).focus();page.keyboard.press('Enter');page.get_by_role('dialog').wait_for();shot(page,name+'-filename-dialog')
   check(name+' full filename disclosed',files[1]['name'] in page.get_by_role('dialog').inner_text())
   page.keyboard.press('Escape');page.wait_for_timeout(150);check(name+' dialog focus returned',page.evaluate('document.activeElement.getAttribute("aria-label")')==triggers.nth(1).get_attribute('aria-label'))
   remove=page.locator('.aui-composer-attachments button').filter(has=page.locator('svg')).first
   # Named removal is a separate button, independent of filename disclosure.
   remove=page.get_by_role('button',name=('Remove ' if lang=='en' else '移除 ')+'notes.txt',exact=True);remove.focus();page.keyboard.press('Enter');page.wait_for_timeout(150)
   check(name+' removal works',triggers.count()==2)
   check(name+' focus after removal stays usable',page.evaluate('document.activeElement !== document.body && document.activeElement.isConnected'),page.evaluate('({tag:document.activeElement.tagName,label:document.activeElement.getAttribute("aria-label")})'))
   inp.fill('\n'.join(['Long mixed-language question 长问题 — preserve evidence and reading continuity.']*20));page.wait_for_timeout(100);shot(page,name+'-long-draft')
   check(name+' long draft remains bounded',inp.bounding_box()['height']<=192.1,inp.bounding_box())
   check(name+' send visible in short height',page.locator('.aui-composer-send').bounding_box()['y']<600)
   inp.fill(six);page.set_viewport_size({'width':390,'height':844});page.wait_for_timeout(100);shot(page,name+'-mobile-attachments');check(name+' attachment mobile overflow contained',page.evaluate('document.documentElement.scrollWidth <= innerWidth'))
   page.set_viewport_size({'width':1280,'height':600});inp.fill('Compare the attached filenames.');inp.press('Enter');page.locator('.aui-composer-cancel').wait_for();page.wait_for_timeout(1200);shot(page,name+'-stream-follow')
   v=page.locator('[data-slot="aui_thread-viewport"]');check(name+' initially follows stream',state(v)['gap']<=2,state(v))
   v.hover();page.mouse.wheel(0,-900);page.wait_for_timeout(250);before=state(v);shot(page,name+'-away-start');page.wait_for_timeout(650);after=state(v);shot(page,name+'-away-growing')
   check(name+' manual scroll held during growth',abs(before['top']-after['top'])<2,{'before':before,'after':after})
   inp.fill(six);page.wait_for_timeout(150);grown=state(v);shot(page,name+'-away-draft-grown');check(name+' reading held while draft grows',abs(after['top']-grown['top'])<2,{'before':after,'after':grown})
   inp.fill('');page.locator('.aui-thread-scroll-to-bottom').click();page.wait_for_timeout(200);follow=[]
   for i in range(3):
    follow.append({'t':time.monotonic(),'state':state(v)});shot(page,name+f'-return-{i}');page.wait_for_timeout(350)
   check(name+' return resumes following',all(s['state']['gap']<=2 for s in follow),follow)
   cancel=page.locator('.aui-composer-cancel')
   if cancel.count():cancel.focus();page.keyboard.press('Enter')
   page.wait_for_timeout(100);text=page.locator('[data-slot="aui_assistant-message-content"]').last.inner_text();page.wait_for_timeout(350)
   check(name+' stop aborts further chunks',text==page.locator('[data-slot="aui_assistant-message-content"]').last.inner_text())
   check(name+' keyboard stop returns focus to composer',inp.evaluate('(e)=>e===document.activeElement'))
   shot(page,name+'-stopped')
   inp.fill('[fail] Verify the failure path '+lang);inp.press('Enter');page.locator('.aui-message-error-root').wait_for(timeout=5000);shot(page,name+'-failure')
   check(name+' failure visible',page.locator('.aui-message-error-root').is_visible())
   page.get_by_role('button',name='Retry response' if lang=='en' else '重试回答',exact=True).last.click();page.locator('.aui-composer-cancel').wait_for();page.locator('.aui-composer-cancel').wait_for(state='detached',timeout=20000);shot(page,name+'-retry-complete')
   complete=page.locator('[data-slot="aui_assistant-message-content"]').last.inner_text();check(name+' retry completes full response',('Observation theme 7' if lang=='en' else '观察主题 7') in complete,{'length':len(complete)})
   inp.fill('Continue this thread.');inp.press('Enter');page.locator('.aui-composer-cancel').wait_for();page.wait_for_timeout(300);page.locator('.aui-composer-cancel').focus();page.keyboard.press('Enter');check(name+' repeat question remains operable',page.locator('[data-slot="aui_assistant-message-content"]').count()==4)
   page.locator('.aui-user-action-edit').last.click();edit=page.locator('.aui-edit-composer-input');edit.wait_for();edit.fill('Revised follow-up 修订后的问题');page.get_by_role('button',name='Update' if lang=='en' else '更新',exact=True).click();page.locator('.aui-composer-cancel').wait_for();page.wait_for_timeout(250);page.locator('.aui-composer-cancel').focus();page.keyboard.press('Enter');shot(page,name+'-edited-continued');check(name+' edited question applied','Revised follow-up 修订后的问题' in page.locator('.aui-user-message-content').last.inner_text())
   page.close()
  except Exception as e:
   check(name+' scenario completed',False,str(e));logs.append({'exception':traceback.format_exc()});shot(page,name+'-exception');page.close()
 b.close()
Path('evidence/final-checks.json').write_text(json.dumps({'checks':checks,'events':logs},ensure_ascii=False,indent=2));print(json.dumps({'checks':len(checks),'failed':sum(not x['pass'] for x in checks)},ensure_ascii=False));sys.exit(1 if any(not x['pass'] for x in checks) else 0)
