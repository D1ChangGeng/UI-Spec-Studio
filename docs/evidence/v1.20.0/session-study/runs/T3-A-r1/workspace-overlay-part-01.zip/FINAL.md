# Fieldnotes — editorial research workspace

Fieldnotes now uses **Paper 0.10.0**, a complete licensed TiddlyWiki theme, with a cream manuscript reading surface, serif prose, separate sans navigation, a ruled monospace editor and a coherent charcoal Night condition. The native research workflow and all eight supplied notes remain intact.

The runnable source is in [app/wiki](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w09/app/wiki). Start the authoritative server from this package:

```bash
cd /workspace/scratch/708e8b7f118e/ui-study/worksets/w09/app
PORT=4409 ./start.sh
```

Open http://127.0.0.1:4409/. The delivery starts with the project index and interview, English UI, Paper Day and no drafts. The preview server used for verification has been stopped. The successful offline build is also available as [index.html](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w09/app/wiki/output/index.html); the Node server remains the authoritative persistence path.

![Final Fieldnotes entry](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w09/evidence/delivery-final/delivery-entry.png)

## Why this direction

I compared the supplied native baseline, Paper and Notebook using original demos and the same populated interview/editor. Notebook's centered sheet, top search strip and compact sans reading were a meaningful alternative. Paper better separated sustained reading from navigation and editing while retaining the familiar native workflow. A rendered Tufte CSS publication page provided a cross-domain comparison of measure and typography; no Tufte assets or implementation were adopted.

| Foundation | Decision |
|---|---|
| TiddlyWiki 5.4.1 | Retained unchanged as the native engine and persistence system. |
| Paper 0.10.0 | Adopted whole-workspace theme from MIT-licensed revision 031a78d4d4187128c632f8a647fa05408eddc700. All 55 theme files remain byte-identical to that source. |
| Notebook 1.4.1 | Trialed as a contrasting mature direction; retained only as research evidence. |
| Tufte CSS | Viewed as a publication reference; no code or fonts adopted. |

The product uses supported Paper settings for visible controls and sticky titles, equivalent scalable text metrics, and three small foreground-role changes using existing source colors. Three tables use Paper's existing scrollable wrapper with a keyboard-focusable labelled region. No original replacement layout, new image assets, remote fonts or animation engine were introduced. Source licenses and exact revisions are retained in [SOURCE-ADOPTION.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w09/SOURCE-ADOPTION.md).

## Verified behavior

The actual browser run passed the central tasks:

- Read through the complete bilingual interview, follow the Evidence ledger link and return.
- Edit an English passage and a Chinese passage through the native editor, save, confirm the native filesystem write and reload agreement, then restore the original wording through the editor.
- Cancel an unsaved edit without altering persisted content.
- Use keyboard search and open the matching note's native editor.
- Render reading and editing in Day/Night and en-GB/zh-Hans at 1440×900, 1280×640 and 390×844, with device scale 1.
- Keep narrow tables within the reading sheet. The ledger and prototype table scroll with arrow keys when focused; the observation table already fits.

The final integrity check confirms all eight note bodies preserve their original text, ignoring only blank-line differences and the added table-wrapper lines. Tables, cross-links, fictional-content disclosure and unfinished status remain. Native saves updated modification metadata and some filenames, as expected. Details are in [FINAL-INTEGRITY.json](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w09/FINAL-INTEGRITY.json), [behavior report](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w09/evidence/final-v2/report.json) and [table checks](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w09/evidence/settled-final-continuation/report.json).

Twenty-four settled matrix frames are retained. I personally opened twelve representative matrix images, the delivered entry and repaired ledger views. The static evidence shows distinct reading/editor typography, readable mixed-language text, visible focus and wrapping narrow editor controls. See [VISUAL-REVIEW.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w09/VISUAL-REVIEW.md) for the exact inspection boundary.

## Corrections and remaining limits

Visual inspection caught a theme-identifier newline that had caused a Vanilla fallback, and a narrow ledger whose last columns were inaccessible. Both were corrected and verified. Earlier failed outputs remain alongside the corrected captures. Transitional editor captures were also retained and superseded by settled views.

One optional Control Panel Appearance-tab automation did not locate its target. Its failures are preserved; direct native settings-tab navigation is not claimed as verified. Final palette, locale, theme and default story were independently restored and checked after reload.

Normal and reduced-motion control episodes were captured, with sampled frames personally inspected. Video is retained, but natural-speed playback was not reviewed, so there is no claim about frame rate or perceptual pacing. Paper's source motion behavior remains; no new motion was introduced.

The controlled run reported no browser page errors or external product requests. Its initial response was about 3.43 MB and DOMContentLoaded about 351 ms on this host; these are a single local sample, not a field performance benchmark. No dependencies or remote services were added.

Verification used headless Chromium 143 and the supplied CJK font fixture. Physical mobile keyboards, screen readers, other browsers, failure injection and real-team preference remain outside the observed evidence. Core English and Simplified Chinese conditions were checked; Paper-specific settings help remains the source's English text.

The completed workspace, source comparisons, actual tool exports, failures, behavior logs and final captures are all retained in this work package.

