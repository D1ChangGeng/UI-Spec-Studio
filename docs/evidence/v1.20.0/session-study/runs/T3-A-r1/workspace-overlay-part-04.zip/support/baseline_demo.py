import asyncio,json,time,os
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence'/'captures';OUT.mkdir(parents=True,exist_ok=True)
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=CHROME,headless=True)
  report=[]
  for name,url in [('baseline','http://127.0.0.1:4409/'),('paper-original',(ROOT/'evidence/research/paper-original-demo.html').as_uri()),('notebook-original',(ROOT/'evidence/research/notebook-original-demo.html').as_uri())]:
   page=await browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
   errors=[];page.on('pageerror',lambda err:errors.append(str(err)))
   started=time.monotonic()
   await page.goto(url,wait_until='domcontentloaded')
   await page.wait_for_selector('.tc-tiddler-frame',timeout=30000)
   await page.evaluate('document.fonts.ready')
   await page.wait_for_timeout(700)
   await page.screenshot(path=str(OUT/(name+'-1440.png')))
   info=await page.evaluate("""() => ({title:document.title,theme:$tw.wiki.getTiddlerText('$:/theme'),palette:$tw.wiki.getTiddlerText('$:/palette'),tiddlers:[...document.querySelectorAll('.tc-tiddler-frame')].map(x=>x.getAttribute('data-tiddler-title')),buttons:[...document.querySelectorAll('button')].slice(0,30).map(x=>({text:x.textContent,title:x.title,aria:x.getAttribute('aria-label')})),font: getComputedStyle(document.querySelector('.tc-tiddler-body')).fontFamily,bodyWidth:document.body.scrollWidth,viewport:innerWidth})""")
   report.append({'name':name,'url':url,'capture':name+'-1440.png','seconds':time.monotonic()-started,'info':info,'errors':errors})
   if name=='baseline':
    note=page.locator('[data-tiddler-title="访谈笔记 — 傍晚通勤"]')
    await note.scroll_into_view_if_needed()
    await page.screenshot(path=str(OUT/'baseline-interview-1440.png'))
   await page.close()
  await browser.close()
  (ROOT/'evidence/research/original-demo-captures.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
  print(json.dumps(report,ensure_ascii=False,indent=2))
asyncio.run(main())

