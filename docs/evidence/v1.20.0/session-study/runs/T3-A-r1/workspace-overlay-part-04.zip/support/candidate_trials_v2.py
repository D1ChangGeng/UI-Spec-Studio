import asyncio,json,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence/captures'
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
TITLE='访谈笔记 — 傍晚通勤'
async def shot(page,name,report):
 await page.evaluate('document.fonts.ready');await page.wait_for_timeout(400)
 await page.screenshot(path=str(OUT/(name+'.png')))
 report.append({'capture':name+'.png','time':time.monotonic(),'viewport':page.viewport_size,'info':await page.evaluate("""() => ({theme:$tw.wiki.getTiddlerText('$:/theme'),palette:$tw.wiki.getTiddlerText('$:/palette'),width:innerWidth,scrollWidth:document.documentElement.scrollWidth,scrollY:scrollY,frames:[...document.querySelectorAll('iframe')].map(x=>({class:x.className,title:x.title})),textareas:[...document.querySelectorAll('textarea')].map(x=>({class:x.className,valueLength:x.value.length})),buttons:[...document.querySelectorAll('.tc-tiddler-frame button')].map(x=>({title:x.title,aria:x.getAttribute('aria-label')})).slice(0,14)})""")})
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=CHROME,headless=True)
  page=await browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
  report=[];errors=[];page.on('pageerror',lambda e: errors.append(str(e)))
  page.on('dialog',lambda dialog:dialog.accept())
  await page.goto('http://127.0.0.1:4409/');await page.wait_for_selector('.tc-tiddler-frame')
  if await page.get_by_role('button',name='Discard changes to this tiddler',exact=True).count(): await page.get_by_role('button',name='Discard changes to this tiddler',exact=True).click()
  for name,theme,palette in [('notebook','$:/themes/nico/notebook','$:/themes/nico/notebook/palettes/palette-beige'),('paper','$:/themes/BurningTreeC/vanilla-paper','$:/palettes/VanillaPaperDay')]:
   await page.evaluate("""([theme,palette])=>{$tw.wiki.setText('$:/theme','text',null,theme);$tw.wiki.setText('$:/palette','text',null,palette);}""",[theme,palette])
   await page.wait_for_timeout(600);await page.reload();await page.wait_for_selector('.tc-tiddler-frame')
   await page.set_viewport_size({'width':1440,'height':900});await page.evaluate('scrollTo(0,0)')
   await shot(page,'trial-v2-'+name+'-index-1440',report)
   index=page.locator('[data-tiddler-title="Fieldnotes — project index"]')
   await index.get_by_role('link',name=TITLE,exact=True).click()
   await shot(page,'trial-v2-'+name+'-read-1440',report)
   note=page.locator('[data-tiddler-title="'+TITLE+'"]')
   await note.get_by_role('button',name='Edit this tiddler',exact=True).click()
   await shot(page,'trial-v2-'+name+'-edit-1440',report)
   await page.set_viewport_size({'width':390,'height':844})
   await shot(page,'trial-v2-'+name+'-edit-390',report)
   cancel=page.get_by_role('button',name='Discard changes to this tiddler',exact=True)
   if await cancel.count()==0: cancel=page.locator('button[title="Cancel editing this tiddler"]')
   await cancel.click()
   await shot(page,'trial-v2-'+name+'-read-390',report)
  (ROOT/'evidence/research/candidate-trials-v2.json').write_text(json.dumps({'report':report,'errors':errors},ensure_ascii=False,indent=2))
  print(json.dumps({'captures':[x['capture'] for x in report],'last':report[-1],'errors':errors},ensure_ascii=False,indent=2))
  await page.goto((ROOT/'evidence/research/tufte-source/index.html').as_uri())
  await page.set_viewport_size({'width':1440,'height':900})
  await page.evaluate('document.fonts.ready')
  await page.screenshot(path=str(OUT/'tufte-original-1440.png'))
  await browser.close()
asyncio.run(main())

