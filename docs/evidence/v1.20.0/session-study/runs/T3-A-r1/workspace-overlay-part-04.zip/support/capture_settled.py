import asyncio,json,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence/settled-final';OUT.mkdir(exist_ok=False)
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
TITLE='访谈笔记 — 傍晚通勤';INDEX='Fieldnotes — project index';records=[];checks=[]
async def capture(page,name):
 await page.evaluate('document.fonts.ready');await page.wait_for_timeout(850)
 start=time.monotonic();await page.screenshot(path=str(OUT/(name+'.png')));end=time.monotonic()
 meta=await page.evaluate("""()=>({viewport:[innerWidth,innerHeight],scrollWidth:document.documentElement.scrollWidth,palette:$tw.wiki.getTiddlerText('$:/palette'),locale:$tw.wiki.getTiddlerText('$:/language'),reduced:matchMedia('(prefers-reduced-motion: reduce)').matches,theme:$tw.wiki.getTiddlerText('$:/theme'),animationDuration:$tw.wiki.getTiddlerText('$:/config/AnimationDuration'),frames:[...document.querySelectorAll('.tc-tiddler-frame')].map(e=>({title:e.getAttribute('data-tiddler-title'),opacity:getComputedStyle(e).opacity,width:e.getBoundingClientRect().width,bodyFont:e.querySelector('.tc-tiddler-body')?getComputedStyle(e.querySelector('.tc-tiddler-body')).fontFamily:null})),focus:{tag:document.activeElement.tagName,class:document.activeElement.className}})""")
 records.append({'file':name+'.png','start':start,'end':end,**meta});(OUT/'report.json').write_text(json.dumps({'captures':records,'checks':checks},ensure_ascii=False,indent=2))
async def getlabel(page,n):return (await page.evaluate('(n)=>$tw.wiki.getTiddlerText("$:/language/Buttons/"+n+"/Hint")',n)).strip()
async def config(page,palette,locale):
 await page.evaluate("""([p,l])=>{$tw.wiki.setText('$:/palette','text',null,'$:/palettes/VanillaPaper'+p);$tw.wiki.setText('$:/language','text',null,'$:/languages/'+l);$tw.wiki.setText('$:/StoryList','list',null,['Fieldnotes — project index','访谈笔记 — 傍晚通勤']);$tw.wiki.setText('$:/state/sidebar','text',null,'yes')}""",[palette,locale])
 await page.wait_for_timeout(250);await page.reload();await page.wait_for_selector('.tc-tiddler-frame')
async def open_note(page,title):
 await page.locator('[data-tiddler-title="'+INDEX+'"]').get_by_role('link',name=title,exact=True).click()
 await page.wait_for_timeout(600)
 return page.locator('[data-tiddler-title="'+title+'"]')
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=CHROME,headless=True)
  page=await b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
  page.set_default_timeout(10000);page.on('dialog',lambda d:d.accept())
  await page.goto('http://127.0.0.1:4409/');await page.wait_for_selector('.tc-tiddler-frame')
  for palette in ['Day','Night']:
   for locale in ['en-GB','zh-Hans']:
    for w,h in [(1440,900),(1280,640),(390,844)]:
     await page.set_viewport_size({'width':w,'height':h});await config(page,palette,locale)
     note=await open_note(page,TITLE);name=f'{palette.lower()}-{locale}-{w}'
     await capture(page,name+'-read')
     await note.get_by_role('button',name=await getlabel(page,'Edit'),exact=True).click()
     await page.wait_for_selector('iframe.tc-edit-texteditor-body')
     await page.locator('.tc-tiddler-frame').filter(has=page.locator('iframe.tc-edit-texteditor-body')).evaluate("(e)=>e.scrollIntoView({block:'start'})")
     await capture(page,name+'-edit')
     await page.get_by_role('button',name=await getlabel(page,'Cancel'),exact=True).click();await page.wait_for_timeout(600)
  for palette in ['Day','Night']:
   await page.set_viewport_size({'width':390,'height':844});await config(page,palette,'zh-Hans')
   for title,key in [('Evidence ledger','ledger'),('Observation log — East entrance','observation'),('Prototype comparison — signs and landmarks','prototype')]:
    note=await open_note(page,title);wrapper=note.locator('.tc-table-wrapper')
    await capture(page,palette.lower()+'-390-'+key+'-left')
    await wrapper.locator('a').first.focus() if await wrapper.locator('a').count() else await wrapper.focus()
    if await wrapper.locator('a').count():await page.keyboard.press('Shift+Tab')
    assert await wrapper.evaluate('(e)=>document.activeElement===e')
    for _ in range(12):await page.keyboard.press('ArrowRight')
    await page.wait_for_timeout(350)
    m=await wrapper.evaluate('(e)=>({client:e.clientWidth,scroll:e.scrollWidth,left:e.scrollLeft,overflow:getComputedStyle(e).overflowX,outline:getComputedStyle(e).outline})')
    assert m['left']>0 and m['overflow']=='auto',m
    checks.append({'name':'table-keyboard-horizontal-scroll','palette':palette,'title':title,**m})
    await capture(page,palette.lower()+'-390-'+key+'-right')
  # Settled quiet condition.
  await page.set_viewport_size({'width':390,'height':844});await page.emulate_media(reduced_motion='reduce');await config(page,'Night','zh-Hans')
  note=await open_note(page,TITLE);await capture(page,'reduced-night-390-read')
  await note.get_by_role('button',name=await getlabel(page,'Edit'),exact=True).click();await page.wait_for_selector('iframe.tc-edit-texteditor-body');await capture(page,'reduced-night-390-edit')
  await page.get_by_role('button',name=await getlabel(page,'Cancel'),exact=True).click();await page.wait_for_timeout(700)
  # Real native settings route, not only harness-selected theme states.
  await page.set_viewport_size({'width':1280,'height':640});await config(page,'Day','en-GB')
  await page.get_by_role('button',name='control panel',exact=True).click();await page.wait_for_timeout(650)
  await page.locator('[data-tiddler-title="$:/ControlPanel"]').get_by_role('button',name='Appearance',exact=True).click()
  await capture(page,'native-appearance-control-panel')
  # Restore initial delivery.
  await page.set_viewport_size({'width':1440,'height':900});await page.emulate_media(reduced_motion='no-preference');await config(page,'Day','en-GB')
  await capture(page,'delivery-entry')
  checks.append({'name':'final-state','drafts':await page.evaluate("$tw.wiki.filterTiddlers('[has[draft.of]]')"),'story':await page.evaluate("$tw.wiki.getTiddlerList('$:/StoryList')")})
  (OUT/'report.json').write_text(json.dumps({'captures':records,'checks':checks},ensure_ascii=False,indent=2))
  await b.close()
 print(json.dumps({'captures':len(records),'checks':checks},ensure_ascii=False,indent=2))
asyncio.run(main())

