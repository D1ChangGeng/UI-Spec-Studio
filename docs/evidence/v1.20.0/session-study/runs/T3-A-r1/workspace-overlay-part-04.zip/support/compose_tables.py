import asyncio,json,time,hashlib
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence/table-repair';OUT.mkdir(exist_ok=False)
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
 report=[]
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=CHROME,headless=True)
  page=await b.new_page(viewport={'width':1440,'height':900});page.on('dialog',lambda d:d.accept())
  await page.goto('http://127.0.0.1:4409/');await page.wait_for_selector('.tc-tiddler-frame')
  await page.evaluate("()=>{$tw.wiki.setText('$:/language','text',null,'$:/languages/en-GB');$tw.wiki.setText('$:/palette','text',null,'$:/palettes/VanillaPaperDay')}")
  for title,accessible in [('Evidence ledger','Evidence table / 证据表'),('Observation log — East entrance','Observation table / 观察表'),('Prototype comparison — signs and landmarks','Prototype comparison / 原型比较')]:
   original=await page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',title)
   lines=original.splitlines();starts=[i for i,l in enumerate(lines) if l.startswith('|')]
   assert starts and starts==list(range(starts[0],starts[-1]+1))
   source_rows=lines[starts[0]:starts[-1]+1]
   revised='\n'.join(lines[:starts[0]]+['<div class="tc-table-wrapper" tabindex="0" role="region" aria-label="'+accessible+'">','']+source_rows+['','</div>']+lines[starts[-1]+1:])+'\n'
   await page.locator('[data-tiddler-title="Fieldnotes — project index"]').get_by_role('link',name=title,exact=True).click()
   note=page.locator('[data-tiddler-title="'+title+'"]')
   original_cells=await note.locator('table').inner_text()
   await note.get_by_role('button',name='Edit this tiddler',exact=True).click()
   editor=page.frame_locator('iframe.tc-edit-texteditor-body').locator('textarea')
   await editor.fill(revised)
   await page.get_by_role('button',name='Confirm changes to this tiddler',exact=True).click()
   await page.wait_for_timeout(700)
   assert await note.locator('table').inner_text()==original_cells
   assert await note.locator('.tc-table-wrapper').count()==1
   report.append({'title':title,'source_wrapper':'$:/themes/BurningTreeC/vanilla-paper/2-structure','table_cells_unchanged':True,'original_sha256':hashlib.sha256(original.encode()).hexdigest(),'updated_sha256':hashlib.sha256(revised.encode()).hexdigest()})
  await page.reload();await page.wait_for_selector('.tc-tiddler-frame')
  for item in report:
   content=await page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',item['title'])
   assert 'tc-table-wrapper' in content
   item['reload_verified']=True
  await b.close()
 (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
asyncio.run(main())

