import asyncio,json,re,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w09');OUT=ROOT/'evidence/delivery';OUT.mkdir(exist_ok=False)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True)
  page=await b.new_page(viewport={'width':1280,'height':640},device_scale_factor=1);page.set_default_timeout(5000)
  await page.goto('http://127.0.0.1:4409/');await page.wait_for_selector('.tc-tiddler-frame');await page.wait_for_timeout(600)
  cp=page.locator('[data-tiddler-title="$:/ControlPanel"]')
  if not await cp.count():await page.get_by_role('button',name='control panel',exact=True).click()
  await page.wait_for_timeout(500)
  buttons=await cp.get_by_role('button').all_text_contents();print(json.dumps({'actualControlPanelButtons':buttons}))
  await cp.get_by_role('button',name=re.compile('^appearance$',re.I)).click();await page.wait_for_timeout(600)
  await page.screenshot(path=str(OUT/'native-appearance.png'))
  await page.evaluate("""()=>{$tw.wiki.setText('$:/palette','text',null,'$:/palettes/VanillaPaperDay');$tw.wiki.setText('$:/language','text',null,'$:/languages/en-GB');$tw.wiki.setText('$:/StoryList','list',null,['Fieldnotes — project index','访谈笔记 — 傍晚通勤']);$tw.wiki.setText('$:/state/sidebar','text',null,'yes')}""")
  await page.wait_for_timeout(700);await page.set_viewport_size({'width':1440,'height':900});await page.reload();await page.wait_for_selector('.tc-tiddler-frame');await page.wait_for_timeout(800);await page.screenshot(path=str(OUT/'delivery-entry.png'))
  report=await page.evaluate("""()=>({theme:$tw.wiki.getTiddlerText('$:/theme'),palette:$tw.wiki.getTiddlerText('$:/palette'),language:$tw.wiki.getTiddlerText('$:/language'),story:$tw.wiki.getTiddlerList('$:/StoryList'),drafts:$tw.wiki.filterTiddlers('[has[draft.of]]'),rootOverflow:document.documentElement.scrollWidth>innerWidth})""")
  assert report['theme']=='$:/themes/BurningTreeC/vanilla-paper' and not report['drafts'] and not report['rootOverflow'];(OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False));await b.close()
asyncio.run(main())
