import json,shutil,subprocess,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
WIKI=ROOT/'app/wiki'
def tid(file,title,text):
 (WIKI/'tiddlers'/file).write_text('title: '+title+'\n\n'+text+'\n')
seed=ROOT/'evidence/seed'
if not seed.exists(): shutil.copytree(WIKI,seed)
for label,source in [('vanilla-paper','paper-source/themes/BurningTreeC/vanilla-paper'),('notebook','notebook-source/themes/notebook')]:
 target=WIKI/'themes'/label
 if not target.exists():shutil.copytree(ROOT/'evidence/research'/source,target)
shutil.copy2(ROOT/'evidence/research/paper-source/LICENSE',WIKI/'themes/vanilla-paper/LICENSE')
mobile=WIKI/'plugins/notebook-mobile'
if not mobile.exists():shutil.copytree(ROOT/'evidence/research/notebook-source/plugins/notebook-mobile',mobile)
tid('fieldnotes-theme.tid','$:/theme','$:/themes/nico/notebook')
tid('config-04.tid','$:/palette','$:/themes/nico/notebook/palettes/palette-beige')
sources={}
for name in ['paper','notebook']:
 path=ROOT/('evidence/research/'+name+'-source')
 sources[name]={'source':subprocess.check_output(['git','remote','get-url','origin'],cwd=path,text=True).strip(),'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip(),'license':'MIT','files':{str(f.relative_to(path)):hashlib.sha256(f.read_bytes()).hexdigest() for f in path.rglob('*') if f.is_file() and '.git' not in f.parts}}
(ROOT/'evidence/research/source-identities.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2))
print(json.dumps({k:{x:v[x] for x in ['source','revision','license']} for k,v in sources.items()},indent=2))
print('Notebook same-content trial configured; server must restart.')

