import json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];T=ROOT/'app/wiki/tiddlers'
saved=ROOT/'evidence/config-repair';saved.mkdir(exist_ok=False)
desired={'$:/theme':('fieldnotes-theme.tid','$:/themes/BurningTreeC/vanilla-paper'),'$:/palette':('config-04.tid','$:/palettes/VanillaPaperDay'),'$:/language':('config-05.tid','$:/languages/en-GB')}
for name,value in {'toolbaralways':'yes','stickytitles':'yes'}.items():desired['$:/themes/BurningTreeC/vanilla-paper/options/'+name]=('fieldnotes-paper-option-'+name+'.tid',value)
for name,value in {'fontsize':'0.9375rem','lineheight':'1.6','bodyfontsize':'1.0625rem','bodylineheight':str(30/17)}.items():desired['$:/themes/BurningTreeC/vanilla-paper/metrics/'+name]=('fieldnotes-paper-metric-'+name+'.tid',value)
removed=[]
for p in list(T.glob('*.tid')):
 head=p.read_text().split('\n\n',1)[0];titles=[l[7:] for l in head.splitlines() if l.startswith('title: ')]
 if titles and titles[0] in desired:
  shutil.copy2(p,saved/p.name);removed.append({'file':p.name,'title':titles[0]});p.unlink()
for title,(file,text) in desired.items():(T/file).write_text('title: '+title+'\n\n'+text)
(saved/'repair.json').write_text(json.dumps({'removed_backed_up_files':removed,'values':desired,'cause':'Exact theme and option values incorrectly included trailing newline; duplicate trial files also existed.'},ensure_ascii=False,indent=2))
with (ROOT/'DESIGN-MODEL.md').open('a') as f:f.write('\n## Revision — configuration fidelity repair\nFinal-v1 screenshots were personally viewed and showed the native Vanilla layout despite the Paper palette. The stored theme identifier had a trailing newline, while exact theme resolution requires the actual title. This was an integration defect, not source quality. The theme and option configuration bodies are now exact strings without trailing newlines; duplicate trial configuration files were backed up and removed while the server was stopped. Final-v1 remains failed evidence. A separate test assumption was corrected: the native filesystem adaptor renames a saved note to its title-based filename, so persistence checks resolve by tiddler title. Final-v2 must re-establish selected-source appearance and complete task verification.\n')
print(json.dumps({'repaired':list(desired),'backed_up':removed},ensure_ascii=False,indent=2))

