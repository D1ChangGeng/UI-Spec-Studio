import json,shutil,hashlib,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];WIKI=ROOT/'app/wiki'
def tid(file,title,text):
 (WIKI/'tiddlers'/file).write_text('title: '+title+'\n\n'+text+'\n')
for target in [WIKI/'themes/notebook',WIKI/'plugins/notebook-mobile']:
 if target.exists():shutil.rmtree(target)
tid('fieldnotes-theme.tid','$:/theme','$:/themes/BurningTreeC/vanilla-paper')
tid('config-04.tid','$:/palette','$:/palettes/VanillaPaperDay')
base='$:/themes/BurningTreeC/vanilla-paper/'
options={'toolbaralways':'yes','stickytitles':'yes'}
metrics={'fontsize':'0.9375rem','lineheight':'1.6','bodyfontsize':'1.0625rem','bodylineheight':str(30/17)}
for k,v in options.items():tid('fieldnotes-paper-option-'+k+'.tid',base+'options/'+k,v)
for k,v in metrics.items():tid('fieldnotes-paper-metric-'+k+'.tid',base+'metrics/'+k,v)
for name in ['Day','Night']:
 source=WIKI/'themes/vanilla-paper'/('VanillaPaper'+name+'.tid')
 lines=source.read_text().splitlines()
 changed=[]
 for i,line in enumerate(lines):
  key=line.split(':',1)[0]
  if key in ['tiddler-controls-foreground','sidebar-controls-foreground','tiddler-subtitle-foreground']:
   changed.append({'key':key,'old':line,'new':key+': <<colour sidebar-foreground>>'})
   lines[i]=key+': <<colour sidebar-foreground>>'
 (WIKI/'tiddlers'/('fieldnotes-palette-'+name.lower()+'.tid')).write_text('\n'.join(lines)+'\n')
 print(name,json.dumps(changed))
src=ROOT/'evidence/research/paper-source/themes/BurningTreeC/vanilla-paper';dst=WIKI/'themes/vanilla-paper'
mismatches=[str(f.relative_to(src)) for f in src.rglob('*') if f.is_file() and f.read_bytes()!=(dst/f.relative_to(src)).read_bytes()]
assert not mismatches,mismatches
notes=[]
for f in sorted((WIKI/'tiddlers').glob('note-*.tid')):
 original=(ROOT/'evidence/seed/tiddlers'/f.name).read_bytes()
 assert f.read_bytes()==original,f
 notes.append({'file':str(f.relative_to(ROOT)),'sha256':hashlib.sha256(original).hexdigest()})
record={'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT/'evidence/research/paper-source',text=True).strip(),'unchanged_theme_files':len(list(src.rglob('*'))),'source_mismatches':mismatches,'configuration':{'options':options,'metrics':metrics},'palette_adaptation':'Three foreground roles inherit each palette sidebar-foreground token; original palette identity retained.','notes_unchanged':notes,'notebook_removed_from_runtime':True}
(ROOT/'evidence/research/adoption-integrity.json').write_text(json.dumps(record,indent=2))
(ROOT/'DELEGATION.json').write_text(json.dumps({'children':[],'reason':'ALLOCATION.md explicitly requires no delegation.','requested_model_settings':None,'native_role_bindings':None,'resolved_backend_identity':None,'tokens':None,'billed_cost':None},indent=2))
with (ROOT/'DESIGN-MODEL.md').open('a') as f:
 f.write('''
## Revision — selected Paper after same-content trial
The viewed 1440px interview and editor retain Paper's margin, serif reading, separate sans chrome and ruled mono editing. Notebook's topbar is a useful compact alternative but its sans reading surface creates less distinction between content and operation. Tufte CSS's local original publication demo was viewed as a cross-domain reference: strong measure and typographic roles support sustained reading, but its article/sidenote model does not supply native editable workspace behavior; none of its implementation or font assets are adopted.
Selected: Paper 0.10.0 from revision 031a78d4d4187128c632f8a647fa05408eddc700. The complete theme is installed unchanged under app/wiki/themes/vanilla-paper with its MIT notice. Notebook is retained only as research source, removed from runtime.
Supported configuration keeps note toolbars always visible and titles sticky. Existing numeric text metrics are expressed equivalently in rem/unitless units to respect user scaling without replacing the source type relationships. The existing Day/Night palettes are copied under their original titles with three narrow foreground-role changes to source sidebar-foreground for more legible note actions and timestamps; no new colors are invented.
A narrow editor trial capture after resizing displayed the index at the old scroll offset, rather than the intended editor. This is retained as a failed capture condition, not passed editing evidence. Final checks must set viewport before native navigation/editing and capture the actual draft.
Next: final source selection must pass native persistence, cancel, keyboard search, complete interview/ledger/return, both palettes and required viewports. Sticky titles need assembled inspection, particularly at 390px.
''')
print(json.dumps(record,indent=2))

