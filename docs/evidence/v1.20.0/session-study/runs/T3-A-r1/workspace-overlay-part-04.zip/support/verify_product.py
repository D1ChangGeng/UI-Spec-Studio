import asyncio,json,time,hashlib,traceback
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence/final-v1';OUT.mkdir(parents=True,exist_ok=True)
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
URL='http://127.0.0.1:4409/';TITLE='访谈笔记 — 傍晚通勤';INDEX='Fieldnotes — project index'
report={'conditions':{'browser':CHROME,'fontconfig':'/tmp/ui-spec-fonts/fonts.conf','scale':1},'steps':[],'captures':[],'requests':[],'errors':[]}
def save(): (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
def step(name,**kw): report['steps'].append({'name':name,'time':time.monotonic(),**kw});save()
def body(path):return path.read_text().split('\n\n',1)[1].rstrip('\n')
def sha(s):return hashlib.sha256(s.encode()).hexdigest()
async def text(page,title):return await page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',title)
async def label(page,name):return (await text(page,'$:/language/Buttons/'+name+'/Hint')).strip()
async def screenshot(page,name):
 await page.evaluate('document.fonts.ready')
 start=time.monotonic();await page.screenshot(path=str(OUT/(name+'.png')));end=time.monotonic()
 info=await page.evaluate("""() => ({theme:$tw.wiki.getTiddlerText('$:/theme'),palette:$tw.wiki.getTiddlerText('$:/palette'),language:$tw.wiki.getTiddlerText('$:/language'),reduced:matchMedia('(prefers-reduced-motion: reduce)').matches,scrollY:scrollY,viewport:[innerWidth,innerHeight],scrollWidth:document.documentElement.scrollWidth,font:document.querySelector('.tc-tiddler-body')?getComputedStyle(document.querySelector('.tc-tiddler-body')).fontFamily:null,focus:{tag:document.activeElement.tagName,aria:document.activeElement.getAttribute('aria-label'),class:document.activeElement.className},drafts:$tw.wiki.filterTiddlers('[has[draft.of]]'),animations:document.getAnimations().map(x=>({state:x.playState,time:x.currentTime})),nodes:document.querySelectorAll('*').length})""")
 report['captures'].append({'file':name+'.png','start':start,'end':end,**info});save()
async def navigate(page,title,from_title=INDEX):
 frame=page.locator('[data-tiddler-title="'+from_title+'"]')
 await frame.get_by_role('link',name=title,exact=True).first.click()
 await page.wait_for_timeout(480)
 return page.locator('[data-tiddler-title="'+title+'"]')
async def edit(page,title=TITLE):
 note=page.locator('[data-tiddler-title="'+title+'"]')
 await note.get_by_role('button',name=await label(page,'Edit'),exact=True).click()
 await page.wait_for_selector('iframe.tc-edit-texteditor-body')
 await page.wait_for_timeout(220)
 return page.frame_locator('iframe.tc-edit-texteditor-body').locator('textarea')
async def cancel(page):
 await page.get_by_role('button',name=await label(page,'Cancel'),exact=True).click()
 await page.wait_for_timeout(400)
async def confirm(page):
 await page.get_by_role('button',name=await label(page,'Save'),exact=True).click()
 await page.wait_for_timeout(350)
async def disk_matches(expected):
 for i in range(150):
  actual=body(ROOT/'app/wiki/tiddlers/note-04.tid')
  if actual==expected.rstrip('\n'):return actual
  await asyncio.sleep(.1)
 raise AssertionError('disk did not match expected text after 15s')
async def config(page,palette='Day',locale='en-GB'):
 await page.evaluate("""([palette,locale])=>{$tw.wiki.setText('$:/palette','text',null,'$:/palettes/VanillaPaper'+palette);$tw.wiki.setText('$:/language','text',null,'$:/languages/'+locale);$tw.wiki.setText('$:/state/sidebar','text',null,'yes');$tw.wiki.setText('$:/StoryList','list',null,['Fieldnotes — project index','访谈笔记 — 傍晚通勤']);}""",[palette,locale])
 await page.wait_for_timeout(400);await page.reload();await page.wait_for_selector('.tc-tiddler-frame');await page.evaluate('document.fonts.ready')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=CHROME,headless=True)
  context=await browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1,record_video_dir=str(OUT/'video'),record_video_size={'width':1440,'height':900})
  page=await context.new_page();page.set_default_timeout(10000)
  page.on('dialog',lambda d:d.accept())
  page.on('pageerror',lambda e:report['errors'].append(str(e)))
  page.on('response',lambda r: report['requests'].append({'time':time.monotonic(),'method':r.request.method,'url':r.url,'status':r.status}))
  try:
   await page.goto(URL);await page.wait_for_selector('.tc-tiddler-frame')
   await config(page);await screenshot(page,'01-entry-day-1440')
   note=await navigate(page,TITLE);await screenshot(page,'02-interview-start')
   original=await text(page,TITLE)
   assert original.rstrip('\n')==body(ROOT/'evidence/seed/tiddlers/note-04.tid')
   for number,heading in [(3,'同一路线的不同体验'),(4,'A final unresolved question')]:
    await note.get_by_role('heading',name=heading,exact=True).scroll_into_view_if_needed()
    await screenshot(page,f'{number:02}-interview-scroll')
   assert await note.get_by_text('如果标志必须很少',exact=False).is_visible()
   step('complete-interview-reading',source_text_sha256=sha(original),last_paragraph_visible=True)
   ledger=await navigate(page,'Evidence ledger',TITLE)
   assert await ledger.locator('table').count()==1
   await screenshot(page,'05-evidence-ledger')
   note=await navigate(page,TITLE,'Evidence ledger')
   await screenshot(page,'06-return-interview')
   step('linked-ledger-return',table_rows=await ledger.locator('tr').count(),returned_to=TITLE)
   editor=await edit(page)
   modified=original.replace('The bakery window mattered because','The narrow bakery window mattered because').replace('我们需要保留这种条件差异。','我们需要明确保留这种条件差异。')
   assert modified!=original
   await editor.fill(modified);await screenshot(page,'07-edit-bilingual')
   await confirm(page);disk=await disk_matches(modified)
   (OUT/'persisted-after-edit.tid').write_bytes((ROOT/'app/wiki/tiddlers/note-04.tid').read_bytes())
   await page.reload();await page.wait_for_selector('.tc-tiddler-frame')
   assert (await text(page,TITLE))==modified
   step('save-reload-persistence',passed=True,browser_sha256=sha(modified),disk_body_sha256=sha(disk),english_change='The narrow bakery window mattered because',chinese_change='我们需要明确保留这种条件差异。')
   await navigate(page,TITLE)
   editor=await edit(page);await editor.fill(original);await confirm(page)
   await disk_matches(original);await page.reload();await page.wait_for_selector('.tc-tiddler-frame')
   assert await text(page,TITLE)==original
   step('restore-original-through-native-editor',passed=True,sha256=sha(original))
   await navigate(page,TITLE)
   editor=await edit(page);await editor.fill(original+'\nUNSAVED-CANCEL-PROBE')
   await cancel(page)
   assert await text(page,TITLE)==original
   assert 'UNSAVED-CANCEL-PROBE' not in (ROOT/'app/wiki/tiddlers/note-04.tid').read_text()
   await screenshot(page,'08-cancel-retains-note');step('cancel-edit',passed=True)
   await page.keyboard.press('Control+Shift+F')
   assert await page.locator('.tc-search input').evaluate('(e)=>e===document.activeElement')
   await page.keyboard.type('Quiet route — working draft')
   await page.wait_for_timeout(600);await page.keyboard.press('ArrowDown');await page.keyboard.press('Control+Enter')
   await page.wait_for_selector('iframe.tc-edit-texteditor-body')
   drafts=await page.evaluate("$tw.wiki.filterTiddlers('[has[draft.of]]').map(t=>$tw.wiki.getTiddler(t).fields['draft.of'])")
   assert 'Quiet route — working draft' in drafts,drafts
   await screenshot(page,'09-keyboard-search-editor')
   step('keyboard-search-to-editor',passed=True,keys=['Control+Shift+F','typed exact title','ArrowDown','Control+Enter'],draft_of=drafts)
   await cancel(page)
   # Capture the two UI locales, two palettes and all supplied viewports.
   for palette in ['Day','Night']:
    for locale in ['en-GB','zh-Hans']:
     for w,h in [(1440,900),(1280,640),(390,844)]:
      await page.set_viewport_size({'width':w,'height':h});await page.emulate_media(reduced_motion='no-preference')
      await config(page,palette,locale)
      note=await navigate(page,TITLE)
      name=f'matrix-{palette.lower()}-{locale}-{w}'
      await screenshot(page,name+'-read')
      assert (await page.evaluate('document.documentElement.scrollWidth'))<=w
      editor=await edit(page)
      # Native navigation is performed after setting the viewport. Keep the actual draft in frame.
      draft=page.locator('.tc-tiddler-frame').filter(has=page.locator('iframe.tc-edit-texteditor-body'))
      await draft.evaluate("(e)=>e.scrollIntoView({block:'start'})")
      await screenshot(page,name+'-edit')
      assert await editor.input_value()==original
      assert (await page.evaluate('document.documentElement.scrollWidth'))<=w
      await cancel(page)
   step('matrix',passed=True,viewports=[[1440,900],[1280,640],[390,844]],palettes=['Day','Night'],locales=['en-GB','zh-Hans'],states=['read','edit'])
   # Long dark reading, and scoped table horizontal overflow on narrow screens.
   await page.set_viewport_size({'width':390,'height':844});await config(page,'Night','zh-Hans')
   note=await navigate(page,TITLE)
   await note.get_by_role('heading',name='A final unresolved question',exact=True).scroll_into_view_if_needed()
   await screenshot(page,'10-night-long-reading-end')
   ledger=await navigate(page,'Evidence ledger',TITLE)
   await screenshot(page,'11-night-narrow-ledger')
   step('narrow-ledger',table=await ledger.locator('table').evaluate('(e)=>({client:e.clientWidth,scroll:e.scrollWidth,overflow:getComputedStyle(e).overflowX})'))
   # Actual sidebar toggle episodes, with capture-time brackets, normal and reduced.
   await page.set_viewport_size({'width':1440,'height':900});await config(page)
   await navigate(page,TITLE)
   for motion in ['no-preference','reduce']:
    await page.emulate_media(reduced_motion=motion)
    await screenshot(page,'motion-'+motion+'-before')
    button=page.get_by_role('button',name='hide sidebar',exact=True)
    await button.click()
    for offset in [0,70,300]:
     await page.wait_for_timeout(offset)
     await screenshot(page,'motion-'+motion+'-'+str(offset))
    await page.get_by_role('button',name='show sidebar',exact=True).click()
    await page.wait_for_timeout(500)
    await screenshot(page,'motion-'+motion+'-returned')
   step('motion-episodes',passed=True,claim='ordered screenshots and actual control operation; natural-time playback not inspected')
   await page.emulate_media(reduced_motion='reduce')
   await page.set_viewport_size({'width':390,'height':844});await config(page,'Night','zh-Hans')
   await navigate(page,TITLE);await screenshot(page,'12-reduced-night-narrow-read')
   await edit(page);await screenshot(page,'13-reduced-night-narrow-edit');await cancel(page)
   # Restore delivered initial state and collect runtime cost.
   await page.emulate_media(reduced_motion='no-preference');await page.set_viewport_size({'width':1440,'height':900});await config(page)
   await screenshot(page,'14-final-entry')
   report['runtime']=await page.evaluate("""()=>({navigation:performance.getEntriesByType('navigation').map(n=>({duration:n.duration,encodedBodySize:n.encodedBodySize,decodedBodySize:n.decodedBodySize,domContentLoaded:n.domContentLoadedEventEnd})),resources:performance.getEntriesByType('resource').map(x=>({name:x.name,bytes:x.transferSize})),heap:performance.memory?{used:performance.memory.usedJSHeapSize,total:performance.memory.totalJSHeapSize}:null})""")
   report['external_product_requests']=[x for x in report['requests'] if not x['url'].startswith(URL)]
   assert not report['external_product_requests']
   report['result']='pass';save()
  except Exception as e:
   report['result']='fail';report['exception']=traceback.format_exc();save()
   await page.screenshot(path=str(OUT/'failure.png'))
   raise
  finally:
   await context.close();await browser.close();save()
  print(json.dumps({'result':report['result'],'steps':report['steps'],'capture_count':len(report['captures']),'errors':report['errors'],'runtime':report.get('runtime')},ensure_ascii=False,indent=2))
asyncio.run(main())

