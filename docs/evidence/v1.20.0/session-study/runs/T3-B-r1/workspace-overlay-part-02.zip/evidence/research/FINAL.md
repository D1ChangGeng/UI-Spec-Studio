# Fieldnotes — source and experience research

Research-only report, 31 October 2026. No product code was changed and no final product design was selected.

## Decision-useful result

**Notebook is a credible whole-workspace trial; Captivate is a materially different whole-workspace challenge; Tufte CSS is a strong editorial reference with a narrower adoption scope.** The important distinction is which source supplies the complete reading/editing/navigation relationship. A type treatment alone does not supply that relationship.

The supplied baseline already has a complete native working model. Its viewed 1440×900 index gives a very broad reading panel beside the right sidebar. Notebook replaces that allocation with a centered paper stack and a collapsible left navigation region. Captivate uses a full-width application frame and a separate floating action rail. These are meaningful composition alternatives; their short English demos do not establish how either handles the full bilingual interview.

## Sources, observed relationships and practical routes

### 1. Notebook — centered paper workspace

- Primary source: [NicolasPetton/Notebook](https://github.com/NicolasPetton/Notebook), revision `465c832c885894ee3c97be76449cc524e1252eb0`, theme 1.4.1; repository metadata reports archived.
- Original demo snapshot: [maintained public Notebook demo](https://saqimtiaz.github.io/sq-tw/notebook.html), using TiddlyWiki core 5.3.3. Its desktop/mobile arrangement and three palettes are also described by the official TiddlyWiki community listing. genui{"citation":{"ref":"turn4view2"}}
- Rights: MIT, retained in `notebook-license.txt`; full original HTML and HTTP metadata retained. Demo SHA-256: `6d27fac424ee7fd20b35e9268fb75b4547cfbafe70b8d7536217f74781ee118b`.
- Available adoption item: `notebook-installable.json`, unchanged extraction of `$:/themes/nico/notebook` 1.4.1 and `$:/plugins/nico/notebook-mobile` 1.0.0. This is source acquisition, not product installation.

**Actually viewed:** At 1440×900 the light demo uses an approximately 800-pixel paper stack, warm off-white surrounding ground, thin edges, soft shadows, bold sans-serif titles, and quieter dates and per-note controls. The compact toolbar aligns to the paper edges. Opening the menu reveals a roughly 350-pixel left navigation region and moves the paper composition right while retaining its width. At 390×844 the papers become a contiguous reading surface and the main toolbar moves to the bottom.

The original dark variant retains the geometry and changes the surrounding ground, paper, text, links and input surfaces coherently. The settled editor keeps the same note boundary, with the title, formatting controls and writing area visibly grouped inside it. This supplies actual visual relationships across reading and editing, not merely a palette.

**Adoption path:** Use the theme and mobile plugin unchanged as the trial foundation; select its actual beige/dark palettes and supported theme metrics/font/editor settings. Preserve the theme's paper width, navigation relationship, type hierarchy and restrained depth. Isolate concrete compatibility fixes by original tiddler identity. Test the long interview, evidence table, keyboard focus, narrow editor and authoritative save/reload before expanding claims.

**Observed cautions:** Source DOM exposes malformed `</svg` text in the palette control. A palette-menu-to-editor attempt encountered pointer interception; its log is retained rather than treated as a successful journey. An early 250-millisecond editor frame contained overlapping transition layers; a later 1000-millisecond settled capture does not show that overlap. This supports checking the transition separately from the resting editor. Pale utility icons in both themes merit actual contrast/focus checks; this research does not claim accessibility acceptance.

### 2. Captivate — stronger application framing

- Primary source: [cdruan/tw5-captivate](https://github.com/cdruan/tw5-captivate), `main`; acquired original demo contains theme `$:/themes/cdr/captivate` 0.2.1, requiring core 5.2.0 or later and declaring Vanilla plus `$:/plugins/cdr/colorlab` dependencies.
- Original demo: [Captivate](https://cdruan.github.io/tw5-captivate/). The author documents selectable layouts and light, dark and tan color variations. genui{"citation":{"ref":"turn3search2"}}
- Rights: MIT, retained in `captivate-license.txt`. The exact acquired demo is pinned by SHA-256 `99b76226483df4057cdb9578c78f1dd6c417ae08252fbdcfde4cb95494d05237`; repository HEAD was not independently pinned.

**Actually viewed:** The light demo has a lavender full-frame ground, a compact identity/menu at top left, search at top right, a wider centered rounded paper, and separate circular home/new/settings/save actions down the right. Selecting the visible Dark Theme radio produces a deep navy ground and lighter blue paper while retaining the rails and hierarchy.

**Why this challenges Notebook:** Tools and workspace identity remain more explicit around the reading object. That could help frequent navigation and creation, while Notebook gives more attention to the document itself. This is a task-fit inference, not a measured preference. Captivate's short demo leaves large empty areas; that occupancy is not fairly comparable with the populated Fieldnotes index.

**Adoption path and limits:** Trial the complete Captivate theme with its declared ColorLab dependency and a source-provided color scheme. Preserve the frame/rail/paper system. Confirm installed dependency versions and licenses from the repository before adoption. Long mixed-language reading, editing, narrow layout, focus and TiddlyWiki 5.4.1 compatibility remain untested here.

### 3. Tufte — editorial typography and nearby evidence

Two different sources must remain distinct:

- [Tufte CSS](https://edwardtufte.github.io/tufte-css/), [source](https://github.com/edwardtufte/tufte-css), MIT CSS license retained. The official source describes ETBook, article/section structure and margin-note conventions. genui{"citation":{"refs":["turn4view1","turn3search5"]}}
- [TiddlyWiki Tufte container demo](https://tufte-style.tiddlyhost.com/), acquired and rendered separately. Its redistribution terms were not established; Tufte CSS's MIT license cannot be assumed to cover this distinct implementation.

**Actually viewed:** The original Tufte CSS page uses warm paper, dark serif body text, a large restrained title, italic author/section roles and a generous right margin. The sidenote view places a small numbered annotation alongside the relevant paragraph, preserving the paragraph's reading continuity. The TiddlyWiki container demo retains the native right sidebar and reserves substantial horizontal space next to a narrow text column; it does not provide the richer type system or a new complete editor shell.

**Adoption scope:** Tufte CSS can inform or supply a bounded article-reading treatment, subject to exact source/font terms and a scoped integration trial. Its margin-note markup is additional content structure; Fieldnotes' existing evidence links do not automatically become sidenotes. A global stylesheet transplant would risk changing controls and consuming too much reading width. It is not yet an evidenced whole-workspace alternative under this task's native editor and bilingual requirements.

## Questions changed by the observations

The initial inquiry was whether an editorial workspace needed a more literary typeface. The viewed sources shift the higher-value question to **how the reading object, tools and related notes share space**. Notebook already supplies that connected composition. Captivate tests a more visible application frame. Tufte shows that scholarly character can come from paragraph/annotation relationships, but adopting it here would require additional evidence about actual annotation needs and mixed-script typography.

The next useful trial is therefore populated source fidelity: retain a candidate's defining relationships while running interview → ledger → return → edit → save → reload. The parent designer owns that trial and the final choice.

## Evidence and limits

All research material is under `evidence/research/`:

- `search-001.json`, `open-002.json`, `search-003.json`, `open-004.json`: original returned search/open objects, including access failures.
- `commands/001-fetch`, `003-extract`, `004-capture`, `005-variants`, `006-final-captures`, `007-final-captures`, `008-settled`: exact command outputs, parameters and success/failure records.
- `captures/`: real original-demo renders; `view-*.json` and `view-final-set.json` retain actual image-tool responses for the pixels personally viewed.
- Primary viewed captures: `notebook-1440.png`, `notebook-390.png`, `notebook-sidebar.png`, `notebook-dark-settled.png`, `notebook-dark-editor-settled.png`, `captivate-1440.png`, `captivate-dark-1440.png`, `tufte-1440.png`, `tufte-css-1440.png`, `tufte-css-sidenotes-1440.png`.
- The supplied product baseline was personally viewed from `evidence/baseline-current/light-1440.png`. A local-server observation attempt returned connection refused during the parent's restart/trial interval; no live-baseline journey is claimed.

Captures use the supplied Chromium 143 headless shell, device scale 1 and Noto CJK host fixture. Public demos were downloaded faithfully and locally rendered. Notebook's final dark view uses the source's existing palette selected through its native in-memory configuration; it establishes a static variant, not successful palette-menu operation. Captivate dark uses the actual visible radio. Tufte CSS uses the original HTML/CSS and downloaded source font assets; external embedded media was not awaited and is outside the inspected first/annotation views.

The complete eight common method references, evidence map and action guidance were read. No product persistence, reduced-motion behavior, natural-speed animation, user preference or complete accessibility result was verified by this research. Material's public demo returned HTTP 503; it was replaced in the comparison by the successfully acquired and viewed Captivate source. No original visual substitute or W1–W3 exception was introduced.

