import json,pathlib,os,time
from playwright.sync_api import sync_playwright
ROOT=pathlib.Path(__file__).resolve().parent
OUT=ROOT/'captures';OUT.mkdir(exist_ok=True)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for name,url in [('notebook',(ROOT/'notebook-demo.html').as_uri()),('tufte',(ROOT/'tufte-demo.html').as_uri()),('baseline','http://127.0.0.1:4410/')]:
  context=browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
  page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  try:
   page.goto(url,wait_until='load');page.wait_for_function('document.fonts.status === "loaded"');page.wait_for_timeout(500)
   page.screenshot(path=str(OUT/(name+'-1440.png')))
   data={'name':name,'url':url,'title':page.title(),'captured_at':time.time(),'viewport':{'width':1440,'height':900},'text':page.locator('body').inner_text(),'buttons':page.locator('button').evaluate_all('(els)=>els.map(e=>({title:e.title,aria:e.getAttribute("aria-label"),text:e.innerText,classes:e.className}))'),'errors':errors}
   (ROOT/(name+'-dom.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2));print(name,json.dumps({k:v for k,v in data.items() if k not in ['text']},ensure_ascii=False))
   if name=='notebook':
    page.set_viewport_size({'width':390,'height':844});page.screenshot(path=str(OUT/'notebook-390.png'))
  except Exception as e: print(name,'ERROR',str(e))
  context.close()
 browser.close()
