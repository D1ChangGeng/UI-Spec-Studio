import json,pathlib,urllib.request,urllib.parse,re,concurrent.futures,hashlib,time
from playwright.sync_api import sync_playwright
ROOT=pathlib.Path(__file__).resolve().parent;OUT=ROOT/'captures';TF=ROOT/'tufte-css-original';TF.mkdir(exist_ok=True)
base='https://edwardtufte.github.io/tufte-css/'
html=(ROOT/'tufte-css-demo.html').read_bytes();(TF/'index.html').write_bytes(html)
def fetch(rel):
 try:
  with urllib.request.urlopen(urllib.parse.urljoin(base,rel),timeout=12) as r:data=r.read();status=r.status
  target=TF/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);result={'relative':rel,'status':status,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 except Exception as e:result={'relative':rel,'error':str(e)}
 print(result,flush=True);return result
fetch('tufte.css')
css=(TF/'tufte.css').read_text();assets=re.findall(r'url\(["\']?([^\)"\']+)',css);assets=[x for x in assets if not x.startswith('data:')]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: results=list(pool.map(fetch,assets))
(ROOT/'tufte-css-assets.json').write_text(json.dumps(results,indent=2))
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 context=browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1);page=context.new_page();page.goto((ROOT/'notebook-demo.html').as_uri());page.wait_for_function('document.fonts.status==="loaded"')
 page.locator('button[class*="SwitchPalette"]:visible').last.click();print('Palette choices',page.locator('.tc-drop-down:visible').inner_text(),flush=True);page.locator('.tc-drop-down:visible button').filter(has_text=re.compile('dark',re.I)).first.click();page.wait_for_timeout(850);page.screenshot(path=str(OUT/'notebook-dark-1440.png'));print('Selected palette',page.evaluate('$tw.wiki.getTiddlerText("$:/palette")'),flush=True)
 page.locator('button[title="Edit this tiddler"]:visible').first.click();page.wait_for_timeout(900);page.screenshot(path=str(OUT/'notebook-editor-settled-dark.png'));print('editor settled',page.locator('input.tc-titlebar').count(),flush=True);context.close()
 context=browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1);page=context.new_page();page.goto((TF/'index.html').as_uri());page.wait_for_function('document.fonts.status==="loaded"');page.screenshot(path=str(OUT/'tufte-css-1440.png'));print('tufte fonts',page.locator('p').first.evaluate('(e)=>({font:getComputedStyle(e).fontFamily,width:e.getBoundingClientRect().width})'),flush=True);page.locator('#sidenotes').scroll_into_view_if_needed();page.screenshot(path=str(OUT/'tufte-css-sidenotes-1440.png'));context.close()
 context=browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1);page=context.new_page();page.goto((ROOT/'captivate-demo.html').as_uri());page.wait_for_function('document.fonts.status==="loaded"');page.get_by_label('Dark Theme',exact=True).check();page.wait_for_timeout(850);page.screenshot(path=str(OUT/'captivate-dark-1440.png'));context.close();browser.close()
