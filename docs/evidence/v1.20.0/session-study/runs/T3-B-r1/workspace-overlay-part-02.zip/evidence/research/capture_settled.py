import json,pathlib,time
from playwright.sync_api import sync_playwright
ROOT=pathlib.Path(__file__).resolve().parent;OUT=ROOT/'captures'
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for name,file in [('notebook','notebook-demo.html'),('tufte-css','tufte-css-original/index.html'),('captivate','captivate-demo.html')]:
  context=browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1);page=context.new_page();page.set_default_timeout(8000)
  try:
   page.goto((ROOT/file).as_uri(),wait_until='domcontentloaded');page.wait_for_function('document.fonts.status==="loaded"')
   if name=='notebook':
    page.evaluate('$tw.wiki.setText("$:/palette","text",null,"$:/themes/nico/notebook/palettes/palette-dark")');page.wait_for_timeout(850);page.screenshot(path=str(OUT/'notebook-dark-settled.png'));print('Notebook controlled original dark palette static state',flush=True)
    page.locator('button[title="Edit this tiddler"]:visible').first.click();page.wait_for_timeout(1000);page.screenshot(path=str(OUT/'notebook-dark-editor-settled.png'))
   elif name=='tufte-css':
    page.screenshot(path=str(OUT/'tufte-css-1440.png'));print('Tufte CSS original with downloaded local font resources; external iframe not awaited',flush=True)
    page.locator('#sidenotes').scroll_into_view_if_needed();page.screenshot(path=str(OUT/'tufte-css-sidenotes-1440.png'))
   else:
    page.get_by_label('Dark Theme',exact=True).check();page.wait_for_timeout(850);page.screenshot(path=str(OUT/'captivate-dark-1440.png'));print('Captivate visible Dark Theme radio selected',flush=True)
  except Exception as e:print(name,'ERROR',str(e),flush=True)
  context.close()
 browser.close()
