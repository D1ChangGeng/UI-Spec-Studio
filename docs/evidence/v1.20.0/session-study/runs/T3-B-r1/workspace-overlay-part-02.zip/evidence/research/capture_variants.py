import json,pathlib,os,time,urllib.request,hashlib
from playwright.sync_api import sync_playwright
ROOT=pathlib.Path(__file__).resolve().parent;OUT=ROOT/'captures'
for name,url in [('captivate-demo.html','https://cdruan.github.io/tw5-captivate/'),('captivate-repo.json','https://api.github.com/repos/cdruan/tw5-captivate'),('captivate-license.txt','https://raw.githubusercontent.com/cdruan/tw5-captivate/main/LICENSE')]:
 try:
  with urllib.request.urlopen(url,timeout=15) as resp: data=resp.read();meta={'url':url,'status':resp.status,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
  (ROOT/name).write_bytes(data)
 except Exception as e:meta={'url':url,'error':str(e)}
 (ROOT/(name+'.http.json')).write_text(json.dumps(meta));print(meta,flush=True)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 context=browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1);page=context.new_page()
 page.goto((ROOT/'notebook-demo.html').as_uri());page.wait_for_function('document.fonts.status==="loaded"');page.wait_for_timeout(300)
 for i in range(3):
  palette=page.evaluate('$tw.wiki.getTiddlerText("$:/palette")');page.screenshot(path=str(OUT/f'notebook-palette-{i}.png'));print('notebook palette',i,palette,flush=True)
  page.locator('button[class*="SwitchPalette"]:visible').last.click();page.wait_for_timeout(250)
 page.locator('button[title="Toggle menu"]:visible').last.click();page.wait_for_timeout(300);page.screenshot(path=str(OUT/'notebook-sidebar.png'))
 page.locator('button[title="Edit this tiddler"]:visible').first.click();page.wait_for_timeout(250);page.screenshot(path=str(OUT/'notebook-editor.png'))
 print('notebook editor',page.locator('body').inner_text()[:1500],flush=True)
 context.close()
 if (ROOT/'captivate-demo.html').exists():
  context=browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1);page=context.new_page();page.goto((ROOT/'captivate-demo.html').as_uri());page.wait_for_function('document.fonts.status==="loaded"');page.wait_for_timeout(400);page.screenshot(path=str(OUT/'captivate-1440.png'));print('captivate',page.locator('body').inner_text()[:5000],flush=True)
  (ROOT/'captivate-dom.json').write_text(json.dumps({'text':page.locator('body').inner_text(),'buttons':page.locator('button').evaluate_all('(els)=>els.map(e=>({title:e.title,aria:e.getAttribute("aria-label"),text:e.innerText,classes:e.className}))')},ensure_ascii=False,indent=2));context.close()
 browser.close()
