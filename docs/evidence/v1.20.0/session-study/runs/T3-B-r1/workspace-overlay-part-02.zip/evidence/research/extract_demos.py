import json,re,pathlib,hashlib
root=pathlib.Path(__file__).resolve().parent
for name in ['notebook','tufte']:
 html=(root/(name+'-demo.html')).read_text()
 stores=re.findall(r'<script[^>]+class="tiddlywiki-tiddler-store"[^>]*>(.*?)</script>',html,re.S)
 records=[t for raw in stores for t in json.loads(raw)]
 print(name,[(t['title'],t.get('version'),t.get('plugin-type')) for t in records if t['title']!='$:/core'])
 (root/(name+'-tiddlers.json')).write_text(json.dumps(records,ensure_ascii=False,indent=2))
 selected=[t for t in records if 'notebook' in t['title'].lower() and t.get('plugin-type') in ['theme','plugin']]
 if selected:
  dest=root/'notebook-installable.json';dest.write_text(json.dumps(selected,ensure_ascii=False,indent=2)); print('INSTALLABLE',str(dest),[{'title':t['title'],'version':t.get('version'),'license':t.get('license'),'children':len(json.loads(t.get('text','{}')).get('tiddlers',{}))} for t in selected])
  for t in selected:
   child=json.loads(t['text']).get('tiddlers',{}); filename=re.sub(r'[^a-zA-Z0-9_-]','_',t['title'])+'.expanded.json';(root/filename).write_text(json.dumps(child,ensure_ascii=False,indent=2))
