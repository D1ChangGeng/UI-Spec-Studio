import concurrent.futures, urllib.request, pathlib, json, hashlib, datetime
ROOT=pathlib.Path(__file__).resolve().parent
items={
 'notebook-demo.html':'https://saqimtiaz.github.io/sq-tw/notebook.html',
 'notebook-repo.json':'https://api.github.com/repos/NicolasPetton/Notebook',
 'notebook-head.json':'https://api.github.com/repos/NicolasPetton/Notebook/commits/master',
 'notebook-license.txt':'https://raw.githubusercontent.com/NicolasPetton/Notebook/master/LICENSE',
 'material-demo.html':'https://j.d.material.tiddlyspot.com/',
 'tufte-demo.html':'https://tufte-style.tiddlyhost.com/',
 'tufte-css-demo.html':'https://edwardtufte.github.io/tufte-css/',
 'tufte-css-license.txt':'https://raw.githubusercontent.com/edwardtufte/tufte-css/gh-pages/LICENSE',
}
def fetch(item):
 name,url=item; start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 try:
  req=urllib.request.Request(url, headers={'User-Agent':'Fieldnotes-source-research/1.0'})
  with urllib.request.urlopen(req,timeout=25) as resp:
   data=resp.read(); meta={'url':url,'final_url':resp.url,'status':resp.status,'headers':dict(resp.headers),'started':start,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
  (ROOT/name).write_bytes(data)
 except Exception as exc: meta={'url':url,'started':start,'error':str(exc)}
 (ROOT/(name+'.http.json')).write_text(json.dumps(meta,indent=2)); print(json.dumps({'name':name,**meta}),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: list(pool.map(fetch,items.items()))
