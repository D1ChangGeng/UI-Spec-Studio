import os,json,time
from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];O=R/'evidence/final-reviewed-v2';O.mkdir(exist_ok=True)
os.environ['FONTCONFIG_FILE']='/tmp/ui-spec-fonts/fonts.conf'
N='访谈笔记 — 傍晚通勤';I='Fieldnotes — project index';log=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 pg=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1);pg.set_default_timeout(7000);pg.on('dialog',lambda d:d.accept())
 pg.goto('http://127.0.0.1:4410/');pg.wait_for_selector('.tc-tiddler-frame')
 pg.evaluate("$tw.wiki.setText('$:/state/notebook-sidebar','text',undefined,'no')")
 def f():return pg.locator('.tc-tiddler-frame').filter(has=pg.locator('.tc-titlebar',has_text=N)).last
 def top(e):e.evaluate('(e)=>window.scrollTo(0,e.getBoundingClientRect().top+window.scrollY-(innerWidth>960?66:0))')
 def cap(name):
  pg.evaluate('document.fonts.ready');pg.wait_for_timeout(100);pg.screenshot(path=str(O/(name+'.png')))
  log.append({'name':name,'viewport':pg.viewport_size,'timestamp':time.monotonic(),'palette':pg.evaluate("$tw.wiki.getTiddlerText('$:/palette')"),'scheme':pg.evaluate('getComputedStyle(document.documentElement).colorScheme')})
 for theme in ['Beige','Dark']:
  pg.set_viewport_size({'width':1440,'height':900})
  pg.locator('.nc-topbar input[type="search"]').fill('')
  pg.get_by_role('button',name='Switch colours',exact=True).filter(visible=True).click()
  pg.get_by_role('button',name='Notebook '+theme,exact=True).click()
  pg.locator('.tc-tiddler-frame').first.click(position={'x':20,'y':20})
  for width,height in [(1440,900),(1280,640),(390,844)]:
   pg.set_viewport_size({'width':width,'height':height});top(f());cap(f'{theme.lower()}-read-{width}')
   f().locator('button[title="Edit this tiddler"]').click()
   draft=pg.locator('.tc-tiddler-frame').filter(has=pg.locator('button[title="Confirm changes to this tiddler"]')).last;top(draft)
   editor=draft.frame_locator('iframe').locator('textarea')
   log.append({'native_editor_font':editor.evaluate('(e)=>getComputedStyle(e).fontFamily'),'viewport':pg.viewport_size})
   cap(f'{theme.lower()}-edit-{width}')
   draft.locator('button[title="Discard changes to this tiddler"]').click();pg.wait_for_timeout(100)
  f().locator('h1').last.scroll_into_view_if_needed();cap(f'{theme.lower()}-complete-ending-390')
 pg.emulate_media(reduced_motion='reduce');pg.locator('.nc-bottombar .sidebar-toggle').click();cap('dark-reduced-navigation-390');pg.locator('.nc-bottombar .sidebar-toggle').click();pg.emulate_media(reduced_motion='no-preference')
 pg.set_viewport_size({'width':1440,'height':900});pg.get_by_role('button',name='Switch colours',exact=True).filter(visible=True).click();pg.get_by_role('button',name='Notebook Beige',exact=True).click();pg.locator('.tc-tiddler-frame').first.click(position={'x':20,'y':20})
 pg.locator('.nc-topbar .sidebar-toggle').filter(visible=True).click();pg.get_by_role('button',name='Open',exact=True).filter(visible=True).first.click();top(f());cap('beige-sidebar-1440');pg.locator('.nc-topbar .sidebar-toggle').filter(visible=True).click()
 pg.evaluate("$tw.wiki.setText('$:/language','text',undefined,'$:/languages/zh-Hans')");top(f());cap('beige-chinese-ui-1440');pg.evaluate("$tw.wiki.setText('$:/language','text',undefined,'$:/languages/en-GB')")
 pg.evaluate('window.scrollTo(0,0)');cap('final-entry-1440');pg.wait_for_timeout(1000)
 (O/'capture-log.json').write_text(json.dumps(log,ensure_ascii=False,indent=2));print(json.dumps(log,ensure_ascii=False,indent=2));b.close()
