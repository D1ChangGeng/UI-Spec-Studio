import os, json, time
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence'/'baseline-current'
OUT.mkdir(parents=True,exist_ok=True)
os.environ['FONTCONFIG_FILE']='/tmp/ui-spec-fonts/fonts.conf'
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
    page.goto('http://127.0.0.1:4410/')
    page.wait_for_selector('.tc-tiddler-frame')
    page.evaluate('document.fonts.ready')
    page.screenshot(path=str(OUT/'light-1440.png'))
    facts=page.evaluate('''() => ({title:document.title,frames:[...document.querySelectorAll('.tc-tiddler-frame')].map(e=>({title:e.getAttribute('data-tiddler-title'),text:e.innerText.slice(0,800)})),buttons:[...document.querySelectorAll('button')].map(e=>({title:e.title,text:e.innerText,aria:e.getAttribute('aria-label'),class:e.className})),inputs:[...document.querySelectorAll('input')].map(e=>({placeholder:e.placeholder,class:e.className,type:e.type}))})''')
    (OUT/'dom.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2))
    print(json.dumps(facts,ensure_ascii=False,indent=2))
    browser.close()
