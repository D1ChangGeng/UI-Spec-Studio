import os,json,time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence'/'trial-notebook'; OUT.mkdir(exist_ok=True)
os.environ['FONTCONFIG_FILE']='/tmp/ui-spec-fonts/fonts.conf'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
 page.goto('http://127.0.0.1:4410/');page.wait_for_selector('.tc-tiddler-frame');page.evaluate('document.fonts.ready')
 page.get_by_role('button',name='Switch colours',exact=True).filter(visible=True).click()
 page.get_by_role('button',name='Notebook Beige',exact=True).click()
 page.locator('.nc-topbar .sidebar-toggle').click();page.wait_for_timeout(400)
 page.screenshot(path=str(OUT/'light-index-1440.png'))
 frame=page.locator('.tc-tiddler-frame').filter(has=page.locator('.tc-titlebar',has_text='访谈笔记 — 傍晚通勤'))
 frame.scroll_into_view_if_needed();page.evaluate('window.scrollBy(0,-70)');page.wait_for_timeout(200)
 page.screenshot(path=str(OUT/'light-interview-1440.png'))
 frame.locator('button[title="Edit this tiddler"]').click();page.wait_for_timeout(200)
 page.screenshot(path=str(OUT/'light-editor-1440.png'))
 facts=page.evaluate('''() => ({palette:$tw.wiki.getTiddlerText('$:/palette'),buttons:[...document.querySelectorAll('button')].map(e=>({title:e.title,text:e.innerText,aria:e.getAttribute('aria-label')})),editors:[...document.querySelectorAll('textarea,iframe')].map(e=>({tag:e.tagName,class:e.className,title:e.title,value:e.value?.slice(0,80)})),frames:[...document.querySelectorAll('.tc-tiddler-frame')].map(e=>e.getAttribute('data-tiddler-title'))})''')
 (OUT/'dom.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2)); print(json.dumps(facts,ensure_ascii=False,indent=2))
 page.get_by_role('button',name='cancel',exact=True).click();page.wait_for_timeout(500)
 b.close()
