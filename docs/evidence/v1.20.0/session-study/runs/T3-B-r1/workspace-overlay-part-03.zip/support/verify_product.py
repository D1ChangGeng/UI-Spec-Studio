import os,json,time,hashlib,traceback
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence'/'final';OUT.mkdir(exist_ok=True)
os.environ['FONTCONFIG_FILE']='/tmp/ui-spec-fonts/fonts.conf'
INTERVIEW='访谈笔记 — 傍晚通勤';INDEX='Fieldnotes — project index'
LOG={'checks':[],'captures':[],'console_errors':[],'network':[],'conditions':{'browser':'Chromium 143 headless shell','device_scale_factor':1,'fontconfig':'/tmp/ui-spec-fonts/fonts.conf','source':'Notebook 465c832c885894ee3c97be76449cc524e1252eb0 + recorded narrow patches'}}
def check(name,ok,detail=None):
 LOG['checks'].append({'name':name,'pass':bool(ok),'detail':detail,'monotonic':time.monotonic()}); print(name, bool(ok),flush=True)
 if not ok: raise AssertionError(name+' '+str(detail))
def disk_text(title):
 for f in (ROOT/'app/wiki/tiddlers').glob('*.tid'):
  s=f.read_text()
  if 'title: '+title in s.split('\n\n',1)[0].splitlines(): return s.split('\n\n',1)[1]
 return None
def wait_disk(title,want):
 for i in range(100):
  if disk_text(title)==want:return True
  time.sleep(.1)
 return False
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 ctx=b.new_context(viewport={'width':1440,'height':900},device_scale_factor=1,record_video_dir=str(OUT/'video'),record_video_size={'width':1440,'height':900})
 pg=ctx.new_page();pg.set_default_timeout(7000)
 pg.on('dialog',lambda d:d.accept())
 pg.on('pageerror',lambda e:LOG['console_errors'].append(str(e)))
 pg.on('response',lambda r:LOG['network'].append({'url':r.url,'status':r.status}) if '/recipes/' in r.url else None)
 def capture(name):
  pg.evaluate('document.fonts.ready');pg.screenshot(path=str(OUT/(name+'.png')))
  LOG['captures'].append({'file':name+'.png','viewport':pg.viewport_size,'palette':pg.evaluate("$tw.wiki.getTiddlerText('$:/palette')"),'monotonic':time.monotonic(),'scrollY':pg.evaluate('window.scrollY')})
 def frame(title):return pg.locator('.tc-tiddler-frame').filter(has=pg.locator('.tc-titlebar',has_text=title)).filter(visible=True).last
 def top_of(f):f.evaluate('(e)=>window.scrollTo(0,e.getBoundingClientRect().top+window.scrollY-(window.innerWidth>960?66:0))');pg.wait_for_timeout(120)
 def discard():
  btn=pg.locator('button[title="Discard changes to this tiddler"]')
  while btn.count():btn.first.click();pg.wait_for_timeout(150)
 def edit(title):
  f=frame(title);top_of(f);f.locator('button[title="Edit this tiddler"]').click();pg.wait_for_timeout(150)
  f=pg.locator('.tc-tiddler-frame').filter(has=pg.locator('button[title="Confirm changes to this tiddler"]')).last
  top_of(f)
  return f,f.frame_locator('iframe.tc-edit-texteditor-body').locator('textarea')
 def save(f):f.locator('button[title="Confirm changes to this tiddler"]').click();pg.wait_for_timeout(200)
 def palette(name):
  pg.set_viewport_size({'width':1440,'height':900})
  pg.get_by_role('button',name='Switch colours',exact=True).filter(visible=True).click()
  pg.get_by_role('button',name='Notebook '+name,exact=True).filter(visible=True).click();pg.wait_for_timeout(150)
  pg.locator('.tc-tiddler-frame').first.click(position={'x':20,'y':20});pg.wait_for_timeout(50)
 def close_sidebar():
  if pg.evaluate("$tw.wiki.getTiddlerText('$:/state/notebook-sidebar')==='yes'"):
   pg.locator('.sidebar-toggle').filter(visible=True).first.click();pg.wait_for_timeout(250)
 try:
  pg.goto('http://127.0.0.1:4410/');pg.wait_for_selector('.tc-tiddler-frame');discard();close_sidebar();palette('Beige')
  original=pg.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',INTERVIEW)
  f=frame(INTERVIEW);top_of(f);capture('light-interview-1440')
  # Read to the end, follow native related-note link, and return via the index.
  f.locator('a').filter(has_text='Evidence ledger').first.click();pg.wait_for_timeout(150)
  ledger=frame('Evidence ledger');top_of(ledger);capture('light-ledger-1440')
  check('ledger table reached through interview link',ledger.locator('table').count()>0)
  links=ledger.locator('a').filter(has_text=INTERVIEW)
  if links.count():links.first.click()
  else: frame(INDEX).locator('a').filter(has_text=INTERVIEW).first.click()
  pg.wait_for_timeout(100);check('returned to complete interview',INTERVIEW in frame(INTERVIEW).inner_text())
  f,editor=edit(INTERVIEW)
  check('native iframe editor contains complete interview',editor.input_value()==original)
  changed=original.replace('twice a week','twice each week').replace('沿着有店面的这一侧走','沿着有店面的这一侧向前走')
  check('both English and Chinese passages changed',changed!=original and 'twice each week' in changed and '这一侧向前走' in changed)
  editor.fill(changed);capture('light-edited-1440');save(f)
  check('native save reached filesystem',wait_disk(INTERVIEW,changed))
  pg.reload();pg.wait_for_selector('.tc-tiddler-frame')
  check('reload agrees with saved bilingual changes',pg.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',INTERVIEW)==changed)
  f,editor=edit(INTERVIEW);editor.fill(original);save(f);check('test changes restored through native save',wait_disk(INTERVIEW,original))
  f,editor=edit(INTERVIEW);editor.fill(original+'\nCancelled verification change.');f.locator('button[title="Discard changes to this tiddler"]').click();pg.wait_for_timeout(150)
  check('cancel preserved authoritative interview',pg.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',INTERVIEW)==original and disk_text(INTERVIEW)==original)
  # Native search followed by keyboard activation of result and pencil.
  search=pg.locator('.nc-topbar input[type="search"]');search.fill('Next field session');pg.wait_for_timeout(300)
  result=pg.locator('.tc-search-drop-down a').filter(has_text='Next field session').first
  result.focus();pg.keyboard.press('Enter');pg.wait_for_timeout(150)
  nf=frame('Next field session');pencil=nf.locator('button[title="Edit this tiddler"]');pencil.focus();pg.keyboard.press('Tab');pg.keyboard.press('Shift+Tab');capture('keyboard-pencil-focus')
  focus=pg.evaluate('({title:document.activeElement.title,outline:getComputedStyle(document.activeElement).outlineStyle})')
  check('keyboard search reaches visible pencil focus',focus['title']=='Edit this tiddler' and focus['outline']!='none',focus)
  pg.keyboard.press('Enter');pg.wait_for_timeout(100);check('keyboard opens editor',pg.locator('button[title="Confirm changes to this tiddler"]').count()>0);discard()
  # Matrix: same complete interview, native editor, two palettes, three viewports.
  for theme in ['Beige','Dark']:
   palette(theme);close_sidebar()
   for width,height in [(1440,900),(1280,640),(390,844)]:
    pg.set_viewport_size({'width':width,'height':height});pg.wait_for_timeout(100);close_sidebar()
    f=frame(INTERVIEW);top_of(f);capture(f'{theme.lower()}-read-{width}')
    geom=pg.evaluate('({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,scheme:getComputedStyle(document.documentElement).colorScheme})')
    check(f'{theme} reading reflow at {width}',geom['scrollWidth']<=width+1,geom)
    f,editor=edit(INTERVIEW);capture(f'{theme.lower()}-edit-{width}')
    check(f'{theme} full editor content at {width}',editor.input_value()==original)
    f.locator('button[title="Discard changes to this tiddler"]').click();pg.wait_for_timeout(100)
  # Reduced motion uses actual media emulation and native navigation/menu.
  pg.emulate_media(reduced_motion='reduce');pg.set_viewport_size({'width':390,'height':844})
  pg.locator('.nc-bottombar .sidebar-toggle').click();pg.wait_for_timeout(50);capture('dark-reduced-mobile-navigation')
  motion=pg.evaluate('({reduce:matchMedia("(prefers-reduced-motion: reduce)").matches,sidebarAnimation:getComputedStyle(document.querySelector(".nc-sidebar")).animationName,nativeDuration:$tw.utils.getAnimationDuration()})')
  check('reduced motion quiet navigation',motion['reduce'] and motion['sidebarAnimation']=='none' and motion['nativeDuration']==0,motion)
  close_sidebar();pg.emulate_media(reduced_motion='no-preference');palette('Beige')
  # Locale is a fixture for visual coverage; native language content remains intact.
  pg.evaluate("$tw.wiki.setText('$:/language','text',undefined,'$:/languages/zh-Hans')");pg.wait_for_timeout(200)
  top_of(frame(INTERVIEW));capture('beige-chinese-ui-1440')
  check('Chinese UI keeps original bilingual content',pg.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',INTERVIEW)==original)
  pg.evaluate("$tw.wiki.setText('$:/language','text',undefined,'$:/languages/en-GB')");pg.wait_for_timeout(200)
  # Restore supplied entry objects via native state owner after observed journeys.
  pg.evaluate('''([index,note])=>{$tw.wiki.setText('$:/StoryList','list',undefined,[index,note]);$tw.wiki.setText('$:/state/notebook-sidebar','text',undefined,'no');}''',[INDEX,INTERVIEW])
  pg.evaluate('window.scrollTo(0,0)');capture('final-entry-1440');pg.wait_for_timeout(1000)
  check('no browser page errors',len(LOG['console_errors'])==0,LOG['console_errors'])
 except Exception as e:
  LOG['failure']=repr(e);LOG['traceback']=traceback.format_exc();capture('failure-state');print(LOG['traceback'],flush=True)
 finally:
  (OUT/'verification.json').write_text(json.dumps(LOG,ensure_ascii=False,indent=2));ctx.close();b.close()
 if 'failure' in LOG:raise SystemExit(1)
