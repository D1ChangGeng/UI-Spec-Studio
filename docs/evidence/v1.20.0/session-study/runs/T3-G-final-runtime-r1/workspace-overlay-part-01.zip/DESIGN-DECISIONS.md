# Fieldnotes — current design model

## Formal increment FN-01: an editorial workspace for linked bilingual research

The overall goal is a distinctive, mature editorial research studio that remains composed during reading, following evidence, editing, saving and returning. This increment owns the whole theme because navigation, note typography, editor material, dark appearance and narrow reflow share that foundation. The native TiddlyWiki 5.4.1 store, story navigation, draft lifecycle and filesystem synchronization remain authoritative. No original-construction exception is requested or used.

## Experience and evidence map

- L0: bilingual research team; durable linked notes; calm but recognizable editorial character. User intent comes from INPUT.md, not inferred preference.
- L1: complete interview → Evidence ledger → interview; English/Chinese edit → save → reload; cancel without loss; keyboard search → editor.
- L2: story river and sidebar; native Control Panel; 1440×900, 1280×640, 390×844.
- L3: native note toolbar, search/tags, editor, tables, draft and save feedback.
- L4: navigation/reading/editor type relationships, surface depth, long Chinese wrapping, palette contrast, focus and quiet motion.
- L5: exact source copies, actual PNGs and tool returns, browser interactions, filesystem/reload checks, source comparison and bounded runtime cost.

## Initial decision D1: source foundation (historical checkpoint)

Initial hypothesis: a warm editorial source can make long research feel authored without moving the text during reading. Candidate Paper 0.10.0 (Simon Huber) offers serif reading, sans UI, mono code, ruled editing and coherent day/night palettes. Candidate Notebook 1.4.1 (Nicolas Petton) challenges this with a custom left navigation and fixed task bar. The supplied Vanilla/Snow White provides the native baseline. Source acquisition is complete; current-project rendering and fit are still pending. Both external candidates are MIT; exact revisions are retained in evidence/source-inspection-001.json.

Next action: inspect the source's own demo and trial identical supplied content. A failure in long CJK reading, toolbar reachability, editing or narrow reflow can change the choice. Palette changes alone are not accepted as expressive completion.

## Scope and claims

Research includes the candidates' composition, typography/material and native task handling. Product implementation stays in app/wiki. Regression checks exercise the native server boundary and themes/locales/viewports. Static screenshots establish only their stated static conditions; controlled episodes and natural-time viewing remain distinct. Owner preference and acceptance are pending.

## Host observations

The requested child inquiry failed with the actual agent-thread limit; DELEGATION.json retains it. Source inquiry continues directly. The registered alias was inconsistent; all work after the first inspection uses this physical work package. Actual first retained substantive timestamp: 2026-11-01T11:29:07Z. No source-selection findings were supplied by the coordinator.


## Closed decision D1 and final increment outcome

Paper was selected after corrected populated trials of both external themes and inspection of their own source examples. The primary retained all implementation and assembled-product review. Source identity and task composition are retained; narrow contrast, quiet-motion and table-overflow repairs address observed defects. SOURCE-ADOPTION.md gives exact source/product differences. VISUAL-REVIEW.md maps actual inspected images and controlled episodes. The successful native save/reload, cancel, keyboard and 12 viewport/palette checks are recorded in verification-v3, with the final motion/table repairs separately rechecked. All eight original notes and original start state are restored. No user preference or broad accessibility acceptance is inferred. A child inquiry was attempted and failed at host capacity; it supplied no findings. No further child was needed after primary inquiry resolved the source decision.
