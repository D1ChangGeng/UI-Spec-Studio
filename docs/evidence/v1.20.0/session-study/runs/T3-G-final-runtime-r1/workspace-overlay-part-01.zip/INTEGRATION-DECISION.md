# Integration decision — FN-01

Selected: Simon Huber's Vanilla Paper 0.10.0, revision 031a78d4d4187128c632f8a647fa05408eddc700, MIT. Source: https://github.com/BurningTreeC/vanilla-paper . It carries the complete layout, sheet material, margin rule, type roles, ruled editing, controls, theme states and responsive mechanisms. Native TiddlyWiki 5.4.1 retains all product behavior and persistence.

## Evidence and comparison

The original Paper demo was acquired from https://burningtreec.github.io/vanilla-paper/ and actually rendered/viewed at 1440×900 (view-003). Its local trial was viewed at the same size for index, bilingual interview and editor (view-007 to view-009), and narrow reading at 390×844 (view-010). Notebook 1.4.1 at 465c832c885894ee3c97be76449cc524e1252eb0 was acquired, its original beige screenshot viewed, and its populated local trial viewed (view-005/006). Notebook's centered 800px page and top task bar offer a materially different navigation model. Its stronger bold heading scale and hidden sidebar are usable but less suited to a persistent evidence-oriented editorial studio. Paper's serif reading/UI sans/mono editor roles and paper-rule material retain a stronger relationship across reading and editing. This is the final professional selection for this increment, not user preference evidence.

## Supported configuration and narrow repairs

- Retain Paper's default dimensions, fonts, surface rules and day/night palettes.
- Enable source-supported always-visible note toolbar and sticky titles so editing and current-note identity stay discoverable during long reading.
- Set native TiddlyWiki AnimationDuration to 0 for quiet note opening/edit transitions. The delivered quiet profile disables sidebar travel. Repair the source reduced-motion rule from 150ms to 0ms because it otherwise reintroduced travel.
- Override only sidebar-controls-foreground, tiddler-controls-foreground, tiddler-subtitle-foreground, and sidebar-muted-foreground in the original-identity day/night palette tiddlers. Reuse the palette's existing sidebar-foreground token. This addresses visibly faint operative controls and metadata; it does not invent a replacement palette.
- Add a supported head color-scheme declaration for browser-native controls, following the required modern guidance. Paper already binds :root color-scheme to the active palette.
- Remove the rejected Notebook runtime theme/plugin after retaining its exact source and trial evidence.

No W1, W2, or W3 exception is authorized, requested or used. No new layout, component family, art, font, animation engine or data store is authored. Product changes remain under app/wiki. 54 of 55 Paper source files stay byte-identical. The original-identity 3-surface.tid contains the reduced-motion duration repair and a narrow-width table overflow repair. Settings and exact-title palette overrides carry the remaining adaptation. evidence/paper-final.patch and evidence/source-integrity-final.json record the complete source difference.

## Completed verification and limits

Native save/reload and cancel, keyboard search-to-editor, both palettes, representative Chinese UI conditions, compact/narrow reading/editing and final visual inspection are complete at the scope recorded in VISUAL-REVIEW.md. The early editor transition clone is retained as an intermediate capture. Controlled motion checks exposed and verified the quiet repair; no natural-speed playback claim is made. The final narrow table scroll was exercised by horizontal wheel. Its keyboard semantics and full accessibility acceptance remain unverified.
