# Source adoption and source-to-product comparison

| Foundation | Exact revision | Rights | Actual role |
|---|---|---|---|
| TiddlyWiki 5.4.1 | d391595836e2aead565480763f9bf9eb52e29e75 | Upstream notices retained in vendor | Native store, filesystem synchronization, drafts, search, navigation, editor and controls |
| Vanilla Paper 0.10.0, Simon Huber | 031a78d4d4187128c632f8a647fa05408eddc700 | MIT; original LICENSE plus wiki/licenses/vanilla-paper-MIT.txt | Selected whole-workspace theme |
| Notebook 1.4.1, Nicolas Petton | 465c832c885894ee3c97be76449cc524e1252eb0 | MIT, retained with source | Materially different challenger, trialled and removed from runtime |

Primary sources: https://github.com/TiddlyWiki/TiddlyWiki5 ; https://github.com/BurningTreeC/vanilla-paper ; https://github.com/NicolasPetton/Notebook . Exact acquired repositories and author demos remain in evidence/sources. No third-party image or font was added to the product. Noto Sans CJK SC is the supplied host font fixture.

## What was compared

The native baseline was rendered with the supplied content. Paper's own demo and Notebook's author screenshot/demo were inspected, then both external candidates were installed in the same native application and rendered with the same index/interview at 1440×900. The initial Notebook attempt accidentally retained Vanilla because an exact configuration value had a trailing newline; it is preserved as a failed trial, not evidence of Notebook's design. Corrected Notebook captures are view-005/006.

Notebook introduces an 800px centered card, bold sans headings and a top task bar with a collapsible left navigation. It challenges Paper's persistent right navigation and serif editorial pages. Paper supplies a more coherent relationship between reading and writing for this task: 720px sheets, restrained red margin rule, warm desk, serif prose/title, sans navigation and ruled mono editing. These are the adopted author's mechanisms, not newly drawn substitutes. This is a designer's fit judgment, not measured user preference.

## Exact preservation and adaptations

All 8,823 native vendor files were hash-checked unchanged (evidence/source-integrity.json). Paper contributes 55 files, originally 357,280 bytes. 54 remain byte-identical. The original-identity 3-surface.tid has two documented compatibility repairs: reduced-motion transition duration 150ms becomes 0ms, and a narrow-width table rule enables horizontal overflow inside the existing table. The exact complete diff is evidence/paper-final.patch.

Supported settings enable always-visible toolbar and sticky title, set native AnimationDuration to zero, select Paper Day, and retain English as initial UI language. Both original-identity palette overrides change four muted/control/metadata foreground entries to the source's existing sidebar-foreground token. No invented palette or replacement type scale is introduced. A supported RawMarkup head declaration adds light/dark color-scheme. Source day/night materials, dimensions, font roles, borders, editor rules and core responsive layout remain intact.

The palette token contrast calculation gives day controls/desk 4.56:1, day metadata/sheet 5.543:1, night controls/desk 6.783:1 and night metadata/sheet 6.253:1. This establishes only those color pairs, not a whole-product accessibility certification.

The table repair keeps all original columns and content. At 390px its 483px content scrolls inside 318px; an actual horizontal wheel moved scrollLeft from 0 to165 and exposed the final column. It is not a stacked-card redesign. Keyboard focus/scroll semantics of that table remain unverified.

All eight supplied note files were restored byte-for-byte after the save/cancel tests. Native reload confirmed all eight original bodies. No W1/W2/W3 exception was used.
