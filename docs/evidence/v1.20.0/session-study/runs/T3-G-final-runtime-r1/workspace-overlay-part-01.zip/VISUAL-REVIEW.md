# Actual visual review

Primary designer inspection used actual view_image returns, each retained in evidence/view-*.json. Screenshots were produced by sandboxed local Chromium143, Playwright1.57, device scale1, supplied Noto CJK font configuration. CDP confirms Noto Sans CJK SC actually supplies Chinese glyphs. Browser timezone was Asia/Shanghai; command timestamps are UTC. Compared arms used this same host condition.

## Source and populated comparison

Viewed: author Notebook beige screenshot (001), native baseline (002), Paper demo (003), corrected populated Notebook index/interview (005–006), populated Paper index/interview/editor/narrow (007–010). The first Notebook attempt (004) was a configuration failure; the early Paper editor includes an animation clone. Neither is presented as a final settled view.

Paper preserves clear reading/navigation/writing roles. Its serif paragraphs and margin rule make the content feel like an editorial research notebook, and the ruled editor is visibly a different working mode. Notebook's top bar and bold sans hierarchy were usable but less fitting for this persistent evidence-reading workspace. No imagery or decorative animation was needed.

## Final static views personally opened

| Condition | Actual view records | Observation |
|---|---|---|
| Light reading/editing 1440×900 | 012–013 | Long bilingual title, controls and prose have clear hierarchy; 720px page and 30px line rhythm |
| Light reading/editing 1280×640 | 014–015 | Compact height retains title and editor access; scrolling remains necessary for long material |
| Light reading/editing 390×844 | 016–017 | 350px sheet; readable English/Chinese wraps; toolbar does not collide with long title |
| Dark reading/editing 1440×900 | 018–019 | Warm dark surface and ruled editor retain source identity |
| Dark reading/editing 1280×640 | 020–021 | Legible hierarchy and focus treatment |
| Dark reading/editing 390×844 | 022–023 | Narrow editor tag controls occupy multiple rows but remain reachable |
| Chinese UI, light compact / dark narrow | 024–027 | Native translated controls render without observed clipping; this is representative locale coverage |
| Interview middle/end and ledger desktop | 029–031 | Sticky title supports orientation; final unresolved Chinese question is retained; four-column ledger readable |
| Final restart and reduced motion | 033–034 | Correct initial notes and theme; repaired reduced condition is stationary in captured state |
| Narrow ledger before/after repair | 035–036 | Initial table overflow hid final column; horizontal scrolling repair exposes it within note |
| Delivered clean start after final repair | 037 | Correct two-note start, synced native indicator, visible search focus, intact Paper composition |

View032's display was truncated by context limits; it is not counted as inspected. View033 reopened the image. Final delivered hero is evidence/captures/table-repair/ready-final-1440.png.

## Behavior and controlled episodes

The native journey passed in commands/022-native-verification-framed and captures/verification-v3/verification-log.json: full interview → ledger → interview; English and Chinese edits; native save; actual filesystem write and reload agreement; original passage restoration; cancelled draft preserved the note after reload; Ctrl+Shift+F search and keyboard activation of the editor. Failed selector/frame attempts are retained separately.

Twelve reading/editor viewport-palette captures showed no document horizontal overflow. Four Chinese UI captures cover compact light and narrow dark. This does not imply every state or locale combination was inspected. No page JavaScript errors were reported in the successful main journey; 84 requests were local with no external request.

Controlled sidebar actions retained ordered frames and timestamps. The source reduced-motion rule was found to reintroduce 150ms movement despite quiet configuration and was repaired. Recheck measured page-container transitionDuration 0s in both preferences and zero subtree animations in the reduced sample. The normal sample had six animations elsewhere; no claim of universal zero motion is made. Natural-time video/playback was not viewed, so smoothness, FPS and perceived motion comfort are unknown.

Final narrow-table check (commands029) actually exercised horizontal wheel scrolling, then restored and reloaded the initial story. Desktop and editor styles are outside that <=600px table selector.

## Remaining limits

No user preference study, full accessibility audit, screen reader session, hardware phone/IME, Firefox/Safari, network-failure recovery injection, natural-time playback or device performance measurement was performed. The narrow table requires horizontal navigation; its keyboard semantics were not verified. Native error/recovery behavior was preserved but not fault-injected. No known blocking defect remains in the exercised core paths.
