import json,time
from pathlib import Path
from playwright.sync_api import sync_playwright
B=Path(__file__).resolve().parent
OUT=B/'captures'
logs=[]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',chromium_sandbox=True)
 for name in ['paper','notebook']:
  page=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
  page.on('pageerror',lambda e: logs.append({'error':str(e)}))
  page.goto((B/'sources'/f'{name}-demo.html').as_uri(),wait_until='load')
  page.evaluate('document.fonts.ready')
  page.wait_for_timeout(300)
  page.screenshot(path=str(OUT/f'{name}-source-demo-1440.png'))
  logs.append({'name':name,'title':page.title(),'time':time.time(),'text':page.locator('body').inner_text()[:4000]})
  page.close()
 browser.close()
(OUT/'source-demo-log.json').write_text(json.dumps(logs,ensure_ascii=False,indent=2))
print(json.dumps([{'name':x.get('name'),'title':x.get('title')} for x in logs],ensure_ascii=False))
