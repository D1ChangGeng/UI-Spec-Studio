import os, json, time
from pathlib import Path
from playwright.sync_api import sync_playwright
BASE=Path(__file__).resolve().parent
OUT=BASE/'captures'
OUT.mkdir(exist_ok=True)
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
results=[]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=BROWSER, headless=True, chromium_sandbox=True)
 context=browser.new_context(viewport={'width':1440,'height':900}, device_scale_factor=1)
 page=context.new_page()
 page.on('pageerror',lambda e: results.append({'error':str(e)}))
 page.goto('http://127.0.0.1:4412/',wait_until='networkidle')
 page.evaluate('document.fonts.ready')
 page.screenshot(path=str(OUT/'baseline-light-1440.png'))
 results.append({'condition':'baseline light','title':page.title(),'frames':page.locator('.tc-tiddler-frame').count(),'time':time.time()})
 interview=page.locator('.tc-tiddler-frame[data-tiddler-title="访谈笔记 — 傍晚通勤"]')
 interview.scroll_into_view_if_needed()
 page.screenshot(path=str(OUT/'baseline-interview-1440.png'))
 results.append({'interviewText':interview.inner_text()})
 page.evaluate('window.$tw.wiki.setText("$:/palette","text",null,"$:/palettes/Nord")')
 page.wait_for_timeout(300)
 page.screenshot(path=str(OUT/'baseline-dark-1440.png'))
 context.close()
 browser.close()
(OUT/'initial-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(json.dumps(results[:1],ensure_ascii=False))
