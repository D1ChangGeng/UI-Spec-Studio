import sys,json,time
from pathlib import Path
from playwright.sync_api import sync_playwright
B=Path(__file__).resolve().parent; O=B/'captures'; name=sys.argv[1]; log=[]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',chromium_sandbox=True)
 page=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
 page.on('pageerror',lambda e:log.append({'error':str(e)}))
 page.goto('http://127.0.0.1:4412/',wait_until='networkidle');page.evaluate('document.fonts.ready')
 page.screenshot(path=str(O/f'{name}-trial-index-1440.png'))
 log.append({'theme':page.evaluate('$tw.wiki.getTiddlerText("$:/theme")'),'palette':page.evaluate('$tw.wiki.getTiddlerText("$:/palette")'),'frameCount':page.locator('.tc-tiddler-frame').count(),'time':time.time()})
 interview=page.locator('.tc-tiddler-frame[data-tiddler-title="访谈笔记 — 傍晚通勤"]')
 interview.evaluate('(e)=>e.scrollIntoView({block:"start"})');page.wait_for_timeout(300)
 page.screenshot(path=str(O/f'{name}-trial-interview-1440.png'))
 log.append({'buttons':interview.locator('button').evaluate_all('(es)=>es.map(e=>({text:e.innerText,title:e.title,aria:e.getAttribute("aria-label")}))'),'interviewHeight':interview.bounding_box()['height']})
 interview.locator('button[title="Edit this tiddler"]').click()
 page.wait_for_timeout(200)
 page.screenshot(path=str(O/f'{name}-trial-editor-1440.png'))
 log.append({'editorFrames':page.locator('iframe').count(),'editInputs':page.locator('input,textarea').evaluate_all('(es)=>es.map(e=>({tag:e.tagName,cls:e.className,placeholder:e.placeholder}))')})
 page.locator('button[title="Cancel editing this tiddler"]').click();page.wait_for_timeout(200)
 page.set_viewport_size({'width':390,'height':844});page.evaluate('window.scrollTo(0,0)');page.wait_for_timeout(200)
 page.screenshot(path=str(O/f'{name}-trial-narrow-390.png'))
 log.append({'narrowWidth':page.evaluate('({inner:innerWidth,body:document.body.scrollWidth,doc:document.documentElement.scrollWidth})')})
 browser.close()
(O/f'{name}-trial-log.json').write_text(json.dumps(log,ensure_ascii=False,indent=2));print(json.dumps(log,ensure_ascii=False))
