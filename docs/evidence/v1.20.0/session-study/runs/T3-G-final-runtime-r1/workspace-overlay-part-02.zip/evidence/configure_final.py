from pathlib import Path
import json,socket,shutil,re,hashlib
b=Path.cwd();w=b/'app/wiki';e=b/'evidence'
s=socket.socket();r=s.connect_ex(('127.0.0.1',4412));s.close();assert r!=0,'Server must be stopped'
def set_tid(title,text,name,extra=''):
 for f in (w/'tiddlers').glob('*.tid'):
  if ('title: '+title) in f.read_text().split('\n\n')[0].splitlines(): f.unlink()
 (w/'tiddlers'/name).write_text('title: '+title+'\n'+extra+'\n'+text)
set_tid('$:/theme','$:/themes/BurningTreeC/vanilla-paper','fieldnotes-theme.tid')
set_tid('$:/palette','$:/palettes/VanillaPaperDay','config-04.tid')
set_tid('$:/themes/BurningTreeC/vanilla-paper/options/toolbaralways','yes','fieldnotes-toolbar.tid')
set_tid('$:/themes/BurningTreeC/vanilla-paper/options/stickytitles','yes','fieldnotes-sticky.tid')
set_tid('$:/config/AnimationDuration','0','fieldnotes-quiet.tid')
set_tid('$:/Fieldnotes/HeadColorScheme','<meta name="color-scheme" content="light dark">','fieldnotes-color-scheme.tid','tags: $:/tags/RawMarkup\ntype: text/html\n')
(w/'licenses').mkdir(exist_ok=True)
shutil.copy2(e/'sources/vanilla-paper/LICENSE',w/'licenses/vanilla-paper-MIT.txt')
(w/'themes/vanilla-paper/LICENSE').unlink()
changes={}
for mode in ['Day','Night']:
 source=e/f'sources/vanilla-paper/themes/BurningTreeC/vanilla-paper/VanillaPaper{mode}.tid'
 text=source.read_text();keys=['sidebar-controls-foreground','tiddler-controls-foreground','tiddler-subtitle-foreground','sidebar-muted-foreground']
 for key in keys: text=re.sub(r'^'+re.escape(key)+r': .*$',key+': <<colour sidebar-foreground>>',text,flags=re.M)
 (w/f'tiddlers/fieldnotes-paper-{mode.lower()}.tid').write_text(text)
 changes[mode]=keys
shutil.rmtree(w/'themes/notebook');shutil.rmtree(w/'plugins/notebook-mobile')
print(json.dumps({'configuration':'Paper 0.10.0, visible actions, sticky titles, native quiet motion','paletteOverrides':changes,'noOriginalException':True}))
