from playwright.sync_api import sync_playwright
import json
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',chromium_sandbox=True)
 page=b.new_page(); page.goto('http://127.0.0.1:4412/',wait_until='load');page.wait_for_timeout(700)
 print(json.dumps(page.evaluate('({theme:$tw.wiki.getTiddlerText("$:/theme"),palette:$tw.wiki.getTiddlerText("$:/palette"),notebook:$tw.wiki.getTiddler("$:/themes/nico/notebook"),themes:$tw.wiki.getTiddlerText("$:/themes"),buttons:[...document.querySelectorAll("button")].map(b=>({title:b.title,aria:b.getAttribute("aria-label")}))})'),ensure_ascii=False)[:5000])
 b.close()
