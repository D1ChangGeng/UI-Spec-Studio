from pathlib import Path
import shutil,json,socket,difflib,hashlib
b=Path.cwd();w=b/'app/wiki';e=b/'evidence'
s=socket.socket();r=s.connect_ex(('127.0.0.1',4412));s.close();assert r!=0
src=e/'sources/vanilla-paper/themes/BurningTreeC/vanilla-paper/3-surface.tid';dst=w/'themes/vanilla-paper/3-surface.tid'
text=dst.read_text();assert text.count('transition-duration: 150ms !important;')==1;text=text.replace('transition-duration: 150ms !important;','transition-duration: 0ms !important;');dst.write_text(text)
(e/'paper-reduced-motion.patch').write_text(''.join(difflib.unified_diff(src.read_text().splitlines(True),text.splitlines(True),fromfile='upstream/3-surface.tid',tofile='product/3-surface.tid')))
def title(f):return next((x[7:] for x in f.read_text().split('\n\n')[0].splitlines() if x.startswith('title: ')),None)
originals={title(f):f for f in (e/'original-notes').glob('*.tid')}
removed=[]
reset={'$:/StoryList','$:/HistoryList','$:/palette','$:/language','$:/state/sidebar'}
for f in (w/'tiddlers').glob('*.tid'):
 header=f.read_text().split('\n\n')[0];t=title(f)
 if t in originals or t in reset or any(x.startswith('draft.of:') for x in header.splitlines()):
  removed.append({'file':f.name,'title':t});f.unlink()
for f in originals.values():shutil.copy2(f,w/'tiddlers'/f.name)
(w/'tiddlers/config-04.tid').write_text('title: $:/palette\n\n$:/palettes/VanillaPaperDay')
(w/'tiddlers/config-05.tid').write_text('title: $:/language\n\n$:/languages/en-GB')
res={'serverStopped':True,'sourcePatch':'one reduced-motion duration declaration 150ms → 0ms','restoredNotes':[{'file':f.name,'sha256':hashlib.sha256((w/'tiddlers'/f.name).read_bytes()).hexdigest(),'matchesSnapshot':f.read_bytes()==(w/'tiddlers'/f.name).read_bytes()} for f in originals.values()],'removedTestState':removed}
(e/'cleanup-and-motion-repair.json').write_text(json.dumps(res,ensure_ascii=False,indent=2));print(json.dumps(res,ensure_ascii=False))
