import json,time
from pathlib import Path
from playwright.sync_api import sync_playwright
B=Path(__file__).resolve().parent; O=B/'captures'/'handover';O.mkdir(exist_ok=True); logs=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',chromium_sandbox=True)
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1);page.goto('http://127.0.0.1:4412/',wait_until='networkidle');page.evaluate('document.fonts.ready');page.wait_for_timeout(1200)
 page.screenshot(path=str(O/'ready-1440.png'));logs.append({'capture':'ready-1440','time':time.time()})
 page.locator('.tc-tiddler-frame').first.locator('a.tc-tiddlylink').filter(has_text='Evidence ledger').first.click();page.set_viewport_size({'width':390,'height':844});page.wait_for_timeout(200)
 ledger=page.locator('.tc-tiddler-frame[data-tiddler-title="Evidence ledger"]');ledger.evaluate('(e)=>{e.scrollIntoView();scrollBy(0,-20)}');page.wait_for_timeout(200);page.screenshot(path=str(O/'ledger-390.png'))
 logs.append({'capture':'ledger-390','time':time.time(),'sizes':page.evaluate('({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,table:document.querySelector(\'.tc-tiddler-frame[data-tiddler-title="Evidence ledger"] table\').getBoundingClientRect().toJSON()})')})
 page.evaluate('$tw.wiki.setText("$:/StoryList","list",null,["Fieldnotes — project index","访谈笔记 — 傍晚通勤"])');page.wait_for_timeout(1500);page.reload(wait_until='networkidle');page.wait_for_timeout(700);logs.append({'restoredStory':page.evaluate('$tw.wiki.getTiddlerList("$:/StoryList")')});b.close()
(O/'handover-log.json').write_text(json.dumps(logs,ensure_ascii=False,indent=2));print(json.dumps(logs,ensure_ascii=False))
