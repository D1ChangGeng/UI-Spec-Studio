from pathlib import Path
import shutil,json,hashlib,socket
b=Path.cwd(); w=b/'app/wiki'; e=b/'evidence'
s=socket.socket(); result=s.connect_ex(('127.0.0.1',4412)); s.close()
assert result!=0,'Server must stop before source edits'
(e/'original-notes').mkdir(exist_ok=True)
for f in (w/'tiddlers').glob('note-*.tid'): shutil.copy2(f,e/'original-notes'/f.name)
(w/'themes').mkdir(exist_ok=True); (w/'plugins').mkdir(exist_ok=True)
shutil.copytree(e/'sources/notebook/themes/notebook',w/'themes/notebook')
shutil.copytree(e/'sources/notebook/plugins/notebook-mobile',w/'plugins/notebook-mobile')
(w/'tiddlers/fieldnotes-theme.tid').write_text('title: $:/theme\n\n$:/themes/nico/notebook\n')
(w/'tiddlers/config-04.tid').write_text('title: $:/palette\n\n$:/themes/nico/notebook/palettes/palette-beige\n')
print(json.dumps({'serverStopped':True,'copied':['themes/notebook','plugins/notebook-mobile'],'theme':'$:/themes/nico/notebook','palette':'$:/themes/nico/notebook/palettes/palette-beige'}))
