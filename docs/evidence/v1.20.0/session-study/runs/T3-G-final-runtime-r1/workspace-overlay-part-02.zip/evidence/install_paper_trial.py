from pathlib import Path
import shutil,json,socket
b=Path.cwd();w=b/'app/wiki';e=b/'evidence'
s=socket.socket();r=s.connect_ex(('127.0.0.1',4412));s.close();assert r!=0,'Server must be stopped'
shutil.copytree(e/'sources/vanilla-paper/themes/BurningTreeC/vanilla-paper',w/'themes/vanilla-paper')
shutil.copy2(e/'sources/vanilla-paper/LICENSE',w/'themes/vanilla-paper/LICENSE')
def set_tiddler(title,text,name):
 for f in (w/'tiddlers').glob('*.tid'):
  head=f.read_text().split('\n\n')[0]
  if ('title: '+title) in head.splitlines(): f.unlink()
 (w/'tiddlers'/name).write_text('title: '+title+'\n\n'+text)
set_tiddler('$:/theme','$:/themes/BurningTreeC/vanilla-paper','fieldnotes-theme.tid')
set_tiddler('$:/palette','$:/palettes/VanillaPaperDay','config-04.tid')
print(json.dumps({'serverStopped':True,'installed':'Paper 0.10.0','sourceRevision':'031a78d4d4187128c632f8a647fa05408eddc700'}))
