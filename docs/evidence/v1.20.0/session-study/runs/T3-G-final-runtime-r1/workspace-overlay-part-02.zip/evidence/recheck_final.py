import json,time
from pathlib import Path
from playwright.sync_api import sync_playwright
B=Path(__file__).resolve().parent;O=B/'captures'/'recheck';O.mkdir(exist_ok=True);T='访谈笔记 — 傍晚通勤';I='Fieldnotes — project index';logs=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',chromium_sandbox=True)
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1);page.goto('http://127.0.0.1:4412/',wait_until='networkidle');page.evaluate('document.fonts.ready');page.wait_for_timeout(800)
 def snap(name):
  start=time.time();page.screenshot(path=str(O/(name+'.png')));logs.append({'capture':name,'start':start,'end':time.time()})
 state=page.evaluate('({story:$tw.wiki.getTiddlerList("$:/StoryList"),palette:$tw.wiki.getTiddlerText("$:/palette"),theme:$tw.wiki.getTiddlerText("$:/theme"),language:$tw.wiki.getTiddlerText("$:/language"),motion:$tw.wiki.getTiddlerText("$:/config/AnimationDuration"),timezone:Intl.DateTimeFormat().resolvedOptions().timeZone,notes:$tw.wiki.filterTiddlers("[!is[system]!is[shadow]]")})');assert state['story']==[I,T],state;assert state['palette']=='$:/palettes/VanillaPaperDay'
 for f in (B/'original-notes').glob('*.tid'):
  h,text=f.read_text().split('\n\n',1);title=next(x[7:] for x in h.splitlines() if x.startswith('title: '));actual=page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',title);assert actual==text,(title,len(actual),len(text))
 logs.append({'cleanRestart':state,'allEightOriginalNoteBodiesExact':True});snap('ready-light-1440')
 client=page.context.new_cdp_session(page);client.send('DOM.enable');client.send('CSS.enable');doc=client.send('DOM.getDocument');selector='.tc-tiddler-frame[data-tiddler-title="'+T+'"] .tc-tiddler-body p:nth-of-type(3)';nid=client.send('DOM.querySelector',{'nodeId':doc['root']['nodeId'],'selector':selector})['nodeId'];logs.append({'cjkPlatformFonts':client.send('CSS.getPlatformFontsForNode',{'nodeId':nid})})
 for pref in ['no-preference','reduce']:
  page.emulate_media(reduced_motion=pref);page.set_viewport_size({'width':1280,'height':640});page.wait_for_timeout(200);snap('quiet-'+pref+'-before');page.locator('.btc-sidebar-toggle').first.click();snap('quiet-'+pref+'-after');trans=page.locator('.tc-page-container').evaluate('(e)=>({duration:getComputedStyle(e).transitionDuration,animations:e.getAnimations({subtree:true}).length})');assert trans['duration']=='0s',trans;logs.append({'quietCheck':pref,**trans});page.locator('.btc-sidebar-toggle').first.click();page.wait_for_timeout(200)
 page.emulate_media(reduced_motion='no-preference');page.set_viewport_size({'width':1440,'height':900});page.evaluate('$tw.wiki.setText("$:/palette","text",null,"$:/palettes/VanillaPaperNight")');page.wait_for_timeout(400);page.locator('.tc-tiddler-frame[data-tiddler-title="'+T+'"]').evaluate('(e)=>{e.scrollIntoView();scrollBy(0,-24)}');page.wait_for_timeout(150);snap('ready-dark-interview-1440')
 page.evaluate('$tw.wiki.setText("$:/palette","text",null,"$:/palettes/VanillaPaperDay")');page.wait_for_timeout(450);page.evaluate('scrollTo(0,0)');snap('ready-final-1440')
 page.goto((B.parent/'app/wiki/output/index.html').as_uri(),wait_until='load');page.wait_for_timeout(500);logs.append({'offlineBuildRendered':page.title(),'offlineFrames':page.locator('.tc-tiddler-frame').count()});assert page.locator('.tc-tiddler-frame').count()==2
 b.close()
(O/'recheck-log.json').write_text(json.dumps(logs,ensure_ascii=False,indent=2));print(json.dumps(logs,ensure_ascii=False))
