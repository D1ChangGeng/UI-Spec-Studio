import datetime,json
from pathlib import Path
b=Path.cwd()
now=datetime.datetime.now(datetime.timezone.utc)
prep=datetime.datetime.fromisoformat("2026-11-01T11:28:39.659896+00:00")
result={"kind":"primary_reported_close_with_host_clock","coordinatorRequestPreparationUtc":prep.isoformat(),"preparationIsAuthenticatedEngineStart":False,"firstRetainedSubstantiveObservationUtc":"2026-11-01T11:29:07Z","substantiveClosedAtUtc":now.isoformat(),"preparationToCloseSeconds":(now-prep).total_seconds(),"boundSeconds":1800,"withinPreparationBasedBound":(now-prep).total_seconds()<=1800,"physicalWorkspace":str(b),"ownedPreviewStopped":True,"previewClosureEvidence":"evidence/source-integrity-final.json","remainingLimits":"See VISUAL-REVIEW.md and FINAL.md; narrow table keyboard semantics, natural-time playback, full accessibility, hardware IME, cross-browser and network fault injection unverified.","childAttempt":"Failed at capacity; DELEGATION.json contains actual request/result; no child findings used.","aliasObservation":{"initialReadBeforeMismatch":["TASK.md","INPUT.md","RUN-CONTROL.md","ALLOCATION.md","method filename listing"],"subsequentWork":"Fresh physical path only, as explicitly directed by coordinator."},"handoverLatency":"Substantive close is recorded above; downstream export/snapshot latency is separate and not measured here."}
(b/"RUN-RESULT.json").write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
