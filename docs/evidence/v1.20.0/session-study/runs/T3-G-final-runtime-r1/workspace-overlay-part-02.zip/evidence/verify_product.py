import json,time,traceback
from pathlib import Path
from playwright.sync_api import sync_playwright
B=Path(__file__).resolve().parent; O=B/'captures'; W=B.parent/'app/wiki/tiddlers'
T='访谈笔记 — 傍晚通勤'; INDEX='Fieldnotes — project index'; QUIET='Quiet route — working draft'
log={'started':time.time(),'checks':[],'errors':[],'captures':[],'requests':[]}
def record(name,**kwargs):
 log['checks'].append({'name':name,'time':time.time(),**kwargs}); (O/'verification-log.json').write_text(json.dumps(log,ensure_ascii=False,indent=2))
def body_on_disk(title):
 matches=[]
 for f in W.glob('*.tid'):
  s=f.read_text(); parts=s.split('\n\n',1)
  if ('title: '+title) in parts[0].splitlines(): matches.append({'file':str(f.relative_to(B.parent)),'text':parts[1] if len(parts)>1 else ''})
 return matches
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',chromium_sandbox=True)
 context=browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
 page=context.new_page();page.set_default_timeout(7000)
 page.on('pageerror',lambda e:log['errors'].append(str(e)))
 page.on('request',lambda r:log['requests'].append({'url':r.url,'method':r.method}))
 page.on('dialog',lambda d:(record('dialog',message=d.message),d.accept()))
 def settle():page.wait_for_timeout(550)
 def snap(name):
  page.evaluate('document.fonts.ready');page.screenshot(path=str(O/(name+'.png')));log['captures'].append({'file':name+'.png','time':time.time(),'viewport':page.viewport_size,'scroll':page.evaluate('scrollY')})
 def note(title): return page.locator('.tc-tiddler-frame').filter(has=page.locator(':scope')).filter() if False else page.locator('.tc-tiddler-frame[data-tiddler-title='+json.dumps(title)+']')
 def label(key):return page.evaluate('(k)=>$tw.wiki.getTiddlerText("$:/language/Buttons/"+k+"/Hint")',key)
 def click_edit(title):note(title).locator('button[title='+json.dumps(label('Edit'))+']').click();settle()
 def cancel():page.locator('button[title='+json.dumps(label('Cancel'))+']').click();settle()
 def save():page.locator('button[title='+json.dumps(label('Save'))+']').click();settle()
 def reset_story():page.evaluate('(x)=>{$tw.wiki.setText("$:/StoryList","list",null,x);$tw.wiki.setText("$:/HistoryList","text",null,"[]")}',[INDEX,T]);settle();page.evaluate('scrollTo(0,0)')
 try:
  start=time.perf_counter();page.goto('http://127.0.0.1:4412/',wait_until='networkidle');settle()
  for bt in page.locator('button[title="Discard changes to this tiddler"]').all():bt.click()
  page.evaluate('$tw.wiki.setText("$:/language","text",null,"$:/languages/en-GB");$tw.wiki.setText("$:/palette","text",null,"$:/palettes/VanillaPaperDay");$tw.wiki.setText("$:/state/sidebar","text",null,"yes")');settle();reset_story()
  record('initial render',secondsIncludingWait=round(time.perf_counter()-start,3),theme=page.evaluate('$tw.wiki.getTiddlerText("$:/theme")'),colorScheme=page.evaluate('getComputedStyle(document.documentElement).colorScheme'),headMeta=page.locator('meta[name="color-scheme"]').get_attribute('content'))
  snap('final-light-index-1440')
  note(INDEX).get_by_role('link',name=T,exact=True).click();settle();snap('journey-01-interview-start')
  full=note(T).inner_text();assert 'A final unresolved question' in full
  page.mouse.wheel(0,650);settle();snap('journey-02-interview-middle')
  page.mouse.wheel(0,650);settle();snap('journey-03-interview-end')
  note(T).get_by_role('link',name='Evidence ledger',exact=True).click();settle();snap('journey-04-ledger')
  assert note('Evidence ledger').locator('table').count()>0
  page.locator('.tc-sidebar-header').get_by_role('link',name=T,exact=True).click();settle()
  record('read evidence and return',completeInterviewCharacters=len(full),evidenceTable=True,returnedTitle=note(T).get_attribute('data-tiddler-title'))
  original=page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',T)
  changed=original.replace('The bakery window mattered because','The bakery window was useful because').replace('这提示我们检查信息出现的时机。','这提示我们仔细检查信息出现的时机。')
  assert changed!=original
  click_edit(T);editor=page.locator('textarea.tc-edit-texteditor-body');assert editor.count()==1
  editor.fill(changed);snap('journey-05-bilingual-edit');save()
  page.wait_for_function('(x)=>$tw.wiki.getTiddlerText(x.t)===x.text',arg={'t':T,'text':changed})
  for i in range(30):
   disk=body_on_disk(T)
   if any(x['text'].rstrip()==changed.rstrip() for x in disk):break
   page.wait_for_timeout(100)
  assert any(x['text'].rstrip()==changed.rstrip() for x in disk),'changed passage missing on filesystem'
  page.reload(wait_until='networkidle');settle();assert page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',T)==changed
  record('English and Chinese save persisted',diskMatches=[x['file'] for x in disk if x['text'].rstrip()==changed.rstrip()],browserReloadAgreement=True,english='The bakery window was useful because',chinese='这提示我们仔细检查信息出现的时机。')
  snap('journey-06-saved-reloaded')
  click_edit(T);page.locator('textarea.tc-edit-texteditor-body').fill(original);save();page.reload(wait_until='networkidle');settle();assert page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',T)==original
  record('restore original supplied interview',reloadAgreement=True)
  page.keyboard.press('Control+Shift+F');assert page.locator('.tc-search input').evaluate('(e)=>document.activeElement===e')
  page.keyboard.type('Quiet route');settle();snap('journey-07-keyboard-search');page.keyboard.press('ArrowDown');page.keyboard.press('Enter');settle()
  assert note(QUIET).count()==1
  target_found=False
  for i in range(100):
   active=page.evaluate('({title:document.activeElement.title,note:document.activeElement.closest(".tc-tiddler-frame")?.getAttribute("data-tiddler-title")})')
   if active['title']==label('Edit') and active.get('note')==QUIET:target_found=True;break
   page.keyboard.press('Tab')
  assert target_found,'could not reach target edit control by tab'
  snap('journey-08-keyboard-focus');page.keyboard.press('Enter');settle();assert page.locator('textarea.tc-edit-texteditor-body').count()==1
  qoriginal=page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',QUIET)
  page.locator('textarea.tc-edit-texteditor-body').fill(qoriginal+'\nTemporary verification text — 应取消。')
  snap('journey-09-cancel-edit');cancel();page.reload(wait_until='networkidle');settle();assert page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',QUIET)==qoriginal
  page.locator('.tc-sidebar-header').get_by_role('link',name=T,exact=True).click();settle()
  record('keyboard search to editor and cancel',tabPresses=i,cancelPreservedOriginal=True,continuedTo=T)
  reset_story()
  for mode in ['light','dark']:
   pal='$:/palettes/VanillaPaper'+('Day' if mode=='light' else 'Night');page.evaluate('(p)=>$tw.wiki.setText("$:/palette","text",null,p)',pal);settle()
   for width,height in [(1440,900),(1280,640),(390,844)]:
    page.set_viewport_size({'width':width,'height':height});settle()
    note(T).evaluate('(e)=>{e.scrollIntoView({block:"start"});scrollBy(0,-24)}');settle();snap(f'final-{mode}-read-{width}')
    measure=note(T).evaluate('(e)=>({width:e.getBoundingClientRect().width,font:getComputedStyle(e.querySelector(".tc-tiddler-body")).fontFamily,fontSize:getComputedStyle(e.querySelector(".tc-tiddler-body")).fontSize,lineHeight:getComputedStyle(e.querySelector(".tc-tiddler-body")).lineHeight})')
    click_edit(T);snap(f'final-{mode}-edit-{width}')
    overflow=page.evaluate('({viewport:innerWidth,document:document.documentElement.scrollWidth})');assert overflow['document']<=overflow['viewport']+1
    record('variant',theme=mode,viewport=[width,height],language='en-GB',reading=measure,editorVisible=page.locator('textarea.tc-edit-texteditor-body').is_visible(),overflow=overflow)
    cancel()
  page.evaluate('$tw.wiki.setText("$:/language","text",null,"$:/languages/zh-Hans")');settle()
  for mode,width,height in [('light',1280,640),('dark',390,844)]:
   page.evaluate('(p)=>$tw.wiki.setText("$:/palette","text",null,p)','$:/palettes/VanillaPaper'+('Day' if mode=='light' else 'Night'));page.set_viewport_size({'width':width,'height':height});settle();note(T).evaluate('(e)=>{e.scrollIntoView({block:"start"});scrollBy(0,-24)}');settle();snap(f'final-zh-{mode}-read-{width}');click_edit(T);snap(f'final-zh-{mode}-edit-{width}');cancel();record('Chinese UI variant',theme=mode,viewport=[width,height],editLabel=label('Edit'))
  page.set_viewport_size({'width':1280,'height':640});page.evaluate('$tw.wiki.setText("$:/language","text",null,"$:/languages/en-GB");$tw.wiki.setText("$:/palette","text",null,"$:/palettes/VanillaPaperDay");$tw.wiki.setText("$:/state/sidebar","text",null,"yes")');settle();reset_story()
  for pref in ['no-preference','reduce']:
   page.emulate_media(reduced_motion=pref);settle();snap('motion-'+pref+'-before');start=time.perf_counter();page.locator('.btc-sidebar-toggle').first.click()
   frames=[]
   for delay in [0,80,180,300]:
    page.wait_for_timeout(delay);snap('motion-'+pref+'-'+str(delay));frames.append({'timeFromClick':round(time.perf_counter()-start,4),'geometry':page.locator('.tc-story-river').bounding_box()})
   record('sidebar controlled episode',preference=pref,frames=frames,cssTransition=page.locator('.tc-page-container').evaluate('(e)=>getComputedStyle(e).transitionDuration'))
   page.locator('.btc-sidebar-toggle').first.click();settle()
  page.emulate_media(reduced_motion='no-preference');page.set_viewport_size({'width':1440,'height':900});reset_story();snap('final-ready-1440')
  assert page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',T)==original
  record('completed',pageErrors=log['errors'],requests=len(log['requests']),externalRequests=[r for r in log['requests'] if not r['url'].startswith('http://127.0.0.1:4412')])
 except Exception as e:
  record('FAILED',message=str(e),traceback=traceback.format_exc());snap('verification-failure');raise
 finally:
  log['finished']=time.time();(O/'verification-log.json').write_text(json.dumps(log,ensure_ascii=False,indent=2));print(json.dumps(log['checks'],ensure_ascii=False));context.close();browser.close()
