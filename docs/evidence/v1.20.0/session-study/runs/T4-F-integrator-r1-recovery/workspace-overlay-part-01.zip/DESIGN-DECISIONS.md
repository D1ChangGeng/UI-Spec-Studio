# Current design and evidence model — Fieldnotes save feedback

## Goal and scope

The working product is the supplied Fieldnotes settings application with real browser-local persistence. This increment connects the settled Tabler action-bearing toast to the actual save contract. The existing settings page, theme system, controls and source family remain the design foundation. This is a working local product, not a staged save demonstration.

The active quality responsibility is one complete save-feedback loop: submit → pending → authoritative outcome → explicit dismissal or failed-snapshot retry, including retained newer edits, field recovery and focus. The toast and inline summary share announcement responsibility. The implementation boundary is the three permitted application files in `INTEGRATION-DECISION.md`; the regression boundary includes the header/menu, profile fields, notification/privacy controls, lower save/cancel controls, themes and declared locales. Unrelated gallery destinations remain out of scope.

## Settled source and authority

The coordinator's decision in `INTEGRATION-DECISION.md` is inherited as the design basis. It establishes this variant and placement; it does not establish end-user aesthetic acceptance. No new resource comparison, art direction or W1–W3 original-construction exception is authorized or needed.

- Exact acquired block: `sources/tabler-toast-cookies.html`, SHA-256 `767fe7aaddd46979d9f2748c1488063902086109962051881aeae94ad04dc75a`.
- Related source: Tabler `@tabler/core@1.7.1`, commit `07f60c07da13d8ff957a370434b7ef5c86f5ab94`, `sources/shared/components/demo/Toast.astro`, MIT license retained in `app/LICENSE`.
- Acquired deployed page: `sources/official-toasts-snapshot.html`, SHA-256 `c5d0c06e11c2990ef70e5502cc72c2a2a8f6d13af25ac08d64a9859fe93c5e5d`. It reports 1.7.1; the actual deployment commit remains unknown and is not equated with the related tag.
- Official current documentation: [Bootstrap Toasts](https://getbootstrap.com/docs/5.3/components/toasts/), exact returned tool evidence in `evidence/web-sources-001.json` and `evidence/web-toasts-accessibility.json`.

The source carries the 350px maximum width, compact identity/time/close header, body, separated small primary action, type, borders, shallow shadow, theme material, native fade and dismissal. Product configuration moves the toast to the specified top-right utility container. Content substitutions are FN / Fieldnotes, actual save states, actual saved time and the retry action; the cookie example and portrait are reference-only.

## Direct source observations

The primary agent viewed the block-only preview in both themes at 1440×900 and the baseline full settings page. The source has a visually compact header, small avatar slot, modest body padding and a thin separator before the blue action. The shadow is shallow, so its placement and surface boundary carry much of its separation. The dark variant retains the same spacing and hierarchy with a darker header and slightly lighter body. The source-preview emoji appears as a missing glyph under this environment; the adopted decision requires no emoji, so this does not create a product asset task.

The primary also rendered the exact frozen official toast document locally using a temporary request route and matching supplied CSS/JS, operated the Cookies toast control, and verified native close in both themes. `evidence/frozen-source-render/` preserves these observations and request limitations. External requests were aborted; unavailable portraits remain empty. This is frozen-source rendering, not live-public-browser observation. The live public Chromium request failed TLS verification and is retained in `evidence/source-inspection/observations.json`; no TLS bypass was used. The web retrieval tool could read the current public page text, which is a different evidence boundary.

## Owners and continuity

`settings-store.js` remains the authority for validation, submitted snapshots, operation IDs, the 750ms pending interval, schema version 1 and localStorage writes. The controller owns live form values and controls. The adapter may render events and explicitly retry a failed snapshot; it must not write storage or replace form drafts. An older error must not displace newer feedback. Saved wording follows a successful write. Failure and dismissal preserve both the draft and previous stored value.

The inline summary stays in the form but does not repeat the toast's live announcement. The toast remains polite and persistent. Native close dismisses feedback only. The new source action is exposed only for errors; removing a focused retry or close must return focus to a useful initiating control. Invalid submission links concrete field messages to affected fields and focuses the first invalid field when recovery needs it.

## Evidence plan and current status

The required matrix is light/English and dark/Chinese at 1440×900 and 1280×600, plus 390×844 containment. The independent primary review script exercises visible save, edits during pending, actual storage readback, forced failure, retry with a newer draft still in the form, invalid fields, native close, close during pending, persistence after reload, notification/privacy fields and adjacent theme controls. A separate ordering case checks an older error following a newer invalid event, plus reduced-motion behavior. Captures record actual browser performance-time brackets, focus, scroll and state.

Source acquisition, bounded integration and independent primary inspection are now complete for final revision 3. The primary accepts the settled integration within the required local-product matrix. VISUAL-REVIEW.md records actual personally viewed images, the two focus defects and repairs, independent checks, source fidelity and remaining placement/evidence limits. This is not owner approval; actual screen-reader speech and natural-time video playback remain unverified.

## Guidance applicability

The modern-web-guidance search and persistent-toast guide were actually executed and captured in `evidence/commands/001-modern-search` and `003-modern-retrieve`. The current guide describes a manual Popover implementation. This task explicitly requires the already selected Tabler/Bootstrap Toast and prohibits replacing its surface, transition or close behavior. The selected source therefore governs implementation; the guide's persistent, explicit-dismissal and noninterruption goals are relevant, while its alternate Popover mechanism is not adopted. The guide reported a newer skill revision; the supplied method and role bytes remain unchanged.

## Allocation

The primary retains design judgment and final assembled-product inspection. The bounded fresh-context child follows `roles/ui_integrator.toml`; the exact prompt and actual responses are retained in `DELEGATION.json`. An initial spawn was rejected by the host's thread limit. Independent source/evidence preparation continued during the capacity wait. The subsequent dispatch succeeded with model and effort inherited; resolved backend identities, native role bindings, total tokens and billed cost are unavailable.

## Meaningful revisions and final judgment

The fresh bounded integrator made three product revisions. Primary inspection found offscreen focus return, then invalid-field occlusion after the complete flow. Native focus reveal and centered invalid recovery repaired those relationships while retaining the chosen shell. Error summary wording now truthfully permits continued editing without claiming an unchanged saved form is dirty. Final computed source comparison finds zero differences across seventeen properties of seven parts in two variants. The 350px compact shell, small separated action, type/material/borders/shadow and native fade survive.

Final independent evidence: 178 behavior checks pass in primary-review-003; 18 focused visibility checks pass in primary-settled-004. The primary actually viewed all six final invalid-recovery conditions, final error/retry/close/lower-region examples, header neighbors and the twenty-frame save/error/retry/close contact sheet. Source craft retention and whole-flow recovery are accepted for this bounded increment. Fixed top-right feedback still covers some header utilities until dismissed; this is an explicit retained composition tradeoff, not hidden by the passing test counts.

Implementation scope is index.html, settings-controller.js and save-notification.js only. The retained final diff totals 244 additions and 8 deletions; no merge conflict occurred. The two corrective integration cycles are actual rework, not hypothetical cost savings. Total tokens, billing and native backend identity are unknown.
