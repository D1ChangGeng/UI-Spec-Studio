# Fieldnotes save feedback — completed

The settled Tabler toast is connected to the real settings save contract. It now presents pending, saved, failed-with-retry and invalid-field states in English and Chinese. Retry uses the failed submitted snapshot while preserving newer edits in the form; successful wording follows an actual browser-local storage write. Native close dismisses feedback without cancelling persistence.

The runnable product is in [app](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w17/app/index.html). Start it with:

```sh
python3 -m http.server 4417 --bind 127.0.0.1 --directory /workspace/scratch/708e8b7f118e/ui-study/worksets/w17/app
```

Then open `http://127.0.0.1:4417/`. The owned review server was stopped after inspection as required.

## What changed and why

Only `app/index.html`, `app/settings-controller.js` and the new `app/save-notification.js` changed. The existing store remains authoritative for validation, snapshots, operation IDs and writes. The integration retains the selected source’s 350px shell, identity/time/close header, compact body, separated small action, typography, materials, borders, shadow and native transition. The MIT notice is retained beside the adopted block. No replacement style system, dependency or motion was introduced.

The source is the exact acquired Tabler cookie-action block, related to Tabler 1.7.1 revision `07f60c07da13d8ff957a370434b7ef5c86f5ab94`. Its deployed HTML snapshot remains a separate identified source whose exact deployment commit is unknown. The [design decision record](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w17/DESIGN-DECISIONS.md) preserves hashes, adoption responsibilities and guidance applicability.

Primary visual inspection caught two issues that semantic checks alone missed: retry/close could return focus offscreen, and a later invalid submission could place the first field under the fixed toast. The bounded integrator repaired both with native focus and scroll behavior. Final screenshots show the invalid field, its label and its error clear of the notification in all six required conditions.

## Independent verification

| Evidence | Final result |
|---|---|
| [Behavior results](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w17/evidence/primary-review-003/results.json) | 178/178 checks pass: light/en and dark/zh at 1440×900, 1280×600 and 390×844, plus stale-event and reduced-motion checks. |
| [Focus visibility](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w17/evidence/primary-settled-004/focus-visibility-checks.json) | 18/18 settled checks pass for retry return, dismissal return and invalid recovery. |
| [Source and neighbors](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w17/evidence/source-and-neighbors-final/results.json) | Zero differences across seventeen computed properties of seven source/product parts in the two compared variants; keyboard header menu and native close work. |
| [Primary visual review](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w17/VISUAL-REVIEW.md) | Personally viewed final six-condition recovery, error/retry/close examples, neighboring settings/header regions and twenty ordered temporal captures. |

Actual storage readback, failed-write preservation, newer draft retention, pending dismissal, reload, switches, cancel and theme continuity were exercised. Original failed attempts and corrected runs remain in the evidence archive. The [final diff](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w17/evidence/final-integration.diff) records 244 additions and 8 deletions; protected application files remain unchanged.

## Scope and limitations

The bounded integration is implemented and independently accepted for the declared local-product matrix. The inherited top-right placement temporarily covers some header utilities while feedback persists. Its close control remains reachable and clears the overlay; changing that placement would reopen the settled decision.

Live public-browser source access failed TLS verification; exact frozen-source rendering and separate public textual retrieval are retained. Actual screen-reader speech, natural-time video playback, other browser engines and unrelated gallery destinations were not verified. Ordered frames establish sampled state/transition behavior, not frame-rate smoothness. No owner approval is implied.

One fresh bounded child performed the integration, with inherited model and effort. [DELEGATION.json](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w17/DELEGATION.json) retains the exact prompt, actual thread-limit rejection, successful dispatch and final report references. Approximately 216 seconds separate the retained failed/successful dispatch export timestamps; primary source/evidence work continued during that interval, so it is not claimed as idle time. Three implementation revisions and two primary-directed repair cycles occurred, with no merge conflict. Native backend identity, total tokens and billed cost are unknown.
