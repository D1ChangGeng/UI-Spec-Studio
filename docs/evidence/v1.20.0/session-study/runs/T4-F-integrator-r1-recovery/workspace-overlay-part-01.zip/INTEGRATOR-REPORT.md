# Bounded integration report

## Outcome and responsibility

The settled Tabler action-toast integration is implemented in the authorized three product files and available through the existing primary preview at `http://127.0.0.1:4417/`. The final product revision 3 includes the primary agent's independently confirmed focus-return and invalid-field-reveal corrections, plus the neutral inline failure summary. No consequential source, art-direction, layout, motion, persistence, or business-policy decision was changed.

This report covers the integrator's implementation and scoped checks. It does not declare the formal UI SPEC complete, provide whole-product acceptance, or substitute for the primary agent's independent six-condition and neighboring-experience review.

## Exact changed product files

| File | Change |
|---|---|
| `app/index.html` | Adopts the selected toast in `toast-container position-fixed top-0 end-0 p-3`; copies the full MIT notice beside the block; uses Fieldnotes/FN; retains the native header/body/action hierarchy and close control; turns the existing inline summary's live announcements off. |
| `app/settings-controller.js` | Coordinates the form summary, current-draft comparisons, native invalid-field presentation, field-error association, rejected-submit focus recovery, stale-event filtering, and initiating-control return. Preserves the existing language/theme/navigation handlers. |
| `app/save-notification.js` | New small adapter subscribing to authoritative events, rendering the native toast, guarding against older operation IDs, retaining the failed snapshot, invoking explicitly requested retry, and coordinating native dismissal with a later arriving event. |

`app/settings-store.js`, `dist/`, `preview/`, source previews, and unrelated navigation were not edited. The store's final SHA-256 is `32139de23b4ad411c402620e84d5592f7ccfbcf68cece1a123946c29b63c2da0`, identical to the supplied baseline. No dependency, custom stylesheet, replacement surface system, animation, or W1–W3 construction was introduced.

Final SHA-256 identities, also emitted by the actual repaired check:

| Product file | SHA-256 |
|---|---|
| `index.html` | `8a0b482a1d686a505a0321e81dd8be1e9955ace68730c3efa30d3b81aa88843e` |
| `settings-controller.js` | `e10a86a0dab0c23a2b166bf34344e9efe4748f3fac3f8fb43beac225a1785b1d` |
| `save-notification.js` | `931e95666a858829b3698ca4987b4e7387dce8d7dc011ca39df00408e57ea2d4` |

## Source identity and retained relationships

The adopted source is `sources/tabler-toast-cookies.html` and `sources/shared/components/demo/Toast.astro`, with matching local Tabler 1.7.1 assets and bundled Bootstrap Toast exposed as `window.tabler.Toast`. The related tagged revision is `07f60c07da13d8ff957a370434b7ef5c86f5ab94`. The extracted block's SHA-256 is `767fe7aaddd46979d9f2748c1488063902086109962051881aeae94ad04dc75a`, matching the manifest. The deployed HTML snapshot is a separately identified acquisition; its exact deployment commit is unknown.

Retained mechanisms are the source's standard 350px maximum width; the avatar/identity/time/close header; the compact body; the separated `mt-2 pt-2 border-top` action row; `btn btn-primary btn-sm`; native type, padding, borders, materials, shadow and focus treatment; and native Toast show/hide/fade/dismissal. The container uses only the settled native positioning and spacing utilities. The action row is hidden outside error states. Native close retains `data-bs-dismiss="toast"`; Retry intentionally invokes the store rather than inheriting the sample acknowledgement's dismiss action.

The source sample portrait is replaced by its avatar initials fallback, `FN`, with `Fieldnotes` identity. Cookie sample copy is replaced by the decided save-state content. These are content/state adaptations. `role="status"`, `aria-live="polite"`, `aria-atomic="true"`, and `data-bs-autohide="false"` remain on the toast. `#save-status` is still a concise visible form summary with `aria-live="off"` and no duplicate status role.

I read the assigned role, task, input, run control, allocation, integration decision, source manifest, the full method skill, all eight professional references, and the full integration reference. I also read the actual current modern-web search and retrieved guide exports already retained by the primary agent. The guide's alternative manual-popover implementation conflicts with the explicitly settled native Tabler source; the authorized source API and transition were preserved. No TLS bypass or additional public-source request was made by this integrator.

## State and ownership behavior

The store remains authoritative for schema version 1, `fieldnotes-settings-v1`, validation, the 750ms pending interval, snapshots, writes and outcome events. The notification never reads an unrelated live draft during retry, writes storage, clears fields, or declares success from a timer.

| State | Rendered behavior |
|---|---|
| Pending | “Saving changes” / “正在保存更改”; explains that this submitted version is being saved in the current browser. The action row is hidden. The source disabled button presentation plus `aria-disabled`/`aria-busy` and a guarded click prevent duplicate visible submissions while retaining keyboard focus. Form fields remain editable. |
| Success | “Changes saved” / “更改已保存”; states that this submitted version is saved only in the current browser. The source time slot displays the actual `savedAt` formatted for the locale and retains its ISO value in `title`. No focus movement is performed because a save completed. |
| Error | “Save did not complete” / “保存未完成”; retains the submitted snapshot and explains that Retry saves that version. “Retry save” / “重试保存” calls `saveSettings({...failedSnapshot})`. The final inline summary says “You can keep editing this form.” / “你可以继续编辑表单。” without asserting that an unchanged form is dirty. |
| Invalid | “Check profile fields” / “请检查个人资料字段”; names the actual first invalid field and its store-provided error, translated for Chinese. Native `is-invalid`/`invalid-feedback`, `aria-invalid`, and `aria-describedby` attach errors to fields. A rejected visible submit moves focus only if focus is not already on an invalid field, then reveals that first field with native `scrollIntoView({block:'center'})` so its visible label and error remain clear of the fixed toast. |

Both controller and adapter reject events with an older `operationId`. Native close dismisses only feedback. Closing pending feedback does not cancel the store's write; a later authoritative result can display again. A result arriving during the native closing transition is displayed after `hidden.bs.toast`, preserving the native transition callback.

Explicit retry/close return now calls native `focus()` on the initiating save control so the browser reveals it. No scrolling implementation or new motion was added. Later field edits remain present during and after pending, success, failure and retry.

## Executed checks and revision boundaries

All browser runs used the supplied Chrome 143 headless-shell executable, Playwright 1.57, isolated browser contexts, the primary server at port 4417, and `FONTCONFIG_FILE=/tmp/ui-spec-fonts/fonts.conf`. Nothing stopped or replaced the primary server.

| Evidence | Actual result and scope |
|---|---|
| `evidence/integrator/001-implementation/` | Exact successful implementation subprocess output. |
| `evidence/integrator/002-behavior-attempt/` | Retained failed first check attempt: the harness used a positional argument where Playwright requires `arg=`. This was a harness error, not a product result. The original script is retained as `check-attempt-001.py`. |
| `evidence/integrator/003-behavior-corrected/` and `check-002/checks.json` | Passed visible keyboard save; pending edit retention; success/storage readback and real saved time; one-time failure preserving prior storage; keyboard retry of failed snapshot with a newer live draft; invalid first-field changes and associations; dismissal and return; close during pending; stale older success/error after a newer invalid operation; Chinese errors; and selected viewport containment. |
| `evidence/integrator/004-focus-reveal/` and `focus-001/` | Diagnosed native smooth scrolling: an immediate narrow invalid frame was a progression frame. Timestamped geometry shows the focused field settled at y=402–442 in the 390×844 viewport. |
| `evidence/integrator/005-pre-correction-snapshot/` and `revision-1/` | Preserved exact first-revision product bytes and hashes before the independently confirmed repair. |
| `evidence/integrator/006-focus-summary-repair/` | Exact successful narrow correction output after the primary agent finished its prior-revision capture and authorized the repair. |
| `evidence/integrator/007-repaired-focus-check/` and `repair-check-001/checks.json` | Passed revision-2 explicit retry/close reveal at light/en 1440×900 and dark/zh 390×844, retained snapshot retry/newer draft, no completion focus theft, and truthful summary when an unchanged saved form's save fails. Includes the hashes of that revision. |
| `evidence/integrator/008-invalid-reveal-repair/` | Exact successful revision-3 repair output: native centered reveal is called only when rejected-submit recovery moves focus. |
| `evidence/integrator/009-invalid-centered-check/` and `invalid-check-001/checks.json` | Passed settled first-invalid-field centering, visible display-name label/error, actual field hit target and no toast overlap in all six required conditions. Also passed dark/zh 390 reduced-motion and subsequent email recovery. The original email label remains visually hidden by its native source class; its accessible association and visible error are preserved. Includes final revision-3 hashes. |

The first-revision adapter checks used light/en at 1440×900, dark/zh at 1280×600, and both declared variants at 390×844. Toast width was actually measured as 350px, with x=24 and right=374 at 390px. The final integrator validation-recovery check covers all six conditions at that narrow responsibility. The primary agent owns the complete required six-condition whole-product matrix, header/menu reachability, surrounding settings regions, and final assembled judgment. This report does not promote the integrator's sampled checks into that complete review.

## Actual visual inspection

The following images were opened with `view_image`; exact successful returned objects are retained under `evidence/integrator/view-source-dark.json` and `evidence/integrator/views/`:

- Parent-provided `evidence/frozen-source-render/frozen-block-dark.png`: locally rendered frozen original source block, showing the compact dark header, body and separated small action. This was not a successful live public-browser observation.
- First revision `check-002/light-en-1440-error.png` and `light-en-1440-success-newer-draft.png`: source hierarchy and width remain legible beside the settings content; the error action is separated; success has no empty action footer; live input and focused state remain present.
- First revision `check-002/dark-zh-1280-error.png`: Chinese body wraps without clipping, the native primary retry action remains distinct, and the lower save control retains visible focus.
- First revision `check-002/dark-zh-390-invalid.png`: explicitly a native-scroll progression frame, not a settled recovery judgment.
- `focus-001/focus-600.png`: actual settled narrow validation view; the named invalid field, native border/icon and associated message are visible below the toast.
- Revision 2 `repair-check-001/light-en-1440-error.png` and `dark-zh-390-error.png`: source shell and action relationship persist with the corrected behavior and summary. The 390px toast remains contained.
- Revision 2 `repair-check-001/dark-zh-390-close-focus-visible.png`: a focus-reveal progression frame showing the focused initiating save within the viewport after native dismissal. It is not represented as the final rest of smooth scrolling; the primary agent's settled capture addresses that condition.

- Primary revision-2 `evidence/primary-settled-002/390x844-dark-zh/06-invalid-field.png`: actually viewed the settled defect in which the fixed toast covered most of the first invalid input; retained as `views/revision-2-covered-invalid.json`.
- Final revision-3 `invalid-check-001/1280x600-light-en-no-preference-business-name.png`, `390x844-light-en-no-preference-business-name.png`, and `390x844-dark-zh-no-preference-business-name.png`: actually viewed centered recovery. The visible field label, editable input and associated feedback are now separated from the fixed toast. Exact view responses are retained in `views/`.

The observed source-to-product retention is the compact header/body/action hierarchy, standard width, native material and button relationships. The source cookie text, portrait and relative sample time were intentionally replaced. No natural-time video playback was performed by this integrator; ordered geometry/captures and actual scripted interactions support only their stated temporal scope.

## Findings, repairs and remaining limits

The primary agent independently confirmed that the first revision's `focus({preventScroll:true})` could return active focus to an offscreen save control. The integrator's narrow repair uses `focus()` only when a focused toast control disappears. The final check verifies that the save control becomes visible while ordinary completion still preserves field focus. The neutral inline failure summary also removes an unsupported dirty-state claim for an unchanged saved form.

The immediate mobile invalid image was initially a capture-timing issue caused by the source's existing smooth-scroll CSS. Its separately viewed settled diagnostic showed correct recovery for that simpler starting condition. That limited diagnostic did not establish every later recovery sequence. The primary agent subsequently found an actual settled revision-2 defect after the complete flow: at both 390px variants, the first invalid input at y=0–40 was mostly covered by the toast; at 1280px, the input was horizontally outside the toast but its label remained above the viewport. These are distinct visibility relationships.

Revision 3 adds native `scrollIntoView({block:'center'})` immediately after rejected-submit recovery moves focus to the first invalid field. No source spacing, fixed placement, custom motion or completion-focus change was introduced. The focused six-condition check waits for twelve stable animation frames before measuring and capturing. It verifies the first input at y=430–470 for 1440×900, y=280–320 for 1280×600, and y=402–442 for 390×844, with the display-name label and error visible, no toast overlap, and the actual input returned by hit testing. Reduced-motion output uses the source's `auto` scroll behavior; ordinary output uses its `smooth` behavior. The field, label and error were personally viewed in both 390px variants and light/en 1280px. The primary agent retains the broader final acceptance.

One attempted image-response export failed because its generated patch omitted a `+` prefix. The repeated `view_image` call and successful exact response export are retained. The original failed tool call remains in this child transcript; it was not retrospectively fabricated as a standalone tool record.

No unresolved consequential integration decision remains with this integrator. Important scope limits remain: the public live demo's TLS failure belongs to the retained primary evidence; tagged-source and deployed-snapshot identities remain separate; actual screen-reader speech was not tested; and final whole-product acceptance remains with the primary agent. The read-only store does not cancel earlier writes merely because later validation failed. The stale-event check confirms that those older outcomes do not replace newer feedback; it does not claim new persistence concurrency semantics.
