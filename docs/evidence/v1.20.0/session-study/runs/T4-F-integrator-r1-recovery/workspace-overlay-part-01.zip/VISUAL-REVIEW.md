# Primary visual review — final revision 3

## Responsibility and evidence boundary

The primary designer independently inspected the selected source, the assembled application and affected neighbors. This is scoped design acceptance for the settled save-feedback integration. It does not represent owner approval, a new art-direction choice, a screen-reader session or natural-time video viewing. The source and related tag remain identified separately from the deployed snapshot in DESIGN-DECISIONS.md and SOURCE-MANIFEST.json.

All application captures came from the running local application in the supplied Playwright/Chrome environment with the provided Noto CJK font configuration. The primary preview used port 4417 and was stopped after review as RUN-CONTROL.md requires. Original command exports, including failed attempts, remain in evidence/commands/. Product revision identities are in evidence/revision-final-r3.json.

## Personally viewed source and product

The primary viewed local original source previews in both themes, the baseline whole settings application, the frozen official whole toast page in light and its cookie-action block in dark. Exact returned image-tool objects are saved in evidence/view-local-source-*.json, view-baseline-product-light-en.json, view-frozen-full-light.json and view-frozen-block-dark.json. The frozen page was fulfilled locally with matching assets and external requests aborted. A live browser request failed TLS verification; no bypass was attempted. Current public textual retrieval is separately retained.

Revision-2 error captures in primary-settled-002 were personally viewed in all six required conditions. They establish the adopted source hierarchy, small action, text wrapping and containment. Final revision-3 source comparisons and captures confirm that the subsequent validation-reveal repair did not alter these visual relationships.

Final revision-3 primary-settled-004/06-invalid-field.png was personally opened for all six conditions: light/en and dark/zh at 1440×900, 1280×600 and 390×844. Exact image responses are in evidence/w17-confirmed-<viewport>-<theme>-<locale>-invalid.json. The first invalid field, its visible display-name label and associated error are now clear of the fixed toast. Inputs settle at y=430–470, y=280–320 and y=402–442 respectively. The short desktop view intentionally centers recovery, so some upper heading content is outside the viewport. The focused recovery target and context remain clear.

Additional final images personally opened and retained as evidence/w17-confirmed-*.json:

| Actual image | Observed relationship |
|---|---|
| primary-settled-004/390x844-dark-zh/01-error-top.png | The 350px toast is contained at x=24–374, Chinese copy wraps, the retry action remains separated and native close remains visible. It overlays the header and top settings area under the settled placement. |
| primary-settled-004/1440x900-light-en/03-retry-focus.png | The focused initiating Save is visible after retry, while the form retains later edits and pending feedback remains in the source shell. Native disabled button material is visible. |
| primary-settled-004/390x844-dark-zh/05-close-focus.png | Native close has removed feedback; the lower Save control has visible focus, surrounded by the existing privacy and notification controls. |
| primary-settled-004/390x844-dark-zh/07-lower-controls.png | Existing switches, email recovery, save/cancel and footer retain their native grouping and usable spacing. |
| source-and-neighbors-final/390-dark-header-menu.png | Header menu opens by keyboard, but the specified persistent top-right toast overlays some upper menu/header content. |
| source-and-neighbors-final/1440-light-header-after-dismiss.png | Native close restores the unobscured header and leaves the settings composition intact. |

One attempted final image lookup used an incorrect flattened path and failed before viewing. The successful subsequent calls used the actual nested paths. An earlier multi-image output was truncated; the final six invalid views were explicitly reopened in bounded batches rather than treating those saved files as proof of viewing.

## Temporal observation

The primary personally viewed evidence/primary-episode-002/contact-sheet.png at original resolution. It contains twenty actual captured toast regions, each labeled with the browser performance-time capture bracket and current state. The sampled episode shows before-save, source fade into pending, authoritative failure with separated Retry, retry returning to pending, saved state with real saved time, fading close and cleared return. These are real-timer ordered samples, not synthetic frames and not natural-time video playback. Their timestamps include capture overhead; they do not establish frame-rate smoothness. Full original screenshots and episode.json are retained alongside the sheet. This revision-2 episode is carried forward only for its unchanged save/retry/close path; the final revision-3 change is confined to invalid-field reveal, separately recaptured and checked.

## Independent checks and source fidelity

| Evidence | Result and scope |
|---|---|
| primary-review-003/results.json; commands/011-* | Final revision: 178/178 behavior checks pass across six required conditions plus stale-event/reduced-motion case. Includes actual successful/failed storage boundary, failed-snapshot retry with newer live draft, pending edits, keyboard, close during pending, reload, switches, cancel and theme continuity. |
| primary-settled-004/focus-visibility-checks.json; commands/014-* | Final revision: 18/18 settled focus/visibility checks pass for retry return, close return and invalid recovery across six conditions. |
| source-and-neighbors-final/results.json; commands/013-* | Seventeen computed style properties compared across seven source/product parts, in light/desktop and dark/mobile, with zero differences. Includes type, padding, material, border, radius, shadow and transition. Keyboard header menu opens and native close dismisses. |
| revision-final-r3.json; final-integration.diff | Only the three authorized product files changed. The read-only store and all protected baseline application files are unchanged. No new dependencies, styles or motion. |

Passing assertions are not the basis of visual acceptance alone. The viewed final renders preserve the selected compact identity/time/close header, body, separated small primary action, shallow shadow, source surfaces and native type. Error action is clear; success and validation do not leave an empty action footer. English and Chinese retain their declared content differences without clipping the toast.

## Findings and repairs

Revision 1 returned active focus to an offscreen Save using preventScroll. Primary settled screenshots and geometry exposed it despite earlier semantic tests passing. The child repaired explicit retry/close return with native focus reveal. The inline error summary was also made neutral so an unchanged saved form does not falsely claim unsaved changes.

Revision 2 still placed the first invalid field at the very top after a complete flow. On mobile, the fixed toast covered it; at short desktop, its label was outside the viewport. The primary actually viewed these frames and requested native centered reveal only when rejected-submit recovery moves focus. Final revision 3 resolves that relationship without changing source placement or completion focus behavior.

Source smooth scrolling caused early captures called top views to occur mid-scroll. All initial attempts remain, and the final harness waits for stable frames. A strengthened final visibility assertion initially mistook the native pending Save pointer-events:none behavior for overlay occlusion; that failed run remains in primary-settled-003. The corrected predicate accepts the native disabled control when hit testing falls to its parent. The product was not changed for this harness correction. A missing Pillow dependency during contact-sheet construction is also retained; the installed primary runtime produced the sheet successfully.

## Acceptance and remaining limits

Accept the bounded integration for the declared local product and required matrix. Preserve the inherited placement tradeoff: persistent feedback temporarily covers some header utilities (four tested desktop centers and two mobile centers). Close remains reachable and clears the overlay; keyboard menu behavior is retained. Changing placement would reopen the settled decision and was not authorized.

The store remains browser-local and owns persistence concurrency; hiding feedback does not cancel a write. Older results are prevented from replacing newer feedback, but no new cancellation/transaction semantics are claimed. Actual screen-reader speech, natural-time transition smoothness, other browser engines and unrelated gallery destinations remain unverified. The exact live deployed source commit remains unknown. No consequential integration decision is outstanding, and no owner approval is claimed.
