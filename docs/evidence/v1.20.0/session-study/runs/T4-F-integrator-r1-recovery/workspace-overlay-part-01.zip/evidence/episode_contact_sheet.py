import json,math
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]
base=ROOT/'evidence/primary-episode-002'
episode=json.loads((base/'episode.json').read_text())
cellw,cellh=390,286
sheet=Image.new('RGB',(4*cellw,math.ceil(len(episode['frames'])/4)*cellh),'#e7e7e7')
draw=ImageDraw.Draw(sheet)
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',11)
for i,frame in enumerate(episode['frames']):
 im=Image.open(ROOT/frame['path']).convert('RGB')
 if im.size!=(390,250): im=im.crop((890,0,1280,250))
 x=(i%4)*cellw;y=(i//4)*cellh
 text=f"{i:02d} {frame['name']}\n{frame['capture_bracket_ms'][0]:.1f}–{frame['capture_bracket_ms'][1]:.1f} ms | {frame.get('state')}"
 draw.text((x+4,y+3),text,font=font,fill='#111111')
 sheet.paste(im,(x,y+36))
sheet.save(base/'contact-sheet.png')
print(json.dumps({'path':str(base/'contact-sheet.png'),'frames':len(episode['frames']),'derived':'Unaltered toast-region crops arranged with actual capture-time labels; overview of ordered samples, not video playback.'}))
