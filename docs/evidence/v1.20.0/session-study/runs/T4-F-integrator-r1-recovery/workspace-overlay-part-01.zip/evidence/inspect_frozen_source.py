import asyncio,json,time,hashlib
from pathlib import Path
from urllib.parse import urlsplit
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence/frozen-source-render'
OUT.mkdir(parents=True,exist_ok=False)
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=BROWSER,headless=True,args=['--no-sandbox'])
  context=await browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
  blocked=[]
  async def route_request(route):
   url=route.request.url
   if '/frozen-toasts.html' in url:
    await route.fulfill(status=200,content_type='text/html',body=(ROOT/'sources/official-toasts-snapshot.html').read_text())
   elif urlsplit(url).netloc!='127.0.0.1:4417':
    blocked.append(url)
    await route.abort()
   else: await route.continue_()
  await context.route('**/*',route_request)
  page=await context.new_page()
  logs=[]
  for theme in ['light','dark']:
   await page.goto('http://127.0.0.1:4417/frozen-toasts.html?theme='+theme)
   await page.evaluate('document.fonts.ready')
   await page.get_by_role('button',name='Cookies toast',exact=True).click()
   await page.locator('#toast-cookies').wait_for(state='visible')
   await page.wait_for_timeout(250)
   await page.screenshot(path=str(OUT/f'frozen-full-{theme}.png'))
   await page.locator('#toast-cookies').screenshot(path=str(OUT/f'frozen-block-{theme}.png'))
   logs.append({'theme':theme,'html_sha256':hashlib.sha256((ROOT/'sources/official-toasts-snapshot.html').read_bytes()).hexdigest(),'toast':await page.locator('#toast-cookies').evaluate('(el)=>({rect:el.getBoundingClientRect().toJSON(),html:el.outerHTML})')})
   await page.locator('#toast-cookies .btn-close').focus()
   await page.keyboard.press('Enter')
   await page.wait_for_timeout(250)
   logs[-1]['native_close_hides']=not await page.locator('#toast-cookies').is_visible()
  (OUT/'observations.json').write_text(json.dumps({'observations':logs,'external_requests_aborted':blocked,'scope':'Exact frozen source document rendered locally with supplied matching CSS/JS; missing portraits remain unavailable; external scripts and requests were aborted. This is not a claim of live public browser viewing.'},indent=2))
  print(json.dumps({'themes':[x['theme'] for x in logs],'native_close':[x['native_close_hides'] for x in logs],'external_requests_aborted':len(blocked)},indent=2))
  await browser.close()
asyncio.run(main())
