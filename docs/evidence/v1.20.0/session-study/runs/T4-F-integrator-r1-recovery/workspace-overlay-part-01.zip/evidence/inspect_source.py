import asyncio,json,time,hashlib
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence/source-inspection'
OUT.mkdir(parents=True,exist_ok=False)
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=BROWSER,headless=True,args=['--no-sandbox'])
  context=await browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
  page=await context.new_page()
  observations=[]
  for theme in ['light','dark']:
   await page.goto('http://127.0.0.1:4417/toast-source-preview.html')
   await page.evaluate('(theme)=>document.documentElement.setAttribute("data-bs-theme",theme)',theme)
   await page.evaluate('document.fonts.ready')
   await page.screenshot(path=str(OUT/f'local-source-{theme}.png'))
   observations.append({'subject':'selected local source block','theme':theme,'viewport':{'width':1440,'height':900},'toast':await page.locator('#toast-cookies').evaluate('(el)=>({html:el.outerHTML,rect:el.getBoundingClientRect().toJSON(),style:{width:getComputedStyle(el).width,font:getComputedStyle(el).font,padding:getComputedStyle(el).padding,shadow:getComputedStyle(el).boxShadow}})')})
  await page.goto('http://127.0.0.1:4417/?theme=light&lang=en')
  await page.evaluate('document.fonts.ready')
  await page.screenshot(path=str(OUT/'baseline-product-light-en.png'))
  try:
   response=await page.goto('https://preview.tabler.io/toasts.html',wait_until='networkidle',timeout=25000)
   await page.evaluate('document.fonts.ready')
   await page.locator('#toast-cookies').evaluate('(el)=>el.classList.add("show")')
   await page.locator('#toast-cookies').scroll_into_view_if_needed()
   await page.screenshot(path=str(OUT/'public-current-toasts.png'))
   html=await page.content()
   (OUT/'public-current-toasts.html').write_text(html)
   observations.append({'subject':'current public original demo','url':page.url,'status':response.status if response else None,'rendered_html_sha256':hashlib.sha256(html.encode()).hexdigest(),'note':'Current public page; frozen acquired snapshot identity remains separate.'})
  except Exception as error:
   observations.append({'subject':'current public original demo','error':str(error)})
  (OUT/'observations.json').write_text(json.dumps(observations,ensure_ascii=False,indent=2))
  print(json.dumps(observations,ensure_ascii=False,indent=2))
  await browser.close()
asyncio.run(main())
