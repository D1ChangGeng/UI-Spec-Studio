The bounded integration is implemented and ready for your final assembled-product acceptance. The report is saved as [INTEGRATOR-REPORT.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w17/INTEGRATOR-REPORT.md).

### Product changes

- `app/index.html` adopts the selected native toast, copies the full MIT notice with it, uses Fieldnotes/FN, and retains the concise inline form summary without duplicate live announcements.
- `app/settings-controller.js` coordinates pending controls, current form values, field errors, rejected-submit recovery, stale-event filtering and explicit focus return.
- `app/save-notification.js` renders authoritative events through `tabler.Toast` and retries the retained failed snapshot. It does not replace later form edits or write storage itself.

The source's 350px width, identity/time/close header, compact body, separated small action, type, material, spacing and native transition remain. The action row is hidden for pending, success and invalid states. Success uses the actual saved timestamp and states the browser-local boundary. No dependency, replacement styling, custom animation, or original visual construction was added. The store remains byte-identical to the baseline.

### Checks and corrections

The first-revision behavioral run passed actual save, pending edits, storage readback, forced failure, retry with a newer live draft, invalid-field association and focus, close/return, close during pending, stale older success/error, Chinese errors, and selected viewport containment. Its exact outputs are under `evidence/integrator/003-behavior-corrected/`.

Your independent inspection found that explicit toast dismissal or retry could return focus to an offscreen Save control. After your prior-revision capture completed, I applied the authorized narrow correction: native `focus()` now reveals that initiating control. The neutral failure summary also avoids claiming unsaved changes when an unchanged saved form fails.

The final targeted check passed in light/en at 1440×900 and dark/zh at 390×844: retry and close reveal the Save control, retry still persists the failed snapshot while keeping the newer draft, successful completion preserves field focus, and an unchanged form's failed save has truthful summary text. Exact outputs and final hashes are under `evidence/integrator/007-repaired-focus-check/`. Final controller SHA-256 is `e8b1dae34456a23d7581dbce6140b2f4ca57152d7154336b30ef59ee0bd19a9a`.

I viewed the frozen original dark source block, representative integrated light/error and success views, dark Chinese short and narrow views, the settled narrow invalid-field view, and final repaired captures. The first immediate narrow invalid screenshot caught native smooth scrolling in progress; the separately viewed settled frame shows the invalid field and its associated message visibly recovered. All successful image-tool responses were retained at their call sites.

### Handover limits

The report distinguishes my sampled adapter checks from your complete six-condition matrix and neighboring-experience acceptance. No consequential integration decision remains unresolved. Actual screen-reader speech and natural-time video playback were not exercised by me. The public live-demo TLS failure remains retained by you, and the deployed HTML snapshot's unknown commit is kept separate from the related Tabler tag.

First-revision product bytes, the failed initial harness attempt, the correction, and final product bytes are preserved under `evidence/integrator/`. No further product change is pending from this integrator, and I have not declared the formal UI SPEC complete.
