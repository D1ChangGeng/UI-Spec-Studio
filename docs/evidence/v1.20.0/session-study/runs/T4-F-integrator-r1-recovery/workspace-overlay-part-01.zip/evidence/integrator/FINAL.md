**Revision 3 of the bounded integration is implemented and ready for your assembled-product acceptance.** The current report is [INTEGRATOR-REPORT.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w17/INTEGRATOR-REPORT.md).

### Changed files and retained source

- [index.html](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w17/app/index.html) adopts the selected native toast, copies the full MIT notice with it, uses Fieldnotes/FN, and retains the inline form summary without duplicate live announcements.
- [settings-controller.js](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w17/app/settings-controller.js) coordinates current form values, pending controls, actual field errors, rejected-submit focus recovery, stale-event filtering and explicit focus return.
- [save-notification.js](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w17/app/save-notification.js) renders authoritative events through `tabler.Toast` and retries the retained failed snapshot without replacing later form edits or writing storage itself.

The source's 350px width, identity/time/close header, compact body, separated small action, type, materials, spacing and native transition remain. The action row appears only for failure. Success uses the actual saved timestamp and states the browser-local boundary. No dependency, replacement styling, custom animation, or original visual construction was added. The store remains byte-identical to the baseline.

### Checks and repaired findings

The initial behavioral run passed visible save, pending edits, storage readback, forced failure, retry with a newer live draft, invalid-field association, close/return, close during pending, stale older success/error, Chinese errors, and selected viewport containment. Exact results are retained under `evidence/integrator/003-behavior-corrected/`.

Your independent review identified two focus-continuity defects, both now repaired within the controller:

1. **Explicit retry/close could return focus off screen.** Native `focus()` now reveals the initiating save control. The revision-2 targeted checks confirm visibility, preserved snapshot retry, and no focus movement on successful completion. The inline failure summary also now remains truthful when an unchanged saved form fails.
2. **Later validation recovery could leave the field under the fixed toast.** In both 390px cases, the toast covered most of the first invalid input at the top edge. At 1280px the field was horizontally outside the toast, but its label remained above the viewport. Revision 3 uses native `scrollIntoView({block:'center'})` only when rejected-submit recovery moves focus to the first invalid field.

The final focused validation check passed **all six required conditions**, plus dark/zh narrow reduced motion and subsequent email recovery. It waits for actual scroll settlement, verifies the visible display-name label and error, checks toast non-overlap, and confirms that hit testing reaches the input. The first invalid input settles at y=430–470 in 1440×900, y=280–320 in 1280×600, and y=402–442 in 390×844. Exact results and final hashes are under `evidence/integrator/009-invalid-centered-check/`.

Final controller SHA-256: `e10a86a0dab0c23a2b166bf34344e9efe4748f3fac3f8fb43beac225a1785b1d`.

### Viewed evidence and handover limits

I viewed the locally rendered frozen original source block, representative light/error and success states, dark Chinese short/narrow views, the actual revision-2 covered-field defect, and final centered validation views at 1280px and both 390px variants. Successful image-tool responses are retained at their call sites. An initial immediate invalid screenshot caught native scrolling in progress; the later primary finding concerned a separate settled recovery defect and is recorded distinctly.

The report separates my adapter and targeted-repair checks from your complete six-condition whole-product and neighboring-experience acceptance. No consequential integration decision or requested product change remains with this integrator. Actual screen-reader speech and natural-time video playback were not exercised by me. The public live-demo TLS failure remains retained, and its deployed snapshot's unknown commit remains separate from the related Tabler tag.

All three product revisions, prior reports, failed harness attempt, corrections, command outputs and current visual review are preserved under `evidence/integrator/`. No further product edits are pending, and this handover does not declare the formal UI SPEC complete.
