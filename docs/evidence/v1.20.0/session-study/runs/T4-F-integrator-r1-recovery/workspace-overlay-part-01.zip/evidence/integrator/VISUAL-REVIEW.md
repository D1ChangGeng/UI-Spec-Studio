# Integrator visual review — final revision 3

## Actual visual inspection

The following images were opened with `view_image`; exact successful returned objects are retained under `evidence/integrator/view-source-dark.json` and `evidence/integrator/views/`:

- Parent-provided `evidence/frozen-source-render/frozen-block-dark.png`: locally rendered frozen original source block, showing the compact dark header, body and separated small action. This was not a successful live public-browser observation.
- First revision `check-002/light-en-1440-error.png` and `light-en-1440-success-newer-draft.png`: source hierarchy and width remain legible beside the settings content; the error action is separated; success has no empty action footer; live input and focused state remain present.
- First revision `check-002/dark-zh-1280-error.png`: Chinese body wraps without clipping, the native primary retry action remains distinct, and the lower save control retains visible focus.
- First revision `check-002/dark-zh-390-invalid.png`: explicitly a native-scroll progression frame, not a settled recovery judgment.
- `focus-001/focus-600.png`: actual settled narrow validation view; the named invalid field, native border/icon and associated message are visible below the toast.
- Revision 2 `repair-check-001/light-en-1440-error.png` and `dark-zh-390-error.png`: source shell and action relationship persist with the corrected behavior and summary. The 390px toast remains contained.
- Revision 2 `repair-check-001/dark-zh-390-close-focus-visible.png`: a focus-reveal progression frame showing the focused initiating save within the viewport after native dismissal. It is not represented as the final rest of smooth scrolling; the primary agent's settled capture addresses that condition.

- Primary revision-2 `evidence/primary-settled-002/390x844-dark-zh/06-invalid-field.png`: actually viewed the settled defect in which the fixed toast covered most of the first invalid input; retained as `views/revision-2-covered-invalid.json`.
- Final revision-3 `invalid-check-001/1280x600-light-en-no-preference-business-name.png`, `390x844-light-en-no-preference-business-name.png`, and `390x844-dark-zh-no-preference-business-name.png`: actually viewed centered recovery. The visible field label, editable input and associated feedback are now separated from the fixed toast. Exact view responses are retained in `views/`.

The observed source-to-product retention is the compact header/body/action hierarchy, standard width, native material and button relationships. The source cookie text, portrait and relative sample time were intentionally replaced. No natural-time video playback was performed by this integrator; ordered geometry/captures and actual scripted interactions support only their stated temporal scope.

