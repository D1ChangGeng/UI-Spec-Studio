import json, os, time
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w17')
OUT=ROOT/'evidence/integrator/check-002'
OUT.mkdir(parents=True,exist_ok=False)
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
events=[]
def log(name, **data):
    row={'check':name,'monotonic':time.monotonic(),**data}; events.append(row); print(json.dumps(row,ensure_ascii=False),flush=True)
def snap(page,name):
    path=OUT/(name+'.png'); page.screenshot(path=str(path)); log('capture',path=str(path),viewport=page.viewport_size)
def state(page):
    return page.evaluate('''() => ({state:document.querySelector('#save-notification').dataset.state, operation:document.querySelector('#save-notification').dataset.operationId, message:document.querySelector('#save-notification-message').textContent, summary:document.querySelector('#save-status').textContent, focus:document.activeElement.id, live:window.fieldnotes.draft(), storage:JSON.parse(localStorage.getItem('fieldnotes-settings-v1')), toast:document.querySelector('#save-notification').className, retryHidden:document.querySelector('#save-notification-action').hidden})''')
def wait_state(page,name):
    page.wait_for_function('(s) => document.querySelector("#save-notification").dataset.state === s',arg=name)
def submit(page):
    page.locator('#save-settings').focus();page.locator('#save-settings').press('Enter')
def boot(browser,theme,lang,width,height):
    ctx=browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1)
    page=ctx.new_page(); page.on('pageerror',lambda e: log('pageerror',error=str(e)))
    page.goto(f'http://127.0.0.1:4417/?theme={theme}&lang={lang}')
    page.wait_for_function('Boolean(window.fieldnotes)');page.evaluate('document.fonts.ready')
    page.evaluate('''async () => { const store=await import('./settings-store.js'); window.__storeEvents=[]; store.subscribeSettings(e=>window.__storeEvents.push({status:e.status,operationId:e.operationId,snapshot:e.snapshot,settings:e.settings,savedAt:e.savedAt})); }''')
    return ctx,page

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=CHROME,headless=True,args=['--no-sandbox'],env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
    ctx,page=boot(browser,'light','en',1440,900)
    page.locator('#business-name').fill('Submitted first')
    submit(page);wait_state(page,'pending')
    assert page.locator('#save-settings').get_attribute('aria-disabled')=='true'
    assert page.evaluate('document.activeElement.id')=='save-settings'
    assert page.locator('#save-notification-action').evaluate('(e)=>e.hidden')
    page.locator('#business-name').fill('Edited while pending')
    snap(page,'light-en-1440-pending-edit')
    wait_state(page,'success')
    s=state(page); assert s['storage']['settings']['displayName']=='Submitted first';assert s['live']['displayName']=='Edited while pending';assert s['focus']=='business-name';assert s['storage']['savedAt']==page.locator('#save-notification-time').get_attribute('title');assert s['summary']=='Your newer edits are not saved yet.'
    assert page.locator('#save-status').get_attribute('role') is None
    assert page.locator('#save-status').get_attribute('aria-live')=='off'
    log('success_snapshot_readback_and_pending_edit',**s)
    snap(page,'light-en-1440-success-newer-draft')

    page.evaluate('window.fieldnotes.setFailureMode(true)')
    page.locator('#business-name').fill('Failed snapshot')
    submit(page);wait_state(page,'error');s=state(page)
    assert s['storage']['settings']['displayName']=='Submitted first';assert s['live']['displayName']=='Failed snapshot';assert not s['retryHidden']
    log('failure_preserves_prior_storage_and_draft',**s)
    snap(page,'light-en-1440-error')
    page.locator('#business-name').fill('New live draft after failure')
    page.locator('#retry-save').focus();page.locator('#retry-save').press('Enter');wait_state(page,'pending')
    s=state(page);assert s['focus']=='save-settings';assert s['retryHidden'];log('retry_keyboard_focus_returns',**s)
    wait_state(page,'success');s=state(page)
    assert s['storage']['settings']['displayName']=='Failed snapshot';assert s['live']['displayName']=='New live draft after failure'
    assert s['summary']=='Your newer edits are not saved yet.';log('retry_uses_failed_snapshot_not_live_draft',**s)
    page.wait_for_timeout(300)
    page.locator('#save-notification .btn-close').focus();page.locator('#save-notification .btn-close').press('Enter')
    page.wait_for_function('!document.querySelector("#save-notification").classList.contains("show")')
    assert page.evaluate('document.activeElement.id')=='save-settings';log('native_close_returns_focus',**state(page))
    submit(page);wait_state(page,'pending');page.locator('#save-notification .btn-close').click()
    wait_state(page,'success');page.wait_for_timeout(200);s=state(page)
    assert s['storage']['settings']['displayName']=='New live draft after failure';assert 'show' in s['toast'];log('dismiss_pending_does_not_cancel_persistence',**s)

    page.locator('#business-name').fill('');page.locator('#email').fill('incomplete')
    submit(page);wait_state(page,'invalid');s=state(page)
    assert s['focus']=='business-name';assert 'Display name' in s['message'];assert page.locator('#business-name').get_attribute('aria-describedby')=='business-name-error';assert page.locator('#email').get_attribute('aria-invalid')=='true'
    log('invalid_first_field_association_and_focus',**s);snap(page,'light-en-1440-invalid-name')
    page.locator('#business-name').fill('Recovered name');submit(page);wait_state(page,'invalid');s=state(page)
    assert s['focus']=='email';assert 'Email' in s['message'];log('invalid_first_field_changes_with_actual_errors',**s)
    page.locator('#email').fill('recovered@example.invalid');submit(page);wait_state(page,'success')

    # Real store concurrency available through its public diagnostic API:
    # a later rejected operation resolves before an older 750ms save.
    page.evaluate('''() => {const d=window.fieldnotes.draft();void window.fieldnotes.saveSettings({...d,displayName:'Older operation success'}).catch(()=>{});void window.fieldnotes.saveSettings({...d,email:'invalid'}).catch(()=>{});}''')
    wait_state(page,'invalid');op=state(page)['operation'];page.wait_for_timeout(900);s=state(page)
    assert s['state']=='invalid' and s['operation']==op;log('older_success_does_not_replace_newer_invalid',**s)
    page.evaluate('''() => {window.fieldnotes.setFailureMode(true);const d=window.fieldnotes.draft();void window.fieldnotes.saveSettings({...d,displayName:'Older operation failure'}).catch(()=>{});void window.fieldnotes.saveSettings({...d,email:'invalid'}).catch(()=>{});}''')
    wait_state(page,'invalid');op=state(page)['operation'];page.wait_for_timeout(900);s=state(page)
    assert s['state']=='invalid' and s['operation']==op;log('older_error_does_not_replace_newer_invalid',**s)
    log('authoritative_event_log',events=page.evaluate('window.__storeEvents'))
    ctx.close()

    for theme,lang,width,height in [('dark','zh',1280,600),('light','en',390,844),('dark','zh',390,844)]:
        ctx,page=boot(browser,theme,lang,width,height)
        page.evaluate('window.fieldnotes.setFailureMode(true)')
        submit(page);wait_state(page,'error');page.wait_for_timeout(220)
        box=page.locator('#save-notification').bounding_box();assert box['x']>=0 and box['x']+box['width']<=width
        assert box['width']==350
        log('toast_containment',theme=theme,lang=lang,viewport=page.viewport_size,box=box,**state(page))
        snap(page,f'{theme}-{lang}-{width}-error')
        page.locator('#retry-save').focus();page.locator('#retry-save').press('Enter');wait_state(page,'success');snap(page,f'{theme}-{lang}-{width}-success')
        if lang=='zh':
            page.locator('#business-name').fill('');submit(page);wait_state(page,'invalid');s=state(page);assert '显示名称' in s['message'];assert page.locator('#business-name-error').inner_text()=='请填写显示名称。';log('chinese_validation',**s);snap(page,f'{theme}-{lang}-{width}-invalid')
        ctx.close()
    browser.close()
(OUT/'checks.json').write_text(json.dumps(events,ensure_ascii=False,indent=2)+'\n')
print('PASS: adapter behavior, storage, failure/snapshot retry, validation, dismissal/focus, stale results, and selected viewport checks.')
