from pathlib import Path
p=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w17/app/settings-controller.js')
s=p.read_text()
assert "target.focus({preventScroll:true});" in s
s=s.replace("target.focus({preventScroll:true});","target.focus();")
s=s.replace("error:'表单中的更改尚未保存。'","error:'你可以继续编辑表单。'")
s=s.replace("error:'The form contains unsaved changes.'","error:'You can keep editing this form.'")
p.write_text(s)
print('Explicit retry/close focus return now uses native focus reveal; error summary makes no unsupported dirty-state claim. No completion focus was added.')
