from pathlib import Path
p=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w17/app/settings-controller.js')
s=p.read_text()
old="  if (rejectedSubmitRecovery && !invalidElements.includes(document.activeElement)) invalidElements[0]?.focus();"
new="""  if (rejectedSubmitRecovery && !invalidElements.includes(document.activeElement)) {
    const firstInvalid = invalidElements[0];
    firstInvalid?.focus();
    // Keep rejected-submit recovery clear of the fixed toast while inheriting
    // the source's native smooth/reduced-motion scrolling behavior.
    firstInvalid?.scrollIntoView({block:'center'});
  }"""
assert old in s
p.write_text(s.replace(old,new))
print('Rejected visible submits now center the first invalid field after moving focus. Toast placement, native scrolling and completion focus behavior are unchanged.')
