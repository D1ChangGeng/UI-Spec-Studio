import json,os,time
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w17')
out=root/'evidence/integrator/focus-001';out.mkdir(exist_ok=False)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'],env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
 c=b.new_context(viewport={'width':390,'height':844},device_scale_factor=1)
 page=c.new_page();page.goto('http://127.0.0.1:4417/?theme=dark&lang=zh');page.wait_for_function('Boolean(window.fieldnotes)')
 page.locator('#business-name').fill('');page.locator('#save-settings').focus();page.locator('#save-settings').press('Enter')
 started=time.monotonic()
 for interval in [0,100,200,300,600]:
  if interval:page.wait_for_timeout(interval)
  print(json.dumps({'elapsed':time.monotonic()-started,'details':page.evaluate('''() => ({focus:document.activeElement.id,scrollY,field:document.querySelector('#business-name').getBoundingClientRect().toJSON(),toast:document.querySelector('#save-notification').getBoundingClientRect().toJSON(),scrollBehavior:getComputedStyle(document.documentElement).scrollBehavior})''')},ensure_ascii=False),flush=True)
  page.screenshot(path=str(out/f'focus-{interval}.png'))
 c.close();b.close()
