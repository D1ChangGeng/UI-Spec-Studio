from pathlib import Path

root=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w17')
app=root/'app'
index=(app/'index.html').read_text()
assert 'id="save-notification"' not in index
index=index.replace('id="save-status" role="status"','id="save-status" aria-live="off"')
notice=(app/'LICENSE').read_text().strip()
block='''
    <!-- Adopted from Tabler 1.7.1 toast-cookies / shared/components/demo/Toast.astro.
    Tagged source: 07f60c07da13d8ff957a370434b7ef5c86f5ab94.
    The deployed HTML snapshot has a separate identity; its deployment commit is unknown.
'''+notice+'''
    -->
    <div class="toast-container position-fixed top-0 end-0 p-3">
      <div class="toast" id="save-notification" role="status" aria-live="polite" aria-atomic="true" data-bs-autohide="false">
        <div class="toast-header">
          <span class="avatar avatar-xs me-2" aria-hidden="true">FN</span>
          <strong class="me-auto">Fieldnotes</strong>
          <small id="save-notification-time"></small>
          <button type="button" class="ms-2 btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body">
          <span id="save-notification-message"></span>
          <div class="mt-2 pt-2 border-top" id="save-notification-action" hidden>
            <button type="button" class="btn btn-primary btn-sm" id="retry-save">Retry save</button>
          </div>
        </div>
      </div>
    </div>
'''
index=index.replace('  <script type="module" src="./settings-controller.js"></script>',block+'  <script type="module" src="./settings-controller.js"></script>')
(app/'index.html').write_text(index)

adapter=r'''// Render authoritative settings events through the selected native Tabler Toast.
// Persistence, validation and operation IDs remain owned by settings-store.js.
export function createSaveNotification({subscribeSettings, saveSettings, zh, fieldLabel, fieldError, restoreFocus}) {
  const element = document.getElementById('save-notification');
  const message = document.getElementById('save-notification-message');
  const time = document.getElementById('save-notification-time');
  const action = document.getElementById('save-notification-action');
  const retry = document.getElementById('retry-save');
  const close = element.querySelector('[data-bs-dismiss="toast"]');
  const toast = window.tabler.Toast.getOrCreateInstance(element, {autohide:false});
  let latestOperation = 0;
  let failedSnapshot = null;
  let hiding = false;
  let wantsVisible = false;
  const copy = zh ? {
    pending:'正在保存更改。正在将本次提交的版本保存在当前浏览器中。',
    success:'更改已保存。本次提交的版本仅保存在当前浏览器中。',
    error:'保存未完成。草稿仍然保留。重试将保存此前提交的版本。',
    invalid:'请检查个人资料字段。',
    pendingTime:'正在保存…', errorTime:'未保存', invalidTime:'检查字段',
    retry:'重试保存', close:'关闭保存提示'
  } : {
    pending:'Saving changes. This submitted version is being saved in this browser.',
    success:'Changes saved. This submitted version is saved only in this browser.',
    error:'Save did not complete. Your submitted draft is still available. Retry saves that version.',
    invalid:'Check profile fields.',
    pendingTime:'Saving…', errorTime:'Not saved', invalidTime:'Check fields',
    retry:'Retry save', close:'Close save notification'
  };
  retry.textContent = copy.retry;
  close.setAttribute('aria-label', copy.close);

  // Keep the upstream close interaction and transition. A result arriving during
  // native dismissal waits for hidden.bs.toast instead of racing its callback.
  element.addEventListener('hide.bs.toast', () => {
    hiding = true;
    wantsVisible = false;
    if (element.contains(document.activeElement)) restoreFocus();
  });
  element.addEventListener('hidden.bs.toast', () => {
    hiding = false;
    if (wantsVisible) toast.show();
  });

  retry.addEventListener('click', async () => {
    if (!failedSnapshot || action.hidden) return;
    // Never replace the user's newer live form with this submitted snapshot.
    const snapshot = {...failedSnapshot};
    try { await saveSettings(snapshot); } catch { /* The store emits the outcome. */ }
  });

  return subscribeSettings(event => {
    if (!Number.isInteger(event.operationId) || event.operationId < latestOperation) return;
    if (!['pending','success','error','invalid'].includes(event.status)) return;
    latestOperation = event.operationId;
    failedSnapshot = event.status === 'error' ? {...event.snapshot} : null;
    if (event.status !== 'error' && action.contains(document.activeElement)) restoreFocus();
    action.hidden = event.status !== 'error';
    element.dataset.state = event.status;
    element.dataset.operationId = String(event.operationId);
    let text = copy[event.status];
    if (event.status === 'invalid') {
      const field = Object.keys(event.fieldErrors)[0];
      text += zh ? `${fieldLabel(field)}：${fieldError(event.fieldErrors[field])}`
                 : ` ${fieldLabel(field)}: ${fieldError(event.fieldErrors[field])}`;
    }
    message.textContent = text;
    time.textContent = event.status === 'success'
      ? new Intl.DateTimeFormat(zh ? 'zh-CN' : 'en', {hour:'2-digit',minute:'2-digit',second:'2-digit'}).format(new Date(event.savedAt))
      : copy[`${event.status}Time`];
    if (event.status === 'success') time.title = event.savedAt;
    else time.removeAttribute('title');
    wantsVisible = true;
    if (!hiding && !toast.isShown()) toast.show();
  });
}
'''
(app/'save-notification.js').write_text(adapter)

old=(app/'settings-controller.js').read_text()
tail=old[old.index('if (zh) {'):]
controller=r'''import { readSettings, saveSettings, subscribeSettings, setFailureMode } from './settings-store.js';
import { createSaveNotification } from './save-notification.js';

const ids = {displayName:'business-name',organization:'business-id',location:'location',email:'email',weeklyDigest:'weekly-digest',publicProfile:'public-profile'};
const status = document.querySelector('#save-status');
const save = document.querySelector('#save-settings');
const params = new URLSearchParams(location.search);
const zh = params.get('lang') === 'zh';
const copy = zh ? {
  idle:'更改仅保存在当前浏览器中。', pending:'保存期间可以继续编辑。',
  newer:'较新的编辑尚未保存。', clean:'没有尚未保存的更改。',
  error:'表单中的更改尚未保存。', invalid:'请修改标记的字段。'
} : {
  idle:'Changes are saved only in this browser.', pending:'You can keep editing while this version saves.',
  newer:'Your newer edits are not saved yet.', clean:'No unsaved changes.',
  error:'The form contains unsaved changes.', invalid:'Review the marked fields.'
};
const fieldNames = zh
  ? {displayName:'显示名称',organization:'机构',location:'地点',email:'电子邮件'}
  : {displayName:'Display name',organization:'Organization',location:'Location',email:'Email'};
const errorTranslations = {
  'Add a display name.':'请填写显示名称。',
  'Use 100 characters or fewer.':'请使用不超过 100 个字符。',
  'Use 180 characters or fewer.':'请使用不超过 180 个字符。',
  'Enter a complete email address.':'请输入完整的电子邮件地址。'
};
const fieldLabel = key => fieldNames[key] || key;
const fieldError = text => zh ? (errorTranslations[text] || text) : text;
let baseline;
let currentEvent = null;
let latestOperation = 0;
let pending = false;
let rejectedSubmitRecovery = false;
let initiatingControl = save;

function draft() {
  return Object.fromEntries(Object.entries(ids).map(([key,id]) => {
    const el = document.getElementById(id);
    return [key,el.type === 'checkbox' ? el.checked : el.value];
  }));
}
function matches(a,b) { return b && Object.keys(ids).every(key => a[key] === b[key]); }
function load() {
  const data = readSettings();
  baseline = {...data};
  for (const [key,id] of Object.entries(ids)) {
    const el = document.getElementById(id);
    if (el.type === 'checkbox') el.checked = data[key]; else el.value = data[key];
  }
}
function updateSummary() {
  const values = draft();
  const state = currentEvent?.status;
  if (state === 'pending') status.textContent = matches(values,currentEvent.snapshot) ? copy.pending : copy.newer;
  else if (state === 'invalid' && document.querySelector('.form-control.is-invalid')) status.textContent = copy.invalid;
  else if (state === 'error') status.textContent = copy.error;
  else status.textContent = matches(values,baseline) ? (state === 'success' ? copy.clean : copy.idle) : copy.newer;
}
function clearFieldError(key) {
  const el = document.getElementById(ids[key]);
  if (!el) return;
  const errorId = `${el.id}-error`;
  el.classList.remove('is-invalid');
  el.removeAttribute('aria-invalid');
  const describedBy = (el.getAttribute('aria-describedby') || '').split(' ').filter(id => id && id !== errorId);
  if (describedBy.length) el.setAttribute('aria-describedby',describedBy.join(' '));
  else el.removeAttribute('aria-describedby');
  document.getElementById(errorId)?.remove();
}
function clearFieldErrors() { Object.keys(ids).forEach(clearFieldError); }
function showFieldErrors(errors) {
  clearFieldErrors();
  for (const [key,text] of Object.entries(errors)) {
    const el = document.getElementById(ids[key]);
    if (!el) continue;
    const feedback = document.createElement('div');
    feedback.id = `${el.id}-error`;
    feedback.className = 'invalid-feedback';
    feedback.textContent = fieldError(text);
    el.insertAdjacentElement('afterend',feedback);
    el.classList.add('is-invalid');
    el.setAttribute('aria-invalid','true');
    el.setAttribute('aria-describedby',[el.getAttribute('aria-describedby'),feedback.id].filter(Boolean).join(' '));
  }
  const invalidElements = Object.keys(errors).map(key => document.getElementById(ids[key])).filter(Boolean);
  if (rejectedSubmitRecovery && !invalidElements.includes(document.activeElement)) invalidElements[0]?.focus();
}
function restoreFocus() {
  const target = initiatingControl?.isConnected && !initiatingControl.disabled ? initiatingControl : save;
  target.focus({preventScroll:true});
}
try { load(); status.textContent = copy.idle; } catch (error) { status.textContent = error.message; }

subscribeSettings(event => {
  if (!Number.isInteger(event.operationId) || event.operationId < latestOperation) return;
  latestOperation = event.operationId;
  currentEvent = event;
  pending = event.status === 'pending';
  // The native disabled visual state, aria-disabled and the guarded handler keep
  // the initiating button focusable while preventing a duplicate submission.
  save.classList.toggle('disabled',pending);
  save.setAttribute('aria-disabled',String(pending));
  save.setAttribute('aria-busy',String(pending));
  status.dataset.state = event.status;
  if (event.status === 'invalid') showFieldErrors(event.fieldErrors);
  if (event.status === 'pending') clearFieldErrors();
  if (event.status === 'success') baseline = {...event.settings};
  updateSummary();
});
createSaveNotification({subscribeSettings,saveSettings,zh,fieldLabel,fieldError,restoreFocus});

save.addEventListener('click',async () => {
  if (pending) return;
  initiatingControl = save;
  rejectedSubmitRecovery = true;
  const operation = saveSettings(draft());
  rejectedSubmitRecovery = false; // Validation is emitted synchronously by the store.
  try { await operation; } catch { /* Authoritative events supply all feedback. */ }
});
for (const [key,id] of Object.entries(ids)) {
  document.getElementById(id).addEventListener('input',() => { clearFieldError(key); updateSummary(); });
}
document.querySelector('#cancel-settings').addEventListener('click',() => {
  try { load(); clearFieldErrors(); if (!pending) currentEvent = null; updateSummary(); }
  catch (error) { status.textContent = error.message; }
});
document.querySelector('#focus-email').addEventListener('click',()=>document.querySelector('#email').focus());
document.querySelector('#language-toggle').addEventListener('click',()=>{params.set('lang',zh?'en':'zh');location.search=params.toString();});
document.querySelector('#theme-toggle').addEventListener('click',()=>{const dark=document.documentElement.getAttribute('data-bs-theme')==='dark';document.documentElement.setAttribute('data-bs-theme',dark?'light':'dark');localStorage.setItem('tabler-theme',dark?'light':'dark');});
window.fieldnotes = { readSettings, saveSettings, setFailureMode, draft };
'''
(app/'settings-controller.js').write_text(controller+tail)
print('Updated app/index.html and app/settings-controller.js; created app/save-notification.js.')
