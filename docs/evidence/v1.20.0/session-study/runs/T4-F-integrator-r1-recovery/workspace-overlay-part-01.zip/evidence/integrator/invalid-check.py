import json,os,time,hashlib
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w17')
out=root/'evidence/integrator/invalid-check-001';out.mkdir(exist_ok=False)
rows=[]
def log(name,**data):
 row={'check':name,'time':time.monotonic(),**data};rows.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
def settle(page):
 page.evaluate('''() => new Promise((resolve,reject) => {let previous=scrollY,stable=0,frames=0;function tick(){frames++;if(scrollY===previous)stable++;else stable=0;previous=scrollY;if(stable>=12)resolve({scrollY,frames});else if(frames>240)reject(new Error('Scroll did not settle'));else requestAnimationFrame(tick);}requestAnimationFrame(tick);})''')
def wait_state(page,s):page.wait_for_function('s=>document.querySelector("#save-notification").dataset.state===s',arg=s)
def verify(page,field,theme,lang,w,h,motion):
 settle(page)
 result=page.evaluate('''id => {const field=document.getElementById(id);const r=field.getBoundingClientRect();const t=document.getElementById('save-notification').getBoundingClientRect();const label=document.querySelector(`label[for="${id}"]`).getBoundingClientRect();const error=document.getElementById(id+'-error').getBoundingClientRect();return {focus:document.activeElement.id,scrollY,field:r.toJSON(),label:label.toJSON(),error:error.toJSON(),toast:t.toJSON(),covered:r.x<t.right&&r.right>t.x&&r.y<t.bottom&&r.bottom>t.y,hit:document.elementFromPoint(r.x+r.width/2,r.y+r.height/2)?.id,message:document.querySelector('#save-notification-message').textContent,scrollBehavior:getComputedStyle(document.documentElement).scrollBehavior};}''',field)
 assert result['focus']==field and result['hit']==field
 assert result['field']['top']>=0 and result['field']['bottom']<=h and not result['covered']
 assert result['label']['top']>=0 and result['error']['bottom']<=h
 assert abs((result['field']['top']+result['field']['bottom'])/2-h/2)<=1
 log('centered_invalid_recovery',theme=theme,lang=lang,width=w,height=h,motion=motion,details=result)
 page.screenshot(path=str(out/f'{w}x{h}-{theme}-{lang}-{motion}-{field}.png'))
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'],env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
 conditions=[(theme,lang,w,h,'no-preference') for w,h in [(1440,900),(1280,600),(390,844)] for theme,lang in [('light','en'),('dark','zh')]]+[('dark','zh',390,844,'reduce')]
 for theme,lang,w,h,motion in conditions:
  c=b.new_context(viewport={'width':w,'height':h},device_scale_factor=1,reduced_motion=motion)
  page=c.new_page();page.goto(f'http://127.0.0.1:4417/?theme={theme}&lang={lang}');page.wait_for_function('Boolean(window.fieldnotes)');page.evaluate('document.fonts.ready')
  page.evaluate('window.fieldnotes.setFailureMode(true)');page.locator('#save-settings').click();wait_state(page,'error');settle(page)
  page.locator('#save-notification .btn-close').click();page.wait_for_function('!document.querySelector("#save-notification").classList.contains("show")');settle(page)
  page.locator('#business-name').fill('');page.locator('#email').fill('not-an-email');page.locator('#save-settings').click();wait_state(page,'invalid')
  verify(page,'business-name',theme,lang,w,h,motion)
  if w==390 and lang=='zh':
   page.locator('#business-name').fill('Recovered name');page.locator('#save-settings').click();wait_state(page,'invalid');verify(page,'email',theme,lang,w,h,motion)
  c.close()
 b.close()
log('final_product_identity',files={name:hashlib.sha256((root/'app'/name).read_bytes()).hexdigest() for name in ['index.html','settings-controller.js','save-notification.js','settings-store.js']})
(out/'checks.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print('PASS: first invalid field centered, label/error visible, no toast overlap, actual hit target, all six conditions plus reduced motion and next-field recovery.')
