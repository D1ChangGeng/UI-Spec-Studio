import json,os,time,hashlib
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w17')
out=root/'evidence/integrator/repair-check-001';out.mkdir(exist_ok=False)
records=[]
def record(name,**kwargs):
 r={'check':name,'time':time.monotonic(),**kwargs};records.append(r);print(json.dumps(r,ensure_ascii=False),flush=True)
def details(page):
 return page.evaluate('''() => ({focus:document.activeElement.id,scrollY,height:innerHeight,save:document.querySelector('#save-settings').getBoundingClientRect().toJSON(),state:document.querySelector('#save-notification').dataset.state,summary:document.querySelector('#save-status').textContent,draft:window.fieldnotes.draft(),stored:JSON.parse(localStorage.getItem('fieldnotes-settings-v1'))})''')
def wait_state(page,s):page.wait_for_function('s=>document.querySelector("#save-notification").dataset.state===s',arg=s)
def visible_save(page):
 page.wait_for_function('''() => {const r=document.querySelector('#save-settings').getBoundingClientRect();return r.top>=0&&r.bottom<=innerHeight}''')
def submit(page):page.locator('#save-settings').focus();page.locator('#save-settings').press('Enter')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'],env={**os.environ,'FONTCONFIG_FILE':'/tmp/ui-spec-fonts/fonts.conf'})
 for theme,lang,w,h in [('light','en',1440,900),('dark','zh',390,844)]:
  c=b.new_context(viewport={'width':w,'height':h},device_scale_factor=1)
  page=c.new_page();page.goto(f'http://127.0.0.1:4417/?theme={theme}&lang={lang}')
  page.wait_for_function('Boolean(window.fieldnotes)');page.evaluate('document.fonts.ready')
  page.evaluate('window.fieldnotes.setFailureMode(true)');page.locator('#business-name').fill('Submitted failed version')
  submit(page);wait_state(page,'error');visible_save(page)
  page.screenshot(path=str(out/f'{theme}-{lang}-{w}-error.png'))
  page.locator('#business-name').fill('Newer live draft')
  page.evaluate('window.scrollTo({top:0,behavior:"instant"})')
  before=details(page);assert before['save']['top']>h;record('retry_before',theme=theme,lang=lang,details=before)
  page.locator('#retry-save').focus();page.locator('#retry-save').press('Enter')
  visible_save(page);s=details(page);assert s['focus']=='save-settings';record('retry_return_is_visible',theme=theme,lang=lang,details=s)
  wait_state(page,'success');s=details(page)
  assert s['stored']['settings']['displayName']=='Submitted failed version';assert s['draft']['displayName']=='Newer live draft';record('repaired_retry_snapshot_continuity',theme=theme,lang=lang,details=s)
  page.evaluate('window.scrollTo({top:0,behavior:"instant"})');assert details(page)['save']['top']>h
  page.locator('#save-notification .btn-close').focus();page.locator('#save-notification .btn-close').press('Enter')
  visible_save(page);page.wait_for_function('!document.querySelector("#save-notification").classList.contains("show")')
  s=details(page);assert s['focus']=='save-settings';record('close_return_is_visible',theme=theme,lang=lang,details=s)
  page.screenshot(path=str(out/f'{theme}-{lang}-{w}-close-focus-visible.png'))
  submit(page);wait_state(page,'pending');page.locator('#email').fill('newer@example.invalid')
  wait_state(page,'success');s=details(page);assert s['focus']=='email';assert s['draft']['email']=='newer@example.invalid';assert s['stored']['settings']['email']=='mei.lin@example.invalid'
  record('completion_still_preserves_edit_focus_and_draft',theme=theme,lang=lang,details=s)
  # Make an unchanged saved form fail, so summary truth is checked independently
  # of dirty-state assumptions. Explicit Cancel loads the last saved snapshot.
  page.locator('#cancel-settings').click();page.evaluate('window.fieldnotes.setFailureMode(true)')
  submit(page);wait_state(page,'error');s=details(page)
  assert s['summary']==('你可以继续编辑表单。' if lang=='zh' else 'You can keep editing this form.')
  assert s['draft']==s['stored']['settings'];record('unchanged_saved_form_failure_has_truthful_summary',theme=theme,lang=lang,details=s)
  c.close()
 b.close()
record('final_product_identity',files={name:hashlib.sha256((root/'app'/name).read_bytes()).hexdigest() for name in ['index.html','settings-controller.js','save-notification.js','settings-store.js']})
(out/'checks.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
print('PASS: repaired retry/close reveal, snapshot continuity, completion focus preservation, and unchanged-form failure summary in both variants.')
