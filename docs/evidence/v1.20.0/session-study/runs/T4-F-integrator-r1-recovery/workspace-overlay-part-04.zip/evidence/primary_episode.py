import asyncio,json,time,sys
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence'/sys.argv[1]
OUT.mkdir(parents=True,exist_ok=False)
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=BROWSER,headless=True,args=['--no-sandbox'])
  context=await browser.new_context(viewport={'width':1280,'height':600},device_scale_factor=1)
  page=await context.new_page()
  await page.goto('http://127.0.0.1:4417/?theme=light&lang=en&fail=once')
  await page.wait_for_function('Boolean(window.fieldnotes)')
  await page.evaluate('document.fonts.ready')
  await page.locator('#business-name').fill('Ordered episode review')
  await page.locator('#save-settings').scroll_into_view_if_needed()
  await page.wait_for_timeout(250)
  frames=[]
  async def capture(name,full=False):
   before=await page.evaluate('performance.now()')
   path=OUT/(name+'.png')
   await page.screenshot(path=str(path),**({} if full else {'clip':{'x':890,'y':0,'width':390,'height':250}}))
   after=await page.evaluate('performance.now()')
   data=await page.evaluate('({state:document.querySelector("#save-status").dataset.state,focus:document.activeElement.id||document.activeElement.tagName,scrollY,toastClass:document.querySelector(".toast-container .toast").className,opacity:getComputedStyle(document.querySelector(".toast-container .toast")).opacity})')
   frames.append({'name':name,'path':str(path.relative_to(ROOT)),'capture_bracket_ms':[before,after],**data})
  await capture('00-before-save',True)
  await page.locator('#save-settings').focus()
  trigger=await page.evaluate('performance.now()')
  await page.keyboard.press('Enter')
  for offset in [0,70,160,350,650,850,1100]:
   current=await page.evaluate('performance.now()')
   if current<trigger+offset: await page.wait_for_timeout(trigger+offset-current)
   await capture(f'01-save-{offset:04d}ms')
  await capture('02-error-whole',True)
  await page.locator('.toast-container .toast').get_by_role('button',name='Retry save',exact=True).focus()
  retry_trigger=await page.evaluate('performance.now()')
  await page.keyboard.press('Enter')
  for offset in [0,100,350,800,1000]:
   current=await page.evaluate('performance.now()')
   if current<retry_trigger+offset: await page.wait_for_timeout(retry_trigger+offset-current)
   await capture(f'03-retry-{offset:04d}ms')
  await capture('04-success-whole',True)
  await page.locator('.toast-container .toast .btn-close').focus()
  close_trigger=await page.evaluate('performance.now()')
  await page.keyboard.press('Enter')
  for offset in [0,80,180,300]:
   current=await page.evaluate('performance.now()')
   if current<close_trigger+offset: await page.wait_for_timeout(close_trigger+offset-current)
   await capture(f'05-close-{offset:04d}ms')
  await capture('06-return-whole',True)
  data={'viewport':{'width':1280,'height':600},'theme':'light','lang':'en','clock':'browser performance.now() around each screenshot; real timers, no clock mocking','triggers':{'save':trigger,'retry':retry_trigger,'close':close_trigger},'frames':frames,'limits':'Ordered sampled frames, not a natural-time playback or frame-rate measurement; capture overhead retained in actual time brackets.'}
  (OUT/'episode.json').write_text(json.dumps(data,indent=2))
  print(json.dumps({'frames':len(frames),'first_ms':frames[0]['capture_bracket_ms'][0],'last_ms':frames[-1]['capture_bracket_ms'][1],'states':[x.get('state') for x in frames]},indent=2))
  await browser.close()
asyncio.run(main())
