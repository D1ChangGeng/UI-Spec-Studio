import asyncio,json,time,sys,hashlib,os
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
RUN=sys.argv[1] if len(sys.argv)>1 else 'primary-review-001'
OUT=ROOT/'evidence'/RUN
OUT.mkdir(parents=True,exist_ok=False)
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
BASE='http://127.0.0.1:4417/'
results=[]

def check(log,name,passed,detail=None):
 log['checks'].append({'name':name,'pass':bool(passed),'detail':detail})

async def snap(page,folder,name,log):
 before=await page.evaluate('performance.now()')
 path=folder/(name+'.png')
 await page.screenshot(path=str(path))
 after=await page.evaluate('performance.now()')
 state=await page.evaluate('({focus:document.activeElement?.id||document.activeElement?.tagName,scrollY,theme:document.documentElement.getAttribute("data-bs-theme"),state:document.querySelector("#save-status")?.dataset.state,toastText:document.querySelector(".toast-container .toast")?.innerText})')
 log['captures'].append({'path':str(path.relative_to(ROOT)),'capture_bracket_ms':[before,after],**state})

async def state(page,name):
 await page.wait_for_function('(name)=>document.querySelector("#save-status").dataset.state===name',arg=name,timeout=5000)

async def stored(page):
 return await page.evaluate('JSON.parse(localStorage.getItem("fieldnotes-settings-v1"))')

async def run_case(browser,width,height,theme,lang):
 label=f'{width}x{height}-{theme}-{lang}'
 folder=OUT/label
 folder.mkdir()
 log={'case':label,'viewport':{'width':width,'height':height},'theme':theme,'lang':lang,'checks':[],'captures':[],'errors':[]}
 results.append(log)
 context=await browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1,locale='zh-CN' if lang=='zh' else 'en-US')
 page=await context.new_page()
 page.on('pageerror',lambda error:log['errors'].append(str(error)))
 try:
  await page.goto(BASE+f'?theme={theme}&lang={lang}')
  await page.wait_for_function('Boolean(window.fieldnotes)')
  await page.evaluate('document.fonts.ready')
  await page.wait_for_timeout(250)
  await page.evaluate('''async()=>{window.__saveEvents=[];const {subscribeSettings}=await import('./settings-store.js');subscribeSettings(event=>window.__saveEvents.push({time:performance.now(),status:event.status,operationId:event.operationId,snapshot:event.snapshot,settings:event.settings,savedAt:event.savedAt,fieldErrors:event.fieldErrors}));}''')
  await snap(page,folder,'00-initial-top',log)
  check(log,'no horizontal overflow at entry',await page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
  name=page.locator('#business-name')
  org=page.locator('#business-id')
  save=page.locator('#save-settings')
  toast=page.locator('.toast-container .toast').first
  check(log,'one adopted toast',await page.locator('.toast-container .toast').count()==1)
  initial=await page.evaluate('window.fieldnotes.draft()')
  submitted='Reviewed profile '+label
  await name.fill(submitted)
  await save.focus()
  await page.keyboard.press('Enter')
  await state(page,'pending')
  pending_focus=await page.evaluate('document.activeElement.id || document.activeElement.tagName')
  check(log,'pending keyboard activation retains a meaningful focus target',pending_focus not in ['BODY','HTML'],pending_focus)
  await snap(page,folder,'01-pending-lower',log)
  newer_org='Later draft / 后续草稿 '+label
  await org.fill(newer_org)
  await state(page,'success')
  saved=await stored(page)
  check(log,'success persisted submitted snapshot',saved['settings']['displayName']==submitted and saved['settings']['organization']==initial['organization'],saved)
  check(log,'pending edits remain after success',await org.input_value()==newer_org)
  check(log,'success does not steal field focus',await page.evaluate('document.activeElement.id')=='business-id')
  check(log,'source shell uses polite atomic persistent feedback',await toast.get_attribute('role')=='status' and await toast.get_attribute('aria-live')=='polite' and await toast.get_attribute('aria-atomic')=='true' and await toast.get_attribute('data-bs-autohide')=='false')
  check(log,'inline summary is not a second live announcement',await page.locator('#save-status').evaluate('(el)=>(el.getAttribute("role")!=="status" && el.getAttribute("role")!=="alert" && !["polite","assertive"].includes(el.getAttribute("aria-live"))) || el.getAttribute("aria-live")==="off"'))
  await snap(page,folder,'02-success-form',log)
  await page.evaluate('scrollTo(0,0)')
  await snap(page,folder,'03-success-top',log)
  geom=await toast.evaluate('(el)=>({rect:el.getBoundingClientRect().toJSON(),width:getComputedStyle(el).width,header:el.querySelector(".toast-header")?.className,body:el.querySelector(".toast-body")?.className,closeReachable:(()=>{const b=el.querySelector(".btn-close"),r=b.getBoundingClientRect();return b.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))})()})')
  check(log,'toast contained within viewport',geom['rect']['left']>=0 and geom['rect']['right']<=width,geom)
  check(log,'native close reachable while over header',geom['closeReachable'])
  if width==1440 and lang=='en':
   await page.wait_for_timeout(5250)
   check(log,'feedback remains after ordinary autohide interval',await toast.is_visible())
  previous=await stored(page)
  await page.evaluate('window.fieldnotes.setFailureMode(true)')
  failed_name='Failed snapshot '+label
  await name.fill(failed_name)
  await save.click()
  await state(page,'error')
  check(log,'failed save preserves previous storage',await stored(page)==previous)
  later_name='Unsaved later draft '+label
  await name.fill(later_name)
  await page.evaluate('scrollTo(0,0)')
  await snap(page,folder,'04-error-top',log)
  retry=toast.get_by_role('button',name='重试保存' if lang=='zh' else 'Retry save',exact=True)
  check(log,'error has source action row',await retry.is_visible() and await retry.evaluate('(el)=>el.parentElement.classList.contains("border-top")'))
  await retry.focus()
  await page.keyboard.press('Enter')
  await state(page,'pending')
  retry_focus=await page.evaluate('document.activeElement.id||document.activeElement.tagName')
  check(log,'disappearing focused retry returns focus',retry_focus not in ['BODY','HTML'],retry_focus)
  await snap(page,folder,'05-retry-pending',log)
  await state(page,'success')
  retried=await stored(page)
  check(log,'retry saves the failed snapshot',retried['settings']['displayName']==failed_name,retried)
  check(log,'retry retains the newer draft',await name.input_value()==later_name)
  await snap(page,folder,'06-retry-success',log)
  close=toast.locator('.btn-close')
  await close.focus()
  await page.keyboard.press('Enter')
  await page.wait_for_timeout(250)
  check(log,'native close hides only feedback',not await toast.is_visible() and await stored(page)==retried and await name.input_value()==later_name)
  close_focus=await page.evaluate('document.activeElement.id||document.activeElement.tagName')
  check(log,'focused close returns to meaningful control',close_focus not in ['BODY','HTML'],close_focus)
  await snap(page,folder,'07-closed',log)
  await name.fill('')
  await page.locator('#email').fill('incomplete')
  await save.focus()
  await page.keyboard.press('Enter')
  await state(page,'invalid')
  check(log,'invalid submission focuses first field',await page.evaluate('document.activeElement.id')=='business-name')
  check(log,'invalid fields associated with explanations',await name.get_attribute('aria-invalid')=='true' and bool(await name.get_attribute('aria-describedby')))
  check(log,'invalid write leaves previous stored value',await stored(page)==retried)
  await snap(page,folder,'08-invalid',log)
  invalid_text=await toast.inner_text()
  check(log,'invalid toast names first field',('显示名称' if lang=='zh' else 'Display name') in invalid_text,invalid_text)
  await name.fill('Final snapshot '+label)
  await page.locator('#email').fill('review@example.invalid')
  await page.locator('#weekly-digest').set_checked(False)
  await page.locator('#public-profile').set_checked(True)
  await save.click()
  await state(page,'pending')
  await close.focus()
  await page.keyboard.press('Enter')
  await page.wait_for_timeout(220)
  check(log,'dismiss pending hides feedback during operation',not await toast.is_visible())
  await state(page,'success')
  final=await stored(page)
  check(log,'dismiss pending did not cancel storage',final['settings']['displayName']=='Final snapshot '+label)
  check(log,'notification and privacy controls persist',not final['settings']['weeklyDigest'] and final['settings']['publicProfile'])
  await page.locator('#cancel-settings').click()
  check(log,'cancel restores actual stored value',await page.evaluate('window.fieldnotes.draft()')==final['settings'])
  log['events']=await page.evaluate('window.__saveEvents||[]')
  await page.reload()
  await page.wait_for_function('Boolean(window.fieldnotes)')
  check(log,'reload reads persisted settings',await page.evaluate('window.fieldnotes.draft()')==final['settings'])
  await page.locator('#theme-toggle').click()
  check(log,'neighboring theme control remains operable',await page.evaluate('document.documentElement.getAttribute("data-bs-theme")')!=theme)
  check(log,'theme control preserves draft',await page.evaluate('window.fieldnotes.draft()')==final['settings'])
  check(log,'no page errors in tested journey',not log['errors'],log['errors'])
 except Exception as error:
  log['exception']=str(error)
  check(log,'journey completed',False,str(error))
  try: await snap(page,folder,'99-exception',log)
  except: pass
 finally:
  try:
   if 'events' not in log: log['events']=await page.evaluate('window.__saveEvents||[]')
  except: pass
  await context.close()

async def race_checks(browser):
 log={'case':'operation-order-and-reduced-motion','checks':[],'captures':[],'errors':[]}
 results.append(log)
 folder=OUT/'ordering'
 folder.mkdir()
 context=await browser.new_context(viewport={'width':1280,'height':600},reduced_motion='reduce')
 page=await context.new_page()
 try:
  await page.goto(BASE+'?theme=light&lang=en')
  await page.wait_for_function('Boolean(window.fieldnotes)')
  await page.evaluate('''()=>{const old={...window.fieldnotes.draft(),displayName:'Old operation'};window.fieldnotes.setFailureMode(true);window.fieldnotes.saveSettings(old).catch(()=>{});window.fieldnotes.saveSettings({...old,displayName:''}).catch(()=>{});}''')
  await state(page,'invalid')
  await page.wait_for_timeout(950)
  check(log,'older error cannot replace newer invalid result',await page.locator('#save-status').get_attribute('data-state')=='invalid')
  check(log,'older failure cannot persist',await stored(page) is None)
  await snap(page,folder,'older-error-after-newer-invalid',log)
  await page.locator('#business-name').fill('Motion preference test')
  await page.locator('#save-settings').click()
  await state(page,'success')
  toast=page.locator('.toast-container .toast').first
  transition=await toast.evaluate('(el)=>getComputedStyle(el).transitionDuration')
  check(log,'reduced-motion inherited transition is quiet',transition in ['0s','0.01s','1e-05s'],transition)
  await snap(page,folder,'reduced-motion-success',log)
 except Exception as error:
  check(log,'ordering and reduced-motion run completed',False,str(error))
 finally: await context.close()

async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=BROWSER,headless=True,args=['--no-sandbox'])
  for width,height in [(1440,900),(1280,600),(390,844)]:
   for theme,lang in [('light','en'),('dark','zh')]:
    await run_case(browser,width,height,theme,lang)
    (OUT/'results-in-progress.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
  await race_checks(browser)
  await browser.close()
 summary={'cases':len(results),'checks':sum(len(x['checks']) for x in results),'failed':[{'case':r['case'],**c} for r in results for c in r['checks'] if not c['pass']]}
 (OUT/'results.json').write_text(json.dumps({'summary':summary,'results':results},ensure_ascii=False,indent=2))
 print(json.dumps(summary,ensure_ascii=False,indent=2))
 return bool(summary['failed'])
sys.exit(asyncio.run(main()))
