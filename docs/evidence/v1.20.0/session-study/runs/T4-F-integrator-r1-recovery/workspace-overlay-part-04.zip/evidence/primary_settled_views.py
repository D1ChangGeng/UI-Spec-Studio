import asyncio,json,sys
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence'/sys.argv[1]
OUT.mkdir(parents=True,exist_ok=False)
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def settle(page):
 previous=None
 repeats=0
 for _ in range(40):
  y=await page.evaluate('scrollY')
  repeats=repeats+1 if previous==y else 0
  if repeats>=4: return
  previous=y
  await page.wait_for_timeout(40)
async def capture(page,path,log):
 await settle(page)
 await page.wait_for_function('''()=>{const el=document.querySelector('.toast-container .toast');return !el||getComputedStyle(el).display==='none'||getComputedStyle(el).opacity==='1';}''')
 before=await page.evaluate('performance.now()')
 await page.screenshot(path=str(path))
 after=await page.evaluate('performance.now()')
 data=await page.evaluate('''()=>{const t=document.querySelector('.toast-container .toast');const a=document.activeElement,r=a.getBoundingClientRect();return {scrollY,focus:a.id||a.tagName,focusRect:r.toJSON(),focusVisible:r.bottom>0&&r.top<innerHeight&&r.right>0&&r.left<innerWidth,focusFullyVisible:r.top>=0&&r.bottom<=innerHeight&&r.left>=0&&r.right<=innerWidth,focusPointerEvents:getComputedStyle(a).pointerEvents,focusAriaDisabled:a.getAttribute('aria-disabled'),focusUnobscured:(()=>{const hit=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return a.contains(hit)||(a.getAttribute('aria-disabled')==='true'&&getComputedStyle(a).pointerEvents==='none'&&a.parentElement.contains(hit));})(),labelRect:(()=>{const label=document.querySelector('label[for=\"'+a.id+'\"]');return label?label.getBoundingClientRect().toJSON():null})(),toast:t?{rect:t.getBoundingClientRect().toJSON(),text:t.innerText,opacity:getComputedStyle(t).opacity}:null,state:document.querySelector('#save-status').dataset.state};}''')
 log.append({'path':str(path.relative_to(ROOT)),'capture_bracket_ms':[before,after],**data})
async def main():
 observations=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=BROWSER,headless=True,args=['--no-sandbox'])
  for w,h in [(1440,900),(1280,600),(390,844)]:
   for theme,lang in [('light','en'),('dark','zh')]:
    folder=OUT/f'{w}x{h}-{theme}-{lang}'
    folder.mkdir()
    context=await browser.new_context(viewport={'width':w,'height':h},device_scale_factor=1)
    page=await context.new_page()
    await page.goto(f'http://127.0.0.1:4417/?theme={theme}&lang={lang}&fail=once')
    await page.wait_for_function('Boolean(window.fieldnotes)')
    await page.evaluate('document.fonts.ready')
    await page.wait_for_timeout(250)
    log=[]
    await capture(page,folder/'00-initial-top.png',log)
    await page.locator('#business-name').fill('Mei Lin · 林玫 — field study')
    await page.locator('#save-settings').click()
    await page.wait_for_function('document.querySelector("#save-status").dataset.state==="error"')
    await page.evaluate('scrollTo(0,0)')
    await page.wait_for_function('scrollY<1')
    await capture(page,folder/'01-error-top.png',log)
    toast=page.locator('.toast-container .toast')
    await toast.screenshot(path=str(folder/'02-error-block.png'))
    await toast.get_by_role('button',name='重试保存' if lang=='zh' else 'Retry save',exact=True).focus()
    await page.keyboard.press('Enter')
    await capture(page,folder/'03-retry-focus.png',log)
    await page.wait_for_function('document.querySelector("#save-status").dataset.state==="success"')
    await capture(page,folder/'04-success-top.png',log)
    await toast.locator('.btn-close').focus()
    await page.keyboard.press('Enter')
    await page.wait_for_timeout(250)
    await capture(page,folder/'05-close-focus.png',log)
    await page.locator('#business-name').fill('')
    await page.locator('#email').fill('not-an-email')
    await page.locator('#save-settings').click()
    await page.wait_for_function('document.querySelector("#save-status").dataset.state==="invalid"')
    await capture(page,folder/'06-invalid-field.png',log)
    await page.locator('#save-settings').scroll_into_view_if_needed()
    await capture(page,folder/'07-lower-controls.png',log)
    observations.append({'case':f'{w}x{h}-{theme}-{lang}','captures':log})
    (OUT/'observations-in-progress.json').write_text(json.dumps(observations,ensure_ascii=False,indent=2))
    await context.close()
  await browser.close()
 (OUT/'observations.json').write_text(json.dumps(observations,ensure_ascii=False,indent=2))
 focus=[{'case':case['case'],'path':x['path'],'focus':x['focus'],'focusVisible':x['focusVisible'],'rect':x['focusRect']} for case in observations for x in case['captures'] if 'focus' in x['path'] or 'invalid' in x['path']]
 print(json.dumps(focus,ensure_ascii=False,indent=2))
 checks=[{'case':case['case'],'path':x['path'],'pass':x['focusFullyVisible'] and x['focusUnobscured'] and (x['labelRect'] is None or x['labelRect']['top']>=0)} for case in observations for x in case['captures'] if 'focus' in x['path'] or 'invalid' in x['path']]
 (OUT/'focus-visibility-checks.json').write_text(json.dumps(checks,indent=2))
 print(json.dumps({'focus_checks':len(checks),'failed':[x for x in checks if not x['pass']]}))
 if any(not x['pass'] for x in checks): raise SystemExit(1)
asyncio.run(main())
