import asyncio,json
from pathlib import Path
from urllib.parse import urlsplit
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence/source-and-neighbors-final'
OUT.mkdir(parents=True,exist_ok=False)
BROWSER='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
STYLE='''el=>{const s=getComputedStyle(el);return Object.fromEntries(['fontFamily','fontSize','fontWeight','lineHeight','letterSpacing','paddingTop','paddingRight','paddingBottom','paddingLeft','borderTopWidth','borderTopStyle','borderTopColor','borderRadius','boxShadow','backgroundColor','color','transitionDuration'].map(k=>[k,s[k]]));}'''
async def styles(page,base):
 return {key:await page.locator(base+selector).evaluate(STYLE) for key,selector in [('toast',''),('header',' .toast-header'),('identity',' .toast-header strong'),('body',' .toast-body'),('action',' .border-top'),('button',' .btn-primary'),('close',' .btn-close')]}
async def main():
 result=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=BROWSER,headless=True,args=['--no-sandbox'])
  for theme,lang,w,h in [('light','en',1440,900),('dark','zh',390,844)]:
   context=await browser.new_context(viewport={'width':w,'height':h})
   page=await context.new_page()
   async def route_request(route):
    if '/frozen-toasts.html' in route.request.url: await route.fulfill(status=200,content_type='text/html',body=(ROOT/'sources/official-toasts-snapshot.html').read_text())
    elif urlsplit(route.request.url).netloc!='127.0.0.1:4417': await route.abort()
    else: await route.continue_()
   await context.route('**/*',route_request)
   await page.goto('http://127.0.0.1:4417/frozen-toasts.html?theme='+theme)
   await page.get_by_role('button',name='Cookies toast',exact=True).click()
   await page.wait_for_timeout(350)
   source=await styles(page,'#toast-cookies')
   await page.goto(f'http://127.0.0.1:4417/?theme={theme}&lang={lang}&fail=once')
   await page.wait_for_function('Boolean(window.fieldnotes)')
   await page.locator('#save-settings').click()
   await page.wait_for_function('document.querySelector("#save-status").dataset.state==="error"')
   await page.evaluate('scrollTo(0,0)')
   await page.wait_for_function('scrollY<1')
   await page.wait_for_timeout(250)
   adopted=await styles(page,'#save-notification')
   differences={part:{k:{'source':source[part][k],'adopted':adopted[part][k]} for k in source[part] if source[part][k]!=adopted[part][k]} for part in source}
   differences={k:v for k,v in differences.items() if v}
   controls=await page.locator('header button,header a.nav-link').evaluate_all('''els=>els.filter(el=>{const r=el.getBoundingClientRect();return r.width&&r.height}).map(el=>{const r=el.getBoundingClientRect();return {name:el.innerText||el.getAttribute('aria-label')||el.getAttribute('title')||el.className,rect:r.toJSON(),centerHit:el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))};})''')
   trigger=page.locator('button.navbar-toggler:visible').first if w==390 else page.locator('a.nav-link.dropdown-toggle:visible').first
   trigger_name=await trigger.inner_text()
   await trigger.focus()
   await page.keyboard.press('Enter')
   await page.wait_for_timeout(350)
   expanded=await trigger.get_attribute('aria-expanded')
   await page.screenshot(path=str(OUT/f'{w}-{theme}-header-menu.png'))
   await page.locator('#save-notification .btn-close').click()
   await page.wait_for_timeout(350)
   await page.evaluate('scrollTo(0,0)')
   await page.wait_for_function('scrollY<1')
   await page.screenshot(path=str(OUT/f'{w}-{theme}-header-after-dismiss.png'))
   result.append({'theme':theme,'lang':lang,'viewport':[w,h],'source_styles':source,'adopted_styles':adopted,'style_differences':differences,'header_controls_while_visible':controls,'keyboard_menu':{'name':trigger_name,'ariaExpanded':expanded},'close_dismissed':not await page.locator('#save-notification').is_visible()})
   await context.close()
  await browser.close()
 (OUT/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
 print(json.dumps([{'theme':r['theme'],'style_differences':r['style_differences'],'keyboard_menu':r['keyboard_menu'],'close_dismissed':r['close_dismissed'],'header_controls_covered':len([x for x in r['header_controls_while_visible'] if not x['centerHit']])} for r in result],ensure_ascii=False,indent=2))
asyncio.run(main())
