from pathlib import Path
import json,time
from playwright.sync_api import sync_playwright
root=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w17')
records=[]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
    context=browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
    page=context.new_page()
    page.route('http://127.0.0.1:4417/acquired-toasts.html',lambda route:route.fulfill(path=str(root/'sources/official-toasts-snapshot.html'),content_type='text/html'))
    page.on('requestfailed',lambda req:records.append({'requestfailed':req.url,'failure':req.failure}))
    page.goto('http://127.0.0.1:4417/acquired-toasts.html',wait_until='networkidle')
    page.get_by_role('button',name='Cookies toast',exact=True).click()
    page.wait_for_selector('#toast-cookies.show')
    page.wait_for_timeout(250)
    page.screenshot(path=str(root/'evidence/captures/acquired-source-1440.png'))
    records.append({'subject':'local rendering of exact acquired official HTML, local matching assets; not live upstream rendering','viewport':page.viewport_size,'source':'sources/official-toasts-snapshot.html','toast':page.locator('#toast-cookies').bounding_box(),'timestamp':time.time(),'styles':page.locator('#toast-cookies').evaluate('(el)=>{const s=getComputedStyle(el); return {width:s.width,font:s.font,padding:s.padding,border:s.border,boxShadow:s.boxShadow}}')})
    context.close()
    baseline=[]
    for width,height in [(1440,900),(1280,600),(390,844)]:
        for theme,lang in [('light','en'),('dark','zh')]:
            c=browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1)
            pg=c.new_page()
            pg.route('http://127.0.0.1:4417/baseline-inspection.html*',lambda route:route.fulfill(path=str(root/'evidence/source/baseline-index.html'),content_type='text/html'))
            pg.route('**/settings-controller.js',lambda route:route.fulfill(path=str(root/'evidence/source/baseline-settings-controller.js'),content_type='application/javascript'))
            pg.goto(f'http://127.0.0.1:4417/baseline-inspection.html?theme={theme}&lang={lang}',wait_until='networkidle')
            pg.evaluate('document.fonts.ready')
            geom={}
            for selector in ['.page-body .card','#profile-heading','#business-name','#save-settings']:
                geom[selector]=pg.locator(selector).first.bounding_box()
            baseline.append({'viewport':[width,height],'theme':theme,'lang':lang,'geometry':geom,'bodyWidth':pg.evaluate('document.body.scrollWidth'),'innerWidth':width})
            c.close()
    (root/'evidence/source/baseline-geometry.json').write_text(json.dumps(baseline,indent=2))
    print(json.dumps({'source':records,'baseline':baseline},indent=2))
    browser.close()

