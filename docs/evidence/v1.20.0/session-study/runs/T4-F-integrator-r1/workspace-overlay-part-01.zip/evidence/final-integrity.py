from pathlib import Path
import json,hashlib,difflib,datetime
r=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w17')
files=['app/index.html','app/settings-controller.js','app/save-notification.js','app/settings-store.js','app/toast-source-preview.html','app/dist/css/tabler.min.css','app/dist/js/tabler.min.js','app/LICENSE','app/package.json','SOURCE-MANIFEST.json','sources/official-toasts-snapshot.html','sources/tabler-toast-cookies.html']
out={'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':{name:hashlib.sha256((r/name).read_bytes()).hexdigest() for name in files},'assertions':{}}
out['assertions']['store_matches_baseline']=(r/'app/settings-store.js').read_bytes()==(r/'evidence/source/baseline-settings-store.js').read_bytes()
out['assertions']['tabler_css_matches_initial_digest']=out['files']['app/dist/css/tabler.min.css']=='dcf84d7b4319c29ab33450bfe2a7bbf607458d994ef71023f7509e912cafdbd5'
marker="document.querySelector('#focus-email')"
out['assertions']['unrelated_controller_tail_unchanged']=(r/'app/settings-controller.js').read_text().split(marker,1)[1]==(r/'evidence/source/baseline-settings-controller.js').read_text().split(marker,1)[1]
out['assertions']['acquired_block_matches_manifest']=out['files']['sources/tabler-toast-cookies.html']=='767fe7aaddd46979d9f2748c1488063902086109962051881aeae94ad04dc75a'
out['assertions']['acquired_html_matches_manifest']=out['files']['sources/official-toasts-snapshot.html']=='c5d0c06e11c2990ef70e5502cc72c2a2a8f6d13af25ac08d64a9859fe93c5e5d'
out['lockfiles']=[str(p.relative_to(r)) for p in (r/'app').rglob('*') if p.name in ('package-lock.json','pnpm-lock.yaml','yarn.lock','bun.lock','bun.lockb')]
(r/'FINAL-SOURCE-DIGESTS.json').write_text(json.dumps(out,indent=2)+'\n')
views=[]
for p in sorted((r/'evidence/views').glob('*.json')):
 v=json.loads(p.read_text())
 views.append({'record':str(p.relative_to(r)),'tool':v.get('tool'),'input_path':v.get('arguments',{}).get('path'),'record_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'detail':v.get('result',{}).get('detail')})
(r/'evidence/viewed-images.json').write_text(json.dumps({'observer':'main agent','count':len(views),'views':views},indent=2)+'\n')
diff=[]
for name in ['index.html','settings-controller.js']:
 diff.extend(difflib.unified_diff((r/'evidence/source'/('baseline-'+name)).read_text().splitlines(True),(r/'app'/name).read_text().splitlines(True),fromfile='baseline/'+name,tofile='app/'+name))
diff.extend(difflib.unified_diff([], (r/'app/save-notification.js').read_text().splitlines(True),fromfile='/dev/null',tofile='app/save-notification.js'))
(r/'evidence/main-integration.diff').write_text(''.join(diff))
print(json.dumps({'digests':out,'view_receipts':len(views),'diff_lines':len(diff)},indent=2))
assert all(out['assertions'].values())

