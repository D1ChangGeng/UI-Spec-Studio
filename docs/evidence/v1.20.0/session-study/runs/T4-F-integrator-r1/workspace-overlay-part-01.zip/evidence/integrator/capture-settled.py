import asyncio, json, time, shutil
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w17')
OUT=ROOT/'evidence/integrator/004-settled'
OUT.mkdir(parents=True,exist_ok=True)
records=[]
async def capture(page,name):
    await page.wait_for_function('!document.querySelector("#save-notification").classList.contains("showing")')
    await page.evaluate('document.fonts.ready')
    before=time.monotonic()
    await page.screenshot(path=str(OUT/(name+'.png')))
    records.append({'image':name+'.png','capture_start':before,'capture_end':time.monotonic(),'scrollY':await page.evaluate('scrollY'),'viewport':page.viewport_size,'state':await page.locator('#save-notification').get_attribute('data-state'),'focus':await page.evaluate('document.activeElement.id')})
async def main():
  async with async_playwright() as p:
    browser=await p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
    for width,height,theme,lang in [(1440,900,'light','en'),(1440,900,'dark','zh'),(1280,600,'light','en'),(1280,600,'dark','zh'),(390,844,'light','en'),(390,844,'dark','zh')]:
      name=f'{width}-{theme}-{lang}'
      context=await browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1)
      page=await context.new_page()
      await page.goto(f'http://127.0.0.1:4417/?theme={theme}&lang={lang}&fail=once')
      await page.wait_for_function('!!window.fieldnotes')
      await page.locator('#save-settings').click()
      await page.wait_for_function('document.querySelector("#save-notification").dataset.state==="error"')
      await page.evaluate('scrollTo({top:0,behavior:"instant"})')
      await capture(page,name+'-error-top')
      await page.locator('#save-settings').evaluate('el=>el.scrollIntoView({block:"end",behavior:"instant"})')
      await capture(page,name+'-error-actions')
      await page.locator('#business-name').fill('')
      await page.locator('#email').fill('incomplete')
      await page.locator('#save-settings').click()
      await page.wait_for_function('document.querySelector("#save-notification").dataset.state==="invalid"')
      await page.locator('#business-name').evaluate('el=>el.scrollIntoView({block:"center",behavior:"instant"})')
      await capture(page,name+'-invalid')
      await context.close()
    await browser.close()
  (OUT/'captures.json').write_text(json.dumps(records,indent=2)+'\n')
  for path in Path('/tmp').glob('w17-integrator-view-*.json'):
    shutil.copy2(path,ROOT/'evidence/integrator'/path.name.replace('w17-integrator-',''))
  shutil.copy2('/tmp/w17-integrator-check.py',ROOT/'evidence/integrator/check.py')
  shutil.copy2('/tmp/w17-integrator-settled.py',ROOT/'evidence/integrator/capture-settled.py')
  shutil.copy2('/tmp/w17-integrator-implement.py',ROOT/'evidence/integrator/implementation.py')
  print(json.dumps({'captured':len(records),'output':str(OUT)}))
asyncio.run(main())
