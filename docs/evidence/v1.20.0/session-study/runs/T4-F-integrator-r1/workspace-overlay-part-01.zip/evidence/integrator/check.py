import asyncio, json, time, hashlib
from pathlib import Path
from playwright.async_api import async_playwright

ROOT = Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w17')
OUT = ROOT/'evidence/integrator/003-browser'
OUT.mkdir(parents=True, exist_ok=True)
BROWSER = '/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
checks=[]
events=[]
errors=[]
def check(name, value, detail=None):
    checks.append({'check':name,'pass':bool(value),'detail':detail})
    assert value, f'{name}: {detail}'
async def state(page, value):
    await page.locator('#save-notification').wait_for(state='visible')
    await page.wait_for_function('(s)=>document.querySelector("#save-notification").dataset.state===s',arg=value)
async def shot(page,name):
    await page.evaluate('document.fonts.ready')
    t=time.monotonic()
    await page.screenshot(path=str(OUT/(name+'.png')))
    events.append({'image':name+'.png','capture_start_monotonic':t,'capture_end_monotonic':time.monotonic(),'state':await page.locator('#save-notification').get_attribute('data-state'),'scrollY':await page.evaluate('scrollY'),'focus':await page.evaluate('document.activeElement.id')})
async def stored(page):
    return await page.evaluate('JSON.parse(localStorage.getItem("fieldnotes-settings-v1"))')
async def geometry(page):
    return await page.locator('#save-notification').evaluate('el=>{const s=getComputedStyle(el),r=el.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,right:r.right,fontSize:s.fontSize,borderRadius:s.borderRadius,boxShadow:s.boxShadow,borderWidth:s.borderWidth}}')

async def run():
  async with async_playwright() as p:
    browser=await p.chromium.launch(executable_path=BROWSER, headless=True, args=['--no-sandbox'])
    for width,height,theme,lang in [(1440,900,'light','en'),(1440,900,'dark','zh'),(1280,600,'light','en'),(1280,600,'dark','zh'),(390,844,'light','en'),(390,844,'dark','zh')]:
      name=f'{width}-{theme}-{lang}'
      context=await browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1)
      page=await context.new_page()
      page.on('pageerror', lambda e:errors.append(str(e)))
      await page.goto('http://127.0.0.1:4417/?theme='+theme+'&lang='+lang)
      await page.wait_for_function('!!window.fieldnotes')
      await page.evaluate('document.fonts.ready')
      check(name+' preexisting polite status',await page.locator('#save-notification').get_attribute('aria-live')=='polite')
      check(name+' inline summary not live',await page.locator('#save-status').get_attribute('role') is None)
      await page.locator('#business-name').fill('Submitted '+name)
      await page.locator('#save-settings').click()
      await state(page,'pending')
      check(name+' save disabled while pending',await page.locator('#save-settings').is_disabled())
      check(name+' pending no retry',not await page.locator('#retry-save').is_visible())
      await page.locator('#business-name').fill('Newer '+name)
      if width==1440: await shot(page,name+'-pending')
      await state(page,'success')
      data=await stored(page)
      check(name+' authoritative saved snapshot',data['settings']['displayName']=='Submitted '+name,data)
      check(name+' newer draft and focus retained',await page.locator('#business-name').input_value()=='Newer '+name and await page.evaluate('document.activeElement.id')=='business-name')
      check(name+' success timestamp',bool(await page.locator('#save-notification-time').inner_text()))
      await page.evaluate('scrollTo(0,0)')
      await shot(page,name+'-success')
      before=json.dumps(data,sort_keys=True)
      await page.evaluate('fieldnotes.setFailureMode(true)')
      await page.locator('#save-settings').click()
      await state(page,'pending')
      await page.locator('#business-name').fill('Later '+name)
      await state(page,'error')
      check(name+' failed write preserves storage',json.dumps(await stored(page),sort_keys=True)==before)
      check(name+' failure preserves newer form',await page.locator('#business-name').input_value()=='Later '+name)
      check(name+' error retry shown',await page.locator('#retry-save').is_visible())
      await page.evaluate('scrollTo(0,0)')
      await shot(page,name+'-error')
      g=await geometry(page)
      check(name+' native width and containment',abs(g['width']-350)<1 and g['x']>=0 and g['right']<=width,g)
      check(name+' close reachable',await page.locator('#save-notification-close').evaluate('el=>{const r=el.getBoundingClientRect();return document.elementFromPoint(r.x+r.width/2,r.y+r.height/2)===el}'))
      if width==1440 and lang=='en':
        await page.wait_for_timeout(5200)
        check(name+' error does not autohide',await page.locator('#save-notification').is_visible())
      await page.locator('#retry-save').focus()
      await page.keyboard.press('Enter')
      await state(page,'pending')
      check(name+' disappearing retry focuses usable field',await page.evaluate('document.activeElement.id')=='business-name')
      await state(page,'success')
      data=await stored(page)
      check(name+' retry saves failed snapshot',data['settings']['displayName']=='Newer '+name,data)
      check(name+' retry leaves later form edits',await page.locator('#business-name').input_value()=='Later '+name)
      await page.locator('#save-notification-close').focus()
      await page.keyboard.press('Enter')
      await page.locator('#save-notification').wait_for(state='hidden')
      check(name+' close focus return',await page.evaluate('document.activeElement.id')=='save-settings')
      check(name+' close leaves persisted snapshot',(await stored(page))['settings']['displayName']=='Newer '+name)
      await page.locator('#business-name').fill('')
      await page.locator('#email').fill('incomplete')
      await page.locator('#business-id').fill('o'*181)
      await page.locator('#location').fill('x'*101)
      await page.locator('#save-settings').click()
      await state(page,'invalid')
      check(name+' first invalid receives focus',await page.evaluate('document.activeElement.id')=='business-name')
      for field in ['business-name','email','business-id','location']:
        check(name+' associated error '+field,await page.locator('#'+field).get_attribute('aria-invalid')=='true' and bool(await page.locator('#'+field+'-error').inner_text()) and field+'-error' in await page.locator('#'+field).get_attribute('aria-describedby'))
      check(name+' actual localized validation',await page.locator('#business-name-error').inner_text()==('请填写显示名称。' if lang=='zh' else 'Add a display name.'))
      await shot(page,name+'-invalid')
      await page.locator('#business-name').fill('Corrected')
      check(name+' editing clears only edited field error',await page.locator('#business-name').get_attribute('aria-invalid') is None and await page.locator('#email').get_attribute('aria-invalid')=='true')
      check(name+' rejected submission preserves stored settings',(await stored(page))['settings']['displayName']=='Newer '+name)
      if width==1440 and lang=='en':
        # Real concurrent owner events, without replacing the read-only store.
        await page.evaluate('''async()=>{
          window.observedStates=[];
          new MutationObserver(()=>observedStates.push(document.querySelector('#save-notification').dataset.state)).observe(document.querySelector('#save-notification'),{attributes:true,attributeFilter:['data-state']});
          const valid={...fieldnotes.readSettings(),displayName:'older'};
          fieldnotes.setFailureMode(true);
          const older=fieldnotes.saveSettings(valid).catch(()=>{});
          await new Promise(r=>setTimeout(r,100));
          const newer=fieldnotes.saveSettings({...valid,displayName:'newest'});
          await Promise.all([older,newer]);
        }''')
        check('stale older error cannot replace newer pending/success','error' not in await page.evaluate('observedStates'),await page.evaluate('observedStates'))
        await page.evaluate('''async()=>{
          const valid=fieldnotes.readSettings();
          const old=fieldnotes.saveSettings(valid);
          await fieldnotes.saveSettings({...valid,displayName:''}).catch(()=>{});
          await old;
        }''')
        check('older success cannot replace newer invalid',await page.locator('#save-notification').get_attribute('data-state')=='invalid')
      await context.close()
    check('no runtime page errors',not errors,errors)
    # Compare actual source and integrated computed shell at matching conditions.
    context=await browser.new_context(viewport={'width':1440,'height':900})
    page=await context.new_page()
    await page.goto('http://127.0.0.1:4417/toast-source-preview.html')
    source=await page.locator('#toast-cookies').evaluate('el=>{const s=getComputedStyle(el);return {width:s.width,fontSize:s.fontSize,borderRadius:s.borderRadius,boxShadow:s.boxShadow,borderWidth:s.borderWidth,headerPadding:getComputedStyle(el.querySelector(".toast-header")).padding,bodyPadding:getComputedStyle(el.querySelector(".toast-body")).padding}}')
    await page.goto('http://127.0.0.1:4417/?theme=light&lang=en&fail=once')
    await page.wait_for_function('!!window.fieldnotes')
    await page.locator('#save-settings').click()
    await state(page,'error')
    integrated=await page.locator('#save-notification').evaluate('el=>{const s=getComputedStyle(el);return {width:s.width,fontSize:s.fontSize,borderRadius:s.borderRadius,boxShadow:s.boxShadow,borderWidth:s.borderWidth,headerPadding:getComputedStyle(el.querySelector(".toast-header")).padding,bodyPadding:getComputedStyle(el.querySelector(".toast-body")).padding}}')
    check('source computed shell relationships retained',source==integrated,{'source':source,'integrated':integrated})
    protected=json.loads((ROOT/'evidence/integrator/protected-before.json').read_text())
    check('read-only files unchanged',all(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest for name,digest in protected.items()))
    await context.close()
    await browser.close()

try:
    asyncio.run(run())
finally:
    result={'checks':checks,'captures':events,'pageErrors':errors,'conditions':{'browser':BROWSER,'deviceScaleFactor':1,'fontconfig':'/tmp/ui-spec-fonts/fonts.conf','timing':'natural timers with ordered static captures; no playback claim'}}
    (OUT/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'passed':sum(c['pass'] for c in checks),'total':len(checks),'captures':len(events),'pageErrors':errors},ensure_ascii=False))
