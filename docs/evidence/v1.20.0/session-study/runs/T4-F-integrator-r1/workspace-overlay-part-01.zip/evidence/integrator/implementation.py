from pathlib import Path
import shutil, hashlib, json

root = Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w17')
out = root / 'evidence/integrator'
out.mkdir(parents=True, exist_ok=True)
for name in ('index.html', 'settings-controller.js'):
    shutil.copy2(root / 'app' / name, out / ('before-' + name))
protected = ['app/settings-store.js', 'app/toast-source-preview.html', 'SOURCE-MANIFEST.json']
(out / 'protected-before.json').write_text(json.dumps({name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in protected}, indent=2)+'\n')
for name in ('source','baseline'):
    shutil.copy2('/tmp/w17-integrator-view-'+name+'.json', out / ('view-'+name+'.json'))

path = root / 'app/index.html'
html = path.read_text()
html = html.replace('id="save-status" role="status"', 'id="save-status"')
for ident in ('business-name', 'business-id', 'location', 'email'):
    lines = html.splitlines(keepends=True)
    for i,line in enumerate(lines):
        if '<input ' in line and 'id="'+ident+'"' in line:
            lines[i] = line.replace(' />', ' aria-describedby="'+ident+'-error" />')
            lines.insert(i+1, '                            <div class="invalid-feedback" id="'+ident+'-error"></div>\n')
            break
    html = ''.join(lines)
notice = (root / 'app/LICENSE').read_text().strip()
block = '''    <!--
    Adapted from Tabler 1.7.1 action-bearing toast (toast-cookies).
    Tagged source: 07f60c07da13d8ff957a370434b7ef5c86f5ab94,
    shared/components/demo/Toast.astro. Deployed HTML snapshot identity is
    recorded separately in SOURCE-MANIFEST.json; its exact deployment commit
    is not advertised.

'''+notice+'''
    -->
    <div class="toast-container position-fixed top-0 end-0 p-3">
      <div class="toast" id="save-notification" role="status" aria-live="polite" aria-atomic="true" data-bs-autohide="false">
        <div class="toast-header">
          <span class="avatar avatar-xs me-2" aria-hidden="true">FN</span>
          <strong class="me-auto">Fieldnotes</strong>
          <small id="save-notification-time"></small>
          <button type="button" class="ms-2 btn-close" data-bs-dismiss="toast" aria-label="Close" id="save-notification-close"></button>
        </div>
        <div class="toast-body">
          <span id="save-notification-message"></span>
          <div class="mt-2 pt-2 border-top" id="save-notification-actions" hidden>
            <button type="button" class="btn btn-primary btn-sm" id="retry-save">Retry save</button>
          </div>
        </div>
      </div>
    </div>
'''
html = html.replace('  <script type="module" src="./settings-controller.js"></script>', block+'  <script type="module" src="./settings-controller.js"></script>')
path.write_text(html)

path = root / 'app/settings-controller.js'
original = path.read_text()
unchanged = original[original.index("document.querySelector('#focus-email')"):]
head = '''import { readSettings, saveSettings, subscribeSettings, setFailureMode } from './settings-store.js';
import { createSaveNotification } from './save-notification.js';

const ids = {displayName:'business-name',organization:'business-id',location:'location',email:'email',weeklyDigest:'weekly-digest',publicProfile:'public-profile'};
const status = document.querySelector('#save-status');
const save = document.querySelector('#save-settings');
const params = new URLSearchParams(location.search);
const zh = params.get('lang') === 'zh';
const copy = zh
  ? {idle:'更改仅保存在当前浏览器中。',pending:'正在保存…',success:'已保存在当前浏览器。',error:'更改尚未保存。',invalid:'请修正标记的字段。',dirty:'当前表单有未保存的更改。'}
  : {idle:'Changes are saved only in this browser.',pending:'Saving…',success:'Saved in this browser.',error:'Changes have not been saved.',invalid:'Correct the marked fields.',dirty:'The form has unsaved changes.'};
const fieldNames = zh
  ? {displayName:'显示名称',organization:'机构',location:'地点',email:'电子邮件'}
  : {displayName:'Display name',organization:'Organization',location:'Location',email:'Email'};
const errorTranslations = {
  'Add a display name.':'请填写显示名称。',
  'Use 100 characters or fewer.':'请使用不超过 100 个字符。',
  'Use 180 characters or fewer.':'请使用不超过 180 个字符。',
  'Enter a complete email address.':'请输入完整的电子邮件地址。'
};
let latestOperation = 0;
let currentEvent = null;
let lastField = document.getElementById(ids.displayName);
function draft() {
  return Object.fromEntries(Object.entries(ids).map(([key,id]) => {
    const el = document.getElementById(id);
    return [key, el.type === 'checkbox' ? el.checked : el.value];
  }));
}
function sameValues(a, b) { return Object.keys(ids).every(key => a[key] === b[key]); }
function clearFieldError(key) {
  const el = document.getElementById(ids[key]);
  el.classList.remove('is-invalid');
  el.removeAttribute('aria-invalid');
  const feedback = document.getElementById(ids[key] + '-error');
  if (feedback) feedback.textContent = '';
}
function clearErrors() { Object.keys(ids).forEach(clearFieldError); }
function load() {
  const data = readSettings();
  for (const [key,id] of Object.entries(ids)) {
    const el = document.getElementById(id);
    if (el.type === 'checkbox') el.checked = data[key];
    else el.value = data[key];
  }
  clearErrors();
}
function restoreFeedbackFocus() {
  // A retry starts synchronously; Save is already disabled at this point.
  const target = !save.disabled ? save : lastField;
  target.focus();
}
const notification = createSaveNotification({zh, fieldNames, restoreFocus:restoreFeedbackFocus});
try { load(); status.textContent = copy.idle; } catch (error) { status.textContent = error.message; }
subscribeSettings(event => {
  // Validation also consumes an operation ID. Never let an older completion
  // replace a newer rejected submission or a newer result.
  if (event.operationId < latestOperation) return;
  latestOperation = event.operationId;
  currentEvent = event;
  save.disabled = event.status === 'pending';
  save.setAttribute('aria-busy', String(event.status === 'pending'));
  status.dataset.state = event.status;
  status.textContent = event.status === 'success' && !sameValues(draft(), event.settings)
    ? copy.dirty : copy[event.status] || copy.idle;
  if (event.status === 'pending') clearErrors();
  let firstInvalid;
  if (event.status === 'invalid') {
    clearErrors();
    for (const key of Object.keys(ids)) {
      const message = event.fieldErrors[key];
      if (!message) continue;
      const el = document.getElementById(ids[key]);
      el.classList.add('is-invalid');
      el.setAttribute('aria-invalid', 'true');
      document.getElementById(ids[key] + '-error').textContent = zh ? errorTranslations[message] || message : message;
      firstInvalid ||= el;
    }
  }
  notification.render(event);
  if (firstInvalid && document.activeElement !== firstInvalid) firstInvalid.focus();
});
for (const [key,id] of Object.entries(ids)) {
  const el = document.getElementById(id);
  el.addEventListener('focus', () => { lastField = el; });
  el.addEventListener('input', () => {
    clearFieldError(key);
    if (currentEvent?.status !== 'pending') status.textContent = copy.dirty;
  });
}
save.addEventListener('click', async () => {
  try { await saveSettings(draft()); } catch { /* Store events own feedback. */ }
});
document.querySelector('#cancel-settings').addEventListener('click', () => {
  try { load(); status.textContent = currentEvent?.status === 'pending' ? copy.pending : copy.idle; }
  catch (error) { status.textContent = error.message; }
});
'''
path.write_text(head + unchanged)

(root / 'app/save-notification.js').write_text('''import { saveSettings } from './settings-store.js';

// State adapter for the MIT Tabler 1.7.1 action-toast markup in index.html.
// All surface, transition and dismissal behavior remains with tabler.Toast.
export function createSaveNotification({zh, fieldNames, restoreFocus}) {
  const element = document.getElementById('save-notification');
  const message = document.getElementById('save-notification-message');
  const time = document.getElementById('save-notification-time');
  const actions = document.getElementById('save-notification-actions');
  const retry = document.getElementById('retry-save');
  const close = document.getElementById('save-notification-close');
  const toast = tabler.Toast.getOrCreateInstance(element, {autohide:false});
  const copy = zh ? {
    pending:'正在保存更改。正在将已提交的版本保存到当前浏览器。',
    success:'更改已保存。此版本仅存储在当前浏览器中。',
    error:'保存未完成。草稿仍然保留。重试将保存失败的版本。',
    invalid:name => `请检查个人资料字段。请先检查${name}。`,
    retry:'重试保存',close:'关闭保存通知',now:'刚刚'
  } : {
    pending:'Saving changes. The submitted version is being saved in this browser.',
    success:'Changes saved. This version is stored only in this browser.',
    error:'Save did not complete. Your draft is still available. Retry saves the failed version.',
    invalid:name => `Check profile fields. Start with ${name}.`,
    retry:'Retry save',close:'Close save notification',now:'Just now'
  };
  close.setAttribute('aria-label', copy.close);
  retry.textContent = copy.retry;
  let latestOperation = 0;
  let failedSnapshot = null;
  let renderVersion = 0;
  let hiding = false;
  let hideVersion = 0;
  let returnAfterHide = false;

  element.addEventListener('hide.bs.toast', () => {
    hiding = true;
    hideVersion = renderVersion;
    returnAfterHide = element.contains(document.activeElement);
  });
  element.addEventListener('hidden.bs.toast', () => {
    hiding = false;
    if (returnAfterHide && (document.activeElement === document.body || element.contains(document.activeElement))) restoreFocus();
    returnAfterHide = false;
    // A newer authoritative event can arrive during the native hide transition.
    if (renderVersion !== hideVersion) toast.show();
  });
  retry.addEventListener('click', async () => {
    if (!failedSnapshot) return;
    const snapshot = {...failedSnapshot};
    // Do not dismiss here: only the authoritative pending event replaces error.
    try { await saveSettings(snapshot); } catch { /* Store events own feedback. */ }
  });
  return {
    render(event) {
      if (event.operationId < latestOperation) return;
      latestOperation = event.operationId;
      renderVersion++;
      const firstField = Object.keys(fieldNames).find(key => event.fieldErrors?.[key]);
      message.textContent = event.status === 'invalid' ? copy.invalid(fieldNames[firstField] || (zh ? '标记的字段' : 'the marked field')) : copy[event.status];
      time.textContent = event.status === 'success'
        ? new Date(event.savedAt).toLocaleTimeString(zh ? 'zh-CN' : 'en', {hour:'2-digit',minute:'2-digit'})
        : copy.now;
      time.title = event.status === 'success' ? new Date(event.savedAt).toLocaleString(zh ? 'zh-CN' : 'en') : '';
      failedSnapshot = event.status === 'error' ? {...event.snapshot} : null;
      if (event.status !== 'error' && document.activeElement === retry) restoreFocus();
      actions.hidden = event.status !== 'error';
      element.dataset.state = event.status;
      element.dataset.operationId = String(event.operationId);
      // Existing visible feedback updates in place; the source owns its entrance.
      if (!hiding && !toast.isShown()) toast.show();
    }
  };
}
''')
print(json.dumps({'changed':['app/index.html','app/settings-controller.js','app/save-notification.js'],'protected':protected}))
