from pathlib import Path
import json,time,traceback,hashlib
from playwright.sync_api import sync_playwright,expect

ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w17')
OUT=ROOT/'evidence/main-check'
OUT.mkdir(exist_ok=True)
BASE='http://127.0.0.1:4417/'
KEY='fieldnotes-settings-v1'
TOAST='.toast-container .toast'
baseline=json.loads((ROOT/'evidence/source/baseline-geometry.json').read_text())
report={'subject':'independent main-agent integrated product checks','browser':'Chromium headless shell 143.0.7499.4','device_scale_factor':1,'fontconfig':'/tmp/ui-spec-fonts/fonts.conf','cases':[],'captures':[],'limits':['Desktop browser viewport emulation; no real mobile virtual keyboard.','Recorded video is retained but not declared as naturally viewed playback.','Live-region semantics checked; no screen-reader auditory session.']}

def state(page,value):
    page.wait_for_function('(v)=>document.querySelector("#save-status").dataset.state===v',arg=value,timeout=4000)

def storage(page):
    return page.evaluate('(key)=>JSON.parse(localStorage.getItem(key))',KEY)

def focus(page):
    return page.evaluate('()=>({id:document.activeElement.id,tag:document.activeElement.tagName,disabled:Boolean(document.activeElement.disabled),visible:Boolean(document.activeElement.getClientRects().length)})')

def capture(page,case,name):
    path=OUT/f'{case}-{name}.png'
    started=page.evaluate('performance.now()')
    page.screenshot(path=str(path))
    report['captures'].append({'case':case,'state':name,'path':str(path.relative_to(ROOT)),'capture_start_page_ms':started,'capture_end_page_ms':page.evaluate('performance.now()'),'wall_timestamp':time.time(),'viewport':page.viewport_size,'scrollY':page.evaluate('scrollY'),'focus':focus(page)})
    return str(path)

def check(case,label,condition,detail=None):
    case['checks'].append({'check':label,'pass':bool(condition),'detail':detail})
    if not condition:raise AssertionError(label+': '+str(detail))

def toast_text(page):
    return page.locator(TOAST).inner_text()

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
    for width,height in [(1440,900),(1280,600),(390,844)]:
        for theme,lang in [('light','en'),('dark','zh')]:
            name=f'{width}x{height}-{theme}-{lang}'
            case={'name':name,'viewport':[width,height],'theme':theme,'lang':lang,'checks':[],'page_errors':[],'console_errors':[]}
            report['cases'].append(case)
            opts={'viewport':{'width':width,'height':height},'device_scale_factor':1,'locale':'zh-CN' if lang=='zh' else 'en-US'}
            if width==1440:opts.update(record_video_dir=str(OUT/'videos'),record_video_size={'width':width,'height':height})
            context=browser.new_context(**opts)
            page=context.new_page()
            page.on('pageerror',lambda error,c=case:c['page_errors'].append(str(error)))
            page.on('console',lambda message,c=case:c['console_errors'].append(message.text) if message.type=='error' else None)
            try:
                page.goto(f'{BASE}?theme={theme}&lang={lang}',wait_until='networkidle')
                page.evaluate('document.fonts.ready')
                page.wait_for_function('Boolean(window.fieldnotes)')
                page.evaluate('''async()=>{window.audit=[]; const s=await import('./settings-store.js');s.subscribeSettings(e=>window.audit.push({status:e.status,operationId:e.operationId,snapshot:e.snapshot,settings:e.settings,savedAt:e.savedAt,fieldErrors:e.fieldErrors,page_ms:performance.now()}));}''')
                capture(page,name,'initial')
                expected=next(x for x in baseline if x['viewport']==[width,height] and x['theme']==theme and x['lang']==lang)
                geometry={sel:page.locator(sel).first.bounding_box() for sel in expected['geometry']}
                check(case,'initial form geometry retained',geometry==expected['geometry'],{'before':expected['geometry'],'after':geometry})
                check(case,'no horizontal document overflow',page.evaluate('document.body.scrollWidth<=innerWidth'))
                check(case,'correct initial theme',page.locator('html').get_attribute('data-bs-theme')==theme)

                submitted='Submitted version / 已提交版本'
                later='Later draft / 后续草稿'
                page.locator('#business-name').fill(submitted)
                page.locator('#weekly-digest').uncheck()
                page.locator('#public-profile').check()
                page.locator('#save-settings').focus()
                page.keyboard.press('Enter')
                state(page,'pending')
                check(case,'save is disabled during authoritative pending',page.locator('#save-settings').is_disabled())
                if width==1440:capture(page,name,'pending')
                page.locator('#business-name').fill(later)
                current_focus=focus(page)
                state(page,'success')
                check(case,'newer draft survives completion',page.locator('#business-name').input_value()==later)
                check(case,'completion preserves field focus',focus(page)['id']=='business-name',{'before':current_focus,'after':focus(page)})
                persisted=storage(page)
                check(case,'actual persisted submitted snapshot',persisted['settings']['displayName']==submitted and not persisted['settings']['weeklyDigest'] and persisted['settings']['publicProfile'],persisted)
                check(case,'success only after store event',page.evaluate('audit.at(-1).status')=='success')
                page.evaluate('scrollTo(0,0)')
                capture(page,name,'success')
                check(case,'success stays visible',page.locator(TOAST).is_visible())
                check(case,'native persistent setting',page.locator(TOAST).get_attribute('data-bs-autohide')=='false')
                before=persisted

                failed='Failed version / 失败版本'
                newest='New unsaved draft / 最新未保存草稿'
                page.evaluate('window.fieldnotes.setFailureMode(true)')
                page.locator('#business-name').fill(failed)
                page.locator('#save-settings').click()
                state(page,'pending')
                page.locator('#business-name').fill(newest)
                state(page,'error')
                check(case,'failure preserves prior storage',storage(page)==before,storage(page))
                check(case,'failure preserves newer draft',page.locator('#business-name').input_value()==newest)
                retry=page.locator(TOAST+' .toast-body button').filter(has_text='重试保存' if lang=='zh' else 'Retry save')
                expect(retry).to_be_visible()
                page.evaluate('scrollTo(0,0)')
                capture(page,name,'error')
                box=page.locator(TOAST).bounding_box()
                close=page.locator(TOAST+' .btn-close')
                closebox=close.bounding_box()
                check(case,'toast remains within viewport',box['x']>=0 and box['y']>=0 and box['x']+box['width']<=width+0.5 and box['y']+box['height']<=height,box)
                check(case,'native close receives pointer at center',close.evaluate('(el)=>{const r=el.getBoundingClientRect();return el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}'),closebox)
                check(case,'toast does not move form layout',page.locator('#business-name').bounding_box()['x']==geometry['#business-name']['x'])
                if width==390:
                    page.locator('#save-settings').scroll_into_view_if_needed()
                    capture(page,name,'error-lower-controls')
                    sbox=page.locator('#save-settings').bounding_box()
                    check(case,'lower save control remains reachable',0<=sbox['y'] and sbox['y']+sbox['height']<=height,sbox)
                retry.focus()
                page.keyboard.press('Enter')
                state(page,'pending')
                retry_focus=focus(page)
                check(case,'retry hides its action during pending',not retry.is_visible())
                check(case,'focus remains on a usable control after Retry disappears',retry_focus['visible'] and not retry_focus['disabled'] and retry_focus['tag'] not in ['BODY','HTML'],retry_focus)
                if width==1440:capture(page,name,'retry-pending')
                state(page,'success')
                check(case,'retry saves failed snapshot rather than current later draft',storage(page)['settings']['displayName']==failed,storage(page))
                check(case,'retry preserves current later draft',page.locator('#business-name').input_value()==newest)
                after_retry=storage(page)
                close.focus()
                page.keyboard.press('Enter')
                expect(page.locator(TOAST)).to_be_hidden()
                check(case,'close preserves storage and draft',storage(page)==after_retry and page.locator('#business-name').input_value()==newest)
                f=focus(page)
                check(case,'close restores usable task focus',f['visible'] and not f['disabled'] and f['tag'] not in ['BODY','HTML'],f)

                page.locator('#business-name').fill('')
                page.locator('#email').fill('not-an-email')
                page.locator('#save-settings').click()
                state(page,'invalid')
                check(case,'rejected submit focuses actual first invalid field',focus(page)['id']=='business-name',focus(page))
                for selector in ['#business-name','#email']:
                    field=page.locator(selector)
                    described=field.get_attribute('aria-describedby') or ''
                    check(case,selector+' has associated field error',field.get_attribute('aria-invalid')=='true' and bool(described),described)
                    for ident in described.split():
                        check(case,selector+' description exists',page.locator('[id="'+ident+'"]').count()==1,ident)
                check(case,'invalid submit preserves stored value',storage(page)==after_retry)
                check(case,'invalid toast identifies first field',('显示名称' if lang=='zh' else 'Display name').lower() in toast_text(page).lower(),toast_text(page))
                if width==1440:capture(page,name,'invalid')
                check(case,'inline summary is not a duplicate live status',page.locator('#save-status').get_attribute('role')!='status' and page.locator('#save-status').get_attribute('aria-live') not in ['polite','assertive'])
                check(case,'toast uses polite atomic status',page.locator(TOAST).get_attribute('role')=='status' and page.locator(TOAST).get_attribute('aria-live')=='polite' and page.locator(TOAST).get_attribute('aria-atomic')=='true')
                page.locator('#cancel-settings').click()
                check(case,'existing Cancel restores stored version',page.locator('#business-name').input_value()==failed and page.locator('#email').input_value()==after_retry['settings']['email'])
                page.reload(wait_until='networkidle')
                check(case,'saved data survives reload',page.locator('#business-name').input_value()==failed and storage(page)==after_retry)
                check(case,'no page JavaScript errors',not case['page_errors'],case['page_errors'])
                case['status']='pass'
            except Exception as e:
                case['status']='fail';case['failure']=str(e);case['traceback']=traceback.format_exc()
                capture(page,name,'failed-check')
            finally:
                try:case['events']=page.evaluate('window.audit || []')
                except:pass
                if width==1440:case['video']=str(page.video.path().relative_to(ROOT))
                context.close()
                (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
                print(json.dumps({'case':name,'status':case['status'],'failure':case.get('failure'),'checks':len(case['checks'])},ensure_ascii=False),flush=True)

    # Contract stress: an older asynchronous failure must not replace a newer invalid result.
    c=browser.new_context(viewport={'width':1440,'height':900})
    pg=c.new_page();stress={'name':'stale-operation-and-dismiss-pending','checks':[]};report['cases'].append(stress)
    try:
        pg.goto(BASE+'?theme=light&lang=en',wait_until='networkidle')
        pg.evaluate('''()=>{fieldnotes.setFailureMode(true);const old=fieldnotes.draft();fieldnotes.saveSettings(old).catch(()=>{});fieldnotes.saveSettings({...old,displayName:''}).catch(()=>{});}''')
        state(pg,'invalid')
        invalid=toast_text(pg)
        pg.wait_for_timeout(900)
        check(stress,'old failed event cannot replace newer invalid feedback',pg.locator('#save-status').get_attribute('data-state')=='invalid' and toast_text(pg)==invalid,toast_text(pg))
        pg.locator('#business-name').fill('Dismiss pending verification')
        pg.locator('#save-settings').click()
        state(pg,'pending')
        pg.locator(TOAST+' .btn-close').click()
        state(pg,'success')
        check(stress,'dismissing pending does not cancel persistence',storage(pg)['settings']['displayName']=='Dismiss pending verification',storage(pg))
        check(stress,'next authoritative result returns feedback',pg.locator(TOAST).is_visible())
        stress['status']='pass'
    except Exception as e:stress.update(status='fail',failure=str(e),traceback=traceback.format_exc());capture(pg,'stress','failure')
    c.close()
    print(json.dumps(stress,ensure_ascii=False),flush=True)
    browser.close()

report['protected_store_sha256']=hashlib.sha256((ROOT/'app/settings-store.js').read_bytes()).hexdigest()
report['pass']=all(c['status']=='pass' for c in report['cases']) and report['protected_store_sha256']=='32139de23b4ad411c402620e84d5592f7ccfbcf68cece1a123946c29b63c2da0'
(OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'pass':report['pass'],'report':str(OUT/'report.json'),'capture_count':len(report['captures'])},ensure_ascii=False))
raise SystemExit(0 if report['pass'] else 1)

