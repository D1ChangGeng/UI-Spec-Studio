from pathlib import Path
import json,time
from playwright.sync_api import sync_playwright,expect
R=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w17')
O=R/'evidence/neighbors';O.mkdir(exist_ok=True)
out={'header':[],'mobile_save':[],'reduced_motion':{}}
hit='''el=>{const r=el.getBoundingClientRect();const x=r.x+r.width/2,y=r.y+r.height/2;const top=document.elementFromPoint(x,y);return {rect:{x:r.x,y:r.y,width:r.width,height:r.height},center_reachable:el.contains(top),top_tag:top?.tagName,top_id:top?.id,top_class:top?.className}}'''
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 for width,height in [(1440,900),(1280,600),(390,844)]:
  c=b.new_context(viewport={'width':width,'height':height});g=c.new_page()
  g.goto('http://127.0.0.1:4417/?theme=light&lang=en&fail=once',wait_until='networkidle')
  g.locator('#save-settings').click()
  g.wait_for_function("document.querySelector('#save-notification').dataset.state==='error' && !document.querySelector('#save-notification').classList.contains('showing')")
  g.evaluate("scrollTo({top:0,behavior:'instant'})")
  buttons=g.locator('header a,header button').all()
  vals=[]
  for el in buttons:
   if el.is_visible():
    rect=el.bounding_box()
    if rect and rect['y']>=0 and rect['y']+rect['height']<=112:
     vals.append({'label':(el.get_attribute('aria-label') or el.inner_text()).strip(),'hit':el.evaluate(hit)})
  before=[x for x in vals if not x['hit']['center_reachable']]
  close=g.locator('#save-notification-close').evaluate(hit)
  g.locator('#save-notification-close').click();expect(g.locator('#save-notification')).to_be_hidden()
  g.evaluate("scrollTo({top:0,behavior:'instant'})")
  after=[]
  for el in g.locator('header a,header button').all():
   if el.is_visible():
    rect=el.bounding_box()
    if rect and rect['y']>=0 and rect['y']+rect['height']<=112:
     result=el.evaluate(hit)
     if not result['center_reachable']:after.append({'label':(el.get_attribute('aria-label') or el.inner_text()).strip(),'hit':result})
  out['header'].append({'viewport':[width,height],'occluded_while_toast_visible':before,'occluded_after_dismissal':after,'close':close})
  assert close['center_reachable'] and not after
  c.close()
 for lang,theme in [('en','light'),('zh','dark')]:
  for subject in ['baseline','integrated']:
   c=b.new_context(viewport={'width':390,'height':844});g=c.new_page()
   if subject=='baseline':
    g.route('**/baseline-neighbors.html*',lambda route:route.fulfill(path=str(R/'evidence/source/baseline-index.html'),content_type='text/html'))
    g.route('**/settings-controller.js',lambda route:route.fulfill(path=str(R/'evidence/source/baseline-settings-controller.js'),content_type='application/javascript'))
   path='baseline-neighbors.html' if subject=='baseline' else ''
   g.goto(f'http://127.0.0.1:4417/{path}?theme={theme}&lang={lang}',wait_until='networkidle')
   g.locator('#save-settings').evaluate("el=>el.scrollIntoView({block:'end',behavior:'instant'})")
   sample=g.locator('#save-settings').evaluate('''el=>{const r=el.getBoundingClientRect();return {rect:{x:r.x,y:r.y,width:r.width,height:r.height},center:el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2)),right_top:el.contains(document.elementFromPoint(r.right-5,r.y+5)),covering_element:document.elementFromPoint(r.right-5,r.y+5)?.outerHTML}}''')
   capture=O/f'{subject}-{lang}-save-edge.png';g.screenshot(path=str(capture))
   out['mobile_save'].append({'subject':subject,'lang':lang,'theme':theme,'capture':str(capture.relative_to(R)),'hit':sample,'scrollY':g.evaluate('scrollY')})
   assert sample['center']
   c.close()
 c=b.new_context(viewport={'width':1440,'height':900},reduced_motion='reduce');g=c.new_page()
 g.goto('http://127.0.0.1:4417/?theme=dark&lang=zh&fail=once',wait_until='networkidle')
 g.locator('#save-settings').click()
 g.wait_for_function("document.querySelector('#save-notification').dataset.state==='pending'")
 duration=g.locator('#save-notification').evaluate("el=>getComputedStyle(el).transitionDuration")
 g.wait_for_function("document.querySelector('#save-notification').dataset.state==='error'")
 g.locator('#retry-save').focus();g.keyboard.press('Enter')
 g.wait_for_function("document.querySelector('#save-notification').dataset.state==='success'")
 g.evaluate("scrollTo({top:0,behavior:'instant'})")
 g.screenshot(path=str(O/'reduced-motion-success.png'))
 out['reduced_motion']={'media':g.evaluate("matchMedia('(prefers-reduced-motion: reduce)').matches"),'toast_transition_duration':duration,'actual_result':g.locator('#save-notification-message').inner_text(),'saved':g.evaluate("JSON.parse(localStorage.getItem('fieldnotes-settings-v1'))"),'capture':'evidence/neighbors/reduced-motion-success.png'}
 assert duration=='0s'
 c.close();b.close()
(R/'evidence/neighbors/results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps(out,ensure_ascii=False,indent=2))

