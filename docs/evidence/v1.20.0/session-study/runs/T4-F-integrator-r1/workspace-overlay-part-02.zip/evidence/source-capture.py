from pathlib import Path
import json, time
from playwright.sync_api import sync_playwright
root=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w17')
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
    log=[]
    for name,url in [('source','http://127.0.0.1:4417/toast-source-preview.html'),('baseline','http://127.0.0.1:4417/?theme=light&lang=en')]:
        page.goto(url,wait_until='networkidle');page.evaluate('document.fonts.ready')
        path=root/'evidence/captures'/f'{name}-1440.png'
        page.screenshot(path=str(path))
        log.append({'name':name,'url':url,'capture':str(path),'timestamp':time.time(),'viewport':page.viewport_size})
    print(json.dumps(log,indent=2))
    browser.close()
