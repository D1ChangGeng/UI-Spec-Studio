from pathlib import Path
import subprocess,os,signal,json,time,urllib.request,urllib.error
expected=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w17/app')
result=subprocess.run(['pgrep','-f','^python3 -m http.server 4417 --bind 127.0.0.1$'],capture_output=True,text=True)
stopped=[]
for value in result.stdout.split():
 pid=int(value)
 cwd=Path(f'/proc/{pid}/cwd').resolve()
 if cwd!=expected:raise RuntimeError(f'Refusing to stop different cwd: {cwd}')
 os.kill(pid,signal.SIGTERM);stopped.append(pid)
time.sleep(.1)
try:
 urllib.request.urlopen('http://127.0.0.1:4417/',timeout=1)
 reachable=True
except (urllib.error.URLError,TimeoutError):reachable=False
print(json.dumps({'command':'python3 -m http.server 4417 --bind 127.0.0.1','cwd':str(expected),'stopped_pids':stopped,'preview_reachable_after_stop':reachable},indent=2))
assert stopped and not reachable

