# Fieldnotes save feedback — current design model

## Scope and authority

Complete the settled `INTEGRATION-DECISION.md` in the existing Tabler settings application. The source, placement, themes and languages are fixed. This is one bounded finish increment: preserve the action-toast shell while connecting authoritative save events, error recovery and keyboard continuity. No original visual construction, source reselection or changed persistence policy is authorized.

## Evidence and implementation boundaries

- Source acquisition: exact supplied deployed HTML/block digests and tagged revision remain distinct in `SOURCE-MANIFEST.json`.
- Source observation: read the acquired cookie block and original Astro component; source rendering will be inspected separately from product captures.
- Product ownership: store owns validation and local writes; controller owns current draft; adapter renders current authoritative events and explicitly retries the failed snapshot.
- L0/L1: edit profile → submit → authoritative pending/result → recover or continue editing.
- L2/L3: fixed native toast at top/end; existing summary and fields remain in the form; neighboring header and save controls need contextual review.
- L4: preserve source width, header/body/footer, native type, padding, border, shadow, close and fade. Use initials FN and Fieldnotes identity.
- L5: real local storage readback, deterministic failure, keyboard paths, viewport captures and protected-source digests.

## Current questions and actions

Inspect the selected source render before modification. Then implement only the allowed HTML/controller/adapter files. Verify pending edits, saved snapshot, retry of the failed snapshot, validation associations, announcement ownership, stale event rejection and focus return. Personally inspect all required 1440×900, 1280×600 and 390×844 light/en and dark/zh conditions.

## Current guidance applicability

The required modern-web-guidance search and full toast/forms guides are retained in `evidence/commands/001` and `002`. The general toast guide recommends the Popover API; the explicit settled task requires the existing bundled Bootstrap Toast and its native close/transition, so that task-specific decision governs. Form associations, meaningful labels, retained focus and pending protection apply. The source store remains the validation authority; no parallel validation policy is introduced.

## Coordination

This is the main-only arm specified by `ALLOCATION.md`. No child agent is used. Final design responsibility and actual assembled-product inspection remain with this agent. Native model identity, token totals and billed cost are not exposed by this host.

## Delivered result and evidence

The settled integration operates in `app/index.html`, `app/settings-controller.js` and `app/save-notification.js`; no dependency or mature asset changes were required. The source shell and native Bootstrap Toast lifecycle are retained. The controller coordinates draft, field errors and the non-live summary; the adapter owns feedback and explicit failed-snapshot retry.

`evidence/behavior-002.json` contains 126 passing assertions and six event records. `evidence/source-comparison-settled.json` records matched native styles after equivalent activation and settlement. `VISUAL-REVIEW.md` records the personally opened source and integrated images, scope-specific visual findings and temporal limits. `evidence/integration.diff` records the bounded product change. `FINAL.md` is the handover.

Observed placement tradeoff: the fixed upper toast obscures part of the upstream utility header, particularly at 390 px, until dismissed. Close remains reachable and lower settings actions remain available. The explicit placement was preserved. No open source-selection or original-design responsibility was created.

Rework was limited to one Playwright harness argument correction and improved capture/comparison conditions. The first command failure and initial non-equivalent style samples remain archived. No product repair, child integration or merge conflict was involved. Command durations are exposed in the actual capture records; total agent cost and any comparison against another allocation remain unknown here.
