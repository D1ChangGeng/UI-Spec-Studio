import { readSettings, saveSettings, subscribeSettings, setFailureMode } from './settings-store.js';
import { createSaveNotification } from './save-notification.js';

const ids = {displayName:'business-name',organization:'business-id',location:'location',email:'email',weeklyDigest:'weekly-digest',publicProfile:'public-profile'};
const status = document.querySelector('#save-status');
const save = document.querySelector('#save-settings');
const params = new URLSearchParams(location.search);
const zh = params.get('lang') === 'zh';
const copy = zh ? {
  idle:'更改仅保存在当前浏览器中。', pending:'本次提交正在保存。', success:'当前表单与已保存版本一致。',
  newer:'后续编辑尚未保存。', error:'更改尚未保存。', invalid:'请修正标记的字段。', dirty:'有尚未保存的更改。'
} : {
  idle:'Changes are saved only in this browser.', pending:'Submitted version in progress.', success:'The form matches the saved version.',
  newer:'Your newer edits have not been saved.', error:'Changes remain unsaved.', invalid:'Correct the highlighted fields.', dirty:'You have unsaved changes.'
};
const errorTranslations = {
  'Add a display name.':'请填写显示名称。',
  'Use 100 characters or fewer.':'请使用不超过 100 个字符。',
  'Use 180 characters or fewer.':'请使用不超过 180 个字符。',
  'Enter a complete email address.':'请输入完整的电子邮箱地址。'
};
const fieldError = message => zh ? (errorTranslations[message] || message) : message;
const fieldLabel = key => document.querySelector('label[for="' + ids[key] + '"]').textContent.trim();
let latestOperation = 0;
let pending = false;
let userSubmit = false;
let savedSettings;

function draft() {
  return Object.fromEntries(Object.entries(ids).map(([key,id])=>{
    const el=document.getElementById(id);
    return [key,el.type==='checkbox'?el.checked:el.value];
  }));
}
function sameDraft(data) {
  return data && Object.entries(draft()).every(([key,value])=>data[key]===value);
}
function clearError(key) {
  const el=document.getElementById(ids[key]);
  el.classList.remove('is-invalid');
  el.removeAttribute('aria-invalid');
  const errorId=ids[key]+'-error';
  const descriptions=(el.getAttribute('aria-describedby') || '').split(' ').filter(id=>id && id!==errorId);
  if(descriptions.length) el.setAttribute('aria-describedby',descriptions.join(' '));
  else el.removeAttribute('aria-describedby');
  document.getElementById(errorId)?.remove();
}
function clearErrors() { Object.keys(ids).forEach(clearError); }
function showErrors(errors) {
  clearErrors();
  for(const [key,message] of Object.entries(errors)) {
    const el=document.getElementById(ids[key]);
    const feedback=document.createElement('div');
    feedback.id=ids[key]+'-error';
    feedback.className='invalid-feedback';
    feedback.textContent=fieldError(message);
    el.after(feedback);
    el.classList.add('is-invalid');
    el.setAttribute('aria-invalid','true');
    el.setAttribute('aria-describedby',[el.getAttribute('aria-describedby'),feedback.id].filter(Boolean).join(' '));
  }
  const first=Object.keys(errors)[0];
  if(userSubmit && first && document.activeElement!==document.getElementById(ids[first])) document.getElementById(ids[first]).focus();
}
function load() {
  const data=readSettings();
  savedSettings=data;
  for(const [key,id] of Object.entries(ids)) {
    const el=document.getElementById(id);
    if(el.type==='checkbox') el.checked=data[key]; else el.value=data[key];
  }
}
function submit(snapshot) {
  userSubmit=true;
  const operation=saveSettings(snapshot);
  userSubmit=false;
  return operation.catch(()=>{});
}
const notification=createSaveNotification({
  saveSnapshot:submit, zh, fieldLabel, fieldError, fallbackFocus:()=>save
});
try { load(); status.textContent=copy.idle; } catch(error) { status.textContent=error.message; }
subscribeSettings(event=>{
  if(event.operationId<latestOperation) return;
  latestOperation=event.operationId;
  pending=event.status==='pending';
  // A native disabled button loses keyboard focus; Tabler's existing disabled
  // presentation plus aria-disabled retains focus while the handler blocks repeats.
  save.classList.toggle('disabled',pending);
  save.setAttribute('aria-disabled',String(pending));
  save.setAttribute('aria-busy',String(pending));
  if(event.status==='success') savedSettings=event.settings;
  status.textContent=event.status==='success' && !sameDraft(event.settings) ? copy.newer : (copy[event.status] || copy.idle);
  status.dataset.state=event.status;
  notification.render(event);
  if(event.status==='invalid') showErrors(event.fieldErrors);
  else if(event.status==='pending') clearErrors();
});
save.addEventListener('click',()=>{
  if(!pending) void submit(draft());
});
for(const [key,id] of Object.entries(ids)) {
  document.getElementById(id).addEventListener('input',()=>{
    clearError(key);
    status.textContent=pending ? copy.newer : (sameDraft(savedSettings)?copy.idle:copy.dirty);
  });
}
document.querySelector('#cancel-settings').addEventListener('click',()=>{
  try { load(); clearErrors(); status.textContent=pending?copy.pending:copy.idle; }
  catch(error) { status.textContent=error.message; }
});
document.querySelector('#focus-email').addEventListener('click',()=>document.querySelector('#email').focus());
document.querySelector('#language-toggle').addEventListener('click',()=>{params.set('lang',zh?'en':'zh');location.search=params.toString();});
document.querySelector('#theme-toggle').addEventListener('click',()=>{const dark=document.documentElement.getAttribute('data-bs-theme')==='dark';document.documentElement.setAttribute('data-bs-theme',dark?'light':'dark');localStorage.setItem('tabler-theme',dark?'light':'dark');});
window.fieldnotes = { readSettings, saveSettings, setFailureMode, draft };
if (zh) {
  document.documentElement.lang='zh-CN';
  const dictionary={
    'Account Settings':'账户设置','My Account':'我的账户','Profile Details':'个人资料','Business Profile':'工作资料','Display name':'显示名称','Organization':'机构','Location':'地点','Email':'电子邮件','Edit email':'编辑邮箱','Notifications':'通知','My Notifications':'我的通知','Privacy':'隐私','Public profile':'公开个人资料','Save changes':'保存更改','Cancel':'取消','Switch theme':'切换主题','Business settings':'工作设置',
    'Receive a weekly digest of research notes shared with your workspace.':'每周接收工作区共享研究笔记的摘要。',
    'Weekly digest is enabled':'已开启每周摘要','Weekly digest is disabled':'已关闭每周摘要',
    'Allow other members of this research workspace to find your profile. Your email remains private.':'允许研究工作区的其他成员找到你的个人资料。电子邮箱仍为私密信息。',
    "You're currently visible":'当前可见',"You're currently invisible":'当前不可见',
    'This contact will be shown to others publicly, so choose it carefully.':'此邮箱用于工作区通知，不会显示在公开个人资料中。'
  };
  const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
  while(walker.nextNode()){const node=walker.currentNode;const source=node.textContent.trim();if(dictionary[source])node.textContent=node.textContent.replace(source,dictionary[source]);}
} else {
  for(const el of document.querySelectorAll('.card-subtitle')) if(el.textContent.trim()==='This contact will be shown to others publicly, so choose it carefully.') el.textContent='This email receives workspace notifications and stays private.';
}
