import json,time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
out=ROOT/'evidence'
log={'captures':[],'sourceComparison':[],'notes':'Native animations enabled; final static views wait for settlement. Episode frames use natural browser time and retain capture brackets; no playback or frame-rate claim.'}
def capture(page,name):
    before=page.evaluate('performance.now()')
    path=out/'captures'/f'{name}.png'
    page.screenshot(path=str(path),animations='allow')
    facts=page.evaluate('''()=>({time:performance.now(),scrollY,active:document.activeElement.id,state:document.querySelector('#save-notification')?.dataset.state,timeZone:Intl.DateTimeFormat().resolvedOptions().timeZone,viewport:[innerWidth,innerHeight],toast:(()=>{const e=document.querySelector('#save-notification');if(!e)return null;const r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,opacity:getComputedStyle(e).opacity}})()})''')
    log['captures'].append({'file':str(path.relative_to(ROOT)),'captureBracketMs':[before,facts['time']],'wallTime':time.time(),'facts':facts})
def metrics(page,selector):
    return page.locator(selector).evaluate('''e=>{let result={};for(const [name,el] of [['toast',e],['header',e.querySelector('.toast-header')],['body',e.querySelector('.toast-body')],['action',e.querySelector('.mt-2')],['button',e.querySelector('.btn-sm')],['close',e.querySelector('.btn-close')]]){let s=getComputedStyle(el);result[name]=Object.fromEntries(['fontFamily','fontSize','lineHeight','fontWeight','padding','marginTop','border','borderRadius','boxShadow','backgroundColor','color','transitionDuration'].map(k=>[k,s[k]]));}return result}''')
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
    for w,h in [(1440,900),(1280,600),(390,844)]:
      for theme,lang in [('light','en'),('dark','zh')]:
        key=f'{theme}-{lang}-{w}'
        context=b.new_context(viewport={'width':w,'height':h},device_scale_factor=1)
        page=context.new_page()
        page.goto(f'http://127.0.0.1:4416/?theme={theme}&lang={lang}&fail=once',wait_until='networkidle')
        page.evaluate('document.fonts.ready')
        page.locator('#save-settings').click()
        page.wait_for_function('document.querySelector("#save-notification").dataset.state==="error"')
        page.evaluate('window.scrollTo({top:0,behavior:"instant"})')
        page.wait_for_timeout(200)
        capture(page,'final-error-top-'+key)
        integrated=metrics(page,'#save-notification')
        page.evaluate('window.scrollTo({top:document.documentElement.scrollHeight,behavior:"instant"})')
        page.wait_for_timeout(100)
        capture(page,'final-error-lower-'+key)
        if w==390:
          page.locator('#business-name').fill('')
          page.locator('#save-settings').focus()
          page.keyboard.press('Enter')
          page.wait_for_timeout(250)
          capture(page,'final-invalid-'+key)
        source=context.new_page()
        source.goto('http://127.0.0.1:4416/toast-source-preview.html',wait_until='networkidle')
        source.evaluate('(theme)=>document.documentElement.setAttribute("data-bs-theme",theme)',theme)
        origin=metrics(source,'#toast-cookies')
        # Native toast show adds its source fade class; source-preview is already shown.
        diffs={f'{part}.{prop}':{'source':value,'integrated':integrated[part][prop]} for part,props in origin.items() for prop,value in props.items() if value!=integrated[part][prop]}
        log['sourceComparison'].append({'condition':key,'source':origin,'integrated':integrated,'differences':diffs})
        context.close()
    context=b.new_context(viewport={'width':1280,'height':600})
    page=context.new_page()
    page.goto('http://127.0.0.1:4416/?theme=light&lang=en&fail=once',wait_until='networkidle')
    page.locator('#save-settings').focus()
    capture(page,'episode-00-before-save')
    start=page.evaluate('performance.now()')
    page.keyboard.press('Enter')
    capture(page,'episode-01-pending-entry')
    page.wait_for_timeout(160)
    capture(page,'episode-02-pending-settled')
    page.wait_for_function('document.querySelector("#save-notification").dataset.state==="error"')
    capture(page,'episode-03-error')
    page.locator('#retry-save').focus()
    page.keyboard.press('Enter')
    capture(page,'episode-04-retry-pending')
    page.wait_for_function('document.querySelector("#save-notification").dataset.state==="success"')
    capture(page,'episode-05-success')
    page.locator('#save-notification [data-bs-dismiss="toast"]').focus()
    page.keyboard.press('Enter')
    capture(page,'episode-06-native-dismiss')
    page.wait_for_timeout(250)
    capture(page,'episode-07-return')
    log['episodeStartPerformanceMs']=start
    context.close()
    b.close()
(out/'final-capture-log.json').write_text(json.dumps(log,ensure_ascii=False,indent=2))
print(json.dumps({'captures':len(log['captures']),'sourceComparisonDifferences':[{ 'condition':c['condition'],'differences':c['differences']} for c in log['sourceComparison']]},indent=2))

