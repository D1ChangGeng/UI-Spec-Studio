import json, time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
out=ROOT/'evidence'
records=[]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
    for theme in ['light','dark']:
        page.goto('http://127.0.0.1:4416/toast-source-preview.html',wait_until='networkidle')
        page.evaluate('(theme)=>document.documentElement.setAttribute("data-bs-theme",theme)',theme)
        page.evaluate('document.fonts.ready')
        file=out/'captures'/f'source-local-{theme}-1440.png'
        page.screenshot(path=str(file))
        records.append({'subject':'provided local rendering of acquired action toast','theme':theme,'viewport':[1440,900],'path':str(file),'timestamp':time.time(),'metrics':page.locator('#toast-cookies').evaluate('(el)=>{const s=getComputedStyle(el);return {width:el.getBoundingClientRect().width,font:s.font,padding:s.padding,shadow:s.boxShadow,border:s.border,transition:s.transition}}')})
    page.goto('http://127.0.0.1:4416/?theme=light&lang=en',wait_until='networkidle')
    page.evaluate('document.fonts.ready')
    page.screenshot(path=str(out/'captures'/'baseline-light-en-1440.png'))
    records.append({'subject':'unmodified integrated settings baseline','viewport':[1440,900],'path':'evidence/captures/baseline-light-en-1440.png','timestamp':time.time()})
    browser.close()
(out/'source-observations.json').write_text(json.dumps(records,indent=2))
print(json.dumps(records,indent=2))

