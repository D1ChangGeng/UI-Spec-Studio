import json
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
metric='''e=>{let result={};for(const [name,el] of [['toast',e],['header',e.querySelector('.toast-header')],['body',e.querySelector('.toast-body')],['action',e.querySelector('.mt-2')],['button',e.querySelector('.btn-sm')],['close',e.querySelector('.btn-close')]]){let s=getComputedStyle(el);result[name]=Object.fromEntries(['fontFamily','fontSize','lineHeight','fontWeight','padding','marginTop','border','borderRadius','boxShadow','backgroundColor','color','transitionDuration'].map(k=>[k,s[k]]));}return result}'''
result=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 for theme,lang in [('light','en'),('dark','zh')]:
  c=b.new_context(viewport={'width':1440,'height':900})
  page=c.new_page()
  page.goto(f'http://127.0.0.1:4416/?theme={theme}&lang={lang}&fail=once',wait_until='networkidle')
  page.locator('#save-settings').click()
  page.wait_for_function('document.querySelector("#save-notification").dataset.state==="error"')
  page.wait_for_timeout(350)
  actual=page.locator('#save-notification').evaluate(metric)
  source=c.new_page()
  source.goto('http://127.0.0.1:4416/toast-source-preview.html',wait_until='networkidle')
  source.evaluate('(theme)=>document.documentElement.setAttribute("data-bs-theme",theme)',theme)
  source.locator('#toast-cookies [data-bs-dismiss="toast"]').first.click()
  source.wait_for_timeout(350)
  source.evaluate('window.tabler.Toast.getOrCreateInstance(document.querySelector("#toast-cookies")).show()')
  source.wait_for_timeout(450)
  original=source.locator('#toast-cookies').evaluate(metric)
  differences={f'{part}.{prop}':{'source':value,'integrated':actual[part][prop]} for part,props in original.items() for prop,value in props.items() if value!=actual[part][prop]}
  result.append({'theme':theme,'source':original,'integrated':actual,'differences':differences,'condition':'Native Toast activated on both pages; all theme/fade transitions settled before sampling.'})
  c.close()
 b.close()
(ROOT/'evidence/source-comparison-settled.json').write_text(json.dumps(result,indent=2))
print(json.dumps([{'theme':r['theme'],'differences':r['differences']} for r in result],indent=2))

