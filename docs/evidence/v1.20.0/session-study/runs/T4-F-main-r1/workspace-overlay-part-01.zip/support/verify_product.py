import json,time,traceback,hashlib,sys
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence'
RUN=sys.argv[1] if len(sys.argv)>1 else '002'
LOG={'checks':[],'captures':[],'errors':[],'conditions':{'browser':'Chromium 143 headless shell','deviceScaleFactor':1,'fontconfig':'/tmp/ui-spec-fonts/fonts.conf','animation':'native, enabled','time':'natural browser time; screenshots impose capture overhead'}}
def check(name, value, detail=None):
    LOG['checks'].append({'name':name,'pass':bool(value),'detail':detail})
    assert value, (name,detail)
def state(page, expected):
    page.wait_for_function('(state)=>document.querySelector("#save-notification").dataset.state===state',arg=expected)
def snap(page,name):
    before=page.evaluate('performance.now()')
    path=OUT/'captures'/f'{RUN}-{name}.png'
    page.screenshot(path=str(path),animations='allow')
    facts=page.evaluate('''()=>({time:performance.now(),scroll:[scrollX,scrollY],active:document.activeElement.id,theme:document.documentElement.dataset.bsTheme,lang:document.documentElement.lang,state:document.querySelector('#save-notification').dataset.state,toast:(()=>{const e=document.querySelector('#save-notification'),s=getComputedStyle(e),r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,border:s.border,shadow:s.boxShadow,fontSize:s.fontSize,bodyPadding:getComputedStyle(e.querySelector('.toast-body')).padding}})(),viewport:[innerWidth,innerHeight],scrollWidth:document.documentElement.scrollWidth})''')
    LOG['captures'].append({'file':str(path.relative_to(ROOT)),'wallTime':time.time(),'captureBracketMs':[before,facts['time']],'facts':facts})
def saved(page):
    return page.evaluate('JSON.parse(localStorage.getItem("fieldnotes-settings-v1"))')
def keyboard_save(page):
    page.locator('#save-settings').focus()
    page.keyboard.press('Enter')
def run():
  with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
    for w,h in [(1440,900),(1280,600),(390,844)]:
      for theme,lang in [('light','en'),('dark','zh')]:
        key=f'{theme}-{lang}-{w}'
        context=browser.new_context(viewport={'width':w,'height':h},device_scale_factor=1)
        page=context.new_page()
        page.on('pageerror',lambda err:LOG['errors'].append(str(err)))
        page.goto(f'http://127.0.0.1:4416/?theme={theme}&lang={lang}',wait_until='networkidle')
        page.evaluate('document.fonts.ready')
        page.evaluate('''async()=>{const store=await import('./settings-store.js');window.observedEvents=[];store.subscribeSettings(e=>window.observedEvents.push({status:e.status,id:e.operationId,time:performance.now()}));}''')
        check(key+' loaded',page.evaluate('!!window.fieldnotes'))
        snap(page,'integrated-idle-'+key)
        page.locator('#business-name').fill('Submitted A / 提交 A')
        keyboard_save(page)
        state(page,'pending')
        page.keyboard.press('Enter')
        check(key+' pending prevents repeat',page.evaluate('window.observedEvents.filter(e=>e.status==="pending").length')==1)
        check(key+' save focus retained',page.evaluate('document.activeElement.id')=='save-settings')
        page.locator('#business-name').fill('Newer draft / 后续编辑')
        snap(page,'integrated-pending-'+key)
        state(page,'success')
        check(key+' writes submitted snapshot',saved(page)['settings']['displayName']=='Submitted A / 提交 A')
        check(key+' preserves pending edits',page.locator('#business-name').input_value()=='Newer draft / 后续编辑')
        check(key+' success preserves field focus',page.evaluate('document.activeElement.id')=='business-name')
        check(key+' single live result path',page.locator('#save-status').get_attribute('role') is None and page.locator('#save-notification').get_attribute('aria-live')=='polite')
        page.evaluate('window.scrollTo(0,0)')
        snap(page,'integrated-success-'+key)
        before=saved(page)
        page.evaluate('window.fieldnotes.setFailureMode(true)')
        page.locator('#business-name').fill('Failed B / 失败 B')
        keyboard_save(page)
        state(page,'pending')
        page.locator('#business-name').fill('Later C / 后来的 C')
        state(page,'error')
        check(key+' failed write preserves stored value',saved(page)==before)
        check(key+' failed write preserves current draft',page.locator('#business-name').input_value()=='Later C / 后来的 C')
        page.evaluate('window.scrollTo(0,0)')
        snap(page,'integrated-error-'+key)
        page.locator('#save-settings').scroll_into_view_if_needed()
        snap(page,'integrated-error-lower-'+key)
        page.locator('#retry-save').focus()
        page.keyboard.press('Enter')
        state(page,'pending')
        check(key+' retry focus returns',page.evaluate('document.activeElement.id')!='retry-save')
        state(page,'success')
        check(key+' retry saves failed snapshot',saved(page)['settings']['displayName']=='Failed B / 失败 B')
        check(key+' retry preserves newer draft',page.locator('#business-name').input_value()=='Later C / 后来的 C')
        snap(page,'integrated-retry-success-'+key)
        page.locator('#save-notification [data-bs-dismiss="toast"]').focus()
        page.keyboard.press('Enter')
        page.wait_for_function('!document.querySelector("#save-notification").classList.contains("show")')
        page.wait_for_timeout(250)
        check(key+' close returns outside hidden toast',page.evaluate('!document.querySelector("#save-notification").contains(document.activeElement) && document.activeElement!==document.body'))
        check(key+' close preserves storage',saved(page)['settings']['displayName']=='Failed B / 失败 B')
        page.locator('#business-name').fill('')
        page.locator('#email').fill('incomplete')
        keyboard_save(page)
        state(page,'invalid')
        check(key+' invalid focuses first field',page.evaluate('document.activeElement.id')=='business-name')
        check(key+' field error linked',page.locator('#business-name').get_attribute('aria-describedby')=='business-name-error')
        check(key+' invalid preserves stored value',saved(page)['settings']['displayName']=='Failed B / 失败 B')
        snap(page,'integrated-invalid-'+key)
        page.locator('#business-name').fill('Corrected')
        check(key+' editing clears old field error',page.locator('#business-name').get_attribute('aria-invalid') is None)
        page.locator('#cancel-settings').click()
        check(key+' cancel reloads stored snapshot',page.locator('#business-name').input_value()=='Failed B / 失败 B')
        check(key+' no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
        LOG['checks'].append({'name':key+' real store events','pass':True,'detail':page.evaluate('window.observedEvents')})
        context.close()
    # Closely timed events use the unchanged real store, not manufactured events.
    context=browser.new_context(viewport={'width':1440,'height':900})
    page=context.new_page()
    page.goto('http://127.0.0.1:4416/?theme=light&lang=en&fail=once',wait_until='networkidle')
    page.locator('#business-name').fill('Earlier operation')
    keyboard_save(page)
    page.evaluate('window.fieldnotes.saveSettings({...window.fieldnotes.draft(),displayName:""}).catch(()=>{})')
    state(page,'invalid')
    page.wait_for_timeout(900)
    check('older error cannot replace newer invalid result',page.locator('#save-notification').get_attribute('data-state')=='invalid')
    page.locator('#business-name').fill('Close during pending')
    keyboard_save(page)
    state(page,'pending')
    page.locator('#save-notification [data-bs-dismiss="toast"]').click()
    state(page,'success')
    check('close during pending does not cancel write',saved(page)['settings']['displayName']=='Close during pending')
    page.locator('#save-notification [data-bs-dismiss="toast"]').focus()
    page.keyboard.press('Enter')
    # Another save starts before the native hide transition finishes.
    page.evaluate('window.fieldnotes.saveSettings({...window.fieldnotes.draft(),displayName:"During fade"}).catch(()=>{})')
    state(page,'success')
    page.wait_for_timeout(200)
    check('new event during dismissal remains visible',page.locator('#save-notification').is_visible())
    snap(page,'integrated-dismiss-replace')
    context.close()
    # Native reduced motion and reload persistence check.
    context=browser.new_context(viewport={'width':390,'height':844},reduced_motion='reduce')
    page=context.new_page()
    page.goto('http://127.0.0.1:4416/?theme=dark&lang=zh',wait_until='networkidle')
    page.locator('#business-name').fill('恢复检查')
    keyboard_save(page)
    state(page,'success')
    check('reduced-motion native fade duration',page.locator('#save-notification').evaluate('(el)=>getComputedStyle(el).transitionDuration')=='0s')
    page.reload(wait_until='networkidle')
    check('reload reads real persisted value',page.locator('#business-name').input_value()=='恢复检查')
    context.close()
    browser.close()
    check('no JavaScript exceptions',not LOG['errors'],LOG['errors'])
try:
    run()
    LOG['outcome']='pass'
except Exception as exc:
    LOG['outcome']='fail'
    LOG['exception']=traceback.format_exc()
    raise
finally:
    (OUT/f'behavior-{RUN}.json').write_text(json.dumps(LOG,ensure_ascii=False,indent=2))
    print(json.dumps({'outcome':LOG.get('outcome'),'checks':len(LOG['checks']),'captures':len(LOG['captures']),'errors':LOG['errors'],'exception':LOG.get('exception')},ensure_ascii=False,indent=2))

