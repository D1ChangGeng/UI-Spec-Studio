# W18 — selected Tabler save feedback integration

## Current formal increment

The complete goal is a working browser-local Fieldnotes settings task with truthful save feedback and preserved drafts. This increment inherits the exact source and composition frozen in INTEGRATION-DECISION.md. It connects pending, success, error/retry and invalid states to that source; it does not select a new visual direction. The settings store remains the sole validation and persistence authority.

The acquired resource is Tabler 1.7.1 action-bearing Toast, from the supplied deployed snapshot and tagged Astro source. SOURCE-MANIFEST.json keeps the deployed snapshot identity distinct from tagged commit 07f60c07da13d8ff957a370434b7ef5c86f5ab94. MIT notices remain with app/LICENSE and the adopted block.

## Design and evidence boundaries

- L0/L1: edit, save, continue editing, recover from a failed snapshot, and resume from browser storage.
- L2: preserve the settings page, header/menu, native light/dark system and lower save action.
- L3/L4: preserve the source avatar/title/time/close header, compact body, separated primary small action, native width, spacing, border, shadow and transition. Use the settled top-right utility container.
- L5: inspect source rendering, integrated views and actual event/storage behavior separately. Allowed product edits are index.html, settings-controller.js and optional save-notification.js.

The source has been selected by the supplied decision. Resource reselection and original W1–W3 visual construction are outside this increment. Product writes will stay in the allowed files. No subordinate implementation is used; this narrow integration has a shared controller/adapter focus contract and is being performed directly by the package owner. No additional team is created.

## Questions driving implementation and inspection

1. Does the native toast shell retain readable hierarchy in English/light and Chinese/dark at 1440×900, 1280×600 and 390×844? Capture and personally inspect those conditions.
2. Does feedback follow the latest authoritative operation and keep submitted snapshots distinct from subsequent field edits? Exercise storage reads, failure and retry.
3. Can keyboard users dismiss or retry and return to a sensible live control? Exercise focus, native dismissal and field-error association.
4. Do the header/menu and bottom form actions remain reachable with feedback? Inspect the whole viewport and lower scroll position.

## Current guidance

The modern-web-guidance search and retrieve outputs are preserved in evidence/commands/takeover-001 and takeover-002. The generic guide recommends manual popovers for newly constructed toast systems. This task explicitly requires the supplied Tabler/Bootstrap Toast shell and native dismissal/transition, so that concrete selected contract takes precedence; persistent feedback, explicit dismissal and focus continuity remain applicable. No dependency or independent CSS system is added.

## Initial evidence state

The supplied source code, settings contract and selection decision have been read. Actual rendered source inspection and integrated verification are next; no visual pass or owner aesthetic acceptance is claimed here. All eight common ui-spec references, integration, evidence-map and evidence-actions have been read in this execution. Environment-status tooling and /etc/codex/network-policy.json were unavailable; the declared host escalation path is used for this authorized package and local browser sockets.

## Revision — invalid-field visibility repair

A later keyboard inspection found a real failure after the first functional matrix: at 390×844 the first invalid field had focus but sat at y=0 beneath the toast (evidence/keyboard-final-02, command takeover-013). This invalidated the narrow visible-focus claim. The controller now centers the recovery field with native scrollIntoView and focuses it with preventScroll. This is a bounded focus/scroll repair inside the allowed controller; the selected toast source, placement, CSS and motion are unchanged. Retain the original failure and recheck all affected viewport/theme conditions before accepting the repair.

## Completion and retained source

The visible-focus repair passed in all six declared conditions (command takeover-015). Actual Tab navigation reached the toast controls; native close returned to Save. The package owner personally viewed the six repaired invalid states and restored narrow headers. The remaining mandated header-overlap tradeoff is recorded in VISUAL-REVIEW.md and FINAL.md. The three supplied HTML/block digests match the manifest; 35 protected source/asset files and final module syntax were freshly verified in takeover-016. The exact diff is evidence/product-changes.diff.

The direct integration required no package-child merge and one product behavior repair. Original failed command outputs, their corrections and actual view_image responses remain available. No comparative productivity, unseen playback, real screen-reader or owner-acceptance claim is made.
