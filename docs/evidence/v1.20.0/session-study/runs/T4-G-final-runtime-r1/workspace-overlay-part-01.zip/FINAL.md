# W18 — Tabler save-feedback integration completed

The Fieldnotes settings application now uses the selected Tabler action-bearing Toast for real browser-local save feedback. Pending, success, failure/retry and validation states are connected to the existing authoritative store. The implementation and final visual review are complete within the supplied scope and tested conditions.

## Run the product

From `/workspace/scratch/708e8b7f118e/ui-study/worksets/w18/app`:

```bash
python3 -m http.server 4418 --bind 127.0.0.1
```

Open [the light/English application](http://127.0.0.1:4418/?theme=light&lang=en) or [the dark/Chinese application](http://127.0.0.1:4418/?theme=dark&lang=zh). Add `&fail=once` on a new load to exercise the forced failure, or call `window.fieldnotes.setFailureMode(true)` before saving. No build or install is required. The inspection server is stopped at handover; the application remains runnable with this command.

## What changed

| Product file | Bounded change | Diff |
|---|---|---|
| `app/index.html` | Adopted the exact native toast shell in the prescribed utility container; kept the inline summary quiet to avoid a second live announcement | +19 / −1 lines |
| `app/settings-controller.js` | Coordinates authoritative events, pending controls, field errors, draft-aware summary and visible focus recovery | +68 / −4 lines |
| `app/save-notification.js` | New adapter for native Toast rendering, localized feedback, exact-snapshot retry, stale-event protection and dismissal focus | +69 lines |

No dependency or custom CSS rule was added. The store, source preview and 35 tracked protected source/asset files remain byte-identical. The existing MIT license and adopted-block attribution are retained. The exact final comparison is in [product-changes.diff](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w18/evidence/product-changes.diff).

Success wording follows an actual successful storage write and displays its saved time. Failure preserves both the previous stored value and current form edits. Retry saves the failed submission's snapshot, while a later draft remains in the fields. Toast completion does not steal form focus. Close dismisses only the feedback, and a later authoritative event can replace it. Validation uses the store's actual errors and names the first invalid field in both languages.

## Verification and the repair it prompted

The six required conditions—1440×900, 1280×600 and 390×844, each in light/English and dark/Chinese—passed 180 assertions covering save, pending edits, success, forced failure, retry, validation, close, storage readback, reload, theme controls, announcements and containment. A supplemental sequence verified that an older error cannot replace a newer invalid result and that dismissing pending feedback does not cancel the write.

A later independent keyboard/visual check exposed a real issue missed by DOM-focus assertions: on a narrow screen the first invalid field could be focused at y=0 behind the toast. I repaired only the controller's recovery scrolling. All six conditions then passed fresh Tab traversal, dismissal return, invalid-field visibility and header-return checks, and I personally opened the repaired screenshots. The field now appears visibly centered below the toast. See [the failed observation](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w18/evidence/keyboard-final-02/light-en-settled-invalid.png) and [the repaired narrow view](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w18/evidence/keyboard-final-03/390x844-light-en-settled-invalid.png).

The corrected storage-exception probe confirms that an actual thrown storage write preserves the previous value, and retry succeeds after storage is restored without overwriting newer form edits. Persistent feedback remained visible beyond the native default timeout. Final JavaScript syntax and source digests passed.

Original command failures are retained. The first broad command ended with a supplemental test-harness error after its six matrix cases had passed; the corrected probe is separate. A premature evidence-packaging attempt also failed while waiting for the subsequently repaired keyboard result. These failures are not relabeled as successful runs. [verification-summary.json](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w18/evidence/verification-summary.json) identifies the actual exports and their boundaries.

## Source craft and visual findings

The integration retains the source's 350 px width, native type, header/body grouping, border, shadow, padding, small primary button and separated action row. English and Chinese states fit at the narrow width; the lower settings actions remain reachable. I personally inspected the supplied standalone source, the acquired original-page rendering, integrated whole-page views, source detail, ordered state frames and repaired validation views. [VISUAL-REVIEW.md](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w18/VISUAL-REVIEW.md) records the observations and their limits.

Representative final views:

- [Desktop, light/English error](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w18/evidence/final-inspection/1440x900-light-en-error-top.png)
- [Short viewport, dark/Chinese with lower controls](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w18/evidence/final-inspection/1280x600-dark-zh-error-lower.png)
- [Narrow viewport, dark/Chinese error](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w18/evidence/final-inspection/390x844-dark-zh-error-top.png)
- [Repaired narrow Chinese validation](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w18/evidence/keyboard-final-03/390x844-dark-zh-settled-invalid.png)

**The prescribed placement has a visible tradeoff:** while open, the toast overlaps some upper-right header utilities and much of the narrow header/title area. The native close control stays reachable, and dismissal restores the header. I preserved this settled composition and reported the overlap rather than choosing a new placement.

## Evidence and limits

The three supplied HTML/block hashes match [SOURCE-MANIFEST.json](sandbox:/workspace/scratch/708e8b7f118e/ui-study/worksets/w18/SOURCE-MANIFEST.json). The related tag remains `@tabler/core@1.7.1`, commit `07f60c07da13d8ff957a370434b7ef5c86f5ab94`; the deployed snapshot's exact deployment commit remains unadvertised.

Live public-demo navigation failed TLS verification. I retained the failure and rendered the exact acquired upstream HTML locally with matching assets; this is not a claim of live public-site inspection. Temporal evidence consists of real-time automated actions and personally viewed, timestamped ordered frames. Natural-speed playback and actual screen-reader speech were not inspected. Unrelated upstream gallery routes remain outside the task contract.

This package was implemented directly, with no additional package child and no merge step. The observed product rework was one focused visibility repair; evidence collection also required the documented harness/capture corrections. No sibling package or other agent result was inspected, so no comparative productivity or billed-cost claim is made. Backend identity, token totals and billed cost are unknown.

The runnable source, exact diff, source identities, test scripts, failed and successful command outputs, browser-state logs, actual image-tool responses and final captures are retained in this package. Design judgment is recorded separately from test success and end-user acceptance.
