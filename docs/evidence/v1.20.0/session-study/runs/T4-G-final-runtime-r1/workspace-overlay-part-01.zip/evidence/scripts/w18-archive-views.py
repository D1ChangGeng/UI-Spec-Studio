from pathlib import Path
import shutil,sys
out=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w18/evidence/views');out.mkdir(exist_ok=True)
for name in sys.argv[1:]:shutil.copyfile(name,out/Path(name).name)
print('Saved actual view_image responses: '+str(len(sys.argv)-1))
