import asyncio,json,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w18')
OUT=ROOT/'evidence/source-inspection'; OUT.mkdir(parents=True,exist_ok=True)
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
  async with async_playwright() as pw:
    browser=await pw.chromium.launch(executable_path=CHROME,headless=True)
    page=await browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
    notes={'browser':browser.version,'viewport':[1440,900],'device_scale_factor':1,'public_demo':{}}
    try:
      await page.goto('https://preview.tabler.io/toasts.html',wait_until='domcontentloaded',timeout=15000)
      await page.locator('[data-bs-target="#toast-cookies"]').first.click(timeout=5000)
      await page.wait_for_timeout(250)
      await page.screenshot(path=str(OUT/'public-original-demo.png'))
      notes['public_demo']={'result':'loaded and source trigger activated','url':page.url}
    except Exception as exc: notes['public_demo']={'result':'unavailable','error':str(exc)}
    (OUT/'public-demo-attempt.json').write_text(json.dumps(notes['public_demo'],indent=2)+'\n')
    await page.close()
    page=await browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
    await page.goto('http://127.0.0.1:4418/toast-source-preview.html',wait_until='networkidle')
    await page.evaluate('document.fonts.ready')
    await page.screenshot(path=str(OUT/'local-source-light.png'))
    notes['local_source_style']=await page.locator('#toast-cookies').evaluate('(el)=>{const s=getComputedStyle(el);return {width:s.width,fontSize:s.fontSize,lineHeight:s.lineHeight,border:s.border,boxShadow:s.boxShadow,padding:s.padding,transition:s.transition}}')
    await page.evaluate("document.documentElement.setAttribute('data-bs-theme','dark')")
    await page.screenshot(path=str(OUT/'local-source-dark.png'))
    await page.goto('http://127.0.0.1:4418/?theme=light&lang=en',wait_until='networkidle')
    await page.screenshot(path=str(OUT/'settings-before-light.png'))
    notes['baseline']={'store':await page.evaluate('window.fieldnotes.readSettings()'),'toast_api':await page.evaluate('typeof window.tabler.bootstrap.Toast')}
    (OUT/'observations.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(notes,ensure_ascii=False))
    await browser.close()
asyncio.run(main())
