import asyncio,json,hashlib,shutil
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w18');OUT=ROOT/'evidence/final-inspection';OUT.mkdir(parents=True,exist_ok=True)
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
checks=[];captures=[]
async def state(page,status):await page.wait_for_function('(s)=>document.querySelector("#save-notification").dataset.state===s',arg=status)
def check(name,value): checks.append({'check':name,'pass':bool(value)});assert value,name
async def snap(page,name):
 before=await page.evaluate('performance.now()')
 await page.screenshot(path=str(OUT/(name+'.png')))
 captures.append({'file':name+'.png','browser_capture_start_ms':before,**await page.evaluate('()=>({browser_capture_end_ms:performance.now(),scroll:[scrollX,scrollY],focus:document.activeElement.id,state:document.querySelector("#save-notification").dataset.state})')})
async def main():
 report={'checks':checks,'captures':captures,'notes':'Real browser time. Static comparisons explicitly settle document scrolling; screenshots retain native animations.'}
 try:
  async with async_playwright() as pw:
   browser=await pw.chromium.launch(executable_path=CHROME,headless=True)
   ctx=await browser.new_context(viewport={'width':1440,'height':900},reduced_motion='reduce',timezone_id='UTC');page=await ctx.new_page()
   await page.goto('http://127.0.0.1:4418/?theme=light&lang=en',wait_until='networkidle')
   await page.locator('#save-settings').click();await state(page,'success')
   previous=await page.evaluate('localStorage.getItem("fieldnotes-settings-v1")')
   await page.evaluate('''() => {window.originalStorageSet=Storage.prototype.setItem;Storage.prototype.setItem=function(key,value){if(key==="fieldnotes-settings-v1")throw new DOMException("Injected storage quota failure","QuotaExceededError");return window.originalStorageSet.call(this,key,value)};}''')
   await page.locator('#business-name').fill('Storage boundary retry')
   await page.locator('#save-settings').click();await state(page,'error')
   check('actual thrown storage write preserves previous value',await page.evaluate('localStorage.getItem("fieldnotes-settings-v1")')==previous)
   await page.locator('#business-name').fill('Newer form edit')
   await page.evaluate('() => {Storage.prototype.setItem=window.originalStorageSet;}')
   await page.locator('#retry-save').focus();await page.keyboard.press('Enter');await state(page,'success')
   check('retry after storage recovery saves exact failed snapshot',await page.evaluate('window.fieldnotes.readSettings().displayName')=='Storage boundary retry')
   check('newer form value survives recovered storage',await page.locator('#business-name').input_value()=='Newer form edit')
   await page.wait_for_timeout(5300)
   check('feedback remains beyond native default timeout',await page.locator('#save-notification').is_visible())
   await page.evaluate('scrollTo({top:0,behavior:"instant"})');await snap(page,'reduced-motion-storage-recovery')
   await ctx.close()
   for width,height in [(1440,900),(1280,600),(390,844)]:
    for theme,lang in [('light','en'),('dark','zh')]:
     name=f'{width}x{height}-{theme}-{lang}'
     ctx=await browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1,timezone_id='UTC');page=await ctx.new_page()
     await page.goto(f'http://127.0.0.1:4418/?theme={theme}&lang={lang}&fail=once',wait_until='networkidle');await page.evaluate('document.fonts.ready')
     await snap(page,name+'-initial')
     await page.locator('#save-settings').click();await state(page,'error')
     await page.locator('#retry-save').focus();await page.evaluate('scrollTo({top:0,behavior:"instant"})')
     await snap(page,name+'-error-top')
     await page.locator('#save-notification').screenshot(path=str(OUT/(name+'-toast-detail.png')))
     # Native document scrolling keeps the lower form controls reachable.
     await page.evaluate('scrollTo({top:document.documentElement.scrollHeight,behavior:"instant"})')
     await snap(page,name+'-error-lower')
     await page.locator('#retry-save').focus();await page.keyboard.press('Enter');await state(page,'success')
     await page.evaluate('scrollTo({top:0,behavior:"instant"})');await snap(page,name+'-success-top')
     await page.locator('#save-notification .btn-close').focus();await page.keyboard.press('Enter')
     await page.wait_for_timeout(220)
     await page.evaluate('scrollTo({top:0,behavior:"instant"})');await snap(page,name+'-closed-header')
     check(name+' keyboard close recovers save control',await page.evaluate('document.activeElement.id')=='save-settings')
     await ctx.close()
   await browser.close()
  before=json.loads((ROOT/'evidence/baseline/read-only-sha256.json').read_text())
  check('all 35 protected source and asset files unchanged',all(hashlib.sha256((ROOT/file).read_bytes()).hexdigest()==value for file,value in before.items()))
  report['result']='pass'
 finally:
  (OUT/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
  print(json.dumps({'result':report.get('result','fail'),'checks':len(checks),'captures':len(captures)}))
asyncio.run(main())
