from pathlib import Path
import json,shutil
P=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w18')
B='sandbox:'+str(P)
viewed=[]
for file in list((P/'evidence/views').glob('*.json'))+list((P/'evidence/source-inspection').glob('view-*.json')):
 record=json.loads(file.read_text());viewed.append({'image':record['arguments']['path'],'original_tool_export':str(file.relative_to(P)),'tool':record['tool']})
(P/'evidence/viewed-images.json').write_text(json.dumps({'evidence_kind':'index derived from captured actual view_image responses','images':viewed},indent=2)+'\n')
review='''# Visual review — W18 save feedback

## Reviewer and scope

The package owner personally opened the source, trial, final and repaired images using `view_image`; the original returned objects are preserved in `evidence/views/` and `evidence/source-inspection/view-*.json`. `evidence/viewed-images.json` indexes the actual viewed images. This report is professional judgment, not a native tool export or end-user aesthetic acceptance.

The retained source is Tabler 1.7.1's action-bearing cookie Toast. Source identity and composition were settled by the supplied integration decision; no new resource choice or original visual exception was made. The primary task is editing and persisting browser-local settings with truthful feedback and recovery.

## Source observations

I read the exact extracted block and tagged Astro component, then viewed the supplied standalone source rendering in light and dark. I also operated the original Cookies toast trigger in the exact acquired full deployed HTML, rendered locally with the matching supplied assets. Its full-page image includes the entrance transition; the separately viewed toast crop is settled. This is distinct from the integrated settings application.

The live public demo failed certificate verification (`ERR_CERT_AUTHORITY_INVALID`); TLS checks were not weakened. The original deployed snapshot was fulfilled at a local test route, with nonlocal requests blocked. The unavailable sample portrait and cookie glyph are limitations of that source rendering, not assets shipped in the integration. The product uses the authorized FN initials fallback and no emoji.

The source's value is a compact 350 px shell with a quiet identity/time/close header, readable body, and a fine separator above one small primary action. The integrated error state retains those relationships. Native computed values include 14 px body type, 20 px line height, 8×12 px header padding, 12 px body padding, 8 px action margin/padding, 6 px corner radius and the existing border/shadow. They are inherited from the unchanged assets, not replacement CSS.

## Whole-product observations

| Condition | Actually viewed relationship | Judgment |
|---|---|---|
| 1440×900, light/English and dark/Chinese | Initial composition, error toast, source detail, pending and success samples, repaired invalid state | The toast remains a compact secondary surface. The main settings hierarchy, mixed-script values, sidebar and form grouping remain intact. |
| 1280×600, both declared variants | Error at the top and lower document position; repaired invalid states | Short height requires the inherited document scroll. Retry and close remain visible, while the lower Save/Cancel row remains unobstructed. |
| 390×844, both declared variants | Error at top and lower positions; Chinese success; repaired invalid states; restored headers | The 350 px toast fits within the viewport at x=24…374. English and Chinese copy wrap naturally; action text and close stay within the surface. No horizontal page overflow was measured. |

The prescribed top-right placement overlaps some upstream header utilities while feedback is visible; at narrow size it covers much of the header/title area. This is an observed consequence of the fixed integration decision. The native Close control remains exposed, and the restored-header views show the navigation unobscured after dismissal. I preserved the mandated placement rather than changing art direction. Settings controls and lower save actions remain usable by scrolling.

## A real defect found after functional checks

The first matrix verified that invalid submission moved DOM focus to Display name, but a subsequent settled narrow screenshot showed that the field was at y=0, underneath the fixed toast. This was a visible-focus defect, not a passing visual result. The failed screenshot and geometry remain in `evidence/keyboard-final-02`, and commands 011/013 retain the failed assertions.

The allowed controller now uses native `scrollIntoView({block:'center', behavior:'instant'})`, then focuses with `preventScroll`. The final keyboard recheck covers all six declared conditions. The focused field now sits at y=430 at 1440×900, y=280 at 1280×600, and y=402 at 390×844, below the toast. I personally viewed all six repaired invalid-state images and the two restored narrow headers. The field label, input boundary and localized error are visible together. No source CSS, toast transition, placement or store rule changed.

The real Tab sequence from Save reaches Close and Retry in nine Tab steps through the existing footer controls. Shift+Tab returns from Retry to Close; Enter dismisses; focus returns to Save. These were executed in all six final conditions, separately from programmatic focus checks.

## Time, focus and state

I viewed ordered pending/edit/error/retry/success samples and the later measured entrance/result frames. `evidence/temporal-01` records browser `performance.now()` brackets, native Toast events and actual operation events. Frame filename offsets are requested targets; JSON timestamps are the actual capture times. For example, the English file labelled 0400 ms was captured at approximately 617 ms because of capture overhead.

Early entrance frames have the native `showing` class and opacity 0, followed by the source fade. Later pending frames are fully readable before authoritative success. The inline summary acknowledges the operation immediately. Pending and success retain the same compact height, and the lower form action remains anchored. Native focus styling remains visible on Save while its disabled presentation changes. Error adds the inherited separated action row; retry removes that row and returns focus to Save. Editing during pending and success retains the newer draft.

These are real-time automated interactions plus actually viewed ordered frames, with unobserved intervals between samples. No natural-speed live or video playback was viewed, and no smoothness, frame-rate or screen-reader speech claim is made. ARIA ownership and field associations were checked structurally; actual assistive-technology output remains untested.

## Current evidence applicability

The broad save/retry matrix and the source/error/success views precede the narrow recovery-scroll repair. Their state, persistence, source and appearance claims remain applicable because the final delta changes only invalid-field recovery scrolling. All affected invalid-focus, keyboard and restored-header conditions were freshly rerun and viewed after that delta. Final source hashes, protected-file hashes and JavaScript syntax were rechecked after the repair.

Within the stated browser and conditions, the bounded save-feedback integration is ready for review. The remaining visible tradeoff is the prescribed header overlap. Live-source access, normal-speed motion review, real screen-reader output and unrelated upstream routes are outside the completed evidence claims.
'''
(P/'VISUAL-REVIEW.md').write_text(review)
final=f'''# W18 — Tabler save-feedback integration completed

The Fieldnotes settings application now uses the selected Tabler action-bearing Toast for real browser-local save feedback. Pending, success, failure/retry and validation states are connected to the existing authoritative store. The implementation and final visual review are complete within the supplied scope and tested conditions.

## Run the product

From `/workspace/scratch/708e8b7f118e/ui-study/worksets/w18/app`:

```bash
python3 -m http.server 4418 --bind 127.0.0.1
```

Open [the light/English application](http://127.0.0.1:4418/?theme=light&lang=en) or [the dark/Chinese application](http://127.0.0.1:4418/?theme=dark&lang=zh). Add `&fail=once` on a new load to exercise the forced failure, or call `window.fieldnotes.setFailureMode(true)` before saving. No build or install is required. The inspection server is stopped at handover; the application remains runnable with this command.

## What changed

| Product file | Bounded change | Diff |
|---|---|---|
| `app/index.html` | Adopted the exact native toast shell in the prescribed utility container; kept the inline summary quiet to avoid a second live announcement | +19 / −1 lines |
| `app/settings-controller.js` | Coordinates authoritative events, pending controls, field errors, draft-aware summary and visible focus recovery | +68 / −4 lines |
| `app/save-notification.js` | New adapter for native Toast rendering, localized feedback, exact-snapshot retry, stale-event protection and dismissal focus | +69 lines |

No dependency or custom CSS rule was added. The store, source preview and 35 tracked protected source/asset files remain byte-identical. The existing MIT license and adopted-block attribution are retained. The exact final comparison is in [product-changes.diff]({B}/evidence/product-changes.diff).

Success wording follows an actual successful storage write and displays its saved time. Failure preserves both the previous stored value and current form edits. Retry saves the failed submission's snapshot, while a later draft remains in the fields. Toast completion does not steal form focus. Close dismisses only the feedback, and a later authoritative event can replace it. Validation uses the store's actual errors and names the first invalid field in both languages.

## Verification and the repair it prompted

The six required conditions—1440×900, 1280×600 and 390×844, each in light/English and dark/Chinese—passed 180 assertions covering save, pending edits, success, forced failure, retry, validation, close, storage readback, reload, theme controls, announcements and containment. A supplemental sequence verified that an older error cannot replace a newer invalid result and that dismissing pending feedback does not cancel the write.

A later independent keyboard/visual check exposed a real issue missed by DOM-focus assertions: on a narrow screen the first invalid field could be focused at y=0 behind the toast. I repaired only the controller's recovery scrolling. All six conditions then passed fresh Tab traversal, dismissal return, invalid-field visibility and header-return checks, and I personally opened the repaired screenshots. The field now appears visibly centered below the toast. See [the failed observation]({B}/evidence/keyboard-final-02/light-en-settled-invalid.png) and [the repaired narrow view]({B}/evidence/keyboard-final-03/390x844-light-en-settled-invalid.png).

The corrected storage-exception probe confirms that an actual thrown storage write preserves the previous value, and retry succeeds after storage is restored without overwriting newer form edits. Persistent feedback remained visible beyond the native default timeout. Final JavaScript syntax and source digests passed.

Original command failures are retained. The first broad command ended with a supplemental test-harness error after its six matrix cases had passed; the corrected probe is separate. A premature evidence-packaging attempt also failed while waiting for the subsequently repaired keyboard result. These failures are not relabeled as successful runs. [verification-summary.json]({B}/evidence/verification-summary.json) identifies the actual exports and their boundaries.

## Source craft and visual findings

The integration retains the source's 350 px width, native type, header/body grouping, border, shadow, padding, small primary button and separated action row. English and Chinese states fit at the narrow width; the lower settings actions remain reachable. I personally inspected the supplied standalone source, the acquired original-page rendering, integrated whole-page views, source detail, ordered state frames and repaired validation views. [VISUAL-REVIEW.md]({B}/VISUAL-REVIEW.md) records the observations and their limits.

Representative final views:

- [Desktop, light/English error]({B}/evidence/final-inspection/1440x900-light-en-error-top.png)
- [Short viewport, dark/Chinese with lower controls]({B}/evidence/final-inspection/1280x600-dark-zh-error-lower.png)
- [Narrow viewport, dark/Chinese error]({B}/evidence/final-inspection/390x844-dark-zh-error-top.png)
- [Repaired narrow Chinese validation]({B}/evidence/keyboard-final-03/390x844-dark-zh-settled-invalid.png)

**The prescribed placement has a visible tradeoff:** while open, the toast overlaps some upper-right header utilities and much of the narrow header/title area. The native close control stays reachable, and dismissal restores the header. I preserved this settled composition and reported the overlap rather than choosing a new placement.

## Evidence and limits

The three supplied HTML/block hashes match [SOURCE-MANIFEST.json]({B}/SOURCE-MANIFEST.json). The related tag remains `@tabler/core@1.7.1`, commit `07f60c07da13d8ff957a370434b7ef5c86f5ab94`; the deployed snapshot's exact deployment commit remains unadvertised.

Live public-demo navigation failed TLS verification. I retained the failure and rendered the exact acquired upstream HTML locally with matching assets; this is not a claim of live public-site inspection. Temporal evidence consists of real-time automated actions and personally viewed, timestamped ordered frames. Natural-speed playback and actual screen-reader speech were not inspected. Unrelated upstream gallery routes remain outside the task contract.

This package was implemented directly, with no additional package child and no merge step. The observed product rework was one focused visibility repair; evidence collection also required the documented harness/capture corrections. No sibling package or other agent result was inspected, so no comparative productivity or billed-cost claim is made. Backend identity, token totals and billed cost are unknown.

The runnable source, exact diff, source identities, test scripts, failed and successful command outputs, browser-state logs, actual image-tool responses and final captures are retained in this package. Design judgment is recorded separately from test success and end-user acceptance.
'''
(P/'FINAL.md').write_text(final)
(P/'DESIGN-NOTES.md').open('a').write('''\n## Completion and retained source\n\nThe visible-focus repair passed in all six declared conditions (command takeover-015). Actual Tab navigation reached the toast controls; native close returned to Save. The package owner personally viewed the six repaired invalid states and restored narrow headers. The remaining mandated header-overlap tradeoff is recorded in VISUAL-REVIEW.md and FINAL.md. The three supplied HTML/block digests match the manifest; 35 protected source/asset files and final module syntax were freshly verified in takeover-016. The exact diff is evidence/product-changes.diff.\n\nThe direct integration required no package-child merge and one product behavior repair. Original failed command outputs, their corrections and actual view_image responses remain available. No comparative productivity, unseen playback, real screen-reader or owner-acceptance claim is made.\n''')
shutil.copyfile('/tmp/w18-finish.py',P/'evidence/scripts/w18-finish.py')
print(json.dumps({'written':['FINAL.md','VISUAL-REVIEW.md','evidence/viewed-images.json'],'actual_view_exports':len(viewed),'final_words':len(final.split())}))
