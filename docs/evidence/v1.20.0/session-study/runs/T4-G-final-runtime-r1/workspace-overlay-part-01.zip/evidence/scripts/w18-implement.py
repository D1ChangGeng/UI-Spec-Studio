from pathlib import Path
import json
p=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w18')
html=p/'app/index.html'
s=html.read_text()
s=s.replace('id="save-status" role="status"','id="save-status" aria-live="off"')
block='''    <!-- Save-feedback shell adopted from Tabler 1.7.1 toast-cookies.
         Copyright (c) 2018-2026 The Tabler Authors. MIT License; see LICENSE. -->
    <div class="toast-container position-fixed top-0 end-0 p-3">
      <div class="toast" id="save-notification" role="status" aria-live="polite" aria-atomic="true" data-bs-autohide="false">
        <div class="toast-header">
          <span class="avatar avatar-xs me-2" aria-hidden="true">FN</span>
          <strong class="me-auto">Fieldnotes</strong>
          <small id="save-notification-time"></small>
          <button type="button" class="ms-2 btn-close" data-bs-dismiss="toast" aria-label="Close save feedback"></button>
        </div>
        <div class="toast-body">
          <span id="save-notification-message"></span>
          <div class="mt-2 pt-2 border-top" id="save-notification-actions" hidden>
            <button type="button" class="btn btn-primary btn-sm" id="retry-save">Retry save</button>
          </div>
        </div>
      </div>
    </div>
'''
assert 'id="save-notification"' not in s
s=s.replace('  <script type="module" src="./settings-controller.js"></script>',block+'  <script type="module" src="./settings-controller.js"></script>')
html.write_text(s)
(p/'app/save-notification.js').write_text('''// Tabler 1.7.1 action-toast integration. The source shell is in index.html.
// Tabler copyright (c) 2018-2026 The Tabler Authors, MIT; see LICENSE.
import { saveSettings } from './settings-store.js';

export function createSaveNotification({ zh, returnFocus, fieldName }) {
  const root = document.querySelector('#save-notification');
  const message = document.querySelector('#save-notification-message');
  const time = document.querySelector('#save-notification-time');
  const actions = document.querySelector('#save-notification-actions');
  const retry = document.querySelector('#retry-save');
  const close = root.querySelector('[data-bs-dismiss="toast"]');
  const toast = window.tabler.bootstrap.Toast.getOrCreateInstance(root, { autohide: false });
  const formatTime = value => new Intl.DateTimeFormat(zh ? 'zh-CN' : 'en', {hour:'2-digit',minute:'2-digit',second:'2-digit'}).format(new Date(value));
  let latestOperation = 0;
  let failedSnapshot = null;
  let hiding = false;
  let reopen = false;
  let restoreAfterHide = false;
  close.setAttribute('aria-label', zh ? '关闭保存提示' : 'Close save feedback');
  retry.textContent = zh ? '重试保存' : 'Retry save';

  root.addEventListener('hide.bs.toast', () => {
    hiding = true;
    restoreAfterHide = root.contains(document.activeElement);
  });
  root.addEventListener('hidden.bs.toast', () => {
    hiding = false;
    if (restoreAfterHide && (root.contains(document.activeElement) || document.activeElement === document.body)) returnFocus();
    restoreAfterHide = false;
    if (reopen) { reopen = false; toast.show(); }
  });
  retry.addEventListener('click', () => {
    if (!failedSnapshot) return;
    // Retry exactly the submitted snapshot. Later form edits remain owned by the form.
    const snapshot = { ...failedSnapshot };
    saveSettings(snapshot).catch(() => {});
  });

  return {
    render(event) {
      if (event.operationId < latestOperation) return;
      latestOperation = event.operationId;
      const isError = event.status === 'error';
      if (!isError && actions.contains(document.activeElement)) returnFocus();
      failedSnapshot = isError ? { ...event.snapshot } : null;
      actions.hidden = !isError;
      root.dataset.state = event.status;
      root.dataset.operationId = String(event.operationId);
      time.textContent = event.savedAt ? formatTime(event.savedAt) : (zh ? '刚刚' : 'Now');
      if (event.savedAt) time.setAttribute('title', event.savedAt); else time.removeAttribute('title');
      const firstField = Object.keys(event.fieldErrors || {})[0];
      const content = zh ? {
        pending: '正在保存更改。正在将本次提交的版本保存到当前浏览器。',
        success: '更改已保存。本次提交的版本仅保存在当前浏览器中。',
        error: '保存未完成。草稿仍然保留。重试将保存上次提交的版本。',
        invalid: `请检查个人资料字段：${fieldName(firstField)}。`
      } : {
        pending: 'Saving changes. Saving the submitted version in this browser.',
        success: 'Changes saved. The submitted version is saved only in this browser.',
        error: 'Save did not complete. Your draft is preserved. Retry saves the previously submitted version.',
        invalid: `Check profile fields: ${fieldName(firstField)}.`
      };
      message.textContent = content[event.status];
      if (hiding) reopen = true;
      else if (!root.classList.contains('show')) toast.show();
    },
    formatTime
  };
}
''')
controller=p/'app/settings-controller.js'
old=controller.read_text()
start=old.index("document.querySelector('#focus-email')")
tail=old[start:]
head='''import { readSettings, saveSettings, subscribeSettings, setFailureMode } from './settings-store.js';
import { createSaveNotification } from './save-notification.js';

const ids = {displayName:'business-name',organization:'business-id',location:'location',email:'email',weeklyDigest:'weekly-digest',publicProfile:'public-profile'};
const status = document.querySelector('#save-status');
const save = document.querySelector('#save-settings');
const params = new URLSearchParams(location.search);
const zh = params.get('lang') === 'zh';
const copy = zh ? {idle:'更改仅保存在当前浏览器中。',pending:'本次提交正在保存。',error:'未写入本次提交的版本。',invalid:'请修正已标出的字段。'} : {idle:'Changes are saved only in this browser.',pending:'The submitted version is being saved.',error:'The submitted version was not written.',invalid:'Correct the marked fields.'};
const names = zh ? {displayName:'显示名称',organization:'机构',location:'地点',email:'电子邮件'} : {displayName:'Display name',organization:'Organization',location:'Location',email:'Email'};
const errorsZh = {'Add a display name.':'请填写显示名称。','Use 100 characters or fewer.':'请使用不超过 100 个字符。','Use 180 characters or fewer.':'请使用不超过 180 个字符。','Enter a complete email address.':'请填写完整的电子邮件地址。'};
let latestOperation = 0;
let pending = false;
let initiatingControl = save;
function draft() { return Object.fromEntries(Object.entries(ids).map(([key,id])=>{const el=document.getElementById(id);return [key,el.type==='checkbox'?el.checked:el.value];})); }
function clearErrors() {
  for (const id of Object.values(ids)) {
    const field = document.getElementById(id);
    field.classList.remove('is-invalid');
    field.removeAttribute('aria-invalid');
    const described = (field.getAttribute('aria-describedby') || '').split(/\\s+/).filter(value => value && value !== `${id}-error`);
    if (described.length) field.setAttribute('aria-describedby', described.join(' ')); else field.removeAttribute('aria-describedby');
    document.getElementById(`${id}-error`)?.remove();
  }
}
function showErrors(fieldErrors) {
  clearErrors();
  for (const [key, message] of Object.entries(fieldErrors)) {
    const field = document.getElementById(ids[key]);
    if (!field) continue;
    const feedback = document.createElement('div');
    feedback.id = `${field.id}-error`;
    feedback.className = 'invalid-feedback';
    feedback.textContent = zh ? (errorsZh[message] || message) : message;
    field.insertAdjacentElement('afterend', feedback);
    field.classList.add('is-invalid');
    field.setAttribute('aria-invalid', 'true');
    field.setAttribute('aria-describedby', [field.getAttribute('aria-describedby'), feedback.id].filter(Boolean).join(' '));
  }
  const first = document.getElementById(ids[Object.keys(fieldErrors)[0]]);
  if (first && document.activeElement !== first) first.focus();
}
function load() { const data=readSettings(); for(const [key,id] of Object.entries(ids)){const el=document.getElementById(id); if(el.type==='checkbox')el.checked=data[key];else el.value=data[key];} }
function returnFocus() {
  const target = initiatingControl?.isConnected && !initiatingControl.disabled ? initiatingControl : save;
  target.focus();
}
const notification = createSaveNotification({zh, returnFocus, fieldName: key => names[key] || (zh ? '个人资料' : 'Profile')});
try { load(); status.textContent=copy.idle; } catch(error) { status.textContent=error.message; }
subscribeSettings(event => {
  if (event.operationId < latestOperation) return;
  latestOperation = event.operationId;
  pending = event.status === 'pending';
  // Native Tabler disabled styling plus aria-disabled keeps keyboard focus stable.
  save.classList.toggle('disabled', pending);
  save.setAttribute('aria-disabled', String(pending));
  save.setAttribute('aria-busy', String(pending));
  if (event.status === 'invalid') showErrors(event.fieldErrors);
  else if (event.status === 'pending') clearErrors();
  if (event.status === 'success') {
    const changed = Object.keys(ids).some(key => draft()[key] !== event.settings[key]);
    const savedTime = notification.formatTime(event.savedAt);
    status.textContent = zh ? `上次保存：${savedTime}。${changed ? '之后的编辑尚未保存。' : ''}` : `Last saved: ${savedTime}.${changed ? ' Later edits are not saved yet.' : ''}`;
  } else status.textContent = copy[event.status] || copy.idle;
  status.dataset.state = event.status;
  notification.render(event);
});
save.addEventListener('click', async () => {
  if (pending) return;
  initiatingControl = save;
  try { await saveSettings(draft()); } catch {}
});
document.querySelector('#cancel-settings').addEventListener('click',()=>{try{load();clearErrors();status.textContent=copy.idle;status.dataset.state='idle';}catch(error){status.textContent=error.message;}});
'''
controller.write_text(head+tail)
print(json.dumps({'changed':['app/index.html','app/settings-controller.js'],'added':['app/save-notification.js'],'new_dependencies':0,'custom_css':0}))
