import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w18');OUT=ROOT/'evidence/keyboard-final-03';OUT.mkdir(parents=True,exist_ok=True)
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
 reports=[]
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path=CHROME,headless=True)
  for width,height,theme,lang in [(1440,900,'light','en'),(1440,900,'dark','zh'),(1280,600,'light','en'),(1280,600,'dark','zh'),(390,844,'light','en'),(390,844,'dark','zh')]:
   name=f'{width}x{height}-{theme}-{lang}'
   context=await browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1);page=await context.new_page();report={'variant':name,'tab_sequence':[]};reports.append(report)
   await page.goto(f'http://127.0.0.1:4418/?theme={theme}&lang={lang}&fail=once',wait_until='networkidle')
   await page.locator('#save-settings').focus();await page.keyboard.press('Enter');await page.wait_for_function('document.querySelector("#save-notification").dataset.state==="error"')
   for _ in range(25):
    await page.keyboard.press('Tab')
    target=await page.evaluate('()=>({id:document.activeElement.id,tag:document.activeElement.tagName,label:document.activeElement.getAttribute("aria-label"),text:document.activeElement.textContent.trim().slice(0,80)})')
    report['tab_sequence'].append(target)
    if target['id']=='retry-save':break
   report['retry_reached_by_tabs']=report['tab_sequence'][-1]['id']=='retry-save';assert report['retry_reached_by_tabs']
   await page.keyboard.press('Shift+Tab')
   report['close_reached_by_shift_tab']=await page.evaluate('document.activeElement.matches("#save-notification .btn-close")');assert report['close_reached_by_shift_tab']
   await page.keyboard.press('Enter');await page.wait_for_function('!document.querySelector("#save-notification").classList.contains("show")')
   report['close_return']=await page.evaluate('document.activeElement.id');assert report['close_return']=='save-settings'
   await page.locator('#business-name').fill('');await page.locator('#email').fill('invalid');await page.locator('#save-settings').click()
   await page.wait_for_function('document.querySelector("#save-notification").dataset.state==="invalid"')
   await page.wait_for_timeout(900)
   report['invalid']=await page.evaluate('''()=>{const f=document.querySelector('#business-name').getBoundingClientRect(),t=document.querySelector('#save-notification').getBoundingClientRect();return {focus:document.activeElement.id,field:{x:f.x,y:f.y,bottom:f.bottom,right:f.right},toast:{x:t.x,y:t.y,bottom:t.bottom,right:t.right},message:document.querySelector('#save-notification-message').textContent,scrollY}}''')
   assert report['invalid']['focus']=='business-name'
   await page.screenshot(path=str(OUT/(name+'-settled-invalid.png')))
   (OUT/'results.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2)+'\n')
   print(json.dumps(report,ensure_ascii=False))
   assert report['invalid']['field']['y']>=report['invalid']['toast']['bottom'] and report['invalid']['field']['bottom']<=height
   await page.locator('#save-notification .btn-close').focus();await page.keyboard.press('Enter');await page.wait_for_function('!document.querySelector("#save-notification").classList.contains("show")')
   await page.wait_for_timeout(700);await page.evaluate('scrollTo({top:0,behavior:"instant"})');await page.wait_for_timeout(60)
   await page.screenshot(path=str(OUT/(name+'-header-restored.png')))
   report['result']='pass';await context.close()
  await browser.close()
 (OUT/'results.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'result':'pass','variants':len(reports),'tab_steps':[len(r['tab_sequence']) for r in reports]}))
asyncio.run(main())
