from pathlib import Path
import shutil,json,hashlib,difflib,subprocess
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w18');E=ROOT/'evidence'
(E/'scripts').mkdir(exist_ok=True)
for name in ['initial','baseline','implement','verify','source-snapshot','boundary-and-final','temporal','keyboard-final','archive-views','package-evidence','repair-focus']:
 p=Path('/tmp/w18-'+name+'.py')
 if p.exists():shutil.copyfile(p,E/'scripts'/p.name)
manifest=json.loads((ROOT/'SOURCE-MANIFEST.json').read_text())
source_checks=[]
for file,expected in [('sources/official-settings-snapshot.html',manifest['compiled_html']['sha256']),('sources/official-toasts-snapshot.html',manifest['selected_integration_resource']['snapshot_sha256']),('sources/tabler-toast-cookies.html',manifest['selected_integration_resource']['block_sha256'])]:
 actual=hashlib.sha256((ROOT/file).read_bytes()).hexdigest();source_checks.append({'file':file,'expected_sha256':expected,'actual_sha256':actual,'match':actual==expected})
changes=[];diffs=[]
for name in ['index.html','settings-controller.js','save-notification.js']:
 before=(E/'baseline'/name).read_text().splitlines(keepends=True) if (E/'baseline'/name).exists() else []
 after=(ROOT/'app'/name).read_text().splitlines(keepends=True)
 diff=list(difflib.unified_diff(before,after,fromfile='baseline/app/'+name,tofile='app/'+name))
 changes.append({'file':'app/'+name,'added_lines':sum(line.startswith('+') and not line.startswith('+++') for line in diff),'removed_lines':sum(line.startswith('-') and not line.startswith('---') for line in diff),'final_sha256':hashlib.sha256((ROOT/'app'/name).read_bytes()).hexdigest()})
 diffs.extend(diff)
(E/'product-changes.diff').write_text(''.join(diffs))
matrix=json.loads((E/'verification-01/results.json').read_text())
final=json.loads((E/'final-inspection/results.json').read_text())
keyboard=json.loads((E/'keyboard-final-03/results.json').read_text())
summary={'evidence_kind':'derived summary of original captured outputs, not a native tool export','matrix_cases':[{'case':r['case'],'result':r['result'],'passing_checks':sum(c['pass'] for c in r['checks'])} for r in matrix['reports'][:6]],'first_full_command_result':matrix['result'],'supplemental_harness_error':matrix.get('error'),'supplemental_checks_before_harness_error':matrix['reports'][-1]['checks'],'corrected_boundary_and_final_capture_result':final['result'],'corrected_followup_checks':final['checks'],'keyboard_cases':keyboard,'source_identity_checks':source_checks,'product_changes':changes,'new_dependencies':0,'new_custom_css_rules':0,'delegated_package_children':0,'backend_identity':None,'token_count':None,'billed_cost':None,'comparison_limit':'No other work package or agent result was inspected. No comparative productivity or cost claim is made.'}
expected=json.loads((E/'baseline/read-only-sha256.json').read_text())
summary['final_read_only_integrity']={'checked':len(expected),'unchanged':all(hashlib.sha256((ROOT/file).read_bytes()).hexdigest()==value for file,value in expected.items())}
summary['syntax_checks']=[]
for file in ['app/settings-controller.js','app/save-notification.js']:
 result=subprocess.run(['node','--check',file],cwd=ROOT,capture_output=True,text=True)
 summary['syntax_checks'].append({'command':['node','--check',file],'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
(E/'verification-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'source_hashes_match':all(s['match'] for s in source_checks),'matrix_passes':len(summary['matrix_cases']),'matrix_passing_checks':sum(r['passing_checks'] for r in summary['matrix_cases']),'product_changes':changes,'keyboard_passes':len(keyboard)},ensure_ascii=False))
