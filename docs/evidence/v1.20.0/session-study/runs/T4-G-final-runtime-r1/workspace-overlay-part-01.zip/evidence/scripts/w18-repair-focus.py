from pathlib import Path
import shutil,json
p=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w18');file=p/'app/settings-controller.js'
shutil.copyfile(file,p/'evidence/baseline/controller-before-focus-repair.js')
s=file.read_text()
old="  if (first && document.activeElement !== first) first.focus();"
new="""  if (first) {
    // Native focus scrolling can leave a narrow-screen field behind the fixed toast.
    // Center the recovery target while retaining Tabler's field and toast styling.
    first.scrollIntoView({ block: 'center', behavior: 'instant' });
    if (document.activeElement !== first) first.focus({ preventScroll: true });
  }"""
assert old in s;s=s.replace(old,new);file.write_text(s)
(p/'DESIGN-NOTES.md').open('a').write('''\n## Revision — invalid-field visibility repair\n\nA later keyboard inspection found a real failure after the first functional matrix: at 390×844 the first invalid field had focus but sat at y=0 beneath the toast (evidence/keyboard-final-02, command takeover-013). This invalidated the narrow visible-focus claim. The controller now centers the recovery field with native scrollIntoView and focuses it with preventScroll. This is a bounded focus/scroll repair inside the allowed controller; the selected toast source, placement, CSS and motion are unchanged. Retain the original failure and recheck all affected viewport/theme conditions before accepting the repair.\n''')
print(json.dumps({'changed':'app/settings-controller.js','repair':'center first invalid field before focus','visual_source_unchanged':True}))
