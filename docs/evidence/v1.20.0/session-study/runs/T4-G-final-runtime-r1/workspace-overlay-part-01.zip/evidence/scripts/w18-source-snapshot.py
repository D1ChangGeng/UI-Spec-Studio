import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w18');OUT=ROOT/'evidence/source-inspection'
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path=CHROME,headless=True)
  page=await browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
  blocked=[]
  async def route(request):
   url=request.request.url
   if url=='http://127.0.0.1:4418/acquired-upstream-toasts.html': await request.fulfill(status=200,content_type='text/html',body=(ROOT/'sources/official-toasts-snapshot.html').read_text())
   elif url.startswith('http://127.0.0.1:4418/'):await request.continue_()
   else:blocked.append(url);await request.abort()
  await page.route('**/*',route)
  await page.goto('http://127.0.0.1:4418/acquired-upstream-toasts.html',wait_until='domcontentloaded')
  await page.locator('[data-bs-target="#toast-cookies"]').first.click()
  await page.wait_for_timeout(200)
  await page.screenshot(path=str(OUT/'acquired-original-page-local-render.png'))
  await page.locator('#toast-cookies').screenshot(path=str(OUT/'acquired-original-toast-local-render.png'))
  report={'evidence_kind':'acquired deployed original HTML rendered locally','source':'sources/official-toasts-snapshot.html','configuration':'exact acquired HTML fulfilled at local test route; matching supplied Tabler assets; nonlocal requests blocked','action':'native Cookies toast trigger clicked','viewport':[1440,900],'dpr':1,'blocked_nonlocal_urls':blocked,'toast_html':await page.locator('#toast-cookies').evaluate('el=>el.outerHTML'),'limitations':'Live public origin failed TLS verification; this is a local rendering of the supplied snapshot, not a live original-site observation. Portrait and other optional missing local assets remain unavailable.'}
  (OUT/'acquired-original-page-observation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
  print(json.dumps({'result':'captured','blocked_nonlocal_requests':len(blocked),'source':'acquired official snapshot'}))
  await browser.close()
asyncio.run(main())
