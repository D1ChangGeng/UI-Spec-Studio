import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w18');OUT=ROOT/'evidence/temporal-01';OUT.mkdir(parents=True,exist_ok=True)
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path=CHROME,headless=True)
  for theme,lang in [('light','en'),('dark','zh')]:
   ctx=await browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1,timezone_id='UTC');page=await ctx.new_page()
   await page.goto(f'http://127.0.0.1:4418/?theme={theme}&lang={lang}',wait_until='networkidle')
   await page.locator('#save-settings').focus();await page.evaluate('scrollTo({top:document.documentElement.scrollHeight,behavior:"instant"})')
   await page.evaluate('''async()=>{window.toastEvents=[];for(const name of ['show.bs.toast','shown.bs.toast','hide.bs.toast','hidden.bs.toast']) document.querySelector('#save-notification').addEventListener(name,()=>toastEvents.push({event:name,at:performance.now()}));const store=await import('./settings-store.js');store.subscribeSettings(event=>toastEvents.push({event:event.status,operationId:event.operationId,at:performance.now()}));}''')
   start=await page.evaluate('performance.now()');await page.keyboard.press('Enter')
   frames=[]
   for target in [0,100,220,400,650,900]:
    now=await page.evaluate('performance.now()');remaining=start+target-now
    if remaining>0:await page.wait_for_timeout(remaining)
    before=await page.evaluate('''()=>{const el=document.querySelector('#save-notification'),s=getComputedStyle(el);return {at:performance.now(),state:el.dataset.state,className:el.className,opacity:s.opacity,focus:document.activeElement.id,scroll:[scrollX,scrollY]}}''')
    file=f'{theme}-{lang}-{target:04d}ms.png';await page.screenshot(path=str(OUT/file))
    after=await page.evaluate('performance.now()');frames.append({'file':file,'requested_target_ms':target,'capture_start':before,'capture_end_ms':after,'offset_start_ms':before['at']-start})
   report={'clock':'browser performance.now, real time','start_ms':start,'frames':frames,'events':await page.evaluate('toastEvents'),'limitations':'Ordered screenshots at measured capture brackets. No live or video playback was viewed; gaps between samples do not establish smoothness.'}
   (OUT/f'{theme}-{lang}.json').write_text(json.dumps(report,indent=2)+'\n')
   await ctx.close()
  await browser.close()
 print(json.dumps({'result':'captured','episodes':2,'ordered_frames':12}))
asyncio.run(main())
