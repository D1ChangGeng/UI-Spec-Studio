import asyncio,json,time,hashlib,traceback
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path('/workspace/scratch/708e8b7f118e/ui-study/worksets/w18')
OUT=ROOT/'evidence/verification-01'; OUT.mkdir(parents=True,exist_ok=True)
CHROME='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell'
KEY='fieldnotes-settings-v1'
reports=[]
async def state(page,name):
  await page.wait_for_function('(s)=>document.querySelector("#save-notification").dataset.state===s',arg=name)
async def shot(page,folder,name,events):
  before=await page.evaluate('performance.now()')
  await page.screenshot(path=str(folder/(name+'.png')))
  obs=await page.evaluate('''() => ({at:performance.now(),state:document.querySelector('#save-notification').dataset.state,focus:document.activeElement.id,scroll:[scrollX,scrollY],viewport:[innerWidth,innerHeight],toast:(()=>{const r=document.querySelector('#save-notification').getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,right:r.right,bottom:r.bottom}})(),message:document.querySelector('#save-notification-message').textContent,summary:document.querySelector('#save-status').textContent,overflow:document.documentElement.scrollWidth>innerWidth})''')
  events.append({'capture':name+'.png','capture_start_browser_ms':before,**obs})
async def stored(page): return await page.evaluate('(key)=>localStorage.getItem(key)',KEY)
async def run_case(browser,width,height,theme,lang):
  name=f'{width}x{height}-{theme}-{lang}'; folder=OUT/name; folder.mkdir()
  ctx=await browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1,locale='zh-CN' if lang=='zh' else 'en-US')
  page=await ctx.new_page(); events=[]; errors=[]
  page.on('pageerror',lambda error: errors.append(str(error)))
  report={'case':name,'events':events,'page_errors':errors,'checks':[],'browser':browser.version}
  reports.append(report)
  def check(label,ok,detail=None):
    item={'check':label,'pass':bool(ok)}
    if detail is not None:item['detail']=detail
    report['checks'].append(item)
    assert ok,label
  try:
    await page.goto(f'http://127.0.0.1:4418/?theme={theme}&lang={lang}',wait_until='networkidle')
    await page.evaluate('document.fonts.ready')
    await shot(page,folder,'01-initial-whole',events)
    check('requested theme',await page.locator('html').get_attribute('data-bs-theme')==theme)
    check('single live announcement owner',await page.locator('#save-status').get_attribute('role') is None and await page.locator('#save-status').get_attribute('aria-live')=='off' and await page.locator('#save-notification').get_attribute('aria-live')=='polite')
    await page.locator('#business-name').fill('Saved version · 一')
    await page.locator('#weekly-digest').uncheck()
    await page.locator('#public-profile').check()
    await page.locator('#save-settings').focus()
    await page.keyboard.press('Enter')
    await state(page,'pending')
    check('keyboard submit retains initiating focus',await page.evaluate('document.activeElement.id')=='save-settings')
    check('pending prevents duplicate submit',await page.locator('#save-settings').get_attribute('aria-disabled')=='true')
    check('pending has no retry action',not await page.locator('#retry-save').is_visible())
    await shot(page,folder,'02-pending-first-feedback',events)
    await page.locator('#business-name').fill('Newer draft · 二')
    await shot(page,folder,'03-edit-during-pending',events)
    await state(page,'success')
    value=json.loads(await stored(page))
    check('stored submitted snapshot',value['settings']['displayName']=='Saved version · 一' and value['settings']['weeklyDigest']==False and value['settings']['publicProfile']==True,value)
    check('later draft retained after success',await page.locator('#business-name').input_value()=='Newer draft · 二')
    check('success does not steal input focus',await page.evaluate('document.activeElement.id')=='business-name')
    check('success time derives from stored timestamp',await page.locator('#save-notification-time').get_attribute('title')==value['savedAt'])
    check('later edits explained in form summary',('之后的编辑尚未保存' if lang=='zh' else 'Later edits are not saved') in await page.locator('#save-status').inner_text())
    await page.evaluate('scrollTo(0,0)')
    await shot(page,folder,'04-success-whole',events)
    before=await stored(page)
    await page.locator('#business-name').fill('Retry snapshot · 三')
    await page.evaluate('window.fieldnotes.setFailureMode(true)')
    await page.locator('#save-settings').click()
    await state(page,'pending')
    await page.locator('#business-name').fill('Keep later edits · 四')
    await state(page,'error')
    check('failed write preserves previous storage',await stored(page)==before)
    check('failed write preserves current draft',await page.locator('#business-name').input_value()=='Keep later edits · 四')
    check('error exposes source action row',await page.locator('#retry-save').is_visible())
    await page.evaluate('scrollTo(0,0)')
    await page.locator('#retry-save').focus()
    await shot(page,folder,'05-error-retry-focus-whole',events)
    bounds=events[-1]['toast']
    check('toast contained within viewport',bounds['x']>=0 and bounds['right']<=width and bounds['bottom']<=height,bounds)
    check('no horizontal page overflow',not events[-1]['overflow'])
    report['source_shell']=await page.locator('#save-notification').evaluate('''el=>{const s=getComputedStyle(el),h=getComputedStyle(el.querySelector('.toast-header')),b=getComputedStyle(el.querySelector('.toast-body')),a=getComputedStyle(el.querySelector('#save-notification-actions'));return {width:s.width,fontSize:s.fontSize,lineHeight:s.lineHeight,border:s.border,boxShadow:s.boxShadow,borderRadius:s.borderRadius,headerPadding:h.padding,bodyPadding:b.padding,actionMargin:a.marginTop,actionPadding:a.paddingTop,transition:s.transition}}''')
    await page.keyboard.press('Enter')
    await state(page,'pending')
    check('retry disappearance returns focus',await page.evaluate('document.activeElement.id')=='save-settings')
    await shot(page,folder,'06-retry-pending-return',events)
    await state(page,'success')
    retry_value=json.loads(await stored(page))
    check('retry persists exact failed snapshot',retry_value['settings']['displayName']=='Retry snapshot · 三',retry_value)
    check('retry leaves unrelated newer draft intact',await page.locator('#business-name').input_value()=='Keep later edits · 四')
    check('success hides action row',not await page.locator('#retry-save').is_visible())
    await shot(page,folder,'07-retry-success-lower-controls',events)
    await page.locator('#save-notification .btn-close').focus()
    await page.keyboard.press('Enter')
    await page.wait_for_function('!document.querySelector("#save-notification").classList.contains("show")')
    check('native close returns keyboard focus',await page.evaluate('document.activeElement.id')=='save-settings')
    check('close does not mutate stored value',await stored(page)==json.dumps(retry_value,ensure_ascii=False,separators=(',',':')))
    before=await stored(page)
    await page.locator('#business-name').fill('')
    await page.locator('#email').fill('invalid')
    await page.locator('#save-settings').click()
    await state(page,'invalid')
    check('invalid submit preserves storage',await stored(page)==before)
    check('invalid focus moves to first erroneous field',await page.evaluate('document.activeElement.id')=='business-name')
    check('field errors are associated',await page.locator('#business-name').get_attribute('aria-describedby')=='business-name-error' and await page.locator('#business-name').get_attribute('aria-invalid')=='true' and await page.locator('#email-error').is_visible())
    check('invalid toast names actual first field',('显示名称' if lang=='zh' else 'Display name') in await page.locator('#save-notification-message').inner_text())
    await shot(page,folder,'08-invalid-field-focus',events)
    await page.locator('#cancel-settings').click()
    check('cancel restores stored snapshot',await page.locator('#business-name').input_value()=='Retry snapshot · 三')
    check('cancel clears error association',await page.locator('#business-name').get_attribute('aria-invalid') is None)
    await page.locator('#save-notification .btn-close').click()
    await page.wait_for_timeout(180)
    await page.evaluate('scrollTo(0,0)')
    await shot(page,folder,'09-close-and-return-header',events)
    await page.locator('#theme-toggle').click()
    check('existing theme control remains operable',await page.locator('html').get_attribute('data-bs-theme')!=theme)
    await page.locator('#theme-toggle').click()
    await page.reload(wait_until='networkidle')
    check('browser reload restores saved value',await page.locator('#business-name').input_value()=='Retry snapshot · 三')
    check('no page JavaScript errors',not errors,errors)
    report['result']='pass'
  except Exception as exc:
    report['result']='fail';report['error']=str(exc)
    await page.screenshot(path=str(folder/'FAILURE.png'))
    raise
  finally:
    (folder/'episode.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    await ctx.close()
async def additional(browser):
  ctx=await browser.new_context(viewport={'width':1440,'height':900},reduced_motion='reduce')
  page=await ctx.new_page(); report={'case':'concurrency-dismiss-storage-boundary','checks':[]};reports.append(report)
  def check(name,ok):
    report['checks'].append({'check':name,'pass':bool(ok)});assert ok,name
  try:
    await page.goto('http://127.0.0.1:4418/?theme=light&lang=en&fail=once',wait_until='networkidle')
    await page.evaluate('window.fieldnotes.saveSettings(window.fieldnotes.draft()).catch(()=>{}); window.fieldnotes.saveSettings({...window.fieldnotes.draft(),displayName:""}).catch(()=>{})')
    await state(page,'invalid')
    await page.wait_for_timeout(800)
    check('older error cannot overwrite newer invalid result',await page.locator('#save-notification').get_attribute('data-state')=='invalid')
    await page.locator('#business-name').fill('Dismiss during pending')
    await page.locator('#save-settings').click()
    await state(page,'pending')
    await page.locator('#save-notification .btn-close').click()
    await state(page,'success')
    await page.wait_for_timeout(200)
    check('close during pending does not cancel save',json.loads(await stored(page))['settings']['displayName']=='Dismiss during pending')
    check('new result replaces dismissed pending feedback',await page.locator('#save-notification').is_visible())
    before=await stored(page)
    await page.evaluate('window.originalStorageSet=Storage.prototype.setItem; Storage.prototype.setItem=function(key,value){if(key==="fieldnotes-settings-v1")throw new DOMException("Injected storage quota failure","QuotaExceededError");return window.originalStorageSet.call(this,key,value)}')
    await page.locator('#business-name').fill('Storage boundary retry')
    await page.locator('#save-settings').click();await state(page,'error')
    check('storage exception leaves previous value',await stored(page)==before)
    await page.evaluate('Storage.prototype.setItem=window.originalStorageSet')
    await page.locator('#retry-save').click();await state(page,'success')
    check('retry after storage recovery reaches boundary',json.loads(await stored(page))['settings']['displayName']=='Storage boundary retry')
    await page.screenshot(path=str(OUT/'reduced-motion-boundary-success.png'))
    report['result']='pass'
  finally:
    (OUT/'additional.json').write_text(json.dumps(report,indent=2)+'\n');await ctx.close()
async def main():
  result={'browser_conditions':'Chrome headless shell 143, DPR 1, real time, native transitions; ordered screenshots, no playback claim','reports':reports}
  try:
    async with async_playwright() as pw:
      browser=await pw.chromium.launch(executable_path=CHROME,headless=True)
      for width,height in [(1440,900),(1280,600),(390,844)]:
        for theme,lang in [('light','en'),('dark','zh')]: await run_case(browser,width,height,theme,lang)
      await additional(browser)
      await browser.close()
    expected=json.loads((ROOT/'evidence/baseline/read-only-sha256.json').read_text())
    result['read_only_files_unchanged']=all(hashlib.sha256((ROOT/file).read_bytes()).hexdigest()==digest for file,digest in expected.items())
    assert result['read_only_files_unchanged']
    result['result']='pass'
  except Exception as exc:result['result']='fail';result['error']=str(exc);traceback.print_exc()
  finally:
    (OUT/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'result':result['result'],'completed_cases':len(reports),'checks':sum(len(r['checks']) for r in reports),'output':str(OUT),'error':result.get('error')},ensure_ascii=False))
  if result['result']!='pass':raise SystemExit(1)
asyncio.run(main())
