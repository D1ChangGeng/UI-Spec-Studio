# Fieldnotes — editorial research workspace delivered

The working TiddlyWiki 5.4.1 application now uses **Vanilla Paper 0.10.0** as its complete visual foundation. It preserves the eight supplied notes, native story river, search/tags, editor, drafts and real server-backed saving. The selected direction carries through long bilingual reading and editing: a bounded warm paper sheet, fine red margin, strong serif headings, quieter navigation, and a ruled monospace editor.

## Run the product

From this work package:

```bash
cd /workspace/scratch/c0a45b688c5b/ui-study/active-worksets/w11-final/app
PORT=4411 ./start.sh
```

Open **http://127.0.0.1:4411/** in a browser that can reach this executor. The required start state opens the project index and interview, using English UI and Paper Day. The connected user browser cannot reach executor localhost; verification used the provided local Chrome subprocess. The verification server is stopped at handover; the runnable source remains ready to launch.

Use the native pencil/checkmark to edit/save. Choose **Control Panel → Appearance → Palette → Vanilla Paper Night** for the dark condition. The native sidebar toggle gives a quieter reading view. Simplified Chinese remains available in the Control Panel.

## What was selected, and why

Paper was compared with **Notebook**, which offers a materially different arrangement: centered sans serif sheets, fixed search/actions, a left navigation area and bottom mobile controls. Notebook shows more content immediately on mobile. Paper was selected because its publication-like hierarchy and manuscript-like editor better carry the requested editorial studio identity during ordinary populated work. Tufte CSS was inspected as a cross-domain typographic reference; it was not imported as a replacement workspace.

The adopted source is [BurningTreeC/vanilla-paper](https://github.com/BurningTreeC/vanilla-paper), commit **031a78d4d4187128c632f8a647fa05408eddc700**, licensed MIT by Simon Huber. The complete 55-file theme and its license are retained under `app/wiki/themes/vanilla-paper/`; the original repository is retained under `evidence/sources/vanilla-paper/`. The theme supplies layout, surfaces, typography, editor presentation, native-control styling, responsive composition, palettes and sidebar behavior. The vendored TiddlyWiki distribution was not modified.

Only two changes alter the selected source behavior:

- The supported **toolbaralways=yes** setting keeps note actions visible at rest.
- One existing reduced-motion CSS declaration changes **150 ms to 1 ms**, resolving a cascade conflict that overrode the source layout's own quiet-state rule. The exact patch and original/product hashes are retained.

No W1/W2/W3 original construction exception was used. No image, font payload, remote service or animation engine was added. The source's system font stacks and the supplied CJK font fixture carry the typography.

## Actual result and evidence

The primary designer personally opened all twelve final reading/editing views: Day and Night at **1440×900, 1280×640 and 390×844**, plus startup, lower interview content, the evidence ledger, keyboard focus, Chinese UI and sampled sidebar episodes.

Representative captures:

- [Desktop startup](sandbox:/workspace/scratch/c0a45b688c5b/ui-study/active-worksets/w11-final/evidence/delivery-start-1440.png)
- [Day reading](sandbox:/workspace/scratch/c0a45b688c5b/ui-study/active-worksets/w11-final/evidence/final-reading-day-1440.png) and [Night editing](sandbox:/workspace/scratch/c0a45b688c5b/ui-study/active-worksets/w11-final/evidence/final-editing-night-1440.png)
- [Narrow reading](sandbox:/workspace/scratch/c0a45b688c5b/ui-study/active-worksets/w11-final/evidence/final-reading-day-390.png) and [narrow editing](sandbox:/workspace/scratch/c0a45b688c5b/ui-study/active-worksets/w11-final/evidence/final-editing-night-390.png)
- [Evidence ledger](sandbox:/workspace/scratch/c0a45b688c5b/ui-study/active-worksets/w11-final/evidence/verified-ledger-day-1440.png)
- [Keyboard focus after search](sandbox:/workspace/scratch/c0a45b688c5b/ui-study/active-worksets/w11-final/evidence/delivery-keyboard-note-focus.png)

The page retains the source's proportions and material in the actual product. English and Chinese paragraphs remain complete. The editor's different type and ruling make the mode change visible while preserving the same note. At narrow width, tags and toolbars wrap and the native actions remain reachable. All six inspected reading conditions measured no page-wide horizontal overflow.

### Executed product checks

| Check | Observed result |
|---|---|
| Read the complete interview, open Evidence ledger, return | Passed; lower content, final Chinese question, links and table retained |
| Edit an English and a Chinese passage, save, inspect disk, reload | Passed; filesystem content and reloaded native store agreed exactly |
| Restore the original interview through the UI | Passed; exact original text confirmed after reload |
| Start and cancel an edit | Passed; existing note preserved |
| Search and reach editor with keyboard | Passed using native search, Arrow Down/Enter, Tab navigation and Enter on the focused pencil |
| Native palette chooser | Passed; selected Paper Night through Control Panel controls |
| Light/dark reading and editing at all three viewports | Captured and personally viewed after settling |
| Reduced motion | Repaired and rechecked: computed transition 0.001 s versus normal 0.4 s; first sampled reduced geometry already settled |
| Chinese UI | Viewed at 1440×900 in Night; authored bilingual content preserved |
| Final defaults and draft cleanup | English/Day confirmed; no temporary drafts remain |
| Offline build | `npm run build` passed |

The save verifier's first attempt assumed the seed filename, but the native filesystem adaptor renamed the saved note. A corrected check resolved it by native title. Earlier theme-selector, Control Panel locator, locale-logging and keyboard-label failures are preserved beside their corrected attempts. Early editor screenshots caught entry transitions and were superseded by settled final captures. None of those failed attempts is presented as a pass.

## Limits and remaining validation

Paper's author describes unfinished testing, and its public demo runs 5.5.0-prerelease; the actual product checks above were performed separately on the required **5.4.1** server. They support this supplied task, not blanket compatibility with every plugin or browser.

The narrow initial state places roughly 380 px of sidebar before the first sheet. That is a retained source tradeoff; navigation or the native toggle brings reading forward. Metadata and idle controls remain visually subdued. A full contrast/accessibility audit, screen-reader review, physical mobile keyboard/IME test, Firefox/Safari check and injected network-failure recovery remain unperformed. Chinese UI was sampled, not tested across the entire viewport/state matrix.

Temporal evidence consists of operated controls, timestamped geometry and personally viewed ordered frames. A WebM was retained, but no natural-speed playback was performed. No smoothness, frame-rate or user-preference claim is made. Owner acceptance remains pending.

## Handover records

- [DESIGN-DECISIONS.md](sandbox:/workspace/scratch/c0a45b688c5b/ui-study/active-worksets/w11-final/DESIGN-DECISIONS.md) — goal, comparison, adopted responsibilities, revisions and remaining scope.
- [VISUAL-REVIEW.md](sandbox:/workspace/scratch/c0a45b688c5b/ui-study/active-worksets/w11-final/VISUAL-REVIEW.md) — exact viewed coverage and static/temporal limits.
- [SOURCE-ADOPTION.md](sandbox:/workspace/scratch/c0a45b688c5b/ui-study/active-worksets/w11-final/SOURCE-ADOPTION.md) — source, rights, retention and maintenance.
- [RESEARCH-REPORT.md](sandbox:/workspace/scratch/c0a45b688c5b/ui-study/active-worksets/w11-final/evidence/research/RESEARCH-REPORT.md) — independent source inquiry and actual demo/trial observations.
- [final-verification-v3.json](sandbox:/workspace/scratch/c0a45b688c5b/ui-study/active-worksets/w11-final/evidence/final-verification-v3.json), [verification-002.json](sandbox:/workspace/scratch/c0a45b688c5b/ui-study/active-worksets/w11-final/evidence/verification-002.json), and [keyboard-check-v2.json](sandbox:/workspace/scratch/c0a45b688c5b/ui-study/active-worksets/w11-final/evidence/keyboard-check-v2.json) — actual scoped outcomes, including retained failures.
- `evidence/commands/`, `evidence/view-*.json`, `evidence/adoption-manifest.json`, `evidence/paper-reduced-motion.patch`, and `DELEGATION.json` retain original command/tool outputs, captures, source comparisons and child coordination. Backend identity, total tokens and billed cost remain unknown because the host does not expose them.
