# Fieldnotes visual review

## Observation boundary
Primary designer personally opened actual PNGs with `view_image`; full actual returned image objects are retained as `evidence/view-*.json`. These are Chrome headless shell 143 captures at device scale factor 1, with `FONTCONFIG_FILE=/tmp/ui-spec-fonts/fonts.conf`. The final product is the pinned TiddlyWiki 5.4.1 server. Public source-demo versions differ and are labeled in the research report.

## Source and challenger observations
Viewed the Vanilla baseline, original Paper/Notebook/Tufte source demos, and matched-content Paper/Notebook trials. The baseline has an exceptionally broad white elevated sheet and largely uniform sans hierarchy. Paper supplies a coherent narrower sheet, warm surrounding field, fine red margin, strong serif hierarchy and ruled editing surface. Notebook's centered sans sheets and persistent action bar are a substantial compositional challenger; its mobile presentation begins reading immediately and its blue-grey/orange dark palette expresses a more utilitarian tool. Paper was chosen for the explicit editorial identity while retaining its practical mobile tradeoff.

## Final static views personally inspected
- `delivery-start-1440.png`, `delivery-start-390.png`: final English Day startup, both required default notes, visible pencil controls, native search/sidebar. Mobile places navigation above the sheet rather than hiding it automatically.
- `final-reading-{day,night}-{1440,1280,390}.png`: all six opened individually at their actual CSS viewports. Reading measure stays bounded on desktop; mixed scripts and headings wrap without overlap. Narrow text remains within the screen. The margin rule disappears from narrow composition as supplied by source; sheet identity remains through color and type.
- `final-editing-{day,night}-{1440,1280,390}.png`: all six opened individually after settling. Title focus is visible, tags and tools wrap, native save/cancel remain at the note head, and ruled body text remains readable. Short height reduces visible content but preserves document scrolling and controls. Narrow editor has a dense three-row toolbar; no hidden content was removed to improve the view.
- `verified-journey-reading-{0,1,2}.png` and `verified-ledger-day-1440.png`: lower interview passages, final unresolved Chinese question, note links, and four-row evidence body table retained. The ledger wraps long cells naturally; no content shortening occurred.
- `delivery-keyboard-note-focus.png`: visible pencil focus on the unfinished Quiet route note after native search and Tab navigation. The screenshot also shows the real result list. The separate log establishes Enter opens the editor.
- `final-chinese-night-1440.png`: Chinese navigation/date formatting and mixed-language authored content are legible in Night.

Earlier `verified-editor-*` captures sampled entry at 200 ms and showed partial opacity/placement. They are transition samples, not settled appearance. The later `final-editing-*` captures wait for settling and supersede them for static claims.

## Temporal inspection
Opened ordered normal sidebar before/early/settled frames and reduced early/settled frames: `episode-no-preference-before.png`, `episode-no-preference-0.png`, `episode-no-preference-2.png`, `episode-reduce-0.png`, `episode-reduce-2.png`. The source moves the reading sheet toward the center while maintaining its own width. Reduced-motion repair computes 1 ms instead of the previously observed 150 ms. Captures are bracketed with real monotonic timestamps in `final-verification-v3.json`; recorded geometry is already settled at the first reduced sample. Capture overhead limits cadence. A WebM recording of functional checks is retained, but no natural-speed video playback was performed, so smoothness, frame rate and every intervening state remain unverified.

## Functional evidence versus perceptual judgment
`verification-002.json` contains actual disk/reload, restoration and cancellation results (its late locale logging error is retained). `final-verification-v3.json` is a completed passing capture/variant/native-palette/reduced-motion run with no page errors. `keyboard-check-v2.json` verifies search result selection, 21 Tab advances to the target pencil, Enter into editor and no remaining draft. The first keyboard check's English-label assumption failed under the test's persisted Chinese locale; the final English/default state was repaired and rechecked. `commands/019-build/` records the successful offline build.

These checks support an operable, expressive local result. They do not establish user preference, formal accessibility acceptance or broad device/browser reliability. The source's muted metadata/control colors, mobile navigation occupancy, physical IME/keyboard, assistive technology, network failure recovery, broader plugins and natural-speed motion review remain explicit limits.
