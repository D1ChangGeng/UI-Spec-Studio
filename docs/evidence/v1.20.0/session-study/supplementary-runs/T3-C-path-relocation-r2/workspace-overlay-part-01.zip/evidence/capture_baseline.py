import json, time
from pathlib import Path
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
 page.goto('http://127.0.0.1:4411/',wait_until='networkidle')
 page.screenshot(path='evidence/baseline-1440.png')
 print(json.dumps({'title':page.title(),'buttons':page.locator('button').evaluate_all('(xs)=>xs.slice(0,35).map(x=>({title:x.title,aria:x.getAttribute("aria-label"),text:x.textContent}))'),'tiddlers':page.locator('.tc-tiddler-frame').evaluate_all('(xs)=>xs.map(x=>({title:x.getAttribute("data-tiddler-title"),box:x.getBoundingClientRect().toJSON()}))')},ensure_ascii=False,indent=2))
 b.close()
