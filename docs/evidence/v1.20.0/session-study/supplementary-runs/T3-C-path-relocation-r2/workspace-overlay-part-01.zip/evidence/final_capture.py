import json,time,hashlib
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent.parent; EV=ROOT/'evidence'; I='访谈笔记 — 傍晚通勤'
log={'checks':[],'errors':[],'episodes':[]}
def add(n,v): log['checks'].append({'name':n,'result':v});print(n,json.dumps(v,ensure_ascii=False))
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
 page.on('pageerror',lambda e:log['errors'].append(str(e)))
 page.on('dialog',lambda d:d.accept())
 try:
  page.goto('http://127.0.0.1:4411/',wait_until='networkidle');page.wait_for_timeout(600)
  add('theme',page.evaluate('$tw.wiki.getTiddlerText("$:/theme")'))
  add('restored original interview',page.evaluate('(t)=>$tw.wiki.getTiddlerText(t)',I)==(EV/'interview-original-text.txt').read_text())
  add('all supplied notes',page.evaluate('$tw.wiki.filterTiddlers("[!is[system]!has[draft.of]]")'))
  # Palette choice through native Control Panel controls.
  page.get_by_role('button',name='control panel',exact=True).click();page.wait_for_timeout(600)
  page.get_by_role('button',name='Appearance',exact=True).click();page.get_by_role('button',name='Palette',exact=True).click();page.wait_for_timeout(200)
  print('palette controls',page.locator('.tc-tiddler-frame[data-tiddler-title="$:/ControlPanel"] button').all_text_contents())
  page.get_by_role('button',name='Vanilla Paper Night',exact=True).click();page.wait_for_timeout(500)
  add('native palette control changed setting',page.evaluate('$tw.wiki.getTiddlerText("$:/palette")'))
  page.locator('.tc-tiddler-frame[data-tiddler-title="$:/ControlPanel"]').get_by_role('button',name='close',exact=True).click();page.wait_for_timeout(500)
  for palette,label in [('$:/palettes/VanillaPaperDay','day'),('$:/palettes/VanillaPaperNight','night')]:
   page.evaluate('(x)=>$tw.wiki.setText("$:/palette","text",null,x)',palette);page.wait_for_timeout(400)
   for w,h in [(1440,900),(1280,640),(390,844)]:
    page.set_viewport_size({'width':w,'height':h})
    page.evaluate('$tw.wiki.setText("$:/state/sidebar","text",null,"yes")');page.wait_for_timeout(500)
    page.locator('.tc-sidebar-lists a').filter(has_text=I).first.click();page.wait_for_timeout(650)
    n=page.locator('.tc-tiddler-frame[data-tiddler-title="'+I+'"]');n.evaluate('(e)=>e.scrollIntoView({block:"start"})');page.wait_for_timeout(250)
    page.screenshot(path=str(EV/f'final-reading-{label}-{w}.png'))
    add(f'no page overflow {label} {w}',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
    n.get_by_role('button',name='Edit this tiddler',exact=True).click();page.wait_for_timeout(750)
    edit=page.locator('.tc-tiddler-frame').filter(has=page.get_by_role('button',name='Confirm changes to this tiddler',exact=True));edit.evaluate('(e)=>e.scrollIntoView({block:"start"})');page.wait_for_timeout(200)
    page.screenshot(path=str(EV/f'final-editing-{label}-{w}.png'))
    page.get_by_role('button',name='Discard changes to this tiddler',exact=True).click();page.wait_for_timeout(650)
  # Source sidebar motion episode: real captures bracketed by monotonic timestamps.
  page.set_viewport_size({'width':1440,'height':900})
  for mode in ['no-preference','reduce']:
   page.emulate_media(reduced_motion=mode)
   page.evaluate('$tw.wiki.setText("$:/state/sidebar","text",null,"yes")');page.wait_for_timeout(700)
   add('transition duration '+mode,page.locator('.tc-page-container').evaluate('(e)=>getComputedStyle(e).transitionDuration'))
   start=time.monotonic()
   page.screenshot(path=str(EV/f'episode-{mode}-before.png'))
   page.get_by_role('button',name='hide sidebar',exact=True).click()
   for j,delay in enumerate([0,110,400]):
    page.wait_for_timeout(delay);a=time.monotonic();page.screenshot(path=str(EV/f'episode-{mode}-{j}.png'));z=time.monotonic()
    log['episodes'].append({'mode':mode,'frame':j,'capture_bracket_seconds':[a-start,z-start],'geometry':page.locator('.tc-story-river').bounding_box()})
   page.get_by_role('button',name='show sidebar',exact=True).click();page.wait_for_timeout(700)
  page.emulate_media(reduced_motion='reduce')
  page.evaluate('$tw.wiki.setText("$:/language","text",null,"$:/languages/zh-Hans")');page.wait_for_timeout(500)
  page.screenshot(path=str(EV/'final-chinese-night-1440.png'))
  add('Chinese UI',page.locator('.tc-sidebar-tabs').inner_text()[:140])
  page.evaluate('$tw.wiki.setText("$:/language","text",null,"$:/languages/en-GB");$tw.wiki.setText("$:/palette","text",null,"$:/palettes/VanillaPaperDay")');page.wait_for_timeout(500)
  page.reload(wait_until='networkidle');page.wait_for_timeout(600);page.screenshot(path=str(EV/'final-start-1440.png'))
  add('no remaining drafts',page.evaluate('$tw.wiki.filterTiddlers("[has[draft.of]]").length')==0)
  add('final source theme',page.evaluate('$tw.wiki.getTiddlerText("$:/theme")'))
 except Exception as e:
  add('ERROR',repr(e));page.screenshot(path=str(EV/'final-capture-failure.png'));raise
 finally:
  (EV/'final-verification.json').write_text(json.dumps(log,ensure_ascii=False,indent=2));b.close()
