import json,time
from pathlib import Path
from playwright.sync_api import sync_playwright
results={}
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900});page.set_default_timeout(5000)
 page.goto('http://127.0.0.1:4411/',wait_until='networkidle')
 s=page.locator('.tc-search input').first;s.fill('Quiet route');page.wait_for_timeout(400)
 results['result_links']=page.locator('.tc-search-drop-down a').all_text_contents()
 page.screenshot(path='evidence/final-keyboard-search.png')
 s.press('ArrowDown');s.press('Enter');page.wait_for_timeout(700)
 results['native_search_enter_opened_note']=page.locator('.tc-tiddler-frame[data-tiddler-title="Quiet route — working draft"]').count()==1
 steps=[]
 for i in range(100):
  a=page.evaluate('({tag:document.activeElement.tagName,label:document.activeElement.getAttribute("aria-label"),note:document.activeElement.closest(".tc-tiddler-frame")?.getAttribute("data-tiddler-title")})')
  steps.append(a)
  if a.get('label')=='Edit this tiddler' and a.get('note')=='Quiet route — working draft':
   page.screenshot(path='evidence/final-keyboard-note-focus.png');page.keyboard.press('Enter');page.wait_for_timeout(700);break
  page.keyboard.press('Tab')
 results['tab_sequence']=steps
 results['keyboard_editor_opened']=page.get_by_role('button',name='Confirm changes to this tiddler',exact=True).count()==1
 if results['keyboard_editor_opened']:
  page.get_by_role('button',name='Discard changes to this tiddler',exact=True).click();page.wait_for_timeout(700)
 results['no_draft_remains']=page.evaluate('$tw.wiki.filterTiddlers("[has[draft.of]]").length')==0
 print(json.dumps(results,ensure_ascii=False,indent=2));Path('evidence/keyboard-check.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));b.close()
