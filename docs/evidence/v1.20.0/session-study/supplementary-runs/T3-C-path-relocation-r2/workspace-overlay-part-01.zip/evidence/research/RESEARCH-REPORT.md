# Fieldnotes UI source research

## Decision-useful finding

**Continue the real-application trial of Vanilla Paper; retain Notebook as the materially different challenger.** Paper carries the requested editorial character through populated reading and the native editor, rather than supplying only a palette. Notebook offers a credible competing composition with denser sans serif reading, persistent search/actions and immediate access to content on mobile. These are research findings for the parent designer, not a final product choice or acceptance.

The supplied Vanilla baseline was actually viewed at 1440×900: a very broad white note sheet, large sans serif headings and a pale right sidebar. Paper and Notebook both constrain the reading sheet more strongly, but allocate surrounding space and navigation differently.

## Sources, reuse scope and rights

| Source | Exact acquired identity and route | What it can supply | Adoption limit |
|---|---|---|---|
| [Vanilla Paper](https://github.com/BurningTreeC/vanilla-paper), [public demo](https://burningtreec.github.io/vanilla-paper/) | Theme 0.10.0; repository commit `031a78d4d4187128c632f8a647fa05408eddc700`; MIT, copyright Simon Huber 2026. Demo SHA-256 `8af35c85bbfa8cb858150bbc999e77f6dd7f53cbbd5d7ea5096c89a3f66d5e42`. Source tree and license retained. | A standalone whole-workspace theme: layout, typography, paper surface, native-control treatment, editor treatment, day/night palettes and sidebar mechanism. | Public demo runs **TiddlyWiki 5.5.0-prerelease**; theme metadata declares core ≥5.3.0. Appearance on that demo cannot establish compatibility with the required 5.4.1 server. |
| [Notebook](https://github.com/NicolasPetton/Notebook), [community-linked demo](https://saqimtiaz.github.io/sq-tw/notebook.html) | Theme 1.4.1, mobile plugin 1.0.0; repository commit `465c832c885894ee3c97be76449cc524e1252eb0`; MIT. Complete source in `sources/Notebook-master/`. Demo SHA-256 `6d27fac424ee7fd20b35e9268fb75b4547cfbafe70b8d7536217f74781ee118b`. | Centered sheets, custom left sidebar, fixed top search/actions, bottom mobile actions, coordinated grey/beige/dark palettes, editor styling. | Depends on Vanilla and its notebook-mobile plugin. Demo runs **5.3.3**, while repository source dates to 2021. Existing keyboard, plugin and core compatibility need current-app checks. |
| [Tufte CSS](https://edwardtufte.github.io/tufte-css/), [source](https://github.com/edwardtufte/tufte-css) | Complete downloaded source archive; CSS MIT, copyright Dave Liepmann 2014. Archive hash in `fetch-006.json`. | Cross-domain editorial reference and reusable article typography/margin system. | Article system, not an editable TiddlyWiki workspace. No native navigation, persistence or complete dark workspace. It should not be treated as permission to reconstruct a new shell. Font redistribution was not separately audited. |

The author’s [Paper announcement](https://talk.tiddlywiki.org/t/vanilla-notebook-now-paper-theme/15545) explicitly describes incomplete coverage of other palettes, phones, plugins and accessibility. That is a useful maturity limit, not a reason to discard the source: inspect the actual supplied task instead of importing an unsupported blanket maturity claim.

## Actual observed relationships

### Paper: editorial reading and materially distinct editing

In the original demo, the warm desktop surrounds a lighter page with a fine red vertical margin. Serif headings and body text establish a publication-like reading rhythm; the sidebar retains smaller sans serif controls. The narrow paper column and broad surrounding field create a recognizable working surface without imagery or continuous decorative motion.

With **all eight supplied notes copied unchanged into an isolated demo’s in-memory store**, the long interview keeps that character. English prose is visibly serif; Chinese uses the host-provided CJK fallback. The two scripts remain readable and share a roomy paragraph rhythm. The evidence here is static appearance of the inspected portion, not a measured reading-comprehension result.

Entering the native editor changes to monospace text over subtle horizontal ruling. The margin, page material and native title/tags/actions remain recognizable, so the mode change is clear while the working object remains identifiable. Paper’s resting note controls are hidden in the original demo; action discovery therefore warrants configuration/keyboard review. The parent reports using the source’s `toolbaralways=yes` configuration, which should be checked in the assembled app.

At 390×844 the source initially stacks roughly 385 px of sidebar above the first note. After navigating to the interview, the reading sheet fits the viewport without document-wide horizontal overflow in the sampled state. The dark palette preserves a warm near-black sheet, off-white reading text and olive tags. It exposes less interview text per screen than Notebook because the reading type and line spacing are larger.

### Notebook: a credible competing work-tool composition

Notebook’s original beige demo centers an 800 px sheet beneath a fixed bar containing search and global actions. It uses sans serif type throughout. The left sidebar is closed initially; opening it produces a 350 px navigation column with Open, Recent, Tools and More as stacked sections, while the sheet shifts right.

The populated interview shows more bilingual content in the same frame than Paper. The large bold body heading competes more strongly with the note title; this is a different hierarchy, not merely a color variant. Editing keeps the same sheet and compact plain input typography, without Paper’s manuscript-like material change.

On mobile, Notebook begins directly with the note and fixes actions to the bottom. This is its clearest practical advantage over Paper’s initial mobile state. Its dark palette is blue-grey with bright orange tags, a stronger utility-tool character than Paper’s warm editorial night condition. The sampled mobile document width was exactly 390 px for a 390 px viewport.

Source inspection also found `button:focus, button:active { outline: 0 none; }` and hover-reveal control rules in Notebook’s base stylesheet. This is a **code-level concern**, not a completed keyboard accessibility finding. A real adoption would need to verify visible keyboard focus and use supported options or narrow source-preserving repair.

### Tufte CSS: useful expression reference, limited integration scope

The viewed opening article combines serif reading type, italic author text, understated underlined links and a large right-side reserve. It shows how proportion and typography can carry identity without adding illustrative imagery. The documentation describes sidenotes and narrow-screen toggles; those lower-page interactions were not operated here. The source does not solve Fieldnotes’ editable workspace contract, so adopting an entire Tufte page would carry substantially more integration and visual-reconstruction risk than a native theme.

## Temporal observation and a consequential gap

At 1280×640 I operated each downloaded theme’s native sidebar trigger and return under normal and reduced-motion conditions. Ordered screenshots and capture-time brackets are retained in `episode-015.json`; important frames were opened with the image viewer.

Paper’s normal episode shows the reading sheet moving toward the center as the right sidebar moves out. Reading width stays stable in the viewed frames. Notebook opens a left navigation region and shifts the intact 800 px sheet.

**Paper’s reduced-motion condition needs a focused real-app check.** The early reduced-motion geometry recorded the sidebar already at x=1280, but the story region still at an intermediate width of 1202.8 px, between its initial 920 px and final 1280 px. The viewed early frame also places the sheet between its initial and settled positions. This suggests the reduced-motion treatment may suppress sidebar movement while leaving layout interpolation. The causal explanation remains an inference until source/configuration inspection confirms it. The parent was notified before integration completion.

These are sampled real-time episodes, not natural-speed video playback, frame-rate measurement, or proof of every intervening frame. No claim of smoothness or interruption handling is made.

## Practical adoption paths and remaining work

For Paper, preserve the complete source theme, notices, defining typography/material and its two source palettes. Configure available options rather than combining it with arbitrary recreated containers. Validate native editor/save/cancel, search/tags, keyboard focus, sidebar quiet behavior, the table and complete interview on the pinned server. The parent owns that real integration and final visual judgment.

For Notebook, install the actual `$:/themes/nico/notebook` theme plus `$:/plugins/nico/notebook-mobile`, retaining Vanilla and source notices. Its supplied palette switcher and metrics support configuration. Do not copy only its colors and then claim its whole composition was adopted.

No product files were changed by this researcher. The populated trials used in-memory fixtures in downloaded public demos. Native editor entry was exercised; no authoritative save, reload persistence or native cancellation pass is claimed. The trial reset removed a temporary draft in memory after the cancellation locator failed to match. The parent’s separate server tests must establish those product outcomes.

## Evidence index

All paths below are relative to `evidence/research/`.

- Search/source exports: `search-001.json`, `web-002.json`, `search-003.json`; direct acquisition responses, headers, errors and digests: `fetch-004.json`, `fetch-006.json`.
- Original demos actually viewed: `paper-demo-1440.png`, `notebook-demo-1440.png`, `tufte-demo-1440.png`, plus `paper-demo-390.png` and `notebook-demo-390.png`.
- Matched-content comparison actually viewed: `paper-trial-interview-1440-v2.png`, `notebook-trial-interview-1440.png`, `paper-trial-editor-1440-v2.png`, `notebook-trial-editor-1440-v2.png`, `paper-trial-dark-390-v2.png`, `notebook-trial-dark-390-v2.png`. Trial conditions and controls: `trials-012.json`.
- Sidebar episodes: `episode-015.json` and `*-episode-*-v2.png`. Viewed normal Paper before/early/settled, reduced Paper early, and settled Notebook open frames are recorded in `view-016-*.json`.
- Full actual image-tool responses: `view-005-*.json`, `view-008-*.json`, `view-009-*.json`, `view-011-*.json`, `view-013-*.json`, `view-016-*.json`.
- Reproducible scripts and exact stdout/stderr/timestamps: `commands/004-fetch/`, `006-fetch/`, `007-render/`, `010-trial/`, `012-trial/`, `014-episode/`, `015-episode/`. Failed locator attempts remain preserved in 010 and 014; corrected runs are separate.

All browser processes used the specified Chrome 143 executable, device scale 1 and `FONTCONFIG_FILE=/tmp/ui-spec-fonts/fonts.conf`. The requested method and eight common references were read. No further research agents were created. Final product decisions and acceptance remain with the parent designer.

