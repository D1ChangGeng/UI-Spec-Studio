import urllib.request,json,pathlib,concurrent.futures,hashlib,time
root=pathlib.Path(__file__).parent
urls={
"notebook-demo.html":"https://saqimtiaz.github.io/sq-tw/notebook.html",
"notebook-readme.md":"https://raw.githubusercontent.com/NicolasPetton/Notebook/master/README.md",
"notebook-license.txt":"https://raw.githubusercontent.com/NicolasPetton/Notebook/master/LICENSE",
"paper-readme.md":"https://raw.githubusercontent.com/BurningTreeC/vanilla-paper/main/README.md",
"paper-license.txt":"https://raw.githubusercontent.com/BurningTreeC/vanilla-paper/main/LICENSE",
"paper-repo.json":"https://api.github.com/repos/BurningTreeC/vanilla-paper",
"notebook-repo.json":"https://api.github.com/repos/NicolasPetton/Notebook",
"tufte-demo.html":"https://edwardtufte.github.io/tufte-css/"
}
(root/"sources").mkdir(exist_ok=True)
def grab(k,u):
 start=time.time()
 try:
  with urllib.request.urlopen(u,timeout=30) as r: data=r.read();meta={"url":u,"status":r.status,"headers":dict(r.headers)}
  (root/"sources"/k).write_bytes(data)
  return {"file":k,**meta,"sha256":hashlib.sha256(data).hexdigest(),"bytes":len(data),"elapsed":time.time()-start}
 except Exception as e:return {"file":k,"url":u,"error":repr(e),"elapsed":time.time()-start}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex: records=list(ex.map(lambda kv:grab(*kv),urls.items()))
(root/"fetch-004.json").write_text(json.dumps(records,indent=2))
print(json.dumps(records,indent=2))

