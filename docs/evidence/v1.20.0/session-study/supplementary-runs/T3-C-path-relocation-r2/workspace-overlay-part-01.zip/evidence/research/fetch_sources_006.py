import urllib.request,json,pathlib,hashlib,time,zipfile,io,concurrent.futures
root=pathlib.Path(__file__).parent
urls={
"paper-demo.html":"https://burningtreec.github.io/vanilla-paper/",
"paper-tree.json":"https://api.github.com/repos/BurningTreeC/vanilla-paper/git/trees/main?recursive=1",
"notebook-commit.json":"https://api.github.com/repos/NicolasPetton/Notebook/commits/master",
"paper-commit.json":"https://api.github.com/repos/BurningTreeC/vanilla-paper/commits/main",
"notebook-source.zip":"https://codeload.github.com/NicolasPetton/Notebook/zip/refs/heads/master",
"tufte-source.zip":"https://codeload.github.com/edwardtufte/tufte-css/zip/refs/heads/gh-pages"
}
def grab(k,u):
 start=time.time()
 try:
  with urllib.request.urlopen(u,timeout=30) as r: data=r.read();meta={"url":u,"status":r.status,"headers":dict(r.headers)}
  (root/"sources"/k).write_bytes(data)
  if k.endswith(".zip"):
   with zipfile.ZipFile(io.BytesIO(data)) as z:z.extractall(root/"sources")
  return {"file":k,**meta,"sha256":hashlib.sha256(data).hexdigest(),"bytes":len(data),"elapsed":time.time()-start}
 except Exception as e:return {"file":k,"url":u,"error":repr(e),"elapsed":time.time()-start}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex: records=list(ex.map(lambda kv:grab(*kv),urls.items()))
(root/"fetch-006.json").write_text(json.dumps(records,indent=2))
print(json.dumps([{k:r.get(k) for k in ("file","status","error","sha256","bytes")} for r in records],indent=2))

