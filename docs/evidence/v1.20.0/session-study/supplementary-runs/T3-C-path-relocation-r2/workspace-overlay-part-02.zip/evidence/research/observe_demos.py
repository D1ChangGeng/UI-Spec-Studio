import asyncio,json,pathlib,time,os
from playwright.async_api import async_playwright
root=pathlib.Path(__file__).parent
async def main():
 records=[]
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path="/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell",headless=True,args=["--no-sandbox"])
  for name,rel in [("notebook","notebook-demo.html"),("paper","paper-demo.html"),("tufte","tufte-css-gh-pages/index.html")]:
   page=await browser.new_page(viewport={"width":1440,"height":900},device_scale_factor=1)
   errors=[];page.on("pageerror",lambda e:errors.append(str(e)))
   url=(root/"sources"/rel).resolve().as_uri()
   t0=time.time()
   try:
    await page.goto(url,wait_until="domcontentloaded",timeout=15000)
    await page.wait_for_timeout(1200)
    await page.evaluate("document.fonts.ready")
    await page.screenshot(path=str(root/f"{name}-demo-1440.png"))
    info=await page.evaluate("""() => ({title:document.title,buttons:Array.from(document.querySelectorAll('button')).slice(0,80).map(b=>({text:b.textContent.trim().slice(0,50),title:b.title,aria:b.getAttribute('aria-label'),class:b.className})),tiddlers:window.$tw?$tw.wiki.filterTiddlers('[is[tiddler]!is[system]]'):[],theme:window.$tw?$tw.wiki.getTiddlerText('$:/palette'):null,styles:{body:getComputedStyle(document.body).fontFamily}})""")
    records.append({"name":name,"url":url,"elapsed":time.time()-t0,"info":info,"errors":errors})
    await page.set_viewport_size({"width":390,"height":844})
    await page.wait_for_timeout(300)
    await page.screenshot(path=str(root/f"{name}-demo-390.png"))
   except Exception as e:records.append({"name":name,"error":repr(e),"errors":errors})
   await page.close()
  await browser.close()
 (root/"observe-007.json").write_text(json.dumps(records,ensure_ascii=False,indent=2))
 print(json.dumps(records,ensure_ascii=False,indent=2))
asyncio.run(main())

