import asyncio,json,pathlib,time
from playwright.async_api import async_playwright
root=pathlib.Path(__file__).parent
async def frame(page,name,rec):
 t0=time.time();path=root/(name+".png");await page.screenshot(path=str(path))
 data=await page.evaluate("""() => {const box=s=>{const e=document.querySelector(s);if(!e)return null;const r=e.getBoundingClientRect();const c=getComputedStyle(e);return {x:r.x,y:r.y,w:r.width,h:r.height,opacity:c.opacity,display:c.display}};return {clock:performance.now(),story:box('.tc-story-river'),sidebar:box('.tc-sidebar-scrollable'),notebookSidebar:box('.nc-sidebar'),reduced:matchMedia('(prefers-reduced-motion: reduce)').matches}}""")
 rec.append({"file":path.name,"time_bracket":[t0,time.time()],"geometry":data})
async def main():
 records=[]
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path="/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell",headless=True,args=["--no-sandbox"])
  for source in ("notebook","paper"):
   for motion in ("no-preference","reduce"):
    page=await browser.new_page(viewport={"width":1280,"height":640},device_scale_factor=1,reduced_motion=motion)
    await page.goto((root/"sources"/(source+"-demo.html")).resolve().as_uri(),wait_until="domcontentloaded")
    await page.wait_for_timeout(500)
    prefix=source+"-episode-"+motion
    await frame(page,prefix+"-before",records)
    trigger=page.get_by_title("Toggle menu").first if source=="notebook" else page.get_by_title("Hide sidebar")
    await trigger.click()
    await page.wait_for_timeout(60)
    await frame(page,prefix+"-early",records)
    await page.wait_for_timeout(450)
    await frame(page,prefix+"-settled",records)
    reverse=page.get_by_title("Toggle menu").first if source=="notebook" else page.get_by_title("Show sidebar")
    await reverse.click()
    await page.wait_for_timeout(450)
    await frame(page,prefix+"-return",records)
    await page.close()
  await browser.close()
 (root/"episode-014.json").write_text(json.dumps(records,indent=2))
 print(json.dumps(records,indent=2))
asyncio.run(main())

