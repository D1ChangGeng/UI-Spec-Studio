import asyncio,json,pathlib,time
from playwright.async_api import async_playwright
root=pathlib.Path(__file__).parent
package=root.parent.parent
notes=[]
for f in (package/"app/wiki/tiddlers").glob("note-*.tid"):
 head,body=f.read_text().split("\n\n",1)
 fields=dict(line.split(": ",1) for line in head.splitlines() if ": " in line)
 notes.append({**fields,"text":body})
interview="访谈笔记 — 傍晚通勤"
async def shot(page,name,records):
 await page.evaluate("document.fonts.ready")
 start=time.time();path=root/(name+".png");await page.screenshot(path=str(path))
 records.append({"capture":path.name,"time_bracket":[start,time.time()],"viewport":page.viewport_size,"scroll":await page.evaluate("({x:scrollX,y:scrollY})")})
async def main():
 records=[]
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path="/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell",headless=True,args=["--no-sandbox"])
  for source in ("notebook","paper"):
   page=await browser.new_page(viewport={"width":1440,"height":900},device_scale_factor=1)
   await page.goto((root/"sources"/(source+"-demo.html")).resolve().as_uri(),wait_until="domcontentloaded")
   await page.wait_for_timeout(700)
   await page.evaluate("""notes=>{for(const n of notes)$tw.wiki.addTiddler(n);$tw.wiki.setText('$:/SiteTitle','text',null,'Fieldnotes');$tw.wiki.setText('$:/SiteSubtitle','text',null,'研究笔记 · Local research notebook');$tw.wiki.setText('$:/StoryList','list',null,['Fieldnotes — project index','访谈笔记 — 傍晚通勤']);}""",notes)
   await page.wait_for_timeout(300)
   await shot(page,source+"-trial-index-1440",records)
   await page.get_by_role("link",name=interview,exact=True).first.click()
   await page.wait_for_timeout(500)
   await shot(page,source+"-trial-interview-1440",records)
   frame=page.locator('.tc-tiddler-frame').filter(has=page.locator('.tc-title-text',has_text=interview))
   await frame.locator('button[title="Edit this tiddler"]').click()
   await page.wait_for_timeout(500)
   await shot(page,source+"-trial-editor-1440",records)
   records.append({"source":source,"editorButtons":await page.locator('.tc-tiddler-edit-frame button').evaluate_all("(els)=>els.map(e=>({title:e.title,text:e.textContent.trim().slice(0,50)}))")})
   cancel=page.locator('button[title="Cancel editing this tiddler"]')
   if await cancel.count():await cancel.first.click()
   else:
    records.append({"source":source,"cancelTitles":await page.locator('button').evaluate_all("(els)=>els.map(e=>e.title).filter(t=>/cancel/i.test(t))")})
    await page.evaluate("""()=>{const ds=$tw.wiki.filterTiddlers('[has[draft.of]]');ds.forEach(d=>$tw.wiki.deleteTiddler(d));$tw.wiki.setText('$:/StoryList','list',null,['访谈笔记 — 傍晚通勤']);}""")
   await page.wait_for_timeout(200)
   dark="$:/themes/nico/notebook/palettes/palette-dark" if source=="notebook" else "$:/palettes/VanillaPaperNight"
   await page.evaluate("(palette)=>$tw.wiki.setText('$:/palette','text',null,palette)",dark)
   await page.wait_for_timeout(200)
   await page.evaluate("scrollTo(0,document.querySelector('.tc-tiddler-frame[data-tiddler-title=\"访谈笔记 — 傍晚通勤\"]').getBoundingClientRect().top+scrollY)")
   await shot(page,source+"-trial-dark-1440",records)
   await page.set_viewport_size({"width":390,"height":844})
   await page.wait_for_timeout(250)
   await page.evaluate("scrollTo(0,document.querySelector('.tc-tiddler-frame[data-tiddler-title=\"访谈笔记 — 傍晚通勤\"]').getBoundingClientRect().top+scrollY)")
   await shot(page,source+"-trial-dark-390",records)
   records.append({"source":source,"horizontal":await page.evaluate("({client:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth})"),"core":await page.evaluate("$tw.version")})
   await page.close()
  await browser.close()
 (root/"trials-010.json").write_text(json.dumps(records,ensure_ascii=False,indent=2))
 print(json.dumps(records,ensure_ascii=False,indent=2))
asyncio.run(main())

