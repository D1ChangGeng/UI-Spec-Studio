import json, time
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
 page.goto('http://127.0.0.1:4411/',wait_until='networkidle')
 page.screenshot(path='evidence/trial-paper-index-1440.png')
 print('theme',page.evaluate('$tw.wiki.getTiddlerText("$:/theme")'))
 note=page.locator('.tc-tiddler-frame[data-tiddler-title="访谈笔记 — 傍晚通勤"]')
 page.locator('.tc-tiddler-body').first.get_by_role('link',name='访谈笔记 — 傍晚通勤',exact=True).click()
 page.wait_for_timeout(500)
 page.screenshot(path='evidence/trial-paper-interview-1440.png')
 note.get_by_role('button',name='Edit this tiddler',exact=True).click()
 page.wait_for_timeout(400)
 page.screenshot(path='evidence/trial-paper-edit-1440.png')
 print('textareas',page.locator('textarea').count(),'frames',len(page.frames))
 print(json.dumps(page.locator('button').evaluate_all('(xs)=>xs.filter(x=>x.closest(".tc-tiddler-frame")).map(x=>({title:x.title,aria:x.getAttribute("aria-label"),text:x.textContent}))'),ensure_ascii=False))
 b.close()
