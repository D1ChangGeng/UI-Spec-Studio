import json, time, hashlib
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent.parent
EV=ROOT/'evidence'
INTERVIEW='访谈笔记 — 傍晚通勤'
TITLE='Fieldnotes — project index'
results={'conditions':{'browser':'Chrome headless shell 143','dpr':1,'fontconfig':'/tmp/ui-spec-fonts/fonts.conf'},'checks':[], 'console_errors':[], 'requests':[]}
def log(name,value):
 results['checks'].append({'name':name,'result':value,'time':time.time()}); print(name, json.dumps(value,ensure_ascii=False))
def record(page,name):
 page.screenshot(path=str(EV/name))
def note(page,title=INTERVIEW):
 return page.locator('.tc-tiddler-frame').filter(has=page.locator('.tc-title').filter(has_text=title)).first

def bytitle(page,title):
 return page.locator('.tc-tiddler-frame').filter(has=page.locator('.tc-title').filter(has_text=title)).first

def open_interview(page):
 page.locator('.tc-sidebar-lists a').filter(has_text=INTERVIEW).first.click()
 page.wait_for_timeout(500)

def body_editor(page):
 for frame in page.frames:
  if frame!=page.main_frame and frame.locator('textarea').count(): return frame.locator('textarea').first
 return page.locator('textarea.tc-edit-texteditor').first

def click_edit(page,title=INTERVIEW):
 page.locator('.tc-tiddler-frame[data-tiddler-title="'+title+'"]').get_by_role('button',name='Edit this tiddler',exact=True).click()
 page.wait_for_timeout(200)
 return body_editor(page)

def save(page):
 page.get_by_role('button',name='Confirm changes to this tiddler',exact=True).click()
 page.wait_for_timeout(900)

def cancel(page):
 page.get_by_role('button',name='Discard changes to this tiddler',exact=True).click()
 page.wait_for_timeout(400)

with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-preview-browser/chrome-headless-shell-143.0.7499.4/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 context=b.new_context(viewport={'width':1440,'height':900},device_scale_factor=1,record_video_dir=str(EV/'videos'),record_video_size={'width':1440,'height':900})
 page=context.new_page()
 page.on('pageerror',lambda err:results['console_errors'].append(str(err)))
 page.on('response',lambda r:results['requests'].append({'method':r.request.method,'url':r.url,'status':r.status}) if r.request.method in ['PUT','DELETE'] else None)
 page.on('dialog',lambda d:d.accept())
 try:
  page.goto('http://127.0.0.1:4411/',wait_until='networkidle')
  # Supported theme setting: preserve native note action discovery.
  page.evaluate('$tw.wiki.setText("$:/themes/BurningTreeC/vanilla-paper/options/toolbaralways","text",null,"yes")')
  page.wait_for_timeout(500)
  original=(EV/'interview-original-text.txt').read_text()
  if page.evaluate('(title)=>$tw.wiki.getTiddlerText(title)',INTERVIEW)!=original:
   open_interview(page); e=click_edit(page); e.fill(original); save(page)
  record(page,'verified-index-day-1440.png')
  open_interview(page)
  record(page,'verified-interview-day-1440.png')
  interview=page.locator('.tc-tiddler-frame[data-tiddler-title="'+INTERVIEW+'"]')
  print('links',interview.locator('a').all_text_contents())
  # Walk the complete text through ordinary document scrolling.
  box=interview.bounding_box(); start=page.evaluate('scrollY')
  for i,dy in enumerate([650,1300,1950]):
   page.evaluate('(y)=>scrollTo(0,y)',start+dy); page.wait_for_timeout(100); record(page,f'verified-journey-reading-{i}.png')
  log('complete interview available',interview.inner_text()[-600:])
  interview.get_by_role('link',name='Evidence ledger',exact=True).click()
  page.wait_for_timeout(500); record(page,'verified-ledger-day-1440.png')
  ledger=page.locator('.tc-tiddler-frame[data-tiddler-title="Evidence ledger"]')
  log('ledger rows',ledger.locator('tr').count())
  page.locator('.tc-sidebar-lists a').filter(has_text=INTERVIEW).first.click(); page.wait_for_timeout(500)
  log('returned interview',interview.is_visible())
  editor=click_edit(page)
  assert editor.input_value()==original
  changed=original.replace('A route remembered through small anchors','A route remembered through small, familiar anchors',1).replace('从描述到问题','从描述到研究问题',1)
  assert changed!=original
  editor.fill(changed); record(page,'verified-journey-edited-bilingual.png'); save(page)
  disk=next(f for f in (ROOT/'app/wiki/tiddlers').glob('*.tid') if f.read_text().startswith('created:') and ('title: '+INTERVIEW+'\n') in f.read_text() or f.read_text().startswith('title: '+INTERVIEW+'\n'))
  log('disk save English and Chinese', 'small, familiar anchors' in disk.read_text() and '从描述到研究问题' in disk.read_text())
  page.reload(wait_until='networkidle')
  log('reload exact persisted text',page.evaluate('(title)=>$tw.wiki.getTiddlerText(title)',INTERVIEW)==changed)
  # Restore original authored text through the same real save path.
  open_interview(page); editor=click_edit(page); editor.fill(original); save(page)
  page.reload(wait_until='networkidle')
  log('original restored after reload',page.evaluate('(title)=>$tw.wiki.getTiddlerText(title)',INTERVIEW)==original)
  open_interview(page); editor=click_edit(page); editor.fill(original+'\nTemporary cancellation check.'); cancel(page)
  log('cancel preserves existing note',page.evaluate('(title)=>$tw.wiki.getTiddlerText(title)',INTERVIEW)==original)
  # Native search followed by keyboard activation into the editor.
  search=page.locator('.tc-search input').first
  search.fill('Quiet route'); page.wait_for_timeout(500)
  print('search links',page.locator('.tc-search a').all_text_contents())
  search.press('Tab'); page.keyboard.press('Tab')
  target=page.get_by_role('link',name='Quiet route — working draft',exact=True).last
  target.focus(); page.keyboard.press('Enter'); page.wait_for_timeout(400)
  draftnote=page.locator('.tc-tiddler-frame[data-tiddler-title="Quiet route — working draft"]')
  btn=draftnote.get_by_role('button',name='Edit this tiddler',exact=True)
  btn.focus(); record(page,'keyboard-editor-focus.png'); page.keyboard.press('Enter'); page.wait_for_timeout(200)
  log('keyboard search-to-editor',body_editor(page).count()>0)
  cancel(page); search.fill('')
  # Palette/locale setup uses the native wiki setting. Task interactions remain visible controls.
  for palette,label in [('$:/palettes/VanillaPaperDay','day'),('$:/palettes/VanillaPaperNight','night')]:
   page.evaluate('(x)=>$tw.wiki.setText("$:/palette","text",null,x)',palette)
   page.wait_for_timeout(300)
   for width,height in [(1440,900),(1280,640),(390,844)]:
    page.set_viewport_size({'width':width,'height':height})
    page.evaluate('$tw.wiki.setText("$:/state/sidebar","text",null,"yes")'); page.wait_for_timeout(300)
    open_interview(page)
    record(page,f'verified-interview-{label}-{width}.png')
    log(f'overflow {label} {width}',page.evaluate('({client:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth})'))
    editor=click_edit(page); record(page,f'verified-editor-{label}-{width}.png'); cancel(page)
    if width==390:
     page.get_by_role('button',name='hide sidebar',exact=True).click(); page.wait_for_timeout(500)
     page.locator('.tc-tiddler-frame[data-tiddler-title="'+INTERVIEW+'"]').scroll_into_view_if_needed()
     record(page,f'verified-interview-{label}-390-quiet.png')
  page.set_viewport_size({'width':1440,'height':900})
  page.evaluate('$tw.wiki.setText("$:/state/sidebar","text",null,"yes")')
  page.emulate_media(reduced_motion='reduce'); page.wait_for_timeout(200)
  log('reduced motion computed',page.locator('.tc-page-container').evaluate('(x)=>({duration:getComputedStyle(x).transitionDuration,property:getComputedStyle(x).transitionProperty})'))
  record(page,'verified-reduced-night-1440.png')
  page.evaluate('$tw.wiki.setText("$:/language","text",null,"$:/languages/zh-Hans")');page.wait_for_timeout(400)
  record(page,'verified-chinese-ui-night-1440.png')
  log('Chinese interface present',page.locator('.tc-sidebar-lists').inner_text()[:180])
  page.evaluate('$tw.wiki.setText("$:/language","text",null,"$:/languages/en-GB");$tw.wiki.setText("$:/palette","text",null,"$:/palettes/VanillaPaperDay")')
  page.wait_for_timeout(700)
 except Exception as e:
  log('ERROR',repr(e));record(page,'verification-failure-002.png');raise
 finally:
  (EV/'verification-002.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
  context.close(); b.close()
