# 引文如何支持综合笔记：研究结论与后续模型

## 已存在的事实

当前笔记只有 `{ title: string, body: string }`，保存键仍为 `ui-spec-content-note-v1`。没有 note ID、原文资源、quotation ID、句段 ID、版本号或支持边。正文中写着某个来源，不能证明它真实存在、引文逐字准确，或它支持哪一句结论。本轮没有推断或保存任何此类关系。

## 建议的第一种表示

建议从“综合笔记段落 + 对应证据条目”开始：读者选中一条结论，可以查看关联的引文原句、来源、页码/段落位置、关系说明和确认状态，并跳回原文上下文。窄屏顺序阅读；桌面可以在既有编辑器旁逐步展开。首先保障原文与结论的对应关系，之后才评估节点图。

Zotero 的官方说明展示了成熟的回溯链：加入笔记的 annotation 保持 citation 和返回原 PDF 的链接，用户可回到原页查看上下文。它说明“引文应能回到原文”，不代表本项目已拥有 Zotero 数据或已接入其实现。[Zotero PDF Reader and Note Editor](https://www.zotero.org/support/pdf_reader)

W3C Web Annotation Data Model 的 `TextQuoteSelector` 用 exact、prefix、suffix 定位引文；`TextPositionSelector` 用字符区间定位，但官方指出文本变动会使位置脆弱，需结合版本/状态。可把这些字段作为引文定位设计依据，不能把“定位成功”当作“支持结论已成立”。[W3C Web Annotation Data Model](https://www.w3.org/TR/annotation-model/)

## 比较的表示方向

| 方向 | 适用价值 | 当前限制与选择 |
|---|---|---|
| 结论与引文对照列表 | 逐条核查语义、来源与上下文，便于键盘和窄屏阅读 | 推荐首先实现；仍需真实映射数据 |
| 文内引用标记 + 来源侧栏 | 更贴近连续阅读，能从结论直接返回来源 | 需要稳定段落/引文 ID 与编辑后锚点恢复 |
| 节点关系图 | 多条结论共享多条引文时，可显示结构与缺口 | 现有数据没有边；先造图会把推测画成事实，不应在当前产品中伪装成已确认网络 |

## 最小需要增加的信息（提案，未实现）

| 对象 | 最小字段 | 要回答的问题 |
|---|---|---|
| 笔记 | `noteId`, `revision`, `title`, `body` | 关系属于哪份、哪一版笔记？ |
| 结论/句段 | `claimId`, `noteId`, `noteRevision`, `text`, `selector` | 引文具体支持哪句话，而不是整份笔记？ |
| 来源 | `sourceId`, `title`, `url` 或本地文档引用、作者/日期、版本或内容摘要值 | 如何回到原材料并识别它是否变化？ |
| 引文 | `quotationId`, `sourceId`, `exact`, `prefix`, `suffix`, 页码/段落定位、提取时间 | 原句是什么、来自哪里、能否复查？ |
| 关系 | `claimId`, `quotationId`, `relationType`, `rationale`, `status`, `reviewedBy`, `reviewedAt`, 两端版本 | 谁认为它支持/反驳/仅提供背景，为什么，是否确认？ |

`relationType` 和确认责任应先由产品定义。建议至少区分“支持”“反驳”“背景”；状态区分“待核实”“已确认”“来源或文本已变更”。这些是建议的产品语义，不是 W3C 自动规定的事实模型。

编辑后如果结论文本、引文定位或来源版本变化，旧关系应转为待复核而不自动继续显示已确认。没有来源、无法定位、来源无法访问、引文与原文不符要分别表达。未来若提供自动提议，应明确显示“建议关联”，等待实际核查。

## 现在可以支持什么

- 继续保存、编辑和比较完整笔记文本；用户可以在正文里手工记下引文及 URL，但它们只是普通文本。
- 可以设计带有明显“示例/待核实”标签的独立研究原型，验证读者更需要逐句核查还是全局关系；该原型不能宣称显示已有笔记的真实证据。
- 在拿到真实样本、来源访问规则和关系确认责任前，本轮不创建真实支持图，不自动把 URL 或相似词转换成支持边。

## 下一步需要的产品输入

1. 两到三份真实综合笔记及其来源材料，至少包含一例支持、一例反驳/背景和一例无法确认的关系。
2. 确定关系以整份笔记、段落还是句子为粒度；建议句段粒度。
3. 确认引文与关联由用户手工建立、系统提议后核查，还是有其他可信数据输入。
4. 确定来源保存、访问权限与版本失效规则，然后再实现上述数据模型与可点击回溯路径。

## 本轮来源清单及证据边界

均于 2026-10-30 阅读；这些是官方文本/源说明研究，不是假装操作过其完整产品。

- [MDN storage event](https://developer.mozilla.org/en-US/docs/Web/API/Window/storage_event)：同源其他标签页收到 storage 事件；写入所在页面不收到自己的事件。用于真实同步接线。
- [Modern Web Guidance · dialog](https://github.com/GoogleChrome/modern-web-guidance)：通过 CLI 读取 `dialog` 指南，采用原生 `showModal()`、名称关联、native focus/Escape 与滚动 containment；不用自制 trap。
- [Bootstrap 5.3 Modal](https://getbootstrap.com/docs/5.3/components/modal/)：研究通用弹层与网格可用范围；未引入 Bootstrap CSS/JS，因为本项目已接受的视觉系统可承载局部比较，通用 modal 本身也不提供双文本业务比较。
- [Lucide file-text](https://lucide.dev/icons/file-text)：研究普通文件折角语义。没有采用其图形路径或声称它提供 Fieldnote 原创身份。
- Zotero 与 W3C：用于未来引文回溯与锚点的数据方案，不属于本轮已连接能力。
