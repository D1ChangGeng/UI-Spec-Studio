from pathlib import Path
from playwright.sync_api import sync_playwright
root = Path(__file__).parent
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome', headless=True, args=['--no-sandbox'])
    page = browser.new_page(viewport={'width':1440,'height':900}, device_scale_factor=1)
    page.goto('http://127.0.0.1:4317/')
    page.evaluate('document.fonts.ready')
    page.screenshot(path=str(root/'before-desktop.png'))
    page.set_viewport_size({'width':390,'height':844})
    page.screenshot(path=str(root/'before-mobile.png'))
    browser.close()
