from pathlib import Path
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1000,'height':700},device_scale_factor=1)
 page.set_content(Path('evidence/identity.html').read_text()); page.evaluate('document.fonts.ready'); page.screenshot(path='evidence/identity-comparison.png'); b.close()
