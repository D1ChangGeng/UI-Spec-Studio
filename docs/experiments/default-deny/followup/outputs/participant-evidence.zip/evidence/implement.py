from pathlib import Path
p=Path('app/app.js')
s=p.read_text()
s=s.replace("  let retryAction = null;", "  let retryAction = null;\n  let baseSnapshot = 'null';\n  let conflict = null;")
s=s.replace("  function t(name) { return copy[locale][name]; }", """  Object.assign(copy.zh, {
    htmlTitle:'Fieldnote · 研究笔记', compareVersions:'比较两个版本', conflict:'其他标签页修改了这份笔记。请比较版本后再保存。',
    conflictEyebrow:'版本冲突', conflictTitle:'要保留哪个版本？', conflictIntro:'另一个标签页修改了这份笔记。两份文本暂保留在本页，选择前不会覆盖已保存的版本。',
    localHeading:'本页草稿', localMeta:'尚未保存的修改', remoteHeading:'其他标签页的版本', remoteMeta:'当前浏览器中已保存',
    keepLocal:'保留本页草稿', useRemote:'使用此已保存版本', decideLater:'稍后决定',
    conflictHint:'保留草稿后仍需保存；使用已保存版本会替换本页输入。', earlierVersions:'期间收到的其他版本',
    conflictUpdated:'其他标签页又有更新。这里显示最新版本，先前收到的文本仍可展开查看。',
    keptLocal:'已保留本页草稿，尚未保存。保存后将替换另一版本。', remoteChosen:'已使用其他标签页保存的版本。',
    externalUpdated:'已同步其他标签页保存的内容。', externalCleared:'其他标签页已清除笔记。',
    remoteDeleted:'此笔记已在其他标签页清除', deletionHint:'接受清除会清空本页输入。', useCleared:'接受清除',
    emptyTitle:'（无标题）', emptyBody:'（未填写正文）', conflictReadFailed:'暂时无法确认已保存的版本。请稍后决定，再重试读取；两份文本仍在本页。'
  });
  Object.assign(copy.en, {
    htmlTitle:'Fieldnote · Research notes', compareVersions:'Compare versions', conflict:'Another tab changed this note. Compare the versions before saving.',
    conflictEyebrow:'Version conflict', conflictTitle:'Which version should you keep?', conflictIntro:'Another tab changed this note. Both texts stay on this page until you choose. The saved version will not be overwritten.',
    localHeading:'Your draft', localMeta:'Unsaved changes in this tab', remoteHeading:'Version from another tab', remoteMeta:'Currently saved in this browser',
    keepLocal:'Keep my draft', useRemote:'Use this saved version', decideLater:'Decide later',
    conflictHint:'Keeping your draft still requires saving. Using the saved version replaces your current input.', earlierVersions:'Other versions received meanwhile',
    conflictUpdated:'Another tab updated the note again. The latest version is shown; earlier received text is still available below.',
    keptLocal:'Your draft is kept but not saved. Saving will replace the other version.', remoteChosen:'You are using the version saved by the other tab.',
    externalUpdated:'The note was updated from another tab.', externalCleared:'Another tab cleared the note.',
    remoteDeleted:'This note was cleared in another tab', deletionHint:'Accepting this change will empty your current input.', useCleared:'Accept the cleared version',
    emptyTitle:'(Untitled)', emptyBody:'(No context entered)', conflictReadFailed:'The saved version cannot be checked right now. Decide later, then try reading again. Both texts are still here.'
  });
  function t(name) { return copy[locale][name]; }
  const fingerprint = record => JSON.stringify(record && {title:record.title, body:record.body});
  function parseStored(raw) {
    const data = raw === null ? null : JSON.parse(raw);
    if (raw !== null && (!data || typeof data.title !== 'string' || !data.title.trim() || data.title.length > 150 || typeof data.body !== 'string' || data.body.length > 3000)) throw new SyntaxError('Unrecognized note data');
    return data && {title:data.title, body:data.body};
  }
  function stopPending() {
    if (pending) clearTimeout(pending.timer);
    pending = null;
  }
  function renderConflict() {
    if (!conflict) return;
    $('local-title').textContent = $('note-title').value || t('emptyTitle');
    $('local-body').textContent = $('note-body').value || t('emptyBody');
    $('remote-title').textContent = conflict.remote ? conflict.remote.title : t('remoteDeleted');
    $('remote-body').textContent = conflict.remote ? (conflict.remote.body || t('emptyBody')) : t('deletionHint');
    $('choose-remote').textContent = t(conflict.remote ? 'useRemote' : 'useCleared');
    $('conflict-update').textContent = storageState !== 'ready' ? t('conflictReadFailed') : conflict.history.length ? t('conflictUpdated') : '';
    $('conflict-history').hidden = !conflict.history.length;
    $('conflict-history-list').replaceChildren(...conflict.history.map(record => {
      const paragraph = document.createElement('p');
      paragraph.textContent = record ? record.title + '\\n\\n' + record.body : t('remoteDeleted');
      return paragraph;
    }));
  }
  function openConflict() {
    if (!conflict) return;
    renderConflict();
    if (!$('conflict-dialog').open) $('conflict-dialog').showModal();
  }
  function receiveRecord(data, open = true) {
    const next = fingerprint(data);
    if (conflict && next === fingerprint(conflict.remote)) {
      storageState = 'ready'; showStatus('conflict'); renderConflict(); updateControls(); return false;
    }
    if (!conflict && next === baseSnapshot) return false;
    storageState = 'ready';
    if (draftEdited || pending || conflict) {
      const previous = conflict;
      stopPending();
      const history = previous ? [...previous.history, previous.remote] : [];
      conflict = {remote:data, history};
      savedRecord = data;
      showStatus('conflict'); renderSaved(); renderConflict(); updateControls();
      if (open && !previous) openConflict();
      return true;
    }
    savedRecord = data;
    baseSnapshot = next;
    $('note-title').value = data ? data.title : '';
    $('note-body').value = data ? data.body : '';
    draftTouched = false; draftEdited = false;
    clearFieldError(); showStatus(data ? 'externalUpdated' : 'externalCleared'); renderSaved(); updateControls();
    return true;
  }
  function syncFromStorage(open = true) {
    try { return receiveRecord(parseStored(localStorage.getItem(KEY)), open); }
    catch (error) {
      stopPending(); storageState = 'unavailable';
      showStatus(error instanceof SyntaxError ? 'invalidStored' : 'readFailed');
      renderSaved(); renderConflict(); updateControls(); return true;
    }
  }
  function chooseVersion(local) {
    if (!conflict) return;
    // Check again at the decision boundary; never resolve an unseen newer version.
    let data;
    try { data = parseStored(localStorage.getItem(KEY)); }
    catch { syncFromStorage(false); return; }
    if (fingerprint(data) !== fingerprint(conflict.remote)) { receiveRecord(data, false); return; }
    savedRecord = data; baseSnapshot = fingerprint(data); storageState = 'ready';
    if (!local) {
      $('note-title').value = data ? data.title : '';
      $('note-body').value = data ? data.body : '';
      clearFieldError();
    }
    conflict = null;
    draftEdited = fingerprint(currentRecord()) !== baseSnapshot && Boolean($('note-title').value || $('note-body').value || savedRecord);
    draftTouched = draftEdited;
    $('conflict-dialog').close();
    showStatus(local ? 'keptLocal' : data ? 'remoteChosen' : 'externalCleared');
    renderSaved(); updateControls();
  }
""")
s=s.replace("$('save').disabled = pending !== null || storageState !== 'ready';", "$('save').disabled = pending !== null || storageState !== 'ready' || conflict !== null;\n    $('compare-versions').hidden = conflict === null;\n    $('reset').disabled = conflict !== null;")
start=s.index('  function readStored(')
end=s.index('  function renderLocale()',start)
s=s[:start]+"""  function readStored(initial = false) {
    try {
      const data = parseStored(localStorage.getItem(KEY));
      storageState = 'ready';
      if (!initial && (conflict || (draftEdited && fingerprint(data) !== baseSnapshot))) {
        receiveRecord(data); return;
      }
      savedRecord = data; baseSnapshot = fingerprint(data);
      if (!draftTouched) {
        $('note-title').value = data ? data.title : '';
        $('note-body').value = data ? data.body : '';
      }
      if (!initial) showStatus(draftTouched ? (data ? 'readRecoveredDraft' : 'readRecoveredEmptyDraft') : (data ? 'readRecovered' : 'readRecoveredEmpty'));
    } catch (error) {
      storageState = 'unavailable';
      showStatus(error instanceof SyntaxError ? 'invalidStored' : 'readFailed');
    }
    renderSaved(); renderConflict(); updateControls();
  }

"""+s[end:]
s=s.replace('    renderSaved();\n  }\n\n  function clearFieldError()', '    renderSaved();\n    renderConflict();\n  }\n\n  function clearFieldError()')
start=s.index('  function submit()')
end=s.index('  function clearStored()',start)
s=s[:start]+"""  function submit() {
    if (conflict) { openConflict(); return; }
    if (pending !== null || storageState !== 'ready') return;
    if (syncFromStorage()) return;
    const record = currentRecord();
    if (!record.title) {
      $('note-title').setAttribute('aria-invalid', 'true');
      $('title-error').hidden = false; $('title-error').textContent = t('missing');
      showStatus(''); $('note-title').focus(); return;
    }
    clearFieldError();
    const snapshot = JSON.stringify(record);
    const operation = {timer:null}; pending = operation;
    showStatus('saving'); updateControls();
    const fail = () => {
      if (pending !== operation) return;
      pending = null; showStatus('failed'); updateControls();
    };
    const write = () => {
      if (pending !== operation) return;
      try {
        // A second check after any delay prevents a stale draft from overwriting a new save.
        if (syncFromStorage()) return;
        if ($('simulate-failure').checked) throw new Error('Simulated write failure');
        localStorage.setItem(KEY, snapshot);
        savedRecord = record; baseSnapshot = fingerprint(record); pending = null;
        draftEdited = JSON.stringify(currentRecord()) !== snapshot;
        draftTouched = draftEdited;
        showStatus(draftEdited ? 'savedEarlier' : 'saved'); renderSaved(); updateControls();
      } catch { fail(); }
    };
    operation.timer = setTimeout(() => {
      // Native locks serialize cooperating Fieldnote tabs; older browsers retain the pre-write check.
      if (navigator.locks) navigator.locks.request('fieldnote-note-write', write).catch(fail);
      else write();
    }, $('simulate-slow').checked ? 1000 : 140);
  }

"""+s[end:]
s=s.replace('  function clearStored() {', "  function clearStored() {\n    if (conflict) { openConflict(); return; }")
s=s.replace('    savedRecord = null;\n    storageState', "    savedRecord = null;\n    baseSnapshot = 'null';\n    storageState")
s=s.replace("'readRecoveredEmptyDraft'].includes(status)", "'readRecoveredEmptyDraft', 'keptLocal', 'remoteChosen', 'externalUpdated', 'externalCleared'].includes(status)")
s=s.replace("  readStored(true);", """  $('compare-versions').addEventListener('click', openConflict);
  $('choose-local').addEventListener('click', () => chooseVersion(true));
  $('choose-remote').addEventListener('click', () => chooseVersion(false));
  window.addEventListener('storage', event => {
    if (event.key === KEY || event.key === null) syncFromStorage();
  });
  readStored(true);""")
p.write_text(s)
