from pathlib import Path
import json, time, sys
from playwright.sync_api import sync_playwright
OUT=Path(__file__).parent
URL='http://127.0.0.1:4317/'
KEY='ui-spec-content-note-v1'
results=json.loads((OUT/'verification.json').read_text())['results'] if '--extended-only' in sys.argv else []
def report(name, **details):
 results.append({'check':name,'pass':True,**details})
 (OUT/'verification.json').write_text(json.dumps({'results':results},ensure_ascii=False,indent=2))
def saved(page): page.wait_for_function("document.querySelector('#state-message').textContent === '笔记已保存在此浏览器。' || document.querySelector('#state-message').textContent === 'Note saved in this browser.'")
def value(page): return page.evaluate('(key)=>JSON.parse(localStorage.getItem(key))',KEY)
def configure(page, lang, theme):
    if lang=='en': page.locator('#locale-toggle').click()
    if theme=='dark': page.locator('#theme-toggle').click()
def fill(page,title,body):
    page.locator('#note-title').fill(title); page.locator('#note-body').fill(body)
def settings(page):
    if not page.locator('.fixture-controls details').evaluate('(e)=>e.open'): page.locator('.fixture-controls summary').click()
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
    for width,height in ([] if '--extended-only' in sys.argv else [(390,844),(1440,900)]):
      for lang in ['zh','en']:
       for theme in ['light','dark']:
        tag=f'{width}-{lang}-{theme}'
        context=browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1)
        a=context.new_page(); errors=[]; a.on('pageerror',lambda error:errors.append(str(error)))
        a.goto(URL); configure(a,lang,theme); a.evaluate('document.fonts.ready')
        a.screenshot(path=str(OUT/f'{tag}-empty.png'))
        metrics=a.evaluate("""()=>['note-title','note-body'].map(id=>{let e=document.getElementById(id),s=getComputedStyle(e),p=getComputedStyle(e,'::placeholder'),b=e.getBoundingClientRect();return {id,text:s.fontSize,placeholder:p.fontSize,width:b.width,height:b.height}})""")
        assert all(x['text']=='15px' and x['placeholder']=='13px' for x in metrics),metrics
        assert abs(metrics[0]['height']-49.25)<1 and metrics[1]['height']==145,metrics
        a.locator('#note-title').focus(); a.keyboard.press('Tab')
        assert a.locator('#note-body').evaluate('(e)=>e===document.activeElement')
        a.screenshot(path=str(OUT/f'{tag}-focus.png'))
        title='研究问题：供热高峰' if lang=='zh' else 'Research question: peak heating'
        body='保留原始材料，再核查关键结论。\n每条判断都需要来源。' if lang=='zh' else 'Keep the original sources and verify each claim.\nEach claim needs supporting evidence.'
        fill(a,title,body); a.screenshot(path=str(OUT/f'{tag}-entered.png'))
        a.locator('#save').click(); saved(a); assert value(a)=={'title':title,'body':body}
        a.reload(); configure(a,lang,theme); assert a.locator('#note-body').input_value()==body
        b=context.new_page(); b.goto(URL); configure(b,lang,theme)
        local_title='本页未保存的标题' if lang=='zh' else 'My unsaved title'
        local_body='本页草稿：保留居民访谈记录。\n这些判断尚未核实。' if lang=='zh' else 'My draft: retain the resident interviews.\nThese claims still need verification.'
        remote_title='其他标签页的新标题' if lang=='zh' else 'Updated title from the other tab'
        remote_body='另一版本：补充了供热负荷数据。\n数据来源待复核。' if lang=='zh' else 'Other version: added the heating-load data.\nThe data source still needs checking.'
        fill(a,local_title,local_body); fill(b,remote_title,remote_body); b.locator('#save').click(); saved(b)
        a.locator('#conflict-dialog').wait_for(state='visible')
        assert a.locator('#local-body').inner_text()==local_body
        assert a.locator('#remote-body').inner_text()==remote_body
        assert a.locator('#note-body').input_value()==local_body and value(a)['body']==remote_body
        a.screenshot(path=str(OUT/f'{tag}-conflict.png'))
        for i in range(7):
            a.keyboard.press('Tab'); assert a.evaluate("document.querySelector('#conflict-dialog').contains(document.activeElement) || document.activeElement===document.body")
        a.keyboard.press('Escape'); assert not a.locator('#conflict-dialog').is_visible()
        assert a.locator('#save').is_disabled() and a.locator('#note-body').input_value()==local_body
        a.locator('#compare-versions').click(); a.locator('#choose-local').click()
        assert a.locator('#note-body').input_value()==local_body and value(a)['body']==remote_body
        a.locator('#save').click(); saved(a); assert value(a)['body']==local_body
        b.wait_for_function('(v)=>document.querySelector("#note-body").value===v',arg=local_body)
        fill(a,local_title,local_body+' 2'); fill(b,remote_title,remote_body+' 2'); b.locator('#save').click(); saved(b)
        a.locator('#conflict-dialog').wait_for(state='visible'); a.locator('#choose-remote').click()
        assert a.locator('#note-body').input_value()==remote_body+' 2'
        settings(a); a.locator('#simulate-failure').check(); fill(a,title,body+' retry')
        a.locator('#save').click(); a.locator('#retry').wait_for(state='visible')
        assert a.locator('#note-body').input_value()==body+' retry' and value(a)['body']==remote_body+' 2'
        a.screenshot(path=str(OUT/f'{tag}-failure.png'))
        a.locator('#simulate-failure').uncheck(); a.locator('#retry').click(); saved(a)
        assert value(a)['body']==body+' retry'
        assert a.locator('#note-title').evaluate('(e)=>e===document.activeElement')
        assert a.evaluate('document.documentElement.scrollWidth <= innerWidth'), tag
        assert not errors,errors
        report(tag,metrics=metrics,states=['empty','entered','keyboard focus','save/reload','two real tabs','both conflict choices','Escape/defer/reopen','failure/retry','no horizontal overflow'],errors=errors)
        context.close()
    # Additional races, repeated remote versions, deletion, long text and real boundary faults.
    c=browser.new_context(viewport={'width':390,'height':844}); a=c.new_page(); b=c.new_page(); a.goto(URL); b.goto(URL)
    fill(a,'Original','original'); a.locator('#save').click(); saved(a); b.wait_for_function("document.querySelector('#note-body').value==='original'")
    settings(a); a.locator('#simulate-slow').check(); fill(a,'Pending','pending snapshot'); a.locator('#save').click(); a.locator('#note-body').fill('newer draft during save')
    a.wait_for_function("document.querySelector('#state-message').textContent.includes('上一版已保存')")
    assert value(a)['body']=='pending snapshot' and a.locator('#note-body').input_value()=='newer draft during save'
    a.locator('#save').click(); fill(b,'Remote race','remote won'); b.locator('#save').click(); saved(b)
    a.locator('#conflict-dialog').wait_for(state='visible'); a.wait_for_timeout(1100)
    assert value(a)['body']=='remote won' and a.locator('#local-body').inner_text()=='newer draft during save'
    fill(b,'Remote newer','newer remote'); b.locator('#save').click(); saved(b)
    a.wait_for_function("document.querySelector('#remote-body').textContent==='newer remote'")
    a.locator('#conflict-history summary').click()
    assert a.locator('#conflict-history-list').inner_text().find('remote won')>=0
    a.locator('#choose-local').click(); a.locator('#simulate-slow').uncheck(); a.locator('#save').click(); saved(a)
    fill(a,'Long local','本页很长的文本。\n'*100)
    fill(b,'Long remote','Another longer version with quoted data and context.\n'*40); b.locator('#save').click(); saved(b)
    a.locator('#conflict-dialog').wait_for(state='visible'); a.screenshot(path=str(OUT/'390-zh-light-long-conflict.png'))
    a.locator('#choose-remote').click(); assert 'Another longer' in a.locator('#note-body').input_value()
    fill(a,'Deletion conflict','keep this draft'); settings(b); b.locator('#reset').click(); a.locator('#conflict-dialog').wait_for(state='visible')
    assert a.locator('#choose-remote').inner_text()=='接受清除'; a.locator('#choose-local').click(); assert a.locator('#note-body').input_value()=='keep this draft'
    report('races-and-growth',states=['edit during pending','external write cancels pending','multiple remote versions retained','long conflict text scroll','external deletion retains draft'])
    c.close()
    c=browser.new_context(viewport={'width':1440,'height':900}); a=c.new_page(); a.goto(URL)
    fill(a,'Storage faults','draft'); a.locator('#save').click(); saved(a)
    a.evaluate("() => { window.originalSet=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw new DOMException('quota','QuotaExceededError')}; }")
    a.locator('#note-body').fill('quota draft'); a.locator('#save').click(); a.locator('#retry').wait_for(state='visible'); assert a.locator('#note-body').input_value()=='quota draft'
    a.evaluate('() => { Storage.prototype.setItem=window.originalSet; }'); a.locator('#retry').click(); saved(a)
    settings(a); a.evaluate("() => { window.originalRemove=Storage.prototype.removeItem;Storage.prototype.removeItem=function(){throw new DOMException('denied','SecurityError')}; }")
    a.locator('#reset').click(); assert a.locator('#note-body').input_value()=='quota draft'
    a.evaluate('() => { Storage.prototype.removeItem=window.originalRemove; }'); a.locator('#retry').click(); assert value(a) is None
    a.evaluate("localStorage.setItem('ui-spec-content-note-v1','not-json')"); a.reload(); assert a.locator('#save').is_disabled(); assert a.evaluate("localStorage.getItem('ui-spec-content-note-v1')")=='not-json'
    settings(a); a.locator('#reset').click(); fill(a,'Recovered','safe'); a.locator('#save').click(); saved(a)
    report('native-storage-faults',states=['quota write/retry','remove failure/retry','malformed startup preserved','explicit clear/recovery'])
    c.close(); browser.close()
(OUT/'verification.json').write_text(json.dumps({'browser':'Chrome 156.0.8078.80','viewports':[[390,844],[1440,900]],'deviceScaleFactor':1,'results':results,'limits':['Desktop headless browser only, no physical touch or IME test','No independent user comprehension or screen reader study','Conflict copies are held in page memory until selection; reload recovery is not implemented']},ensure_ascii=False,indent=2))
print(json.dumps({'passed':len(results),'results':[r['check'] for r in results]},ensure_ascii=False))
