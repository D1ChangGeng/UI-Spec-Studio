from pathlib import Path
import json, time, sys
from playwright.sync_api import sync_playwright
OUT=Path(__file__).parent
URL='http://127.0.0.1:4317/'
KEY='ui-spec-content-note-v1'
results=json.loads((OUT/'verification.json').read_text())['results'] if '--extended-only' in sys.argv else []
def report(name, **details):
 results.append({'check':name,'pass':True,**details})
 (OUT/'verification.json').write_text(json.dumps({'results':results},ensure_ascii=False,indent=2))
def saved(page): page.wait_for_function("document.querySelector('#state-message').textContent === '笔记已保存在此浏览器。' || document.querySelector('#state-message').textContent === 'Note saved in this browser.'")
def value(page): return page.evaluate('(key)=>JSON.parse(localStorage.getItem(key))',KEY)
def configure(page, lang, theme):
    if lang=='en': page.locator('#locale-toggle').click()
    if theme=='dark': page.locator('#theme-toggle').click()
def fill(page,title,body):
    page.locator('#note-title').fill(title); page.locator('#note-body').fill(body)
def settings(page):
    if not page.locator('.fixture-controls details').evaluate('(e)=>e.open'): page.locator('.fixture-controls summary').click()
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
    c=browser.new_context(viewport={'width':1440,'height':900}); a=c.new_page(); a.goto(URL)
    fill(a,'Storage faults','draft'); a.locator('#save').click(); saved(a)
    a.evaluate("() => { window.originalSet=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw new DOMException('quota','QuotaExceededError')}; }")
    a.locator('#note-body').fill('quota draft'); a.locator('#save').click(); a.locator('#retry').wait_for(state='visible'); assert a.locator('#note-body').input_value()=='quota draft'
    a.evaluate('() => { Storage.prototype.setItem=window.originalSet; }'); a.locator('#retry').click(); saved(a)
    settings(a); a.evaluate("() => { window.originalRemove=Storage.prototype.removeItem;Storage.prototype.removeItem=function(){throw new DOMException('denied','SecurityError')}; }")
    a.locator('#reset').click(); assert a.locator('#note-body').input_value()=='quota draft'
    a.evaluate('() => { Storage.prototype.removeItem=window.originalRemove; }'); a.locator('#retry').click(); assert value(a) is None
    a.evaluate("localStorage.setItem('ui-spec-content-note-v1','not-json')"); a.reload(); assert a.locator('#save').is_disabled(); assert a.evaluate("localStorage.getItem('ui-spec-content-note-v1')")=='not-json'
    settings(a); a.locator('#reset').click(); fill(a,'Recovered','safe'); a.locator('#save').click(); saved(a)
    report('native-storage-faults',states=['quota write/retry','remove failure/retry','malformed startup preserved','explicit clear/recovery'])
    c.close(); browser.close()
(OUT/'verification.json').write_text(json.dumps({'browser':'Chrome 156.0.8078.80','viewports':[[390,844],[1440,900]],'deviceScaleFactor':1,'results':results,'limits':['Desktop headless browser only, no physical touch or IME test','No independent user comprehension or screen reader study','Conflict copies are held in page memory until selection; reload recovery is not implemented']},ensure_ascii=False,indent=2))
print(json.dumps({'passed':len(results),'results':[r['check'] for r in results]},ensure_ascii=False))
