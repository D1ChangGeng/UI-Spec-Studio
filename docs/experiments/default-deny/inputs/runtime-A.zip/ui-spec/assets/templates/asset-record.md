# Asset record

Use this as a compact note or as fields in the project's existing design/resource record. Keep only detail that affects a decision, reproducibility, delivery or acceptance. Several placements can reference one asset ID.

## Role and direction

Asset ID/family; product task and intended perception; destination surface/state;
relationship with layout, type and components; comparison/reference observations;
selected direction, alternatives and approval source/scope.
Attribute reference qualities to the actual artwork, application UI or surrounding
presentation; link the studied property to its intended use in this product.

## Source and allowed use

Original author/source/item/version; exact terms or permission record; intended
use and public/private destination; allowed adaptation and required notices;
third-party brand/subject conditions where relevant; generated-output provenance.

## Production and editable master

Direct adoption, adaptation or composition; concrete source gap or identity/art purpose for original work;
available tool/version and selected route; original and working source location;
meaningful editable parameters; dependencies, transforms and export steps.
Distinguish an image result, vector outlines, a functioning font, editable scene
and runtime asset according to the actual deliverable.

## Delivery variants and placements

| Variant / file | Format and dimensions | Intended use, theme, crop and density | Loading/runtime policy and fallback | Source identity and owner |
|---|---|---|---|---|

Include color/alpha, byte budget, frame rate/duration/state or model/texture
properties when they matter. Record target device/network conditions and relevant
runtime dependencies. Preserve one current master and reproducible derivatives.

## Observations and acceptance

Actual-size preview, surrounding content, light/dark and narrow/wide conditions;
asset-family checks; accessible role/name; loading/error/reduced-motion behavior;
measured transfer/startup/rendering conditions; actual visual observations;
known limits, approval and remaining work. Recheck affected placements when the
master, export, runtime or target conditions change.

Link the original source, local placement trial and integrated result to actually viewed evidence.
Identify qualities preserved or changed by production and export. For
dynamic material, retain the relevant cycle/transition and peak reach, brightness
or loop seam with its event/time context. State the capture and viewing method;
record a visual finding, its perceptual effect and any resulting production or
layout decision. A recorded clip remains available evidence until it is inspected.
Revisit the original selection question at actual placement, scale and content;
separate the demonstrated effect, adopted file and verified integrated result.
