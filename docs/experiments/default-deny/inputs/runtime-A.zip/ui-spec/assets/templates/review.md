# UI review

## Scope and condition

Design question; reference, candidate's original demo, local trial or integrated journey;
routes/states, viewport, browser, theme, locale, data/font readiness, revision and
actual entry path. Retain the conditions needed to interpret and repeat this review.
For external study, identify the carrier page, player, depicted application or
displayed work; source/date and edited demonstration or operation record.

For formal SPEC review, identify the increment, its experience goal and visual
responsibilities in the current product. Distinguish the broader research scope,
primary implementation and affected-product regression. Identify inherited
decisions and shared dependencies relevant to this review; references to existing
records are sufficient.

## Observation

Start with the whole visible interface at its intended scale, then examine consequential
composition, functional regions and component/asset detail. Name the perceptual dimensions
that answer this task's question. Preserve neighbors/background in detail views and return
to the whole after the close reading or change. Identify native-size, cropped, enlarged,
overview or browser-zoom conditions; record only relevant observations, without a fixed score.
Link the viewed frame or interval to the visible relationship, its likely perceptual effect
and product fit. Record strengths worth adopting or preserving as well as problems.
State the clue that prompted further browsing, the relevant operation and the
newly understood relationship when these explain the decision.

## Temporal episode

When quality changes over time, name the object, starting context, trigger,
meaningful progression and settled result or stopping condition. Explain why the
window covers the question; include relevant reversal, interruption, repeated
input, loop seam, delayed result or connected return.
For scroll-driven behavior, retain scroll position, region and direction.

Link recordings or ordered frames to actual event times and source revision.
Keep video size, frame order, capture-time brackets/cadence, gaps and time-control
settings where they affect interpretation. Identify the intervals actually viewed
and the useful full-size frames. Distinguish natural-speed playback, sampled
frames and controlled-time diagnosis; each supports its stated observation.
Record normal-speed review before/after detailed examination when supported;
keep playback-dependent judgments pending when only sampled frames were viewed.

## Interaction

Task steps, focus/input/selection retention, transitions, error/retry and result.

## Findings and repair

Visual fact and condition → likely perceptual/task effect → design relationship or cause
to investigate → product fit → resource/adaptation choice → local and whole-result recheck.

Keep visual observation, professional interpretation, verified cause and observed user response distinct.
Compare equivalent conditions and meaningful event phases. Attribute a gap to resource fit,
adaptation, real content, conflicting composition or target/task mismatch. Recheck the affected
interval and connected path after changes; keep residual gaps and target changes explicit.

Keep repairs and reinspection serving the promised goal within the current SPEC.
If new evidence changes its boundary, record the reason, original finding,
preserved product goal and the scope now responsible for unresolved work. A new
increment does not establish that the earlier finding was resolved.

## Result

State experience-validity and expressive-completion findings independently. Inspect
the promised language in populated core use, long content, repetition and reduced
motion. For source-fidelity work, identify the baseline, corresponding regions,
intentional differences and capture controls; image metrics remain diagnostic.
Distinguish authored-timeline output from actual product response and performance.

Captured evidence; actually inspected frames/intervals; executed interaction and
engineering checks; current result; actual user approval and remaining conditions.
Provide inspectable candidates or before/after results when they explain an
important choice. State which research question the runnable result answers and
which conclusion remains unsupported. For adoption, identify the source and mechanisms
actually retained in the current implementation, local trial scope and expanded verification.
Existing notes can carry this optional record.

State current-SPEC quality findings and related-product integrity findings
separately. Show how the target quality reaches an observed reference, actual
implementation location, current presentation and remaining gap. Present the
working/renderable entry and decisive evidence in the conversation, with important
choices and the next useful increment; writing this record alone is not delivery.
For a product UI, inspect whether real tasks and visual/interaction results carry
the design, with internal method explanations kept in their appropriate record.

For a research or selection decision, assess coverage breadth, inspection depth,
temporal completeness, relevance and reliability together. Identify evidence that
changed the experience hypothesis or candidate choice; keep unobserved conditions
and material disagreements visible. Explain whether the next useful action is
further discovery, a bounded trial or broader implementation. An accomplished
search sequence alone does not establish design readiness.

## Content review

Identify the current task question, intended message, source fact, actual wording/state, typography/layout result, locale coverage and observed behavior. Scope editorial judgment, user comprehension and business approval separately.

## Runtime and maintenance observations

When relevant, record input feedback, usable result and confirmed completion under
stated device/network/data conditions; motion and scroll continuity; preparation cost;
effective template/override content; batch outcomes and recovery. State the metric's
actual boundary and compare equivalent conditions. Link traces and runtime evidence.
