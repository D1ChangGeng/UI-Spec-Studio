# Worked reasoning examples

These examples illustrate application. They are not executed product evaluations or a fixed recipe.

## A user with only a goal

“Help me design this research workspace; I have no visual direction.” Read product facts and actual use. Determine whether people mainly ask and follow up, organize durable material, or manage work. Study the relevant mature flows and engineering candidates. Recommend a primary model and resolve material alternatives before expanding the shell; use a bounded provisional probe under one-shot delegation. Build a representative interaction, present its render with the decision map, and recommend the next increment. The user evaluates the experience while the agent owns routine component choices.

## A user with a precise reference

“Keep this typography and use this selected card interaction.” Treat the typography and intended interaction as constraints. Inspect the selected implementation for framework fit, focus behavior and motion control. Adapt the surrounding spacing, content and shared tokens. Verify actual behavior and supported views. Request a decision only when a material conflict changes the user's intended result.

## A continuation after approval

“Approved, continue.” Identify the reviewed scope, preserve its shared rules and choose the next highest-value incomplete task. In a workspace, a missing return path with retained filters may matter more than a new overview. Complete that path, inspect the affected screens and present a working result. Read required professional references when they are not already available in the execution context.

## Vague compositional feedback

“This feels too low.” Inspect the whole viewport, primary content mass, image contrast, top/bottom space and page family. A compact task may benefit from an optical upward adjustment. A settings tab instead inherits stable family anchors and solves balance within its content area. Implement the bounded hypothesis and compare the actual result.

## A bilingual cultural archive

Use reading flow and real licensed imagery. Shared identity links collection, item and editorial views, while each has its own content shape. Test translated long headings, glyph coverage, image loading and narrow widths. At finish, connect actual content and the contact endpoint; static routes complete through verified content/build behavior.

## A scheduling tool reaching finish

Reconcile the approved editor with existing services. Map create/edit/conflict/retry, permission and timezone owners. Connect a complete create outcome, preserve draft and selection during conflict recovery, then verify persistence and equivalent visual states. A real server rejection is both business evidence and a UI state to inspect.

## A changed design rule in an active project

When the user changes the family density, update its authoritative tokens and design decision, then recheck dependent pages. Preserve unaffected approved choices. The runtime supplies the execution context; project sources provide the current facts the agent can reread.


## A Vue account menu assembled from the right layers

Start from the project's existing shell and accepted identity. Find a reliable
menu primitive when one is needed, a coherent icon/owned avatar and an appropriate
transition. Use the catalog to locate Vue candidates, then read the exact APIs and
observe focus, dismissal and controlled state. Compose behavior and visual treatment
under shared tokens; test keyboard/touch, narrow layouts and real session state.
Keep the selected source/variant and adaptation in the project record.

## A visual direction improved by discovery

For an open introduction surface, research a small set of visual mechanisms that
support the subject. A parameterized background may create depth while leaving
copy readable. Inspect its actual controls and source, then place a representative
instance behind real content. Keep the valuable mechanism, tune its intensity to
the project and test the composed cost/quiet equivalent before extending it.

## A document index with a separate asset catalog

A font provider's AI documentation can describe installation while its generated
family catalog lives elsewhere. Use each entry for its intended role: inspect the
actual typeface and glyph coverage in the catalog, then read version-matched usage
and licensing guidance. An index's coverage informs retrieval; a current project
render establishes typography fit.

## An ambiguous research product

“Redesign our research platform” leaves the primary interaction model open.
Inspect how people begin, what they return to, and where their results live.
Conversational research may prioritize a question composer, follow-ups and
traceable sources; a durable knowledge space may prioritize pages, properties and
collection navigation. Research comparable flows and present the consequential
choice with the same representative task. Give a recommendation and explain its
basis. An explicit one-shot request can use the recommendation as a provisional
probe, with owner acceptance pending.

Before building the major treatment, map concrete pattern and implementation
sources to its shell, composer or editor, typography, surfaces, feedback and
motion. Retain business contracts while assessing current UI on target quality.
Show that map with the actual preview, then verify first-use, active work and
resume. Related examples can use the same process for task systems, editors and
reading surfaces without inheriting this scenario's aesthetics.

## A page-level foundation before local component selection

For a conversational research surface, compare a suitable assistant page template with a task-dashboard template using the same primary loop and content. If the assistant page already resolves welcome composition, composer continuity, message measure and action placement, inherit those decisions together. Add the product's source inspection and research states within that language. A static cross-stack probe can port those relationships with its scope stated; a compatible production stack can retain the source components and runtime behavior directly.

For a small control change inside an accepted interface, that accepted page is already the foundation. Research at the affected component level and preserve the rest. The useful granularity follows the actual problem.

## A brand asset changes the page

A product brief calls for a distinct spatial symbol. Compare suitable mature
models and reusable 2D expressions. Include an original contour-to-3D route only
when W1's identity need and the user's actual authorization cover that asset;
distinctness or a reference alone does not authorize original production. Study the
silhouette and its negative space in the intended composition. A fixed-view hero
can use a refined render; a view-dependent explanation may justify a real-time
model with a useful poster. Preserve the actual master and rights, export the
chosen variants and inspect them beside real copy. The selected asset can change
the composition before the page family expands.

## A wordmark and everyday reading

A user reference suggests interlocking letterforms and slower visual discovery.
Use those qualities to research mature identity material and source-supported
adaptation. If the user has also requested or authorized an original wordmark and
W1 qualifies for that bounded identity asset, extract the relevant contour and
spacing qualities into an independent wordmark,
then compare it at the header and small lockup sizes. Use appropriate ordinary
text for navigation and the accessible name. Check font licenses and actual glyph
coverage for the interface separately from the exported identity graphic.

## A research note with truthful state wording

The task is to name a note and save it locally. A short title orients the editor; a persistent field label identifies the input; supporting text explains the local saving boundary. “Save note” names the actual action. A missing title receives field-level guidance; a simulated storage failure identifies its boundary and preserves the draft; success appears only after the local write succeeds. Chinese and English variants keep the same outcome but allow different sentence length and line breaking. Test the page's typography and interaction with real strings rather than placeholder rectangles.

For a live product, the same patterns map to its real service and access rules. This example carries content decisions without prescribing the language personality of every product.
