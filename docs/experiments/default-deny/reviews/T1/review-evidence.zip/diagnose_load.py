import asyncio, json
from pathlib import Path
from playwright.async_api import async_playwright
OUT=Path(__file__).parent
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
  for sample,port in [('17',4411),('42',4412)]:
   page=await browser.new_page(viewport={'width':1440,'height':900})
   events=[]
   page.on('console',lambda m:events.append({'console':m.type,'text':m.text}))
   page.on('pageerror',lambda e:events.append({'pageerror':str(e)}))
   page.on('requestfailed',lambda r:events.append({'failed':r.url,'failure':r.failure}))
   page.on('response',lambda r:events.append({'status':r.status,'url':r.url}))
   await page.goto(f'http://127.0.0.1:{port}',wait_until='networkidle')
   await page.wait_for_timeout(3000)
   result={'events':events,'text':await page.locator('body').inner_text(),'html':await page.content()}
   print(sample,json.dumps(result,ensure_ascii=False))
   (OUT/f'{sample}-load-diagnostic.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
   await page.screenshot(path=str(OUT/f'{sample}-desktop-after-wait.png'))
   await page.close()
  await browser.close()
asyncio.run(main())
