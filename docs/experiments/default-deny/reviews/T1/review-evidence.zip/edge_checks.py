import asyncio,json,re
from pathlib import Path
from playwright.async_api import async_playwright
OUT=Path(__file__).parent
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
  for sample,port in [('17',4411),('42',4412)]:
   log={};ctx=await browser.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=1)
   page=await ctx.new_page();page.set_default_timeout(4000)
   await page.goto(f'http://127.0.0.1:{port}',wait_until='networkidle')
   await page.screenshot(path=str(OUT/f'{sample}-mobile-viewport.png'))
   log['mobileTypography']=await page.locator('h1,h2,p,button').evaluate_all('(es)=>es.slice(0,15).map(e=>({text:e.innerText,fontSize:getComputedStyle(e).fontSize,height:e.getBoundingClientRect().height}))')
   await page.get_by_role('button',name='Save The quiet interface',exact=True).tap()
   await page.get_by_role('button',name='Save A city after the last train',exact=True).tap()
   await page.get_by_role('button',name=re.compile('^Saved')).first.tap()
   await page.get_by_role('button',name=re.compile('unsave The quiet interface',re.I)).click()
   await page.wait_for_timeout(250)
   log['unsaveFirst']={'text':await page.locator('body').inner_text(),'focus':await page.evaluate('document.activeElement.outerHTML')}
   await page.get_by_role('button',name=re.compile('unsave A city after the last train',re.I)).focus()
   await page.keyboard.press('Space')
   await page.wait_for_timeout(250)
   log['unsaveLast']={'text':await page.locator('body').inner_text(),'focus':await page.evaluate('document.activeElement.outerHTML')}
   await page.screenshot(path=str(OUT/f'{sample}-mobile-unsave-last.png'))
   await page.reload(wait_until='networkidle')
   log['unsaveReload']=await page.locator('body').inner_text()
   allButton=page.get_by_role('button',name=re.compile('^All collections')).first
   await allButton.tap();await page.get_by_role('searchbox').fill('type')
   await page.get_by_role('link',name='Type as a way of thinking',exact=True).tap()
   await page.go_back(wait_until='networkidle')
   log['browserBack']={'url':page.url,'search':await page.get_by_role('searchbox').input_value(),'focus':await page.evaluate('document.activeElement.outerHTML')}
   await ctx.close()
   ctx=await browser.new_context(viewport={'width':1440,'height':900});page=await ctx.new_page()
   await page.goto(f'http://127.0.0.1:{port}',wait_until='networkidle')
   log['fonts']=await page.evaluate('Array.from(document.fonts).map(f=>({family:f.family,status:f.status}))')
   link=page.get_by_role('link',name='The quiet interface',exact=True);box=await link.bounding_box()
   async def grads():
    return await page.locator('body *').evaluate_all('(es)=>es.map(e=>({tag:e.tagName,cls:e.className,bg:getComputedStyle(e).backgroundImage,opacity:getComputedStyle(e).opacity})).filter(x=>x.bg.includes("radial-gradient"))')
   for mode in ['no-preference','reduce']:
    await page.emulate_media(reduced_motion=mode)
    await page.mouse.move(box['x']+10,box['y']+10);await page.wait_for_timeout(350)
    left=await grads();await page.screenshot(path=str(OUT/f'{sample}-{mode}-left.png'))
    await page.mouse.move(box['x']+box['width']-10,box['y']+10);await page.wait_for_timeout(350)
    right=await grads();await page.screenshot(path=str(OUT/f'{sample}-{mode}-right.png'))
    log[mode]={'left':left,'right':right}
   (OUT/f'{sample}-edge-checks.json').write_text(json.dumps(log,ensure_ascii=False,indent=2));print(sample,json.dumps(log,ensure_ascii=False),flush=True)
   await ctx.close()
  await browser.close()
asyncio.run(main())
