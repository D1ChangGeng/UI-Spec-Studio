import asyncio, json, os
from pathlib import Path
from playwright.async_api import async_playwright

OUT = Path(__file__).parent
async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome', headless=True, args=['--no-sandbox'])
        for sample, port in [('17',4411),('42',4412)]:
            context=await browser.new_context(viewport={'width':1440,'height':900}, device_scale_factor=1)
            page=await context.new_page()
            await page.goto(f'http://127.0.0.1:{port}', wait_until='networkidle')
            await page.screenshot(path=str(OUT/f'{sample}-desktop-initial.png'), full_page=True)
            result={'text':await page.locator('body').inner_text(), 'controls': await page.locator('button,input,select,a').evaluate_all('(els)=>els.map(e=>({tag:e.tagName,text:e.innerText,aria:e.getAttribute("aria-label"),placeholder:e.getAttribute("placeholder"),type:e.getAttribute("type"),href:e.getAttribute("href")}))')}
            await page.set_viewport_size({'width':390,'height':844})
            await page.screenshot(path=str(OUT/f'{sample}-mobile-initial.png'),full_page=True)
            result['mobile_width']=await page.evaluate('({client:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth})')
            (OUT/f'{sample}-initial.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
            print(sample,json.dumps(result,ensure_ascii=False))
            await context.close()
        await browser.close()
asyncio.run(main())
