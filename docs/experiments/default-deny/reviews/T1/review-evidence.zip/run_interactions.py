import asyncio,json,re,time
from pathlib import Path
from playwright.async_api import async_playwright
OUT=Path(__file__).parent
LONG='Keeping your place when everything around you is changing'
async def inspect(browser,sample,port):
 ctx=await browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
 page=await ctx.new_page();page.set_default_timeout(5000)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 log={'sample':sample,'port':port,'started':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'steps':[]}
 async def snap(name,full=False):
  await page.screenshot(path=str(OUT/f'{sample}-{name}.png'),full_page=full)
 async def record(name):
  val={'name':name,'url':page.url,'scrollY':await page.evaluate('scrollY'),'text':await page.locator('body').inner_text(),'controls':await page.locator('button,input,a').evaluate_all('(es)=>es.map(e=>({tag:e.tagName,text:e.innerText,aria:e.getAttribute("aria-label"),value:e.value,pressed:e.getAttribute("aria-pressed")}))')}
  log['steps'].append(val);print(sample,name,json.dumps(val,ensure_ascii=False),flush=True)
 try:
  await page.goto(f'http://127.0.0.1:{port}',wait_until='networkidle')
  await snap('desktop-viewport')
  log['typography']=await page.locator('h1,h2,p,button,input').evaluate_all('(es)=>es.slice(0,32).map(e=>{let s=getComputedStyle(e),r=e.getBoundingClientRect();return {tag:e.tagName,text:e.innerText||e.placeholder,font:s.fontFamily,size:s.fontSize,lineHeight:s.lineHeight,color:s.color,background:s.backgroundColor,width:r.width,height:r.height}})')
  await page.get_by_role('button',name=re.compile('^Saved')).first.click()
  await record('empty-saved');await snap('empty-saved')
  await page.get_by_role('button',name=re.compile('^All collections')).click()
  await page.get_by_role('searchbox').fill('cOnTiNuItY')
  await record('search-case-description')
  await page.get_by_role('button',name='Save '+LONG,exact=True).click()
  await record('save-success')
  await page.reload(wait_until='networkidle')
  await record('reload-persistence')
  await page.get_by_role('searchbox').fill('continuity')
  await page.get_by_role('button',name=re.compile('^Saved')).first.click()
  await page.get_by_role('link',name=LONG,exact=True).click()
  await record('long-detail');await snap('long-detail-desktop',True)
  await page.set_viewport_size({'width':390,'height':844});await snap('long-detail-mobile',True)
  log['detailMobileWidth']=await page.evaluate('({viewport:innerWidth,client:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth})')
  await page.set_viewport_size({'width':1440,'height':900})
  back=page.get_by_role('button',name=re.compile('Back|Return',re.I))
  if await back.count()==0:back=page.get_by_role('link',name=re.compile('Back|Return',re.I))
  await back.first.click()
  await record('return-filter-context');await snap('return-filter-context')
  await page.get_by_role('searchbox').fill('zzzz-no-match-测试')
  await record('no-results');await snap('no-results')
  # Start a new visit for realistic scroll-position restoration.
  await page.goto(f'http://127.0.0.1:{port}',wait_until='networkidle')
  await page.get_by_role('button',name=re.compile('^All collections')).click()
  await page.get_by_role('searchbox').fill('')
  await page.get_by_role('link',name=LONG,exact=True).scroll_into_view_if_needed()
  await page.evaluate('window.scrollTo(0,document.documentElement.scrollHeight)')
  before=await page.evaluate('({scrollY,active:document.activeElement?.outerHTML})')
  await page.get_by_role('link',name=LONG,exact=True).click()
  await page.evaluate('window.scrollTo(0,document.documentElement.scrollHeight)')
  back=page.get_by_role('button',name=re.compile('Back|Return',re.I))
  if await back.count()==0:back=page.get_by_role('link',name=re.compile('Back|Return',re.I))
  await back.first.click();await page.wait_for_timeout(250)
  after=await page.evaluate('({scrollY,active:document.activeElement?.outerHTML})')
  log['returnScroll']={'before':before,'after':after}
  await snap('return-scroll')
  # Fault injection: browser storage setItem throws while actual Save control is used.
  await page.evaluate('() => { window.__originalSetItem=Storage.prototype.setItem; Storage.prototype.setItem=function(){throw new DOMException("Review simulated write failure","QuotaExceededError")}; return true; }')
  await page.get_by_role('button',name='Save The quiet interface',exact=True).click()
  await record('storage-failure-save');await snap('storage-failure-save')
  await page.set_viewport_size({'width':390,'height':844});await page.evaluate('window.scrollTo(0,0)');await snap('storage-failure-mobile',True)
  await page.evaluate('() => { Storage.prototype.setItem=window.__originalSetItem; return true; }')
  retry=page.get_by_role('button',name=re.compile('Retry|Try again',re.I))
  if await retry.count():await retry.first.click()
  else:
   b=page.get_by_role('button',name=re.compile('(Remove|Unsave).*quiet|.*quiet.*saved',re.I))
   if await b.count():await b.first.click()
   else:await page.get_by_role('button',name='Save The quiet interface',exact=True).click()
  await record('storage-recovery');await snap('storage-recovery-mobile')
  await page.reload(wait_until='networkidle');await record('recovery-reload')
  # Inspect keyboard-only entry and normal/reduced pointer responses.
  await page.set_viewport_size({'width':1440,'height':900})
  await page.goto(f'http://127.0.0.1:{port}',wait_until='networkidle')
  await page.keyboard.press('Tab');await snap('keyboard-first-focus')
  log['firstTab']=await page.evaluate('document.activeElement.outerHTML')
  await page.keyboard.press('Enter');await page.keyboard.press('Tab')
  log['afterSkipTab']=await page.evaluate('document.activeElement.outerHTML')
  await page.keyboard.press('/')
  log['slashFocus']=await page.evaluate('document.activeElement.outerHTML')
  await page.keyboard.press('Escape')
  link=page.get_by_role('link',name='The quiet interface',exact=True)
  await link.focus();await snap('keyboard-card-focus')
  await link.scroll_into_view_if_needed();box=await link.bounding_box()
  await page.mouse.move(box['x']+10,box['y']+10);await page.wait_for_timeout(500);await snap('pointer-left')
  await page.mouse.move(box['x']+box['width']-10,box['y']+box['height']-10);await page.wait_for_timeout(500);await snap('pointer-right')
  await page.emulate_media(reduced_motion='reduce');await page.mouse.move(box['x']+10,box['y']+10);await page.wait_for_timeout(500);await snap('reduced-motion-pointer')
  log['reducedMotion']=await page.evaluate('({matches:matchMedia("(prefers-reduced-motion: reduce)").matches,animations:document.getAnimations().map(a=>({playState:a.playState,timing:a.effect?.getComputedTiming()}))})')
  await page.emulate_media(color_scheme='light');await page.evaluate('window.scrollTo(0,0)');await snap('os-light-scheme')
  log['lightScheme']=await page.evaluate('({html:document.documentElement.outerHTML.slice(0,200),bodyBackground:getComputedStyle(document.body).backgroundColor})')
 except Exception as e:
  log['error']=repr(e);print(sample,'ERROR',repr(e),flush=True);await snap('interrupted')
 log['pageErrors']=errors
 (OUT/f'{sample}-interaction-log.json').write_text(json.dumps(log,ensure_ascii=False,indent=2))
 await ctx.close()
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
  for sample,port in [('17',4411),('42',4412)]:await inspect(browser,sample,port)
  await browser.close()
asyncio.run(main())
