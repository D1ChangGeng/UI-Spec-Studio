#!/usr/bin/env bash
# Review-only launch; avoids concurrent Vite optimization-cache collisions.
# Usage: bash review-output/start-review-server.sh 17  OR  42
set -eu
candidate="${1:?Use 17 or 42}"
case "$candidate" in
  17) port=4411 ;;
  42) port=4412 ;;
  *) exit 2 ;;
esac
review_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$review_dir/../sample-$candidate/app"
REVIEW_PORT="$port" REVIEW_CACHE="$review_dir/runtime-cache-$candidate" node --input-type=module -e '
  import { createServer } from "vite";
  const server = await createServer({
    cacheDir: process.env.REVIEW_CACHE,
    server: { host: "127.0.0.1", port: Number(process.env.REVIEW_PORT), strictPort: true }
  });
  await server.listen();
  server.printUrls();
'
