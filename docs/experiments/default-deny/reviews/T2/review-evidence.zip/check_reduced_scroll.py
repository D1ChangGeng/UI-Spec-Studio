import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
OUT=Path(__file__).parent
LONG=('观察 01：比较城市采暖峰值与居民活动。Evidence: 17:30–20:00; ΔT=12°C。\n'*8)+'结尾 END：保留未解决的问题。'
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
  for name,port in [('sample-17',4413),('sample-42',4414)]:
   page=await browser.new_page(viewport={'width':390,'height':844});await page.goto(f'http://127.0.0.1:{port}');await page.wait_for_timeout(400);r={}
   async def capture(label):
    r[label]=await page.evaluate('''() => [...document.querySelectorAll('#card-space,#card-space *')].filter(e=>e.scrollTop||e.id==='preview-note'||e.id==='card-back'||e.classList.contains('note-surface')).map(e=>({id:e.id,cls:e.className,scrollTop:e.scrollTop,scrollHeight:e.scrollHeight,clientHeight:e.clientHeight,rect:e.getBoundingClientRect().toJSON(),overflow:getComputedStyle(e).overflow,display:getComputedStyle(e).display,transform:getComputedStyle(e).transform}))''')
    await page.screenshot(path=str(OUT/f'{name}-reduced-repro-{label}.png'),full_page=True)
   async def click_mouse(sel):
    b=await page.locator(sel).bounding_box();await page.mouse.click(b['x']+b['width']/2,b['y']+b['height']/2)
   await page.locator('#note-text').fill(LONG);await click_mouse('#flip');await page.wait_for_timeout(1000)
   await page.locator('#preview-note').focus();await page.keyboard.press('End');await page.wait_for_timeout(600);await capture('scrolled')
   await click_mouse('#back-edit' if name=='sample-17' else '#back-to-editor');await page.wait_for_timeout(1000);await capture('returned')
   await page.emulate_media(reduced_motion='reduce');await click_mouse('#flip');await page.wait_for_timeout(200);await capture('reduced-back')
   await page.emulate_media(reduced_motion='no-preference');await page.wait_for_timeout(200);await capture('motion-back')
   (OUT/f'{name}-reduced-repro.json').write_text(json.dumps(r,ensure_ascii=False,indent=2))
   await page.close()
  await browser.close()
asyncio.run(main())
