import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
OUT=Path(__file__).parent
STATE='''() => ({value:document.querySelector('#note-text').value,status:document.querySelector('#status').innerText,active:document.activeElement.id,face:document.querySelector('#note-card').dataset.face,local:{...localStorage},noteInvalid:document.querySelector('#note-text').getAttribute('aria-invalid'),text:document.body.innerText})'''
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
  for name,port in [('sample-17',4413),('sample-42',4414)]:
   context=await browser.new_context(viewport={'width':1440,'height':900})
   page=await context.new_page();page.set_default_timeout(6000)
   await page.goto(f'http://127.0.0.1:{port}');await page.wait_for_timeout(500)
   r={}
   await page.locator('#note-text').fill('SAVED SNAPSHOT A — 点击保存时的内容。')
   await page.locator('#save').click();await page.wait_for_timeout(170)
   await page.locator('#note-text').fill('NEW DRAFT B — 保存等待时继续修改，应保持草稿。')
   await page.wait_for_timeout(1000)
   r['editDuringSave']=await page.evaluate(STATE)
   await page.screenshot(path=str(OUT/f'{name}-edit-during-save.png'),full_page=True)
   await page.locator('#saved-link').click();r['collectionDuringDraft']=await page.evaluate(STATE)
   await page.locator('#return').click();r['draftReturn']=await page.evaluate(STATE)
   # Keyboard traversal is observed through genuine Tab events.
   await page.reload();await page.wait_for_timeout(300)
   r['tabsFront']=[]
   for i in range(11):
    await page.keyboard.press('Tab')
    r['tabsFront'].append(await page.evaluate('''() => ({id:document.activeElement.id,tag:document.activeElement.tagName,text:document.activeElement.innerText?.slice(0,70),inert:!!document.activeElement.closest('[inert]')})'''))
   await page.locator('#flip').focus();await page.keyboard.press('Enter');await page.wait_for_timeout(1000)
   r['keyboardFlip']=await page.evaluate(STATE)
   # Unbroken rAF stream, turn plus rapid actual reverse clicks, without screenshots interrupting measurement.
   await page.locator('#flip').click();await page.wait_for_timeout(1100)
   await page.evaluate('''() => {window.__motion=[];window.__motionStart=performance.now();window.__motionStop=false;const rot=document.querySelector('#note-card [class*="cursor-grab"]')||document.querySelector('#note-card');function f(t){let m=getComputedStyle(rot).transform;let a=m==='none'?0:(()=>{let v=m.match(/matrix3d\\(([^)]+)\\)/);if(!v)return null;let q=v[1].split(',').map(Number);return Math.atan2(-q[2],q[0])*180/Math.PI;})();window.__motion.push({t:t-window.__motionStart,angle:a,transform:m,face:document.querySelector('#note-card').dataset.face,rect:rot.getBoundingClientRect().toJSON()});if(!window.__motionStop)requestAnimationFrame(f);}requestAnimationFrame(f);}''')
   r['clicks']=[]
   for delay in [180,90,120,70,140,80,1100]:
    r['clicks'].append(await page.evaluate('performance.now()-window.__motionStart'))
    await page.locator('#flip').click();await page.wait_for_timeout(delay)
   await page.evaluate('window.__motionStop=true')
   r['rapidFrames']=await page.evaluate('window.__motion')
   r['rapidFinal']=await page.evaluate(STATE)
   await page.screenshot(path=str(OUT/f'{name}-rapid-final-followup.png'))
   # Fresh load with reduced preference validates both visible face and motion values.
   await page.emulate_media(reduced_motion='reduce');await page.reload();await page.wait_for_timeout(300)
   await page.locator('#flip').click();await page.wait_for_timeout(50)
   r['reduced50']=await page.evaluate('''() => ({face:document.querySelector('#note-card').dataset.face,styles:[...document.querySelectorAll('#note-card *')].filter(e=>getComputedStyle(e).transform!=='none').map(e=>({cls:e.className,transform:getComputedStyle(e).transform})),text:document.body.innerText})''')
   await page.screenshot(path=str(OUT/f'{name}-desktop-reduced-back.png'))
   (OUT/f'{name}-followup.json').write_text(json.dumps(r,ensure_ascii=False,indent=2))
   print(name,'followup done')
   await context.close()
  await browser.close()
asyncio.run(main())
