import asyncio, json, os
from pathlib import Path
from playwright.async_api import async_playwright

OUT = Path(__file__).parent
async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome', headless=True, args=['--no-sandbox'])
        for candidate, port in [('sample-17',4413),('sample-42',4414)]:
            context = await browser.new_context(viewport={'width':1440,'height':900}, device_scale_factor=1)
            page = await context.new_page()
            await page.goto(f'http://127.0.0.1:{port}')
            await page.wait_for_timeout(1000)
            await page.screenshot(path=str(OUT/f'{candidate}-desktop-initial.png'),full_page=True)
            data = await page.evaluate('''() => ({title:document.title,text:document.body.innerText,controls:[...document.querySelectorAll('button,input,textarea,select,a')].map(e=>({tag:e.tagName,id:e.id,type:e.type,text:e.innerText,value:e.value,placeholder:e.getAttribute('placeholder'),aria:e.getAttribute('aria-label')})), storage:{...localStorage}})''')
            (OUT/f'{candidate}-initial.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
            print(candidate, json.dumps(data, ensure_ascii=False))
            await context.close()
        await browser.close()
asyncio.run(main())
