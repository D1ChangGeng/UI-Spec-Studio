"""Make evidence contact sheets from existing unmodified browser screenshots."""
from PIL import Image, ImageDraw
from pathlib import Path

out = Path(__file__).parent
for name in ['sample-17', 'sample-42']:
    panels = []
    for tag in ['turn-0', 'turn-1', 'turn-2', 'turn-3', 'turn-4',
                'rapid-settled', 'reverse-0', 'reverse-1', 'reverse-2', 'reverse-3']:
        shot = Image.open(out / f'{name}-{tag}.png').crop((140, 220, 735, 760))
        shot.thumbnail((360, 330))
        panel = Image.new('RGB', (380, 365), 'white')
        panel.paste(shot, ((380-shot.width)//2, 25))
        ImageDraw.Draw(panel).text((12, 5), tag, fill='black')
        panels.append(panel)
    sheet = Image.new('RGB', (1900, 730), '#dddddd')
    for i, panel in enumerate(panels):
        sheet.paste(panel, ((i % 5)*380, (i // 5)*365))
    sheet.save(out / f'{name}-motion-contact.png')
