import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
OUT=Path(__file__).parent
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
  r={}
  for name,port in [('sample-17',4413),('sample-42',4414)]:
   page=await browser.new_page(viewport={'width':1440,'height':900});await page.goto(f'http://127.0.0.1:{port}');await page.wait_for_timeout(400)
   r[name]={}
   for label,size in [('desktop',{'width':1440,'height':900}),('mobile',{'width':390,'height':844})]:
    await page.set_viewport_size(size)
    r[name][label]=await page.evaluate('''() => Object.fromEntries(['#page-title','#card-space','#note-text','#preview-note','#flip','#theme-toggle','#locale-toggle','#save'].map(sel=>{let e=document.querySelector(sel),s=getComputedStyle(e);return [sel,{rect:e.getBoundingClientRect().toJSON(),fontSize:s.fontSize,lineHeight:s.lineHeight,color:s.color,background:s.backgroundColor}]}))''')
   await page.set_viewport_size({'width':1440,'height':900})
   if name=='sample-42':
    card=page.locator('.fieldnote-flip');await card.focus();await page.keyboard.press('Enter');await page.wait_for_timeout(1000)
    r[name]['cardEnter']=await page.locator('#note-card').get_attribute('data-face')
    await page.keyboard.press('Space');await page.wait_for_timeout(1000)
    r[name]['cardSpace']=await page.locator('#note-card').get_attribute('data-face')
    b=await card.bounding_box();x=b['x']+b['width']/2;y=b['y']+100
    await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x+190,y,steps=12);await page.mouse.up();await page.wait_for_timeout(1200)
    r[name]['drag']=await page.locator('#note-card').get_attribute('data-face')
    await page.screenshot(path=str(OUT/f'{name}-drag-result.png'))
   await page.close()
  (OUT/'layout-measurements.json').write_text(json.dumps(r,ensure_ascii=False,indent=2))
  print(json.dumps(r,ensure_ascii=False))
  await browser.close()
asyncio.run(main())
