import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
OUT=Path(__file__).parent
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
  for name,port in [('sample-17',4413),('sample-42',4414)]:
   page=await browser.new_page(viewport={'width':1440,'height':900})
   await page.goto(f'http://127.0.0.1:{port}')
   await page.locator('summary').click()
   print(name,await page.locator('body').inner_text())
   print(await page.evaluate('''() => [...document.querySelectorAll('input,select,textarea,summary,[tabindex], [role="button"]')].map(e=>({tag:e.tagName,id:e.id,type:e.type,text:e.innerText,value:e.value,role:e.getAttribute('role'), tabindex:e.tabIndex,outer:e.outerHTML.slice(0,700)}))'''))
   await page.screenshot(path=str(OUT/f'{name}-preview-controls.png'),full_page=True)
   await page.locator('#flip').click()
   await page.wait_for_timeout(1400)
   print('FLIP',name,await page.evaluate('''() => ({text:document.body.innerText,active:document.activeElement.id,dom:[...document.querySelectorAll('main *')].filter(e=>getComputedStyle(e).transform!=='none'||e.getAttribute('role')||e.getAttribute('inert')!==null).map(e=>({tag:e.tagName,id:e.id,cls:e.className,role:e.getAttribute('role'),inert:e.inert,ariaHidden:e.getAttribute('aria-hidden'),transform:getComputedStyle(e).transform,rect:e.getBoundingClientRect().toJSON()}))})'''))
   await page.screenshot(path=str(OUT/f'{name}-desktop-back.png'),full_page=True)
   await page.close()
  await browser.close()
asyncio.run(main())
