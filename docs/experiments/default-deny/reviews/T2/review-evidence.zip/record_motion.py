import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
OUT=Path(__file__).parent
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
  for name,port in [('sample-17',4413),('sample-42',4414)]:
   context=await browser.new_context(viewport={'width':1440,'height':900},record_video_dir=str(OUT/f'{name}-video'),record_video_size={'width':1440,'height':900})
   page=await context.new_page();await page.goto(f'http://127.0.0.1:{port}');await page.wait_for_timeout(600)
   await page.locator('#motion-toggle').click()
   await page.locator('#flip').click();await page.wait_for_timeout(1400)
   await page.locator('#flip').click();await page.wait_for_timeout(1400)
   for gap in [100,90,120,80,110,90,100]:
    await page.locator('#flip').click();await page.wait_for_timeout(gap)
   await page.wait_for_timeout(1600)
   await context.close()
  await browser.close()
asyncio.run(main())
