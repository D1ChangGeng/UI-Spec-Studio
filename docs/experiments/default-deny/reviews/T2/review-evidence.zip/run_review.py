import asyncio, json, time
from pathlib import Path
from playwright.async_api import async_playwright

OUT=Path(__file__).parent
LONG=('观察 01：比较城市采暖峰值与居民活动。Evidence: 17:30–20:00; ΔT=12°C。\n'*8)+'结尾 END：保留未解决的问题。'
STATE='''() => ({text:document.body.innerText,value:document.querySelector('#note-text')?.value,active:document.activeElement?.id,disabled:document.querySelector('#note-text')?.disabled,saveDisabled:document.querySelector('#save')?.disabled,face:document.querySelector('#note-card')?.dataset.face,status:document.querySelector('#status')?.innerText,local:{...localStorage},session:{...sessionStorage},width:document.documentElement.scrollWidth,viewport:innerWidth,scrollY,preview:(()=>{let e=document.querySelector('#preview-note');return e?{text:e.innerText,clientHeight:e.clientHeight,scrollHeight:e.scrollHeight,scrollTop:e.scrollTop,overflow:getComputedStyle(e).overflowY}:null})(),card:document.querySelector('#card-space')?.getBoundingClientRect().toJSON()})'''
async def snap(page,name,label,full=True):
 await page.screenshot(path=str(OUT/f'{name}-{label}.png'),full_page=full)
 return await page.evaluate(STATE)
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
  for name,port in [('sample-17',4413),('sample-42',4414)]:
   results={'candidate':name,'longLength':len(LONG),'checks':{},'consoleErrors':[]}
   context=await browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
   page=await context.new_page()
   page.set_default_timeout(8000)
   page.on('pageerror',lambda e:results['consoleErrors'].append(str(e)))
   await page.goto(f'http://127.0.0.1:{port}')
   await page.wait_for_timeout(700)
   await page.locator('#motion-toggle').click()
   results['checks']['pauseDecoration']=await page.evaluate(STATE)
   # Observe all browser animation frames while actual flip buttons are used.
   await page.evaluate('''() => {window.__reviewFrames=[];let start=performance.now();function f(t){let card=document.querySelector('#note-card');let rot=card.style.transform?card:[...card.querySelectorAll('*')].find(e=>e.style.transformStyle==='preserve-3d'||getComputedStyle(e).transformStyle==='preserve-3d');window.__reviewFrames.push({t:t-start,face:card.dataset.face,transform:rot?getComputedStyle(rot).transform:null,angle:card.dataset.angle,rect:(rot||card).getBoundingClientRect().toJSON()});if(t-start<2200)requestAnimationFrame(f);}requestAnimationFrame(f);}''')
   await page.locator('#flip').click()
   for i,delay in enumerate([55,65,100,130,250]):
    await page.wait_for_timeout(delay)
    await snap(page,name,f'turn-{i}',False)
   await page.wait_for_timeout(800)
   results['checks']['back']=await snap(page,name,'desktop-back-settled')
   await page.wait_for_timeout(700)
   results['frames']=await page.evaluate('window.__reviewFrames')
   await page.locator('#flip').click()
   await page.wait_for_timeout(900)
   # Reversal chain with real button actions, preserving frames for each interruption.
   results['checks']['rapid']=[]
   for i in range(7):
    await page.locator('#flip').click()
    await page.wait_for_timeout(60)
    results['checks']['rapid'].append(await page.evaluate(STATE))
    if i<4: await snap(page,name,f'reverse-{i}',False)
   await page.wait_for_timeout(1200)
   results['checks']['rapidSettled']=await snap(page,name,'rapid-settled')
   back_id='#back-edit' if name=='sample-17' else '#back-to-editor'
   await page.locator(back_id).click()
   await page.wait_for_timeout(1000)
   results['checks']['returnToEdit']=await page.evaluate(STATE)
   # Difficult note and draft restoration.
   await page.locator('#note-text').fill(LONG)
   await page.wait_for_timeout(500)
   results['checks']['draftBeforeReload']=await page.evaluate(STATE)
   await page.reload(); await page.wait_for_timeout(500)
   results['checks']['draftReload']=await page.evaluate(STATE)
   await page.locator('#note-text').fill(LONG)
   await page.locator('#flip').click(); await page.wait_for_timeout(1100)
   results['checks']['longBack']=await snap(page,name,'long-back')
   await page.locator('#preview-note').focus()
   await page.keyboard.press('End'); await page.keyboard.press('PageDown')
   results['checks']['longBackScrolled']=await snap(page,name,'long-back-scrolled')
   # Local save: inspect during the advertised delay, then completed collection.
   await page.locator('#save').click()
   await page.wait_for_timeout(180)
   results['checks']['saving180ms']=await snap(page,name,'saving',False)
   await page.wait_for_timeout(1100)
   results['checks']['saved']=await snap(page,name,'saved')
   await page.locator('#saved-link').click(); await page.wait_for_timeout(100)
   results['checks']['collection']=await snap(page,name,'saved-collection')
   await page.locator('#return').click(); await page.wait_for_timeout(100)
   # Storage write fault is the only injected test condition; all product actions use controls.
   fail_text='未保存草稿：FAILURE DRAFT — '+LONG[:330]
   await page.locator('#note-text').fill(fail_text)
   await page.evaluate('''() => {window.__reviewOrigSet=Storage.prototype.setItem;window.__reviewFail=true;Storage.prototype.setItem=function(k,v){if(window.__reviewFail)throw new DOMException('Review induced quota failure','QuotaExceededError');return window.__reviewOrigSet.call(this,k,v)}}''')
   await page.locator('#save').click(); await page.wait_for_timeout(1150)
   results['checks']['failure']=await snap(page,name,'failure')
   await page.evaluate('window.__reviewFail=false')
   await page.locator('#retry').click(); await page.wait_for_timeout(1150)
   results['checks']['retry']=await snap(page,name,'retry')
   await page.reload(); await page.wait_for_timeout(500)
   results['checks']['retryReload']=await page.evaluate(STATE)
   # Overlimit input is allowed to expose validation behavior.
   await page.locator('#note-text').fill('超长。'*230)
   if await page.locator('#save').is_enabled():
    await page.locator('#save').click(); await page.wait_for_timeout(1100)
   results['checks']['overLimit']=await snap(page,name,'over-limit')
   await page.locator('#note-text').fill(LONG)
   await page.locator('#locale-toggle').click(); await page.locator('#theme-toggle').click()
   results['checks']['chineseDark']=await snap(page,name,'desktop-chinese-dark')
   await page.locator('#flip').click(); await page.wait_for_timeout(1000)
   results['checks']['chineseDarkBack']=await snap(page,name,'desktop-chinese-dark-back')
   # Mobile with both faces and available language/theme controls.
   await page.set_viewport_size({'width':390,'height':844})
   await page.evaluate('scrollTo(0,0)')
   results['checks']['mobileDarkBack']=await snap(page,name,'mobile-chinese-dark-back')
   await page.locator('#flip').click(); await page.wait_for_timeout(1100);await page.evaluate('scrollTo(0,0)')
   results['checks']['mobileDarkFront']=await snap(page,name,'mobile-chinese-dark-front')
   await page.locator('#theme-toggle').click(); await page.locator('#locale-toggle').click();await page.evaluate('scrollTo(0,0)')
   results['checks']['mobileLightFront']=await snap(page,name,'mobile-english-light-front')
   await snap(page,name,'mobile-english-light-viewport',False)
   await page.locator('#flip').click(); await page.wait_for_timeout(1100);await page.evaluate('scrollTo(0,0)')
   results['checks']['mobileLightBack']=await snap(page,name,'mobile-english-light-back')
   await page.locator('#preview-note').focus();await page.keyboard.press('End');await page.keyboard.press('PageDown')
   results['checks']['mobileLongScrolled']=await snap(page,name,'mobile-long-scrolled')
   await page.locator(back_id).click();await page.wait_for_timeout(900)
   results['checks']['mobileReturnFocus']=await page.evaluate(STATE)
   # Reduced motion preference activated at runtime, then actual turn and reverse.
   await page.emulate_media(reduced_motion='reduce')
   await page.evaluate('scrollTo(0,0)')
   await page.locator('#flip').click();await page.wait_for_timeout(150)
   results['checks']['reducedBack150']=await snap(page,name,'mobile-reduced-back')
   await page.locator(back_id).click();await page.wait_for_timeout(200)
   results['checks']['reducedReturn']=await page.evaluate(STATE)
   (OUT/f'{name}-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
   print(name,'done',list(results['checks']))
   await context.close()
  await browser.close()
asyncio.run(main())
