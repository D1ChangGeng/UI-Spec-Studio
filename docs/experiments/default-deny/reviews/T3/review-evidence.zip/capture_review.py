import asyncio, json, os, time
from pathlib import Path
from playwright.async_api import async_playwright

ROOT=Path(__file__).resolve().parent
SHOT=ROOT/'screenshots'; SHOT.mkdir(exist_ok=True)
results={}

async def snap(p, name, full=False):
    await p.screenshot(path=str(SHOT/(name+'.png')), full_page=full)

async def inspect(p):
    return await p.evaluate('''() => ({lang:document.documentElement.lang, theme:document.documentElement.dataset.theme, width:innerWidth,height:innerHeight, scrollWidth:document.documentElement.scrollWidth,scrollHeight:document.documentElement.scrollHeight,active:document.activeElement?.id,dialog:document.querySelector('dialog')?.open,fields:[...document.querySelectorAll('#note-title,#note-body')].map(e=>({id:e.id,value:e.value,font:getComputedStyle(e).fontSize,placeholder:getComputedStyle(e,'::placeholder').fontSize,color:getComputedStyle(e).color,placeholderColor:getComputedStyle(e,'::placeholder').color,box:e.getBoundingClientRect().toJSON()})), text:document.body.innerText})''')

async def open_details(p):
    if not await p.locator('.fixture-controls details').evaluate('(e)=>e.open'):
        await p.locator('.fixture-controls summary').click()

async def show_conflict(p, sample):
    if not await p.locator('#conflict-dialog').evaluate('(e)=>e.open'):
        await p.locator('#review-conflict' if sample==17 else '#compare').click()

async def fill(p,title,body):
    await p.locator('#note-title').fill(title)
    await p.locator('#note-body').fill(body)

async def save(p):
    await p.locator('#save').click()
    await p.wait_for_timeout(180)

async def main():
  async with async_playwright() as pw:
    browser=await pw.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
    for sample,port in [(17,4415),(42,4416)]:
      res=results[str(sample)]={'errors':[],'baseline':{},'flows':{}}
      ctx=await browser.new_context(viewport={'width':1440,'height':900}, device_scale_factor=1)
      p=await ctx.new_page()
      p.on('pageerror',lambda e:res['errors'].append(str(e)))
      await p.goto(f'http://127.0.0.1:{port}')
      for viewport,label in [({'width':1440,'height':900},'desktop'),({'width':390,'height':844},'mobile')]:
        await p.set_viewport_size(viewport)
        for name,action in [('zh-light',None),('zh-dark','#theme-toggle'),('en-dark','#locale-toggle'),('en-light','#theme-toggle')]:
          if action: await p.locator(action).click()
          await p.locator('body').click(position={'x':5,'y':100})
          await snap(p,f'{sample}-{label}-empty-{name}',True)
          res['baseline'][f'{label}-{name}']=await inspect(p)
        await p.locator('#locale-toggle').click()
      await p.set_viewport_size({'width':1440,'height':900})
      await p.locator('#save').click()
      await snap(p,f'{sample}-desktop-required-error')
      res['flows']['required']=await inspect(p)
      await p.locator('#note-title').focus()
      await p.keyboard.press('Tab')
      await snap(p,f'{sample}-desktop-keyboard-focus')
      res['flows']['focus']=await inspect(p)
      await fill(p,'基础笔记 / baseline','原始材料：温度 18°C；峰值负荷 42 MW。\nQuotation identifiers are not stored.')
      await save(p)
      await p.reload()
      res['flows']['persistence']=await inspect(p)
      q=await ctx.new_page(); await q.goto(f'http://127.0.0.1:{port}')
      long_title='本页草稿：城市供热、跨时区协作与引用关系 / Draft kept locally — '+('长标题测试与混合文字 ' * 7)
      long_body=('本页尚未保存，必须保留。\nSource: https://example.test/'+('unbreakableword'*9)+'\n逐段引用与证据尚无 ID；this is plain text, not a verified support link.\n')*12
      await fill(p,long_title[:150],long_body[:3000])
      await fill(q,'另一标签页 B1：已保存版本','远端第一版本 / first saved revision\n这段文本也需要保留。')
      await save(q); await p.wait_for_timeout(180)
      await snap(p,f'{sample}-desktop-conflict-arrival')
      res['flows']['conflict_arrival']=await inspect(p)
      await show_conflict(p,sample)
      await snap(p,f'{sample}-desktop-conflict-long')
      res['flows']['conflict_comparison']=await inspect(p)
      await fill(q,'另一标签页 B2：连续更新','第二版本 / second remote revision\nConflict remains open during this change.')
      await save(q); await p.wait_for_timeout(180)
      if await p.locator('#conflict-history').is_visible():
        await p.locator('#conflict-history summary').click()
      await snap(p,f'{sample}-desktop-conflict-continuous')
      res['flows']['conflict_update']=await inspect(p)
      await p.set_viewport_size({'width':390,'height':844})
      await snap(p,f'{sample}-mobile-conflict-long',True)
      res['flows']['conflict_mobile']=await inspect(p)
      await p.locator('#conflict-later' if sample==17 else '#compare-later').click()
      res['flows']['postponed']=await inspect(p)
      await snap(p,f'{sample}-mobile-conflict-postponed',True)
      await show_conflict(p,sample)
      await p.locator('#keep-local' if sample==17 else '#keep-mine').click()
      res['flows']['keep_local']=await inspect(p)
      await save(p)
      await p.reload()
      res['flows']['keep_local_saved']=await inspect(p)
      await q.reload()
      await fill(p,'将被替换的本地草稿','local text to be replaced only after choice')
      await fill(q,'采用远端版本：已保存','remote text chosen deliberately')
      await save(q); await p.wait_for_timeout(120)
      await show_conflict(p,sample)
      await p.locator('#use-remote' if sample==17 else '#use-other').click()
      res['flows']['use_remote']=await inspect(p)
      await p.reload(); res['flows']['use_remote_reloaded']=await inspect(p)
      await q.close()
      await open_details(p)
      await p.locator('#simulate-failure').check()
      await fill(p,'保存失败后重试 / Retry','失败时应保留编辑内容。\nUnsaved text must stay available.')
      await save(p)
      await snap(p,f'{sample}-mobile-save-failure',True)
      res['flows']['failure']=await inspect(p)
      await p.locator('#simulate-failure').uncheck()
      await p.locator('#retry').click(); await p.wait_for_timeout(180)
      await snap(p,f'{sample}-mobile-retry-success',True)
      res['flows']['retry']=await inspect(p)
      await p.locator('#simulate-slow').check()
      await fill(p,'缓慢保存 / saving in progress','This save is intentionally delayed by one second.')
      await p.locator('#save').click()
      await snap(p,f'{sample}-mobile-saving-t0',True)
      res['flows']['saving_t0']=await inspect(p)
      await p.wait_for_timeout(350)
      await snap(p,f'{sample}-mobile-saving-t350',True)
      await p.wait_for_timeout(850)
      await snap(p,f'{sample}-mobile-saving-done',True)
      res['flows']['saving_done']=await inspect(p)
      await p.locator('#simulate-slow').uncheck()
      await p.locator('#locale-toggle').click(); await p.locator('#theme-toggle').click()
      await p.locator('#long-example').click()
      await snap(p,f'{sample}-mobile-long-en-dark',True)
      res['flows']['long_en_dark']=await inspect(p)
      await p.set_viewport_size({'width':1440,'height':900})
      await snap(p,f'{sample}-desktop-long-en-dark',True)
      res['flows']['long_en_dark_desktop']=await inspect(p)
      await ctx.close()
      (ROOT/'observations.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    await browser.close()

asyncio.run(main())
