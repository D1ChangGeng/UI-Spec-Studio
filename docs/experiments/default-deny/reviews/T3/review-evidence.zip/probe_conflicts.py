import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent
OUT={}
async def snap(p,n):
 await p.screenshot(path=str(ROOT/'screenshots'/(n+'.png')))
async def fill(p,t,b):
 await p.locator('#note-title').fill(t); await p.locator('#note-body').fill(b)
async def save(p):
 await p.locator('#save').click(); await p.wait_for_timeout(150)
async def state(p):
 return await p.evaluate('''()=>({title:document.querySelector('#note-title').value,body:document.querySelector('#note-body').value,dialog:document.querySelector('dialog').open,active:document.activeElement.id,activeVisible:!!document.activeElement.getClientRects().length,status:document.querySelector('#state-message').textContent,recent:document.querySelector('#recent-title').textContent,dialogText:document.querySelector('dialog').innerText,documentWidth:document.documentElement.scrollWidth,modal:[...document.querySelectorAll('dialog,dialog .comparison-grid,dialog .version-grid,dialog .version,dialog .version-body,dialog .version-text,dialog .comparison-footer')].map(e=>({cls:e.className,id:e.id,clientHeight:e.clientHeight,scrollHeight:e.scrollHeight,box:e.getBoundingClientRect().toJSON(),overflow:getComputedStyle(e).overflowY}))})''')
async def compare(p,n):
 if not await p.locator('dialog').evaluate('(e)=>e.open'): await p.locator('#review-conflict' if n==17 else '#compare').click()
async def details(p):
 if not await p.locator('.fixture-controls details').evaluate('(e)=>e.open'): await p.locator('.fixture-controls summary').click()
async def main():
 async with async_playwright() as pw:
  b=await pw.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
  for n,port in [(17,4415),(42,4416)]:
   r=OUT[str(n)]={}
   c=await b.new_context(viewport={'width':1440,'height':900});p=await c.new_page();await p.goto(f'http://127.0.0.1:{port}')
   await p.locator('#locale-toggle').click();await p.locator('#theme-toggle').click()
   await fill(p,'BASE A0','base body');await save(p)
   q=await c.new_page();await q.goto(f'http://127.0.0.1:{port}')
   await fill(p,'LOCAL L1','local unsaved body')
   await fill(q,'REMOTE B1','first remote body');await save(q)
   await compare(p,n)
   await fill(q,'REMOTE B2','second remote body');await save(q)
   await p.wait_for_timeout(700)
   r['b2_open']=await state(p);await snap(p,f'{n}-probe-b2-open-en-dark')
   await p.set_viewport_size({'width':390,'height':844})
   await snap(p,f'{n}-probe-b2-mobile-en-dark')
   r['b2_mobile']=await state(p)
   await p.locator('#use-remote' if n==17 else '#use-other').click()
   r['first_choose']=await state(p);await snap(p,f'{n}-probe-first-choose')
   if r['first_choose']['dialog']:
    await p.locator('#use-remote' if n==17 else '#use-other').click();r['second_choose']=await state(p);await snap(p,f'{n}-probe-second-choose')
   await p.keyboard.press('Tab');r['tab_after_choice']=await state(p)
   await p.reload();r['choice_reloaded']=await state(p)
   await q.reload()
   await fill(p,'LOCAL MUST SURVIVE RELOAD','unsaved content before any choice')
   await fill(q,'REMOTE B3','third remote body');await save(q)
   await compare(p,n)
   await p.locator('#conflict-later' if n==17 else '#compare-later').click()
   r['reload_before']=await state(p)
   await p.reload();r['reload_after']=await state(p);await snap(p,f'{n}-probe-reloaded-unresolved')
   if r['reload_after']['dialog']:
    await p.locator('#use-remote' if n==17 else '#use-other').click()
   await p.set_viewport_size({'width':1440,'height':900});await q.reload()
   await fill(p,'LOCAL DURING DELETE','deletion must not lose this draft')
   await details(q);await q.locator('#reset').click();await p.wait_for_timeout(200)
   r['remote_delete_arrival']=await state(p)
   if await p.locator('#review-conflict' if n==17 else '#compare').is_visible() or r['remote_delete_arrival']['dialog']:
    await compare(p,n);r['remote_delete_compare']=await state(p);await snap(p,f'{n}-probe-remote-delete')
    await p.locator('#keep-local' if n==17 else '#keep-mine').click()
   await save(p);await q.reload()
   await details(p);await p.locator('#simulate-slow').check()
   await fill(p,'SLOW LOCAL WRITE','pending delayed local write')
   await fill(q,'REMOTE DURING SLOW','remote save before local delay completes')
   await p.locator('#save').click()
   await q.locator('#save').click()
   await p.wait_for_timeout(1300)
   r['slow_race']=await state(p);await snap(p,f'{n}-probe-slow-race')
   await q.reload();r['slow_race_persisted']=await state(q)
   await c.close()
   (ROOT/'conflict-probes.json').write_text(json.dumps(OUT,ensure_ascii=False,indent=2))
  await b.close()
asyncio.run(main())
