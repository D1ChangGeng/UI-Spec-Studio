import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent
OUT={}
async def main():
 async with async_playwright() as pw:
  b=await pw.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
  for n,port in [(17,4415),(42,4416)]:
   c=await b.new_context(viewport={'width':390,'height':844});p=await c.new_page();await p.goto(f'http://127.0.0.1:{port}')
   await p.locator('#note-title').fill('INITIAL');await p.locator('#save').click();await p.wait_for_function("document.querySelector('#state-message').textContent.includes('已保存')")
   q=await c.new_page();await q.goto(f'http://127.0.0.1:{port}')
   await p.locator('#note-title').fill('本页长标题 / Long title '+('混合文字与很长的标题 '*10))
   await p.locator('#note-body').fill(('正文需可滚动阅读；混合引用、换行与 URL https://example.test/'+('word'*30)+'\n')*15)
   await q.locator('#note-title').fill('远端简短标题 / REMOTE');await q.locator('#note-body').fill('Remote version content.');await q.locator('#save').click()
   await q.wait_for_function("document.querySelector('#state-message').textContent.includes('已保存')")
   if not await p.locator('dialog').evaluate('(e)=>e.open'):await p.locator('#compare').click()
   grid=p.locator('.comparison-grid' if n==17 else '#mine-text');box=await grid.bounding_box()
   await p.mouse.move(box['x']+box['width']/2,min(box['y']+box['height']/2,650));await p.mouse.wheel(0,1000);await p.wait_for_timeout(250)
   await p.screenshot(path=str(ROOT/'screenshots'/f'{n}-mobile-comparison-scrolled.png'))
   r=OUT[str(n)]={'after_wheel':await p.evaluate('''()=>({elements:[...document.querySelectorAll('dialog,dialog .comparison-grid,dialog .version-grid,dialog .version-body,dialog .version-text,dialog button')].map(e=>({id:e.id,cls:e.className,top:e.scrollTop,client:e.clientHeight,height:e.scrollHeight,box:e.getBoundingClientRect().toJSON()}))})''')}
   if n==17:
    await p.mouse.move(345,500);await p.mouse.wheel(0,1000);await p.wait_for_timeout(250)
    await p.screenshot(path=str(ROOT/'screenshots'/f'{n}-mobile-comparison-outer-scrolled.png'))
    r['after_outer_wheel']=await p.evaluate('''()=>({gridScroll:document.querySelector('.comparison-grid').scrollTop,remoteButton:document.querySelector('#use-remote').getBoundingClientRect().toJSON()})''')
   await p.locator('#use-remote' if n==17 else '#use-other').click()
   r['remote_after_scroll']=await p.locator('#note-title').input_value()
   await q.close();await p.set_viewport_size({'width':1440,'height':900})
   await p.locator('#locale-toggle').click();await p.locator('#theme-toggle').click()
   await p.locator('.fixture-controls summary').click();await p.locator('#simulate-failure').check()
   await p.locator('#note-title').fill('Failure and recovery — desktop dark');await p.locator('#note-body').fill('Do not lose this text when saving fails.')
   await p.locator('#save').click();await p.locator('#retry').wait_for(state='visible')
   await p.screenshot(path=str(ROOT/'screenshots'/f'{n}-desktop-failure-en-dark.png'))
   r['failure_en']=await p.locator('#state-message').inner_text()
   await p.locator('#simulate-failure').uncheck();await p.locator('#retry').click();await p.locator('#retry').wait_for(state='hidden')
   await p.wait_for_function("document.querySelector('#state-message').textContent.includes('saved')")
   await p.screenshot(path=str(ROOT/'screenshots'/f'{n}-desktop-retry-en-dark.png'))
   r['retry_en']=await p.locator('#state-message').inner_text()
   await c.close();(ROOT/'mobile-scroll.json').write_text(json.dumps(OUT,ensure_ascii=False,indent=2))
  await b.close()
asyncio.run(main())
