import asyncio,json,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent
OUT={}
async def data(p):
 return await p.evaluate('''()=>({title:document.querySelector('#note-title').value,body:document.querySelector('#note-body').value,status:document.querySelector('#state-message').innerText,recent:document.querySelector('#recent-title').innerText,dialog:document.querySelector('dialog').open,slow:document.querySelector('#simulate-slow').checked,disabled:document.querySelector('#save').disabled,stored:Object.fromEntries(Object.entries(localStorage)),events:window.reviewEvents})''')
async def main():
 async with async_playwright() as pw:
  b=await pw.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
  for n,port in [(17,4415),(42,4416)]:
   c=await b.new_context(viewport={'width':1440,'height':900});p=await c.new_page();await p.goto(f'http://127.0.0.1:{port}')
   await p.locator('#note-title').fill('BASELINE');await p.locator('#note-body').fill('base');await p.locator('#save').click();await p.wait_for_timeout(150)
   q=await c.new_page();await q.goto(f'http://127.0.0.1:{port}')
   await p.evaluate('''()=>{window.reviewEvents=[];addEventListener('storage',e=>window.reviewEvents.push({at:performance.now(),key:e.key,newValue:e.newValue}));}''')
   await p.locator('.fixture-controls summary').click();await p.locator('#simulate-slow').check()
   await p.locator('#note-title').fill('LOCAL DELAYED');await p.locator('#note-body').fill('delayed local')
   await q.locator('#note-title').fill('REMOTE IMMEDIATE');await q.locator('#note-body').fill('remote must survive until choice')
   r=OUT[str(n)]={};t=time.monotonic()
   await p.locator('#save').click();r['after_local_click']={'elapsed':time.monotonic()-t,'p':await data(p),'q':await data(q)}
   await q.locator('#save').click();r['after_remote_click']={'elapsed':time.monotonic()-t,'p':await data(p),'q':await data(q)}
   await p.wait_for_timeout(120);r['at_120']={'elapsed':time.monotonic()-t,'p':await data(p),'q':await data(q)}
   await p.screenshot(path=str(ROOT/'screenshots'/f'{n}-race-after-remote.png'))
   await p.wait_for_timeout(1100);r['at_done']={'elapsed':time.monotonic()-t,'p':await data(p),'q':await data(q)}
   await p.screenshot(path=str(ROOT/'screenshots'/f'{n}-race-after-delay.png'))
   z=await c.new_page();await z.goto(f'http://127.0.0.1:{port}');r['fresh_reader']=await data(z)
   await c.close();(ROOT/'slow-race.json').write_text(json.dumps(OUT,ensure_ascii=False,indent=2))
  await b.close()
asyncio.run(main())
