# Index — 研究集合工作区

## 运行

```bash
cd /workspace/scratch/724448b5313d/ui-application-runs/T1-n2/app
npm run dev -- --host 127.0.0.1 --port 4314
```

入口：http://127.0.0.1:4314/

```bash
npm run build
```

产物在 `dist/`。此工作区已具备冻结的依赖链接，不要修改共享 node_modules。

## 实际功能

- 按标题、主题、摘要即时搜索；All collections / Saved 筛选。
- 卡片及阅读页收藏/取消收藏，localStorage 持久化，刷新可恢复。
- 持久化失败保留内存中的最新选择，显示明确的“仅当前会话”警告并提供 Retry save。
- 标题链接打开独立阅读视图，支持 URL 直接进入和浏览器前进/后退。
- 返回保持搜索、筛选、列表滚动和原卡片焦点；同一会话重新进入集合恢复阅读位置。
- 已收藏列表中移除最后一项后，焦点转向仍可用的筛选/结果区。
- MagicCard 的微弱暖光响应指针；减少动态或无悬停设备使用静态表面。
- 语义化 search、独立链接与收藏按钮、可见键盘焦点、状态播报和跳到内容链接。

## 结构与来源

- `src/App.jsx`：状态、浏览器历史、本地存储与界面组合。
- `src/collections.js`：任务提供的六个示例集合；没有补造单条引用链接。
- `src/styles.css`：Bootstrap 语义主题、阅读调整及 CSS 冲突修复。
- `src/vendor/`：实际采用的 Bootstrap CSS、官方 Blog CSS、MagicCard TSX 与 MIT 通知。
- 上一级 `DESIGN.md`：当前设计、来源责任、修订和证据范围。
- 上一级 `evidence/`：源演示和实际产品截图、可复现检查脚本与 JSON 结果。

## 已验证边界

Chrome for Testing 156.0.8078.80，1440×900 与 390×844，DPR 1。已查看实际截图；搜索、过滤、保存与刷新、取消收藏、浏览器后退、焦点归还、直接进入详情、存储失败与重试、长标题和减少动态均执行过。手机列表位置 1556→1556，阅读位置 420→420。页面运行错误记录为空。

检查脚本使用环境提供的 Python / Playwright 与 Chrome 路径：

```bash
FONTCONFIG_FILE=/tmp/ui-spec-fonts/fonts.conf /tmp/ui-spec-study-venv/bin/python ../evidence/check_ui.py
FONTCONFIG_FILE=/tmp/ui-spec-fonts/fonts.conf /tmp/ui-spec-study-venv/bin/python ../evidence/check_edges.py
```

## 明确限制

- 没有账户、服务端同步、跨设备收藏或真实研究内容管理。
- 六个示例集合保留原始摘要和代表性正文；引用数量是输入数据中的值，未提供逐条参考资料。
- 阅读位置与列表滚动保留在当前会话；刷新后持久的是收藏，搜索和筛选也可从 URL 恢复。
- 指针动态仅检查了进入、移动、离开的有序截图和实际操作，不声明逐帧流畅度或性能指标。
- 未完成实体手机、Safari、Firefox、屏幕阅读器或真实用户验收。
- 构建通过；依赖中 React server directive 的 Vite 警告未影响产物。
