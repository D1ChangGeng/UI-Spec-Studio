import os,json
from pathlib import Path
from playwright.sync_api import sync_playwright
os.environ['FONTCONFIG_FILE']='/tmp/ui-spec-fonts/fonts.conf'
ev=Path(__file__).resolve().parent
results=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':390,'height':844},reduced_motion='reduce')
 page.goto('http://127.0.0.1:4314/',wait_until='networkidle')
 page.keyboard.press('Tab');assert page.get_by_role('link',name='Skip to collections').evaluate('(e)=>e===document.activeElement')
 page.keyboard.press('Enter');page.get_by_label('Search collections',exact=True).focus();page.keyboard.type('quiet');page.keyboard.press('Tab');page.keyboard.press('Tab');page.keyboard.press('Tab');page.keyboard.press('Tab')
 assert page.evaluate('document.activeElement.id')=='open-quiet';page.screenshot(path=str(ev/'mobile-keyboard-focus.png'));page.keyboard.press('Enter');assert page.locator('#detail-title').evaluate('(e)=>e===document.activeElement');results.append({'keyboard_search_open':True})
 page.get_by_role('button',name='Save The quiet interface',exact=True).click();page.get_by_role('button',name='Back to collections',exact=True).click();page.wait_for_timeout(100);page.locator('#saved-filter').click();page.locator('#open-quiet').click();page.get_by_role('button',name='Unsave The quiet interface',exact=True).click();page.get_by_role('button',name='Back to collections',exact=True).click();page.wait_for_timeout(100)
 assert page.locator('.collection-card').count()==0;assert page.evaluate('document.activeElement.id')=='results-heading';page.screenshot(path=str(ev/'mobile-saved-empty.png'));results.append({'unsave_in_detail_returns_to_valid_focus':True})
 page.goto('http://127.0.0.1:4314/#city',wait_until='networkidle');assert page.locator('#detail-title').inner_text()=='A city after the last train';page.get_by_role('button',name='Back to collections',exact=True).click();page.wait_for_timeout(100);assert page.locator('.collection-card').count()==6;results.append({'direct_detail_return':True})
 page.evaluate("() => { Storage.prototype.setItem=function(){throw new Error('blocked')}; }");page.get_by_role('button',name='Save The quiet interface',exact=True).click();page.screenshot(path=str(ev/'mobile-storage-failure.png'));assert page.get_by_role('alert').is_visible();assert page.evaluate('document.documentElement.scrollWidth<=innerWidth');results.append({'mobile_storage_failure_readable':True})
 b.close()
(ev/'edge-checks.json').write_text(json.dumps(results,indent=2));print(json.dumps(results))
