import os,json,time
from pathlib import Path
from playwright.sync_api import sync_playwright
os.environ['FONTCONFIG_FILE']='/tmp/ui-spec-fonts/fonts.conf'
root=Path(__file__).resolve().parents[1]; ev=root/'evidence'; results=[]
def log(n,v=True):results.append({'check':n,'result':v})
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('http://127.0.0.1:4314/',wait_until='networkidle');page.screenshot(path=str(ev/'desktop-initial.png'))
 print('captured desktop',flush=True)
 log('initial cards',page.locator('.collection-card').count())
 page.get_by_label('Search collections',exact=True).fill('type');assert page.locator('.collection-card').count()==1
 page.locator('#open-type').click();assert page.locator('#detail-title').inner_text()=='Type as a way of thinking'
 page.get_by_role('button',name='Back to collections',exact=True).click();page.wait_for_timeout(150)
 assert page.get_by_label('Search collections',exact=True).input_value()=='type';assert page.evaluate('document.activeElement.id')=='open-type';log('search and focus return')
 page.get_by_role('button',name='Save Type as a way of thinking',exact=True).click();page.reload(wait_until='networkidle');assert page.get_by_role('button',name='Unsave Type as a way of thinking',exact=True).count()==1;log('save persists after reload')
 page.get_by_role('button',name='Clear search',exact=True).click();page.locator('#saved-filter').click();assert page.locator('.collection-card').count()==1
 page.locator('#open-type').click();page.go_back();page.wait_for_timeout(150);assert page.locator('#saved-filter').get_attribute('aria-pressed')=='true';log('browser back retains filter')
 page.get_by_role('button',name='Unsave Type as a way of thinking',exact=True).click();assert page.locator('.collection-card').count()==0;page.wait_for_timeout(100);assert page.evaluate('document.activeElement.id')=='saved-filter';log('unsave filtered result and focus recovery')
 page.screenshot(path=str(ev/'saved-empty.png'))
 page.get_by_role('button',name='Explore all collections',exact=True).click()
 page.evaluate("() => { window._originalSet=Storage.prototype.setItem; Storage.prototype.setItem=function(){throw new DOMException('quota','QuotaExceededError')}; }")
 page.get_by_role('button',name='Save The quiet interface',exact=True).click();assert page.get_by_role('alert').is_visible();assert page.get_by_role('button',name='Unsave The quiet interface',exact=True).count()==1
 page.screenshot(path=str(ev/'storage-failure.png'));log('write failure retains usable session state')
 page.evaluate('() => { Storage.prototype.setItem=window._originalSet; }');page.get_by_role('button',name='Retry save',exact=True).click();assert page.get_by_role('alert').count()==0;assert 'quiet' in page.evaluate("localStorage.getItem('index.saved.v1')");log('retry persists session changes')
 page.get_by_label('Search collections',exact=True).fill('no matching collection');page.screenshot(path=str(ev/'search-empty.png'));assert page.locator('.collection-card').count()==0
 page.get_by_role('button',name='Clear filters',exact=True).click();page.locator('#open-time').click();page.screenshot(path=str(ev/'desktop-detail.png'));log('long-title detail')
 page.get_by_role('button',name='Back to collections',exact=True).click();page.wait_for_timeout(150)
 page.evaluate('window.scrollTo(0,0)');page.mouse.move(80,510);page.wait_for_timeout(100);page.screenshot(path=str(ev/'pointer-01.png'));t0=time.monotonic()
 page.mouse.move(450,760,steps=20);page.wait_for_timeout(100);page.screenshot(path=str(ev/'pointer-02.png'));t1=time.monotonic()
 page.mouse.move(1380,400);page.wait_for_timeout(350);page.screenshot(path=str(ev/'pointer-03.png'));t2=time.monotonic();log('pointer capture offsets',[0,round(t1-t0,3),round(t2-t0,3)])
 page.set_viewport_size({'width':390,'height':844});page.screenshot(path=str(ev/'mobile-initial.png'));assert page.evaluate('document.documentElement.scrollWidth <= innerWidth');log('390 no horizontal overflow')
 page.locator('#open-time').scroll_into_view_if_needed();y=page.evaluate('scrollY');page.screenshot(path=str(ev/'mobile-long-card.png'));page.locator('#open-time').click();page.evaluate('window.scrollTo(0,0)');page.screenshot(path=str(ev/'mobile-detail.png'))
 assert page.evaluate('document.documentElement.scrollWidth <= innerWidth');page.evaluate('window.scrollTo(0,420)');read_y=page.evaluate('scrollY');page.get_by_role('button',name='Back to collections',exact=True).click();page.wait_for_timeout(150);restored=page.evaluate('scrollY');print('RESTORE',y,restored,page.evaluate('history.state'),flush=True);assert abs(restored-y)<5;log('mobile list scroll restored',{'before':y,'after':restored})
 page.locator('#open-time').click();page.wait_for_timeout(150);assert abs(read_y-page.evaluate('scrollY'))<5;log('reading context restored',{'wanted':read_y,'actual':page.evaluate('scrollY')})
 page.get_by_role('button',name='Back to collections',exact=True).click();page.wait_for_timeout(150)
 page.emulate_media(reduced_motion='reduce');assert page.locator('.collection-card .z-30').first.evaluate('(el)=>getComputedStyle(el).display')=='none';page.evaluate('window.scrollTo(0,0)');page.screenshot(path=str(ev/'mobile-reduced-motion.png'));log('reduced motion static card')
 log('page errors',errors);assert not errors
 b.close()
(ev/'checks.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
