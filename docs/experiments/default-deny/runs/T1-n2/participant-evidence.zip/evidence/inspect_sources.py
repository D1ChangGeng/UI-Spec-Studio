import os,json,time,urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright
os.environ['FONTCONFIG_FILE']='/tmp/ui-spec-fonts/fonts.conf'
root=Path(__file__).resolve().parents[1]
results=[]
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
    page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1,ignore_https_errors=True)
    for name,url in [('album','https://getbootstrap.com/docs/5.3/examples/album/'),('blog','https://getbootstrap.com/docs/5.3/examples/blog/'),('magic','https://magicui.design/docs/components/magic-card')]:
        try:
            page.goto(url,wait_until='domcontentloaded',timeout=20000)
            page.wait_for_timeout(1200)
            if name=='magic':
                page.get_by_role('heading',name='Magic Card',exact=True).scroll_into_view_if_needed()
            page.screenshot(path=str(root/'evidence'/f'source-{name}.png'))
            if name=='magic':
                page.mouse.move(850,570)
                page.wait_for_timeout(300)
                page.screenshot(path=str(root/'evidence'/'source-magic-hover.png'))
            results.append({'source':url,'captured':True})
        except Exception as e: results.append({'source':url,'error':str(e)})
    try:
        css=urllib.request.urlopen('https://getbootstrap.com/docs/5.3/examples/blog/blog.css',timeout=10).read()
        (root/'app/src/vendor/blog.css').write_bytes(css)
        results.append({'blog_css':'acquired','bytes':len(css)})
    except Exception as e: results.append({'blog_css_error':str(e)})
    b.close()
(root/'evidence/source-capture.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results))
