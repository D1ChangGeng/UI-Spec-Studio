# Index — 研究收藏工作区

本地运行入口：**http://127.0.0.1:4311/**

```bash
cd /workspace/scratch/724448b5313d/ui-application-runs/T1-p6/app
npm run dev -- --host 127.0.0.1 --port 4311
```

生产构建：`npm run build`，输出到 `app/dist/`。当前开发服务器已启动。没有发布到外部环境，没有更改共享 node_modules。

## 已实现

- 六条原始研究收藏数据；保留英文标题、分类、摘要、正文、日期及参考数量。
- 不区分大小写的全文搜索，覆盖标题、分类、摘要和正文；多词匹配。
- 全部／已保存筛选，保存和取消保存，数量实时更新。
- `localStorage` 的真实持久化（键为 `index.saved.v1`）。刷新保留已保存项。
- 写入失败时保留本次会话的内存状态，显示明确提示，并可重试持久化；读取失败有独立提示。
- 原生链接的详情入口、浏览器历史、返回收藏、直接详情 URL；返回保留查询、筛选、列表位置、打开卡片的焦点；重新打开详情恢复本次会话阅读位置。
- `/` 聚焦搜索，`Escape` 返回列表，原生 Tab／Enter 操作，可见焦点、状态宣告和独立保存按钮。
- 石墨色、暖白文字、铜色点缀；本地托管 Instrument Serif 和 DM Sans。三列／两列／单列响应式卡片，长标题自然换行。
- Magic UI MagicCard 的低强度指针表面，触摸输入静态显示，动态监听 `prefers-reduced-motion` 并移除可选运动。

## 实际检查

Chrome for Testing 156.0.8078.80，1440×900 与 390×844。最终手机集合／详情为触摸设备模拟；错误状态另有窄桌面视口检查。

`../evidence/verification.json`：29 项行为检查通过。
`../evidence/final-scoped-checks.json`：6 项针对性复查通过。
`../evidence/all-detail-captures.json`：全部六个详情 × 两个视口，均无横向溢出。

测试内容包含保存与刷新、大小写搜索、筛选／焦点返回、最后一个已保存项移除、实际 Storage 写失败与重试、系统减少运动偏好切换、键盘可见焦点和直接详情入口。手机列表位置为 1568→1568，详情阅读位置为 680→680。所执行路径未出现页面运行异常。

运行复核脚本（浏览器进程需要本环境的本地执行权限）：

```bash
cd /workspace/scratch/724448b5313d/ui-application-runs/T1-p6
/tmp/ui-spec-study-venv/bin/python evidence/verify_product.py
/tmp/ui-spec-study-venv/bin/python evidence/final_scoped_checks.py
```

构建成功。构建日志包含依赖包的 `use client` 指令被 Vite 忽略的提示，详细记录在 `../evidence/build-final.log`。

## 证据、维护与范围

- 实际产品截图：`../evidence/desktop-collection.png`、`../evidence/mobile-collection.png`、`../evidence/*-detail-*.png`。
- 设计决定、发现及修复：`../DESIGN.md`。
- 来源／版本／许可证：`../SOURCES.md`；字体和 Magic UI 许可证置于 `public/licenses/`。
- 材质试验：开发模式 `/trial.html`。它是研究对照页面，不在产品导航中，也不在默认生产入口中。
- 收藏内容是任务提供的样例；没有接入真实远程参考文献库。计数来自原始样例数据，详情展示原始 collection notes。
- 保存仅针对当前浏览器与同一 origin。没有账户同步、多标签页冲突合并或跨设备恢复。滚动／阅读位置保留于当前页面会话；刷新后不承诺恢复阅读位置。
- 已执行 Chrome 的真实 DOM 与截图检查，未执行 Safari／Firefox、真实手机性能、屏幕阅读器用户测试或完整 WCAG 审计。
- 指针视觉证据是按实际顺序查看的四个时间采样帧，具有捕获时间括号；不将其表述为连续视频或帧率测量。
- 用户尚未对视觉偏好做验收。本次交付为已实现、已检查的工作版本。
