import React, {useEffect, useLayoutEffect, useMemo, useRef, useState} from 'react';
import {ArrowLeft, ArrowUpRight, Bookmark, Check, Search, X, ArrowRight, LibraryBig, AlertCircle, RotateCcw} from 'lucide-react';
import {collections} from './collections.js';
import {MagicCard} from './components/magic-card';

const STORAGE_KEY = 'index.saved.v1';
const validIds = new Set(collections.map(item => item.id));
const totalReferences = collections.reduce((sum,item) => sum + parseInt(item.count),0);
const number = value => String(value).padStart(2,'0');
const selectedFromURL = () => collections.find(item => `#collection/${item.id}` === window.location.hash) || null;
function loadSaved() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw === null) return {ids:[], error:false};
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || parsed.some(id => typeof id !== 'string')) throw new Error('Invalid saved data');
    return {ids:[...new Set(parsed.filter(id => validIds.has(id)))],error:false};
  } catch {return {ids:[],error:'read'};}
}

export default function App(){
  const [initialSaved] = useState(loadSaved);
  const [saved,setSaved] = useState(initialSaved.ids);
  const savedRef = useRef(saved);
  const [storageError,setStorageError] = useState(initialSaved.error);
  const [query,setQuery] = useState(() => new URLSearchParams(location.search).get('q') || '');
  const [savedOnly,setSavedOnly] = useState(() => new URLSearchParams(location.search).get('saved') === '1');
  const [selected,setSelected] = useState(selectedFromURL);
  const [notice,setNotice] = useState('');
  const searchRef = useRef(null);
  const listScroll = useRef(0);
  const readingPositions = useRef({});
  const returnFocus = useRef(null);
  const firstRender = useRef(true);
  const shown = useMemo(() => collections.filter(item => {
    const text = [item.title,item.category,item.summary,...item.body].join(' ').toLowerCase();
    return (!savedOnly || saved.includes(item.id)) && query.toLowerCase().trim().split(/\s+/).every(word => text.includes(word));
  }),[query,savedOnly,saved]);

  useEffect(() => {
    const url = new URL(location.href);
    query ? url.searchParams.set('q',query) : url.searchParams.delete('q');
    savedOnly ? url.searchParams.set('saved','1') : url.searchParams.delete('saved');
    history.replaceState(history.state,'',url);
  },[query,savedOnly]);

  useEffect(() => {
    const previous = history.scrollRestoration;
    history.scrollRestoration = 'manual';
    return () => {history.scrollRestoration = previous;};
  },[]);

  useEffect(() => {
    const onNavigation = () => {
      if(selected) readingPositions.current[selected.id] = window.scrollY;
      else listScroll.current = window.scrollY;
      setSelected(selectedFromURL());
      const params = new URLSearchParams(location.search);
      setQuery(params.get('q') || '');
      setSavedOnly(params.get('saved') === '1');
    };
    window.addEventListener('popstate',onNavigation);
    window.addEventListener('hashchange',onNavigation);
    return () => {window.removeEventListener('popstate',onNavigation);window.removeEventListener('hashchange',onNavigation);};
  },[selected]);

  useLayoutEffect(() => {
    document.title = selected ? `${selected.title} — Index` : 'Index — Research collections';
    if(firstRender.current){firstRender.current=false;return;}
    const frame = requestAnimationFrame(() => {
      window.scrollTo({top:selected ? readingPositions.current[selected.id] || 0 : listScroll.current,behavior:'instant'});
      const target = selected ? document.getElementById('detail-title') : document.getElementById(`open-${returnFocus.current}`) || document.getElementById('results-title');
      target?.focus({preventScroll:true});
    });
    return () => cancelAnimationFrame(frame);
  },[selected]);

  useEffect(() => {
    const onKey = event => {
      const editing = event.target instanceof HTMLElement && (event.target.matches('input,textarea,select') || event.target.isContentEditable);
      if(event.key === '/' && !editing && !selected){event.preventDefault();searchRef.current?.focus();}
      if(event.key === 'Escape' && selected && !editing){event.preventDefault();backToCollections();}
    };
    window.addEventListener('keydown',onKey);
    return () => window.removeEventListener('keydown',onKey);
  },[selected]);

  useEffect(() => {
    if(!notice) return;
    const timer=setTimeout(() => setNotice(''),6500);
    return () => clearTimeout(timer);
  },[notice]);

  function openCollection(event,item){
    if(event.button!==0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    listScroll.current=window.scrollY;
    returnFocus.current=item.id;
    history.pushState({fromCollection:true},'',`${location.pathname}${location.search}#collection/${item.id}`);
    setSelected(item);
  }
  function backToCollections(event){
    event?.preventDefault();
    if(!selected) return;
    readingPositions.current[selected.id]=window.scrollY;
    if(history.state?.fromCollection){history.back();}
    else {history.replaceState(null,'',`${location.pathname}${location.search}`);setSelected(null);}
  }
  function persist(ids){
    try {localStorage.setItem(STORAGE_KEY,JSON.stringify(ids));setStorageError(false);return true;}
    catch {setStorageError('write');return false;}
  }
  function toggleSave(item,button){
    const adding=!savedRef.current.includes(item.id);
    const next=adding ? [...savedRef.current,item.id] : savedRef.current.filter(id => id!==item.id);
    savedRef.current=next;
    setSaved(next);
    const durable=persist(next);
    setNotice(durable ? (adding ? 'Collection saved to this browser.' : 'Collection removed from saved.') : (adding ? 'Saved for this session only.' : 'Removed for this session only.'));
    if(!adding && savedOnly && !selected) requestAnimationFrame(() => {if(!button?.isConnected) document.getElementById('results-title')?.focus({preventScroll:true});});
  }
  function retrySave(){
    const success=persist(savedRef.current);
    setNotice(success ? 'Your saved collections are now stored in this browser.' : 'Storage is still unavailable. Your session changes are kept.');
  }
  function clearFilters(){setQuery('');setSavedOnly(false);searchRef.current?.focus();}
  const saveButton = (item,detail=false) => <button type="button" className={`save-button ${detail?'save-detail':''} ${saved.includes(item.id)?'is-saved':''}`} aria-label={`${saved.includes(item.id)?'Saved: unsave':'Save'} ${item.title}`} aria-pressed={saved.includes(item.id)} onClick={e=>toggleSave(item,e.currentTarget)}><Bookmark size={17} fill={saved.includes(item.id)?'currentColor':'none'} strokeWidth={1.6}/><span>{saved.includes(item.id)?'Saved':'Save'}{detail && !saved.includes(item.id)?' collection':''}</span></button>;

  return <>
    <a className="skip-link" href="#main-content">Skip to content</a>
    <header className="site-header"><div className="header-inner">
      <a className="wordmark" href={`${location.pathname}${location.search}`} onClick={backToCollections} aria-label="Index — back to collections"><LibraryBig size={22} strokeWidth={1.35}/><span>Index<span className="wordmark-dot">.</span></span></a>
      <a className="nav-link" href={`${location.pathname}${location.search}`} onClick={backToCollections} aria-current="page">Collections</a>
      <div className="workspace-label"><span className="status-dot"/>Your personal index</div>
    </div></header>
    {storageError && <div className="storage-warning" role="alert"><AlertCircle size={20}/><div><strong>{storageError==='read' ? 'Previous saves could not be loaded.' : 'Changes are kept for this session.'}</strong><p>{storageError==='read' ? 'You can keep collecting here. Retry saving will store your current selection.' : 'Browser storage is unavailable. Your saves may be lost when this page closes.'}</p></div><button type="button" onClick={retrySave}><RotateCcw size={15}/>Retry saving</button></div>}
    <main id="main-content" className={selected?'detail-main':'collection-main'}>
      {selected ? <>
        <div className="detail-nav"><a href={`${location.pathname}${location.search}`} onClick={backToCollections}><ArrowLeft size={17}/>Back to collections</a><span className="detail-position">COLLECTION {number(collections.indexOf(selected)+1)} / {number(collections.length)}</span></div>
        <article className="detail-layout">
          <aside className="detail-aside"><div className="aside-line"/><p className="eyebrow">In this collection</p><dl><div><dt>Topic</dt><dd>{selected.category}</dd></div><div><dt>Collected</dt><dd>{selected.count}</dd></div><div><dt>Last updated</dt><dd>{selected.updated}</dd></div></dl>{saveButton(selected,true)}<p className="aside-note">A small place to keep<br/>a bigger train of thought.</p></aside>
          <div className="detail-content"><p className="eyebrow accent">{selected.category}</p><h1 id="detail-title" tabIndex={-1}>{selected.title}</h1><p className="detail-lede">{selected.summary}</p><div className="reading-rule"><span>Collection notes</span><span>01 — 03</span></div><div className="reading-body">{selected.body.slice(1).map((paragraph,index)=><p key={index}>{paragraph}</p>)}</div><div className="detail-ending"><span className="end-mark" aria-hidden="true">✳</span><p>Good questions are worth returning to.</p><a href={`${location.pathname}${location.search}`} onClick={backToCollections}>Back to your collections<ArrowRight size={16}/></a></div></div>
        </article>
      </> : <>
        <section className="intro" aria-labelledby="page-title"><div><p className="eyebrow intro-kicker"><span/>A space for curious minds</p><h1 id="page-title">Worth another look.</h1><p className="intro-copy">Ideas, observations and references.<br/>Collected to keep your thinking moving.</p></div><div className="collection-tally"><span className="tally-number">{number(collections.length)}</span><div><span>Ongoing collections</span><small>{totalReferences} references to return to</small></div></div></section>
        <section className="collection-tools" aria-label="Find collections"><div className="filter-tabs"><button type="button" className={!savedOnly?'active':''} aria-pressed={!savedOnly} onClick={()=>setSavedOnly(false)}>All collections<span>{number(collections.length)}</span></button><button type="button" className={savedOnly?'active':''} aria-pressed={savedOnly} onClick={()=>setSavedOnly(true)}><Bookmark size={15}/>Saved<span>{number(saved.length)}</span></button></div><div className="search-field"><label className="sr-only" htmlFor="collection-search">Search collections</label><Search size={18} aria-hidden="true"/><input ref={searchRef} id="collection-search" type="search" placeholder="Search your collection…" value={query} onChange={event=>setQuery(event.target.value)} autoComplete="off"/>{query ? <button type="button" aria-label="Clear search" onClick={()=>{setQuery('');searchRef.current?.focus();}}><X size={16}/></button>:<kbd aria-hidden="true">/</kbd>}</div></section>
        <div className="results-heading"><h2 id="results-title" tabIndex={-1} aria-live="polite">{number(shown.length)} {shown.length===1?'collection':'collections'}{query && <span> matching “{query}”</span>}</h2><span>Recently updated</span></div>
        {shown.length ? <section className="collection-grid" aria-label={savedOnly?'Saved collections':'All collections'}>{shown.map(item=><MagicCard key={item.id} className="collection-card-shell" gradientSize={360} gradientFrom="#cf9b72" gradientTo="#554333" gradientColor="#c8956d" gradientOpacity={0.10}><article className="collection-card"><header className="card-top"><p className="eyebrow">{item.category}</p><span className="card-number">{number(collections.indexOf(item)+1)}</span></header><h3><a id={`open-${item.id}`} className="card-link" href={`${location.pathname}${location.search}#collection/${item.id}`} onClick={event=>openCollection(event,item)}>{item.title}<ArrowUpRight className="open-arrow" size={22} strokeWidth={1.3}/></a></h3><p className="card-summary">{item.summary}</p><footer className="card-footer"><span>{item.count}</span>{saveButton(item)}</footer></article></MagicCard>)}</section> : <section className="empty-state"><div className="empty-icon">{savedOnly && !query?<Bookmark size={27} strokeWidth={1.25}/>:<Search size={27} strokeWidth={1.25}/>}</div><p className="eyebrow">{savedOnly && !query?'A little room for discovery':'Keep looking'}</p><h2>{savedOnly && !query?'Your favorites start here.':'Nothing here, just yet.'}</h2><p>{savedOnly && !query?'Save a collection that catches your eye. It will be waiting here when you return.':`No collections match “${query}”${savedOnly?' in your saved items':''}. Try a different title or topic.`}</p><button type="button" className="text-action" onClick={clearFilters}>{savedOnly && !query?'Explore all collections':'Clear filters'}<ArrowRight size={16}/></button></section>}
      </>}
    </main>
    <footer className="site-footer"><span>Stay curious. Keep collecting.</span><span>Sample research collections <span aria-hidden="true">·</span> Saves stay in this browser</span></footer>
    <div className={`notice ${notice?'is-visible':''}`} role="status" aria-live="polite">{notice && <>{storageError?<AlertCircle size={17}/>:<Check size={17}/>}<span>{notice}</span><button type="button" onClick={()=>setNotice('')} aria-label="Dismiss notification"><X size={15}/></button></>}</div>
  </>;
}
