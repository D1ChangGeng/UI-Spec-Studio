# 来源、采用与观察边界

## 任务来源

`TASK.md`、`RUN.md`、`ENVIRONMENT.md`；数据来源为未修改的 `app/src/collections.js`。ui-spec v1.18.0 的 SKILL、八项共同参考以及 integration、evidence-map、evidence-actions 已在实施前实际读取。

## 设计与实现

| 来源 | 版本／位置 | 本项目的实际使用 |
|---|---|---|
| [Magic UI Magic Card](https://magicui.design/docs/components/magic-card) | resources/magicui/magic-card.tsx；revision efe76fc5755eca1142dd4f74c1d6f0ace2887e3c；MIT | 实际采用至 app/src/components/magic-card.tsx。保留径向表面与边缘光、指针位置和全局重置；增加动态减少运动及触摸门控。 |
| [Magic UI Shine Border](https://magicui.design/docs/components/shine-border) | 同一 revision；MIT | 仅本地候选试验使用，不进入生产主入口。 |
| [Bootstrap Album](https://getbootstrap.com/docs/5.3/examples/album/) | 5.3；提供的源码 revision 25aa8cc0b32f0d1a54be575347e6d84b70b1acd7 | 观察完整官方示例，作为集合／动作组织参照；没有把 Bootstrap CSS 或页面代码当成实际采用。 |
| Kokonut CardFlip | 提供的源码 revision b0dfe2b058e1041d5e1f95af462d0dc9e758d06e | 检查过代码机制；没有查看其实际演示，不声称已完成视觉对照；未采用。 |
| Lucide React | starter 锁定安装，package-lock.json | 搜索、书签、返回、提示等同一图标体系。 |
| [Instrument Serif](https://github.com/google/fonts/tree/main/ofl/instrumentserif) | Google Fonts 官方；2026-10-30 获取；OFL | display／标题；本地字体文件与许可证，哈希见 evidence/implementation-sha256.txt。 |
| [DM Sans](https://github.com/google/fonts/tree/main/ofl/dmsans) | Google Fonts 官方；2026-10-30 获取；OFL | 正文／控件；本地变量字体文件与许可证。 |

页级结构、排版 token、搜索／保存／导航状态、恢复规则为本项目实现。没有把图标库或功能依赖当成整页视觉成熟度证明。没有使用第三方摄影或生成图片。

## 实际观察

- `evidence/magic-original.png`：官方 Magic Card 文档的实际浅色演示。通过公开网页只读访问；没有操作登录表单。
- `evidence/album-original.png`：Bootstrap Album 完整首屏；实际观察图片占位、三列关系、文案与独立动作。
- `evidence/material-trial.png`：当前项目的同内容三材质试验。仅渐变面接受了指针；不可据此声称三个候选完整运动均已观察。
- `evidence/pointer-*.png` 与 `pointer-episode.json`：整合产品的静止→进入→移动→退出，已按顺序查看，正文位置保持不变。时间为主机单调时钟捕获括号，帧之间未作连续播放判断。
- 最终 `desktop-collection.png`、`mobile-collection.png`、各 `*-detail-*.png`、空状态、失败与恢复、键盘焦点均在实际浏览器运行时截图。

公开页面初次请求遇到本环境代理证书信任问题。随后仅针对无凭据公开页面使用测试浏览器 ignore_https_errors；保留实际访问日志 source-captures.json。官方文档文本也经 web 检索读取。浏览器失败不是对资源设计质量的判断。

## 现代 Web 建议

使用 modern-web-guidance CLI 搜索后读取 `card` 与 `interactive-content-reveal` 指南，全文保留在 `modern-guidance-retrieved.txt`。落实 article＋原生链接／独立按钮、拉伸链接的独立动作层、默认可读内容、可选指针增强和减少动态效果。未强行引入本任务不需要的遮罩或新 API。
