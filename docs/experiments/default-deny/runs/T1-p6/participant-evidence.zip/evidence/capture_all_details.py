import asyncio,json,os,time
from pathlib import Path
from playwright.async_api import async_playwright,expect
os.environ['FONTCONFIG_FILE']='/tmp/ui-spec-fonts/fonts.conf'
ROOT=Path(__file__).resolve().parent
items=json.loads((ROOT.parent/'app/src/collections.js').read_text().split('=',1)[1].strip().rstrip(';'))
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
  records=[]
  for view,w,h in [('desktop',1440,900),('mobile',390,844)]:
   page=await browser.new_page(viewport={'width':w,'height':h},is_mobile=view=='mobile',has_touch=view=='mobile')
   for item in items:
    await page.goto('http://127.0.0.1:4311/#collection/'+item['id'],wait_until='networkidle')
    await expect(page.locator('#detail-title')).to_have_text(item['title'])
    await expect(page.locator('#detail-title')).to_be_visible()
    await page.evaluate('document.fonts.ready')
    await page.evaluate('new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))')
    path=f'{view}-detail-{item["id"]}.png'
    await page.screenshot(path=str(ROOT/path))
    overflow=await page.evaluate('document.documentElement.scrollWidth>innerWidth')
    assert not overflow
    records.append({'id':item['id'],'viewport':[w,h],'file':path,'overflow':overflow,'captured_at':time.time()})
   await page.close()
  await browser.close()
 (ROOT/'all-detail-captures.json').write_text(json.dumps(records,indent=2))
 print('12 detail viewport captures completed; no horizontal overflow')
asyncio.run(main())
