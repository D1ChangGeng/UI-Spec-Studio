import asyncio, json, time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT = Path(__file__).resolve().parent
async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
        page = await browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1,ignore_https_errors=True)
        logs=[]
        for name,url in [('magic-original','https://magicui.design/docs/components/magic-card'),('album-original','https://getbootstrap.com/docs/5.3/examples/album/')]:
            try:
                await page.goto(url,wait_until='domcontentloaded',timeout=25000)
                await page.wait_for_timeout(1200)
                if name=='magic-original':
                    heading=page.get_by_role('heading',name='Magic Card',exact=True)
                    await heading.scroll_into_view_if_needed()
                    await page.mouse.move(800,550)
                    await page.wait_for_timeout(400)
                await page.screenshot(path=str(ROOT/(name+'.png')))
                logs.append({'name':name,'url':url,'title':await page.title(),'time':time.time()})
            except Exception as e:
                logs.append({'name':name,'url':url,'error':str(e)})
        (ROOT/'source-captures.json').write_text(json.dumps(logs,indent=2))
        await browser.close()
asyncio.run(main())
