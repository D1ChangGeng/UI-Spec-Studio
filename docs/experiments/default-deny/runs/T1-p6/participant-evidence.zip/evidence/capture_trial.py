import asyncio,json,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
  page=await browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
  await page.goto('http://127.0.0.1:4311/trial.html')
  await page.wait_for_timeout(1000)
  await page.mouse.move(300,380)
  await page.screenshot(path=str(ROOT/'material-trial.png'))
  await browser.close()
asyncio.run(main())
