import asyncio,json,os,time
from pathlib import Path
from playwright.async_api import async_playwright,expect
os.environ['FONTCONFIG_FILE']='/tmp/ui-spec-fonts/fonts.conf'
ROOT=Path(__file__).resolve().parent
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
  page=await browser.new_page(viewport={'width':1440,'height':900},reduced_motion='reduce')
  await page.goto('http://127.0.0.1:4311/',wait_until='networkidle')
  await page.locator('#open-quiet').focus()
  await page.keyboard.press('Tab')
  button=page.get_by_role('button',name='Save The quiet interface',exact=True)
  await expect(button).to_be_focused()
  focus=await button.evaluate('(node)=>({width:getComputedStyle(node).outlineWidth,style:getComputedStyle(node).outlineStyle,focusVisible:node.matches(\':focus-visible\')})')
  assert focus['focusVisible'] and focus['width']=='2px'
  await page.screenshot(path=str(ROOT/'desktop-keyboard-focus-final.png'))
  await page.set_viewport_size({'width':390,'height':844})
  await page.evaluate("() => {Storage.prototype.setItem=function(){throw new Error('blocked')}}")
  await button.click()
  await page.evaluate('scrollTo(0,0)')
  await page.screenshot(path=str(ROOT/'mobile-storage-failure-final.png'))
  assert await page.locator('.storage-warning').is_visible()
  assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth')
  await page.get_by_role('button',name='Retry saving',exact=True).click()
  assert 'still unavailable' in await page.locator('.notice').inner_text()
  await page.get_by_role('button',name='Dismiss notification',exact=True).click()
  await page.get_by_role('button',name='Saved: unsave The quiet interface',exact=True).click()
  assert await page.get_by_role('button',name='Save The quiet interface',exact=True).get_attribute('aria-pressed')=='false'
  await page.close()
  direct=await browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
  await direct.goto('http://127.0.0.1:4311/?q=city#collection/city',wait_until='networkidle')
  assert await direct.locator('#detail-title').inner_text()=='A city after the last train'
  await direct.get_by_role('link',name='Back to collections',exact=True).click()
  await expect(direct.locator('#collection-search')).to_have_value('city')
  await expect(direct.locator('.collection-card')).to_have_count(1)
  await direct.screenshot(path=str(ROOT/'mobile-filtered-final.png'))
  await browser.close()
 (ROOT/'final-scoped-checks.json').write_text(json.dumps({'checks':['Real Tab produces visible focus with 2px outline','Initial reduced-motion mode is usable','Final narrow failure banner has no overflow','Repeated failure retry reports current truth','Unsaving stays usable during failure','Direct detail URL returns with query retained'],'focus':focus,'passed':6},indent=2))
 print('6 final scoped checks passed')
asyncio.run(main())
