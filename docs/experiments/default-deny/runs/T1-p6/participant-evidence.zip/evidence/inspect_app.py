import asyncio,json,time,os
from pathlib import Path
from playwright.async_api import async_playwright
os.environ['FONTCONFIG_FILE']='/tmp/ui-spec-fonts/fonts.conf'
ROOT=Path(__file__).resolve().parent
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
  errors=[]
  metadata=[]
  for name,size in [('desktop',{'width':1440,'height':900}),('mobile',{'width':390,'height':844})]:
   page=await browser.new_page(viewport=size,device_scale_factor=1,is_mobile=name=='mobile',has_touch=name=='mobile')
   page.on('pageerror',lambda e: errors.append(str(e)))
   await page.goto('http://127.0.0.1:4311/',wait_until='networkidle')
   await page.evaluate('document.fonts.ready')
   metadata.append({'view':name,'viewport':size,'browser':browser.version,'mobile_touch_emulation':name=='mobile','fonts':await page.evaluate("({display:document.fonts.check('20px \"Instrument Serif\"'),body:document.fonts.check('14px \"DM Sans\"')})"),'captured_at':time.time()})
   await page.screenshot(path=str(ROOT/(name+'-collection.png')))
   await page.screenshot(path=str(ROOT/(name+'-full.png')),full_page=True)
   await page.get_by_role('link',name='Keeping your place when everything around you is changing').click()
   await page.wait_for_timeout(200)
   await page.screenshot(path=str(ROOT/(name+'-detail.png')))
   await page.screenshot(path=str(ROOT/(name+'-detail-full.png')),full_page=True)
   await page.close()
  (ROOT/'initial-inspection.json').write_text(json.dumps({'errors':errors,'captures':metadata},indent=2))
  await browser.close()
asyncio.run(main())
