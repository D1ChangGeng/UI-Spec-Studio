# Fieldnote

单条研究笔记的浏览器本地演示。编辑、预览、保存与恢复继续由 vanilla `app.js` 管理；Kokonut CardFlip v2 作为 React 局部组件提供连续翻面、厚边、光带和落影。

## 运行

在此 `app/` 目录运行：

```bash
npm run dev -- --host 127.0.0.1 --port 4312
```

打开 http://127.0.0.1:4312/ 。原始来源默认演示位于 http://127.0.0.1:4312/source.html （仅开发模式）。生产构建命令为 `npm run build`，输出 `dist/`。

无需改变已提供的 `node_modules`。当前方案使用已冻结的 React、Vite、Tailwind 和 cn 工具。`app.js` 的保存数据键、600 字符限制和 900 ms 演示等待均保持。

## 使用

输入研究笔记，点击“查看背景”或拖动卡片翻面；聚焦卡片后 Enter/Space 也可翻面。背面的“返回编辑”将焦点移回输入区。长文本可在背面独立滚动、选择，不会触发翻转。点击“保存笔记”写入此浏览器。失败时文本保留，可使用明确的重试按钮。

界面支持中英文与深浅主题，切换时保留当前内容。系统减少动态效果偏好会关闭转动与装饰动画，同时保留全部信息及入口。装饰也可单独暂停。

## 来源与验证

Kokonut 原始版本与 MIT notice 分别见 `src/components/card-flip.tsx` 与 `src/components/KOKONUT-LICENSE`。完整来源比较、适配、实际边界与证据索引见上级 `DESIGN-RECORD.md`。

从上级目录重跑浏览器验证：

```bash
FONTCONFIG_FILE=/tmp/ui-spec-fonts/fonts.conf /tmp/ui-spec-study-venv/bin/python evidence/verify.py
python evidence/assert-report.py
```

本地 Chrome 需要运行环境允许其进程 socket。最终保存/故障恢复通过真实 Storage 边界验证；失败由测试临时注入。移动检查为 Chrome 尺寸模拟。未保存草稿只留在当前页面，刷新只恢复已保存版本。
