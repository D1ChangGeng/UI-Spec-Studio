import React, {useState} from 'react';
import {createRoot} from 'react-dom/client';
import {flushSync} from 'react-dom';
import CardFlip from './components/card-flip';
import faces from './faces.json';
import './tailwind.css';
import '../styles.css';

// The island owns only turning. Existing DOM and app.js keep text and Storage authority.
// Stable element objects avoid React replacing vanilla-owned translated content.
const front=<div className="face-content" dangerouslySetInnerHTML={{__html:faces.front}}/>;
const back=<div className="face-content" dangerouslySetInnerHTML={{__html:faces.back}}/>;
function NoteFlip(){
 const [flipped,setFlipped]=useState(false);
 const [lang,setLang]=useState({locale:"en",label:"Research note"});
 window.fieldnoteLanguage=(locale,label)=>setLang({locale,label});
 window.fieldnoteFlip=setFlipped;
 return <CardFlip label={lang.label} roleDescription={lang.locale === "zh" ? "翻转卡片" : "flip card"} instructions={lang.locale === "zh" ? `当前显示${flipped ? "背面" : "正面"}。按回车或空格，或拖动卡片翻面。` : `Showing the ${flipped ? "back" : "front"}. Press Enter or Space, or drag, to turn over.`} flipped={flipped} onFlippedChange={v=>window.fieldnoteSetFace?.(v?'back':'front')} front={front} back={back} className="fieldnote-flip w-full h-full aspect-auto" faceClassName="note-surface"/>;
}
flushSync(()=>createRoot(document.getElementById('card-root')).render(<NoteFlip/>));
await import('../app.js');
