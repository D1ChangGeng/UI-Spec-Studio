import React from 'react';
import {createRoot} from 'react-dom/client';
import CardFlip from './components/card-flip';
import './tailwind.css';
createRoot(document.getElementById('root')).render(<main className="min-h-screen bg-zinc-100 flex items-center justify-center gap-24"><CardFlip/><p className="text-sm max-w-60">Pinned Kokonut CardFlip v2, original supplied demo faces. Click or drag to turn.</p></main>);
