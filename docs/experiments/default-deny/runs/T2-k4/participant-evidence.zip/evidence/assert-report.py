import json
r=json.load(open('evidence/verification.json'));c=r['checks']
assert not r['pageErrors']
assert c[0]['rapidFinalFace']=='front'
assert c[1]['longNoteScroll']['top']>0
assert c[2]['returnFocus']=='note-text'
assert c[3]['storedBeforeCommit'] is None and 'Saving' in c[3]['pending']
assert c[4]['earlierSnapshot'] and c[4]['newerDraftKept']=='newer draft during save'
assert c[5]['retryVisible'] and c[5]['previousStoredUnchanged'] and c[5]['draft']=='newer draft during save'
assert c[6]['savedViewOldSnapshot']
assert c[7]['retryFocus']=='retry'
assert c[8]['retrySaved'] and c[9]['reloadRestoresSaved']
assert c[10]['limitPreserved'] and c[10]['overLimitDraftKept']
for x in c:
 if 'variant' in x: assert not x['overflow'] and x['draftRetained']
assert c[-2]['reducedMotion']['orbitAnimations']==0 and c[-2]['reducedMotion']['draftRetained']
assert c[-1]['keyboardFlipFocus']=='group'
print('PASS: storage, draft, recovery, focus, long content, 16 visual variants and reduced-motion assertions')
