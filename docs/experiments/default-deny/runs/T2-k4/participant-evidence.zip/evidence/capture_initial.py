from playwright.sync_api import sync_playwright
import json,time
from pathlib import Path
out=Path('evidence')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900})
 page.goto('http://127.0.0.1:4312/');page.screenshot(path=str(out/'before-desktop.png'))
 page.goto('http://127.0.0.1:4312/source.html');page.wait_for_timeout(900);page.screenshot(path=str(out/'source-front.png'))
 page.get_by_role('group').click();frames=[]
 for i in range(6):
  t=page.evaluate('performance.now()');page.screenshot(path=str(out/f'source-turn-{i}.png'));frames.append(t);page.wait_for_timeout(70)
 (out/'source-timing.json').write_text(json.dumps(frames))
 b.close()
