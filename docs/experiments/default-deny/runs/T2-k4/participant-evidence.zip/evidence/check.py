from playwright.sync_api import sync_playwright
import json,time
from pathlib import Path
out=Path('evidence');logs=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900})
 page.on('pageerror',lambda e:logs.append(str(e)))
 page.goto('http://127.0.0.1:4312/');page.wait_for_timeout(1300);page.screenshot(path=str(out/'trial-desktop.png'))
 page.locator('#flip').click();page.wait_for_timeout(1200);page.screenshot(path=str(out/'trial-back.png'))
 page.set_viewport_size({'width':390,'height':844});page.locator('#locale-toggle').click();page.wait_for_timeout(800);page.screenshot(path=str(out/'trial-mobile-zh.png'))
 print(json.dumps({'errors':logs,'htmlOverflow':page.evaluate('document.documentElement.scrollWidth>innerWidth'),'back':page.locator('#card-back').count(),'text':page.locator('#preview-note').inner_text()},ensure_ascii=False))
 b.close()
