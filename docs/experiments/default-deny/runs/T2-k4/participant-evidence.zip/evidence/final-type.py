from playwright.sync_api import sync_playwright
from pathlib import Path
import json
checks=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
 page=b.new_page()
 for size,name in [({'width':1440,'height':900},'desktop'),({'width':390,'height':844},'mobile')]:
  page.set_viewport_size(size);page.goto('http://127.0.0.1:4312/');page.wait_for_timeout(300)
  for locale in ['en','zh']:
   if (page.locator('html').get_attribute('lang')=='en')!=(locale=='en'):page.locator('#locale-toggle').click()
   for theme in ['light','dark']:
    if page.locator('html').get_attribute('data-theme')!=theme:page.locator('#theme-toggle').click()
    page.wait_for_timeout(180);page.screenshot(path=f'evidence/final-{name}-{locale}-{theme}.png')
    checks.append({'variant':f'{name}-{locale}-{theme}','overflow':page.evaluate('document.documentElement.scrollWidth>innerWidth'),'balance':page.locator('.card-copy h2').evaluate('(e)=>getComputedStyle(e).textWrap')})
 b.close()
Path('evidence/final-type.json').write_text(json.dumps(checks,indent=2))
assert all(not x['overflow'] for x in checks)
print('8 heading reflow variants passed')
