from pathlib import Path
base=Path('app')
s=(base/'index.html').read_text()
start=s.index('            <article id="note-card"')
end=s.index('</article>',start)+len('</article>')
old=s[start:end]
front=old[old.index('<div id="card-front"'):old.index('<div id="card-back"')].strip()
# Stable business-owned DOM is mounted into source-owned card faces.
front=front.replace('class="card-face card-front"','class="note-front"')
back=old[old.index('<div id="card-back"'):old.rindex('</article>')].strip().replace('class="card-face card-back" aria-hidden="true" inert','class="note-back"')
back=back.replace('<p class="card-foot"','<button id="back-to-editor" class="text-button" type="button" data-no-flip data-i18n="return">Return to editing</button><p class="card-foot"')
(base/'src/faces.json').write_text(__import__('json').dumps({'front':front,'back':back}))
s=s[:start]+'            <article id="note-card" data-record-id="heating-study" data-face="front"><div id="card-root"></div></article>'+s[end:]
s=s.replace('<link rel="stylesheet" href="styles.css">','')
s=s.replace('<script src="app.js"></script>','<script type="module" src="/src/main.jsx"></script>')
s=s.replace('aria-label="Study"><span aria-hidden="true">S</span>Study','aria-label="Fieldnote"><span aria-hidden="true">F</span>Fieldnote')
(base/'index.html').write_text(s)
js=(base/'app.js').read_text()
js=js.replace("$('card-front').inert = face !== 'front';\n    $('card-back').inert = face !== 'back';\n    $('card-front').setAttribute('aria-hidden', String(face !== 'front'));\n    $('card-back').setAttribute('aria-hidden', String(face !== 'back'));", "window.fieldnoteFlip?.(face === 'back');")
js=js.replace("document.title = locale === 'zh' ? 'Study · 笔记预览' : 'Study · Note preview';", "document.title = locale === 'zh' ? 'Fieldnote · 研究笔记' : 'Fieldnote · Research notes';")
js=js.replace("$('flip').addEventListener", "window.fieldnoteSetFace = setFace;\n  $('back-to-editor').addEventListener('click', () => {setFace('front'); $('note-text').focus({preventScroll:true});});\n  $('flip').addEventListener")
js=js.replace("'Back to question'", "'Back to question'")
(base/'app.js').write_text(js)
