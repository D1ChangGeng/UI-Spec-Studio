from playwright.sync_api import sync_playwright
from pathlib import Path
import json
out=Path('evidence');results=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
 for width,height,name in [(1440,900,'desktop'),(390,844,'mobile')]:
  page=b.new_page(viewport={'width':width,'height':height});page.goto('http://127.0.0.1:4312/');page.wait_for_timeout(500)
  page.locator('#flip').click();start=page.evaluate('performance.now()')
  for i in range(9):
   if i==2 or i==4:page.locator('#flip').click()
   before=page.evaluate('performance.now()');page.screenshot(path=str(out/f'envelope-{name}-{i:02}.png'));after=page.evaluate('performance.now()')
   metrics=page.evaluate('''()=>{const r=document.querySelector('.fieldnote-flip [style*="translateZ"]').getBoundingClientRect();const h=document.querySelector('#page-title').getBoundingClientRect();const a=document.querySelector('.preview-actions').getBoundingClientRect();return {cardTop:r.top,cardBottom:r.bottom,headingBottom:h.bottom,actionsTop:a.top}}''')
   results.append({'viewport':name,'frame':i,'startMs':before-start,'endMs':after-start,'metrics':metrics});page.wait_for_timeout(55)
  page.close()
 b.close()
(out/'motion-envelope.json').write_text(json.dumps(results,indent=2))
print('captured',len(results))
