from playwright.sync_api import sync_playwright
from pathlib import Path
import json
out=Path('evidence');checks=[];frames=[];errors=[]
KEY='ui-spec-temporal-note-v1'
LONG=('Evidence: compare district heat demand before and after retrofit. Preserve peak-hour observations and uncertainty.\n\n'*6)[:598]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
 ctx=b.new_context(viewport={'width':1440,'height':900})
 page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('http://127.0.0.1:4312/');page.wait_for_timeout(600);page.evaluate('document.fonts.ready');page.mouse.move(1300,800)
 page.screenshot(path=str(out/'desktop-front.png'))
 page.locator('#note-text').fill(LONG)
 page.locator('#flip').click();start=page.evaluate('performance.now()')
 for i in range(11):
  if i in [2,4,6]:page.locator('#flip').click()
  before=page.evaluate('performance.now()')
  page.screenshot(path=str(out/f'turn-{i:02}.png'))
  after=page.evaluate('performance.now()')
  frames.append({'frame':f'turn-{i:02}.png','start':before-start,'end':after-start,'face':page.locator('#note-card').get_attribute('data-face'),'action':'reverse' if i in [2,4,6] else None})
  page.wait_for_timeout(45)
 page.wait_for_timeout(900)
 checks.append({'rapidFinalFace':page.locator('#note-card').get_attribute('data-face')})
 if page.locator('#note-card').get_attribute('data-face')!='back':page.locator('#flip').click();page.wait_for_timeout(1000)
 page.locator('#preview-note').focus();page.keyboard.press('End');page.locator('#preview-note').evaluate('(e)=>e.scrollTop=e.scrollHeight')
 checks.append({'longNoteScroll':page.locator('#preview-note').evaluate('(e)=>({top:e.scrollTop,height:e.clientHeight,content:e.scrollHeight})')})
 page.screenshot(path=str(out/'desktop-back-long.png'))
 page.locator('#back-to-editor').click();checks.append({'returnFocus':page.evaluate('document.activeElement.id')});page.wait_for_timeout(900)
 # True pending state + edit while the submitted snapshot is waiting.
 page.locator('#save').click();checks.append({'pending':page.locator('#status').inner_text(),'storedBeforeCommit':page.evaluate('(k)=>localStorage.getItem(k)',KEY)})
 page.locator('#note-text').fill('newer draft during save');page.wait_for_timeout(1000)
 checks.append({'earlierSnapshot':json.loads(page.evaluate('(k)=>localStorage.getItem(k)',KEY))['text']==LONG,'newerDraftKept':page.locator('#note-text').input_value(),'status':page.locator('#status').inner_text()})
 # Force actual storage write boundary failure, then use actual retry control.
 page.evaluate("() => {window.originalSet=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw new DOMException('Simulated quota failure','QuotaExceededError')}}")
 page.locator('#save').click();page.wait_for_timeout(1000)
 page.screenshot(path=str(out/'desktop-save-failure.png'))
 checks.append({'failureStatus':page.locator('#status').inner_text(),'retryVisible':page.locator('#retry').is_visible(),'draft':page.locator('#note-text').input_value(),'previousStoredUnchanged':json.loads(page.evaluate('(k)=>localStorage.getItem(k)',KEY))['text']==LONG})
 page.locator('#saved-link').click();checks.append({'savedViewReportsFailure':page.locator('#collection-status').inner_text(),'savedViewOldSnapshot':page.locator('#saved-text').inner_text()==LONG})
 page.locator('#return').click();checks.append({'retryFocus':page.evaluate('document.activeElement.id')})
 page.evaluate('() => {Storage.prototype.setItem=window.originalSet}');page.locator('#retry').click();page.wait_for_timeout(1000)
 checks.append({'retrySaved':json.loads(page.evaluate('(k)=>localStorage.getItem(k)',KEY))['text']=='newer draft during save','retryStatus':page.locator('#status').inner_text()})
 page.reload();page.wait_for_timeout(500);checks.append({'reloadRestoresSaved':page.locator('#note-text').input_value()=='newer draft during save'})
 page.locator('#note-text').fill('x'*601);checks.append({'limitPreserved':page.locator('#save').is_disabled(),'overLimitDraftKept':len(page.locator('#note-text').input_value())==601})
 page.locator('#note-text').fill(LONG)
 for size,name in [({'width':1440,'height':900},'desktop'),({'width':390,'height':844},'mobile')]:
  page.set_viewport_size(size)
  for locale in ['en','zh']:
   if (page.locator('html').get_attribute('lang')=='en')!=(locale=='en'):page.locator('#locale-toggle').click()
   for theme in ['light','dark']:
    if page.locator('html').get_attribute('data-theme')!=theme:page.locator('#theme-toggle').click()
    for face in ['front','back']:
     if page.locator('#note-card').get_attribute('data-face')!=face:page.locator('#flip').click()
     page.wait_for_timeout(900);page.mouse.move(size['width']-2,1);page.wait_for_timeout(550)
     page.screenshot(path=str(out/f'{name}-{locale}-{theme}-{face}.png'))
     checks.append({'variant':f'{name}-{locale}-{theme}-{face}','overflow':page.evaluate('document.documentElement.scrollWidth>innerWidth'),'draftRetained':page.locator('#note-text').input_value()==LONG})
 # reduced motion with both faces, equivalent information and no active decorative animation.
 page.emulate_media(reduced_motion='reduce');page.locator('#flip').click();page.wait_for_timeout(100)
 page.screenshot(path=str(out/'mobile-reduced.png'))
 checks.append({'reducedMotion':{'face':page.locator('#note-card').get_attribute('data-face'),'orbitAnimations':page.locator('.orbit-arm').evaluate('(e)=>e.getAnimations().length'),'draftRetained':page.locator('#note-text').input_value()==LONG}})
 # Keyboard can flip source root and returns focus to input through back action.
 root=page.locator('.fieldnote-flip');root.focus();page.keyboard.press('Enter');page.wait_for_timeout(120)
 checks.append({'keyboardFlipFocus':page.evaluate('document.activeElement.getAttribute("role")')})
 ctx.close();b.close()
(out/'verification.json').write_text(json.dumps({'checks':checks,'frames':frames,'pageErrors':errors},ensure_ascii=False,indent=2))
print(json.dumps({'checks':len(checks),'pageErrors':errors},ensure_ascii=False))
