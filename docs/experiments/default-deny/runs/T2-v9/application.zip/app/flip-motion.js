/* Adapted from Kokonut UI CardFlip v2, Dorian Baffier, MIT.
 * Pinned original and license: ../resources/kokonut/; see THIRD_PARTY_NOTICES.md.
 * Retained: substepped spring, angle-driven lift/shadow/light, 7 thickness slices.
 * Adapted: vanilla DOM, explicit reversible buttons, no drag/hover on readable text.
 */
window.createNoteTurn = function (card, onVisible, onSettled) {
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const shadow = document.createElement('div'); shadow.className='floor-shadow'; shadow.setAttribute('aria-hidden','true'); card.before(shadow);
  for(let i=0;i<7;i++) {const slice=document.createElement('div');slice.className='card-edge';slice.setAttribute('aria-hidden','true');slice.style.transform=`translateZ(${-3+6*(i+.5)/7}px)`;card.prepend(slice);}
  const faces=[document.getElementById('card-front'),document.getElementById('card-back')];
  faces.forEach(face=>{const light=document.createElement('div');light.className='surface-light';light.setAttribute('aria-hidden','true');light.innerHTML='<i class="surface-shade"></i><i class="light-band"></i>';face.append(light);});
  let angle=0, velocity=0, target=0, raf=0, last=0, visible=false;
  function render(){
    const sin=Math.sin(angle*Math.PI/180),turn=Math.abs(sin),facing=Math.abs(Math.cos(angle*Math.PI/180));
    card.style.transform=`translateZ(${(turn*24-3).toFixed(3)}px) rotateY(${angle.toFixed(3)}deg)`;
    card.dataset.angle=angle.toFixed(3);
    shadow.style.transform=`scale(${(.16+.84*facing).toFixed(3)},${(1-turn*.12).toFixed(3)})`;
    shadow.style.opacity=(1-turn*.45).toFixed(3);
    for(const face of faces){face.querySelector('.surface-shade').style.opacity=(turn*.14).toFixed(3);const band=face.querySelector('.light-band');band.style.opacity=(turn*.12).toFixed(3);band.style.transform=`translateX(${(sin*140).toFixed(1)}%) rotate(18deg)`;}
    const back=Math.abs(Math.cos(angle*Math.PI/180))<.001 ? visible : Math.cos(angle*Math.PI/180)<0;
    if(back!==visible){visible=back;onVisible(back);}
  }
  function finish(){angle=target;velocity=0;raf=0;render();onSettled(target===180);}
  function step(now){
    const dt=Math.min(.05,(now-last)/1000);last=now;const n=Math.max(1,Math.ceil(dt/(1/240))),h=dt/n;
    for(let i=0;i<n;i++){velocity+=(-170*(angle-target)-20*velocity)*h;angle+=velocity*h;}
    if(Math.abs(angle-target)<.05&&Math.abs(velocity)<.5){finish();return;}
    render();raf=requestAnimationFrame(step);
  }
  function turn(back){target=back?180:0;card.dataset.face=back?'back':'front';
    if(reduce.matches){cancelAnimationFrame(raf);finish();return;}
    if(!raf){last=performance.now();raf=requestAnimationFrame(step);}
  }
  reduce.addEventListener('change',()=>{if(reduce.matches){cancelAnimationFrame(raf);finish();}});
  document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(raf);finish();}});
  render();onVisible(false);return {turn};
};
