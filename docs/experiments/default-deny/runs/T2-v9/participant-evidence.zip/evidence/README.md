# 实际证据与观看范围

## 入口与运行

当前应用 `http://127.0.0.1:4315`，源代码位于 `../app`。本地服务器仅用于检查，没有发布外部变更。

## 文件说明

- `before-desktop.png`：原始实现，1440×900。
- `source-kokonut-front.png`、`source-turn-0..6.png`：原始 Kokonut 演示的操作截图。实际查看了正面、转动后的侧面和背面；序列捕获没有逐帧时间戳，不将其等同于原速视频观看。
- `source-magic-card.png`：MagicCard 原始演示静止画面，已查看；聚光移动未实际采样。
- `front-*`、`back-*`：两视口×两主题×两语言的界面。创建于语义分行微调前，`final-mobile-zh-dark.png` 为最终中文窄屏版本。
- `episode-00..07.png`：自然时钟运行的连续翻转—反向—再次翻转，8 张全视口帧均已查看。截图前后时间为实际调用区间，不是精确呈现时间。正文、编辑器与外侧按钮保持同一布局位置；可见厚度、收窄投影与随角度变化的光照。
- `long-note-back.png`、`mobile-long-back.png`：长笔记的背面滚动和键盘焦点。
- `failure-desktop.png`、`mobile-failure.png`：明确的存储写失败和可用重试，输入内容保留。
- `verification.json`、`edge-checks.json`：40 项范围明确的断言及运动采样。40 项断言通过不等同于完整产品验收。
- `video/5a1ad39c711bd0cba21f5ff5baa00238.webm`：最新主要验证过程的完整录屏（1440×900 视频画布，移动端片段保持其 CSS 视口但在视频画布中缩放）；录制完成但未以正常速度回放检查。
- `source-hashes.json`：交付代码散列。

## 条件与限制

Chrome for Testing 156.0.8078.80，DPR 1。CSS 视口 1440×900 / 390×844。中文使用主机提供的 Noto Sans SC。保存正常路径是实际本地 Storage；失败由测试临时覆盖原生写方法注入，重试时恢复原生方法。900 ms 延迟是原应用声明的演示时间。

实际观察是有序帧与静态截图，加上真实控件操作和 DOM/Storage 断言。视频存在不等同于观看；上述证据未证明现场性能、全浏览器兼容性、屏幕阅读器体验或用户接受度。详情和决定在 `../DESIGN.md`。
