from playwright.sync_api import sync_playwright
from pathlib import Path
import json
P=Path(__file__).parent;checks=[]
def ck(n,v): checks.append({'name':n,'pass':bool(v)});assert v,n
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
 page.goto('http://127.0.0.1:4315');page.locator('#locale-toggle').click();page.locator('#theme-toggle').click()
 page.locator('#note-text').fill('城市供热研究。\n'*50)
 page.locator('#flip').click();page.wait_for_timeout(1100)
 page.locator('#preview-note').evaluate('(e)=>e.scrollTop=e.scrollHeight')
 ck('long note mobile scroll to end',page.locator('#preview-note').evaluate('(e)=>e.scrollTop>0'))
 page.screenshot(path=str(P/'mobile-long-back.png'))
 page.locator('#back-edit').click();page.wait_for_timeout(1100)
 ck('mobile return focus visible',page.locator('#note-text').evaluate('(e)=>document.activeElement===e && e.getBoundingClientRect().bottom<=innerHeight'))
 page.evaluate("()=>{window.__write=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw new DOMException('Fixture quota failure','QuotaExceededError')}}")
 page.locator('#save').click();page.wait_for_timeout(1000)
 ck('mobile zh dark failed draft retained',page.locator('#status-area').get_attribute('data-status')=='failed' and len(page.locator('#note-text').input_value())>300)
 page.locator('#retry').scroll_into_view_if_needed();page.screenshot(path=str(P/'mobile-failure.png'))
 page.evaluate('()=>{Storage.prototype.setItem=window.__write}');page.locator('#retry').click();page.wait_for_timeout(1000)
 ck('mobile retry persisted',page.evaluate("JSON.parse(localStorage.getItem('ui-spec-temporal-note-v1')).text")==page.locator('#note-text').input_value())
 page.locator('#note-text').fill('长'*650)
 ck('overlimit retained and not saved',len(page.locator('#note-text').input_value())==650 and page.locator('#save').is_disabled() and page.locator('#note-text').get_attribute('aria-invalid')=='true')
 page.reload();ck('reload persisted saved note',len(page.locator('#note-text').input_value())==len('城市供热研究。\n'*50))
 page.evaluate("localStorage.setItem('ui-spec-temporal-note-v1','broken json')");page.reload()
 ck('malformed read blocked truthfully',page.locator('#status-area').get_attribute('data-status')=='unavailable' and page.locator('#save').is_disabled())
 page.locator('#note-text').fill('Keep this current draft');page.locator('#saved-link').click();page.locator('#return').click()
 ck('unreadable return draft preserved',page.locator('#note-text').input_value()=='Keep this current draft')
 page.locator('summary').click();page.locator('#clear').click()
 ck('clear restores editor',page.locator('#note-text').input_value()=='' and not page.locator('#save').is_disabled())
 for theme in ['light','dark']:
  if page.locator('html').get_attribute('data-theme')!=theme:page.locator('#theme-toggle').click()
  for locale in ['en','zh-CN']:
   if page.locator('html').get_attribute('lang')!=locale:page.locator('#locale-toggle').click()
   page.emulate_media(reduced_motion='reduce');page.locator('#note-text').fill('同一张笔记 / one note');page.locator('#flip').click()
   ck(f'reduced face accessible {theme} {locale}',not page.locator('#card-back').evaluate('(e)=>e.inert') and page.locator('#preview-note').inner_text()=='同一张笔记 / one note')
   page.locator('#back-edit').click()
 page.evaluate("document.querySelector('#note-text').value='';document.querySelector('#note-text').dispatchEvent(new Event('input',{bubbles:true}))")
 page.emulate_media(reduced_motion='no-preference');page.evaluate('scrollTo(0,0)');page.screenshot(path=str(P/'final-mobile-zh-dark.png'))
 b.close()
(P/'edge-checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2));print(json.dumps(checks,ensure_ascii=False))
