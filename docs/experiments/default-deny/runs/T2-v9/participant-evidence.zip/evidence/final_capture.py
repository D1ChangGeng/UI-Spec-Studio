from playwright.sync_api import sync_playwright
from pathlib import Path
import hashlib,json
P=Path(__file__).parent
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
 page.goto('http://127.0.0.1:4315');page.wait_for_timeout(250)
 page.screenshot(path=str(P/'final-desktop.png'))
 page.set_viewport_size({'width':390,'height':844});page.locator('#locale-toggle').click();page.locator('#theme-toggle').click()
 page.locator('#note-text').fill('记录高峰时段的需求变化，比较不同街区的数据。\n下一步：核对证据来源与采样范围。')
 page.locator('#note-text').blur();page.evaluate('scrollTo(0,0)');page.wait_for_timeout(250)
 page.screenshot(path=str(P/'final-mobile-zh-dark.png'))
 before=page.locator('#card-space').bounding_box();page.locator('#flip').click();page.wait_for_timeout(1100);after=page.locator('#card-space').bounding_box()
 page.screenshot(path=str(P/'final-mobile-back.png'))
 (P/'final-layout.json').write_text(json.dumps({'viewport':[390,844],'before':before,'after':after,'stable':before==after},indent=2))
 b.close()
paths=['app/index.html','app/styles.css','app/app.js','app/flip-motion.js']
(P/'source-hashes.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths},indent=2))
d=json.loads((P/'verification.json').read_text());print({'rAF_samples':len(d['motion_samples']),'checks':len(d['checks']),'stable':before==after})
