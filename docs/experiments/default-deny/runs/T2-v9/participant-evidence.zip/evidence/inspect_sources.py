from playwright.sync_api import sync_playwright
from pathlib import Path
import json, time
P=Path(__file__).parent
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1,ignore_https_errors=True)
 page.goto('http://127.0.0.1:4315');page.screenshot(path=str(P/'before-desktop.png'))
 for name,url in [('kokonut','https://kokonutui.com/docs/cards/card-flip'),('magic-card','https://magicui.design/docs/components/magic-card')]:
  try:
   page.goto(url,wait_until='domcontentloaded',timeout=25000);page.wait_for_timeout(1600)
   page.screenshot(path=str(P/f'source-{name}.png'))
   (P/f'source-{name}.txt').write_text(page.locator('body').inner_text())
   print(name,page.title(),page.locator('[aria-roledescription="flip card"]').count())
   if name=='kokonut':
    card=page.locator('[aria-roledescription="flip card"]').first
    if card.count():
     card.scroll_into_view_if_needed();page.screenshot(path=str(P/'source-kokonut-front.png'));card.press('Enter')
     for i in range(7):
      page.screenshot(path=str(P/f'source-turn-{i}.png'));page.wait_for_timeout(90)
  except Exception as e: print(name,str(e))
 b.close()
