from playwright.sync_api import sync_playwright
from pathlib import Path
import json,time
P=Path(__file__).parent
results={'checks':[],'frames':[],'console':[]}
def check(name,condition,detail=None):
 results['checks'].append({'name':name,'pass':bool(condition),'detail':detail});assert condition,name
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
 ctx=b.new_context(viewport={'width':1440,'height':900},device_scale_factor=1,record_video_dir=str(P/'video'),record_video_size={'width':1440,'height':900})
 ctx.add_init_script("window.__realWrite=Storage.prototype.setItem; window.__failWrite=false; Storage.prototype.setItem=function(k,v){if(window.__failWrite && k==='ui-spec-temporal-note-v1') throw new DOMException('Fixture quota failure','QuotaExceededError'); return window.__realWrite.call(this,k,v)}")
 page=ctx.new_page();page.on('pageerror',lambda e:results['console'].append(str(e)))
 page.goto('http://127.0.0.1:4315');page.wait_for_timeout(400)
 page.screenshot(path=str(P/'after-desktop.png'))
 # Real task, long text and actual local storage save.
 note=('Evidence: compare district demand by hour. Keep uncertainty visible.\n'*8)[:590]
 page.locator('#note-text').fill(note)
 page.locator('#save').click();check('pending truthful',page.locator('#status-area').get_attribute('data-status')=='saving')
 page.wait_for_timeout(1000)
 check('real local storage saved',page.evaluate("JSON.parse(localStorage.getItem('ui-spec-temporal-note-v1')).text")==note)
 # Capture natural progression with timestamps around capture, no forced seek.
 page.locator('#flip').focus()
 page.evaluate("window.__angles=[];window.__capture=true;const probe=()=>{if(!window.__capture)return;window.__angles.push({t:performance.now(),a:Number(document.querySelector('#note-card').dataset.angle)});requestAnimationFrame(probe)};requestAnimationFrame(probe)")
 begin=page.evaluate('performance.now()');page.locator('#flip').click()
 for i in range(8):
  before=page.evaluate('performance.now()');page.screenshot(path=str(P/f'episode-{i:02}.png'));after=page.evaluate('performance.now()')
  results['frames'].append({'file':f'episode-{i:02}.png','before_ms':before-begin,'after_ms':after-begin,'angle':page.locator('#note-card').get_attribute('data-angle')})
  if i==1:page.locator('#flip').click()
  if i==3:page.locator('#flip').click()
  page.wait_for_timeout(45)
 page.wait_for_timeout(700)
 page.evaluate('window.__capture=false');results['motion_samples']=page.evaluate('window.__angles')
 check('rapid reversal settles back',page.locator('#note-card').get_attribute('data-angle')=='180.000')
 check('back interactive front inert',page.locator('#card-front').evaluate('(e)=>e.inert') and not page.locator('#card-back').evaluate('(e)=>e.inert'))
 check('long back scrolls',page.locator('#preview-note').evaluate('(e)=>e.scrollHeight>e.clientHeight'))
 page.locator('#preview-note').focus();page.keyboard.press('End');page.screenshot(path=str(P/'long-note-back.png'))
 page.locator('#back-edit').click();page.wait_for_timeout(1100)
 check('return focus editor',page.evaluate('document.activeElement.id')=='note-text')
 check('draft retained on return',page.locator('#note-text').input_value()==note)
 # Failure is injected at real local-storage write boundary, then restore and retry.
 changed=note+'\nRetry me.'
 page.locator('#note-text').fill(changed);page.evaluate('window.__failWrite=true');page.locator('#save').click();page.wait_for_timeout(1000)
 check('failure truthful',page.locator('#status-area').get_attribute('data-status')=='failed')
 check('failure draft retained',page.locator('#note-text').input_value()==changed)
 check('previous saved version survives',page.evaluate("JSON.parse(localStorage.getItem('ui-spec-temporal-note-v1')).text")==note)
 page.screenshot(path=str(P/'failure-desktop.png'))
 page.evaluate('window.__failWrite=false');page.locator('#retry').click();page.wait_for_timeout(1000)
 check('retry actual saved value',page.evaluate("JSON.parse(localStorage.getItem('ui-spec-temporal-note-v1')).text")==changed)
 # Edits during 900ms delay remain drafts and are not described as saved.
 page.locator('#note-text').fill('Submitted snapshot');page.locator('#save').click();page.locator('#note-text').fill('Newer unsaved draft');page.wait_for_timeout(1000)
 check('newer draft status',page.locator('#status-area').get_attribute('data-status')=='earlier')
 check('pending snapshot saved',page.evaluate("JSON.parse(localStorage.getItem('ui-spec-temporal-note-v1')).text")=='Submitted snapshot')
 page.locator('#saved-link').click();check('saved read actual value',page.locator('#saved-text').inner_text()=='Submitted snapshot')
 page.locator('#return').click();check('collection return preserves newer draft',page.locator('#note-text').input_value()=='Newer unsaved draft')
 # Full static variant matrix.
 for width,height in [(1440,900),(390,844)]:
  page.set_viewport_size({'width':width,'height':height})
  for theme in ['light','dark']:
   if page.locator('html').get_attribute('data-theme')!=theme:page.locator('#theme-toggle').click()
   for locale in ['en','zh-CN']:
    if page.locator('html').get_attribute('lang')!=locale:page.locator('#locale-toggle').click()
    page.locator('#note-text').fill('记录高峰时段的需求变化，比较不同街区的数据。下一步：核对证据来源与采样范围。' if locale=='zh-CN' else 'Compare peak demand across city districts.\nNext: check evidence sources and sampling windows.')
    page.wait_for_timeout(300);page.screenshot(path=str(P/f'front-{width}-{theme}-{locale}.png'))
    check(f'no horizontal overflow {width} {theme} {locale}',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
    page.locator('#flip').click();page.wait_for_timeout(1100);page.screenshot(path=str(P/f'back-{width}-{theme}-{locale}.png'))
    page.locator('#flip').click();page.wait_for_timeout(1000)
 page.emulate_media(reduced_motion='reduce');page.locator('#flip').click();page.wait_for_timeout(30)
 check('reduced motion immediate correct face',page.locator('#note-card').get_attribute('data-angle')=='180.000')
 check('reduced motion same text',page.locator('#preview-note').inner_text()==page.locator('#note-text').input_value())
 page.screenshot(path=str(P/'reduced-mobile.png'))
 page.locator('#back-edit').click();check('reduced return focus',page.evaluate('document.activeElement.id')=='note-text')
 check('no page errors',not results['console'],results['console'])
 video=page.video.path();results['video']=str(video)
 ctx.close();b.close()
(P/'verification.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(json.dumps({'passed':len(results['checks']),'frames':results['frames'],'video':results['video']},ensure_ascii=False))
