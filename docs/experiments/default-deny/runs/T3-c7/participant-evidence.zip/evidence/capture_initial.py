from playwright.sync_api import sync_playwright
from pathlib import Path
import json

out=Path(__file__).parent
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1,ignore_https_errors=True)
    def baseline(route):
        name=route.request.url.rsplit('/',1)[-1]
        files={'':'index-before.html','styles.css':'styles-before.css','app.js':'app-before.js'}
        mime='text/html' if not name else ('text/css' if name.endswith('.css') else 'application/javascript')
        route.fulfill(body=(out/files[name]).read_text(),content_type=mime)
    page.route('**/baseline/**',baseline)
    page.goto('http://127.0.0.1:4316/baseline/')
    page.screenshot(path=str(out/'before-desktop.png'))
    results={'browser':browser.version,'references':[]}
    for name,url in [('bootstrap-modal','https://getbootstrap.com/docs/5.3/components/modal/'),('zotero-notes','https://www.zotero.org/support/pdf_reader')]:
        try:
            page.goto(url,wait_until='domcontentloaded',timeout=20000)
            if name=='bootstrap-modal':
                page.get_by_role('button',name='Launch demo modal',exact=True).first.click()
                page.wait_for_timeout(400)
            else:
                page.get_by_text('Adding Annotations to Notes',exact=True).first.scroll_into_view_if_needed()
            page.screenshot(path=str(out/(name+'.png')))
            results['references'].append({'name':name,'url':url,'captured':True})
        except Exception as e: results['references'].append({'name':name,'url':url,'error':str(e)})
    (out/'initial-inspection.json').write_text(json.dumps(results,indent=2))
    browser.close()
