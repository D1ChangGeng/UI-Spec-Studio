from playwright.sync_api import sync_playwright, expect
from pathlib import Path
import json
out=Path(__file__).parent
results=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
 for lang in ['zh','en']:
  for theme in ['light','dark']:
   c=b.new_context(viewport={'width':390,'height':844},device_scale_factor=1)
   a=c.new_page();a.goto('http://127.0.0.1:4316')
   if lang=='en':a.locator('#locale-toggle').click()
   if theme=='dark':a.locator('#theme-toggle').click()
   a.locator('#note-title').fill('长文本与键盘滚动' if lang=='zh' else 'Long text and keyboard scrolling')
   a.locator('#save').click();expect(a.locator('.state-area')).to_have_attribute('data-status','saved')
   d=c.new_page();d.goto('http://127.0.0.1:4316')
   local='\n'.join([f'{i+1}. '+('本页草稿需要保留原始材料与问题。' if lang=='zh' else 'Keep the source and open questions in this draft.') for i in range(40)])
   a.locator('#note-body').fill(local)
   d.locator('#note-body').fill('另一页版本。' if lang=='zh' else 'The version saved in the other tab.')
   d.locator('#save').click();expect(a.locator('#conflict-dialog')).to_be_visible()
   a.locator('#local-body').focus();a.keyboard.press('Control+End')
   a.wait_for_timeout(150)
   print(a.locator('#local-body').evaluate('(e)=>({scrollTop:e.scrollTop,scrollHeight:e.scrollHeight,height:e.clientHeight,active:document.activeElement.id})'))
   assert a.locator('#local-body').evaluate('(e)=>e.scrollTop>0')
   a.locator('#conflict-dialog').evaluate('(e)=>e.scrollTop=e.scrollHeight')
   action=a.locator('#use-remote').bounding_box();footer=a.locator('.comparison-footer').bounding_box()
   assert action['y']+action['height'] <= footer['y']
   a.screenshot(path=str(out/f'390-{lang}-{theme}-long-conflict-lower.png'))
   a.locator('#use-remote').click();expect(a.locator('.state-area')).to_have_attribute('data-status','remoteUsed')
   results.append({'locale':lang,'theme':theme,'longTextKeyboardScroll':True,'secondActionClearOfFooter':True,'remoteChoice':True})
   c.close()
 b.close()
(out/'long-content-checks.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(json.dumps(results,ensure_ascii=False))
