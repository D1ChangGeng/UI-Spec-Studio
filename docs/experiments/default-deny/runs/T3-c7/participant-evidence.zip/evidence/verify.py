from playwright.sync_api import sync_playwright, expect
from pathlib import Path
import json, time

OUT=Path(__file__).parent
KEY='ui-spec-content-note-v1'
URL='http://127.0.0.1:4316'
report={'started':time.time(),'conditions':[],'extra':[],'consoleErrors':[]}
def state(page, key):
    expected='error' if key in ['failed','readFailed','invalidStored','clearFailed'] else key
    expect(page.locator('.state-area')).to_have_attribute('data-status',expected)
def save(page):
    page.locator('#save').click()
    state(page,'saved')
def value(page):
    return page.evaluate('(key)=>JSON.parse(localStorage.getItem(key))',KEY)
def variants(page,lang,theme):
    if lang=='en': page.locator('#locale-toggle').click()
    if theme=='dark': page.locator('#theme-toggle').click()
def shot(page,name,full=False):
    page.screenshot(path=str(OUT/(name+'.png')),full_page=full)

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
    report['browser']=browser.version
    for width,height in [(390,844),(1440,900)]:
      for lang in ['zh','en']:
       for theme in ['light','dark']:
        tag=f'{width}-{lang}-{theme}'
        c=browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1)
        a=c.new_page(); a.on('pageerror',lambda e:report['consoleErrors'].append(str(e)))
        a.goto(URL); variants(a,lang,theme)
        fonts=a.locator('#note-title').evaluate('(e)=>({entered:getComputedStyle(e).fontSize,placeholder:getComputedStyle(e,"::placeholder").fontSize,height:e.getBoundingClientRect().height})')
        bodyfonts=a.locator('#note-body').evaluate('(e)=>({entered:getComputedStyle(e).fontSize,placeholder:getComputedStyle(e,"::placeholder").fontSize,height:e.getBoundingClientRect().height})')
        assert fonts['entered']=='15px' and fonts['placeholder']=='14px'
        assert bodyfonts['entered']=='15px' and bodyfonts['placeholder']=='14px'
        assert a.evaluate('document.documentElement.scrollWidth <= innerWidth')
        shot(a,tag+'-empty',True)
        a.locator('#save').click(); expect(a.locator('#note-title')).to_be_focused()
        title='城市供热需求研究' if lang=='zh' else 'Investigating peak heating demand'
        body='先记录研究背景，再核查原始材料。\n这份笔记尚未建立引文与结论的支持关系。' if lang=='zh' else 'Record the context, then check the original material.\nThis note does not yet contain verified links between quotations and claims.'
        a.locator('#note-title').fill(title); a.keyboard.press('Tab'); a.keyboard.type(body) if lang=='en' else a.locator('#note-body').fill(body)
        a.locator('#note-title').focus(); a.keyboard.press('Tab')
        assert a.locator('#note-body').evaluate('(e)=>e.matches(":focus-visible")')
        a.evaluate('scrollTo(0,0)'); shot(a,tag+'-entered-focus',True)
        save(a); assert value(a)=={'title':title,'body':body}
        a.reload(); assert a.locator('#note-title').input_value()==title; variants(a,lang,theme)
        a.locator('summary').first.click(); a.locator('#simulate-failure').check()
        a.locator('#note-body').fill(body+'\nFailed attempt retained.'); a.locator('#save').click(); state(a,'failed')
        assert value(a)['body']==body
        a.locator('#simulate-failure').uncheck(); a.locator('#retry').click(); state(a,'saved')
        assert a.locator('#note-title').evaluate('(e)=>document.activeElement===e')
        a.locator('summary').first.click()
        b=c.new_page(); b.goto(URL)
        local='本页补充：需要比较不同城市的峰值。' if lang=='zh' else 'My draft: compare peak demand across cities.'
        remote='另一页补充：先确认数据的统计口径。' if lang=='zh' else 'Other tab: verify how the data was measured.'
        a.locator('#note-body').fill(local)
        b.locator('#note-body').fill(remote); save(b)
        expect(a.locator('#conflict-dialog')).to_be_visible()
        assert a.locator('#local-body').inner_text()==local
        assert a.locator('#remote-body').inner_text()==remote
        assert a.locator('#note-body').input_value()==local
        assert value(a)['body']==remote
        a.locator('#conflict-dialog').evaluate('(e)=>e.scrollTop=0')
        shot(a,tag+'-conflict')
        a.keyboard.press('Tab'); assert a.evaluate('document.activeElement.closest("#conflict-dialog")!==null')
        if width==390:
            a.locator('#use-remote').scroll_into_view_if_needed(); shot(a,tag+'-conflict-lower')
        a.keyboard.press('Escape'); expect(a.locator('#conflict-dialog')).not_to_be_visible()
        expect(a.locator('#save')).to_be_disabled(); assert a.locator('#note-body').input_value()==local
        a.locator('#review-conflict').click(); a.locator('#keep-local').click(); state(a,'localKept')
        assert value(a)['body']==remote and a.locator('#note-body').input_value()==local
        save(a); assert value(a)['body']==local
        expect(b.locator('#note-body')).to_have_value(local)
        a.locator('#note-body').fill(local+' Again.')
        b.locator('#note-body').fill(remote+' Second.'); save(b)
        expect(a.locator('#conflict-dialog')).to_be_visible()
        a.locator('#use-remote').click(); state(a,'remoteUsed')
        assert a.locator('#note-body').input_value()==remote+' Second.'
        b.close()
        a.locator('summary').first.click(); a.locator('#simulate-slow').check()
        a.locator('#note-body').fill('submitted snapshot'); a.locator('#save').click(); state(a,'saving')
        a.locator('#note-body').fill('newer draft'); state(a,'savedEarlier')
        assert value(a)['body']=='submitted snapshot' and a.locator('#note-body').input_value()=='newer draft'
        a.locator('#save').click(); a.locator('#reset').click(); a.wait_for_timeout(1100)
        assert value(a) is None and a.locator('#note-body').input_value()==''
        report['conditions'].append({'viewport':[width,height],'locale':lang,'theme':theme,'input':fonts,'textarea':bodyfonts,'checks':'empty/entered/focus/validation/native save/reload/write-failure/retry/2 real tabs/both choices/Escape/defer/delayed edit/reset cancellation passed'})
        c.close()
    # Additional risk-driven cases use the same real browser-local boundary.
    c=browser.new_context(viewport={'width':1440,'height':900})
    a=c.new_page(); a.goto(URL); a.locator('#note-title').fill('Recovery case'); a.locator('#note-body').fill('Base'); save(a)
    b=c.new_page(); b.goto(URL); a.locator('#note-body').fill('Unsaved local')
    b.locator('#note-body').fill('Remote one'); save(b); expect(a.locator('#conflict-dialog')).to_be_visible()
    b.locator('#note-body').fill('Remote two'); save(b)
    expect(a.locator('#remote-body')).to_have_text('Remote two')
    assert 'Remote one' in a.locator('#previous-versions').text_content()
    a.reload(); expect(a.locator('#conflict-dialog')).to_be_visible()
    assert a.locator('#note-body').input_value()=='Unsaved local'
    assert a.locator('#remote-body').inner_text()=='Remote two'
    assert 'Remote one' in a.locator('#previous-versions').text_content()
    a.locator('#use-remote').click()
    # Cross-tab deletion while dirty also needs an explicit choice.
    a.locator('#note-body').fill('Keep through deletion')
    b.locator('summary').first.click(); b.locator('#reset').click()
    expect(a.locator('#conflict-dialog')).to_be_visible(); a.locator('#keep-local').click(); save(a)
    assert value(a)['body']=='Keep through deletion'
    b.close()
    # Inject a failure at the native Storage boundary, then exercise visible retry.
    a.evaluate('''()=>{window.originalGet=Storage.prototype.getItem;Storage.prototype.getItem=function(k){if(this===localStorage)throw new Error('injected read failure');return window.originalGet.call(this,k)};window.dispatchEvent(new StorageEvent('storage',{key:'ui-spec-content-note-v1'}));}''')
    state(a,'readFailed'); expect(a.locator('#save')).to_be_disabled()
    a.evaluate('()=>{Storage.prototype.getItem=window.originalGet;}'); a.locator('#retry').click()
    expect(a.locator('#save')).to_be_enabled()
    report['extra']=['Third update keeps earlier remote text','Conflict survives reload in same tab','Cross-tab deletion preserves draft until choice','Native read fault and visible retry passed']
    c.close(); browser.close()
report['finished']=time.time()
(OUT/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'conditions':len(report['conditions']),'extra':report['extra'],'consoleErrors':report['consoleErrors']},ensure_ascii=False))
