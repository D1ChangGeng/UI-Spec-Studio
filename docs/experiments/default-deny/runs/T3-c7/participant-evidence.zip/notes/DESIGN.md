# Fieldnote：本轮设计与实现记录

## 当前目标与边界

这是对已接受的双语本地笔记应用的一次连续改进：维持现有版式、配色、编辑器与最近保存关系；缩小提示字号；更新独立品牌标记；在跨标签页保存冲突时让人比较并选择文本。正式增量 FN-01 负责这条完整的编辑—保存—冲突—恢复路径。引文支持视图作为后续研究，不把没有存储的关系伪装成当前产品事实。

当前实现仍是 vanilla HTML/CSS/JS。`localStorage` 的原有键与 `{title, body}` 记录结构保持兼容，无账号、后端、外部提交或多人服务。说明用语继续保持原有的直接、克制语气。

## 设计决策与证据关系

| 决策 | 问题与依据 | 选择、边界和实现 |
|---|---|---|
| D1 提示层级 | 用户明确要求提示比输入小一档；原始计算值为 15px，现有标签 14px、说明 12px | 仅 `::placeholder` 为 14px；正文 15px、49.25px 单行框、145px 文本框的原比例保持；共享选择器覆盖两个控件、双语言、双主题 |
| D2 品牌 | 用户明确授权为 Fieldnote 原创紧凑折页 monogram，属于 W1；通用文件图标可表示文档，不能直接提供这项独立品牌身份 | 延续原 37px 方形品牌位置；折页外形包裹字母 F 的留白。页折角与 F 竖笔在小尺寸阅读；浅深主题使用既有 `--accent` / `--accent-ink`。SVG 为可编辑路径，没有第三方标记或图片生成依赖 |
| D3 冲突比较 | 现有状态段只能说明结果，最近保存区只有标题，均不能同时承载两份正文；用户已明确授权所缺的比较呈现 | W3：在已接受编辑器基础上新增局部比较对话框。颜色、文字、边框、圆角、按钮沿用现有系统；新增职责限于成对比较、选择说明与移动端堆叠。原生 `<dialog>` 负责焦点和模态。桌面并列，移动端按“本页—另一页”顺序阅读 |
| D4 选择与保存 | “保留”与“已保存”是不同结果；选择应不隐式覆盖另一版本 | 保留本页草稿后仍需按保存；采用另一版本恢复当前已存文本。延后/Escape 保留双方并禁用保存；重新比较恢复对话框。冲突期间本页再次编辑会更新保留草稿 |
| D5 并发与恢复 | storage 事件来自同源另一上下文；延迟保存还需在写入前重新检查 | 实际监听 storage，并在获 Web Lock 后重新读取；变化取消旧的待写快照。冲突双方与期间的较早远端版本留在 sessionStorage，支持同标签页刷新恢复；存储恢复副本失败则明确提示不要刷新/关闭 |
| D6 引文支持视图 | 当前记录只有自由文本，没有能证明“这句引文支持该判断”的数据 | 建议配对阅读、原文定位和人工确认关系；详见 FUTURE-EVIDENCE.md。此轮未添加虚构证据图、可信度数值或支持连线 |

## 资源研究与采用事实

已有应用是用户在 TASK.md 中明确接受的视觉基础，实际基线已在 Chrome 1440×900 中查看。保留了其空间分配、标题层级、输入比例、绿色角色、状态区域与移动端单列机制。

外部成熟候选为 Bootstrap 5.3 Modal 的公开实时示例：已实际打开、点击并查看截图 `evidence/bootstrap-modal.png`。它提供标题—正文—动作的通用模态关系，但示例没有两份笔记的对照、保留草稿与已保存内容的语义，也不是本产品的既有视觉系统。未导入 Bootstrap CSS/JS；本轮不是宣称“采用了 Bootstrap”的重绘。保留已接受项目系统，依据用户对缺失比较呈现的具体许可做 W3 局部扩展。原生 dialog 是语义/焦点基础，不能单独证明视觉成熟度。

现代 Web 指导通过 `modern-web-guidance search` 后读取 `dialog`。使用 showModal、可见延后按钮、默认 Escape、原生焦点约束、`:modal` 与 backdrop overscroll containment。未使用新的 invoker/closedby 依赖，无需相应 polyfill。对话框不含动画，保留既有 reduced-motion 规则。

Zotero 官方文档的产品截图已查看（`evidence/zotero-notes.png`）；它展示标注列表、原文与笔记并置，属于文档中的产品截图证据，未操作真实 Zotero 应用。引文的回到原文行为来自官方说明，未把截图当成功能验证。

## 观察与验证方法

`evidence/verify.py` 用同一浏览器 context 中两个真实 page 触发本地 storage 事件，不以手工触发冲突按钮冒充联动。8 个组合：390×844 / 1440×900 × 中文 / 英文 × 浅色 / 深色。空态与输入态是 full-document capture；冲突为真实 viewport capture，移动端另有下半部分。`verification.json` 是实际断言输出，不代表用户验收。

视图采集与查看分开记录。检查图像中的整体、控件字号和焦点轮廓后再返回整体；完整逐帧视频与真实用户理解测试不在本轮证据范围。测试的 1 秒延迟是原有预览开关，不是测得的存储性能。

公开参考首次浏览遇到测试环境证书链错误；后续在无账号的隔离测试 context 中重新读取公开页面。初次 Bootstrap 按钮定位遇到同名多按钮，限定第一个真实 demo 后重试成功。最终不以这些访问故障判断资源设计质量。

## 已知适用范围

浏览器为指定 Chrome for Testing 156.0.8078.80，DPR 1。使用环境的 Noto Sans SC 字体配置；产品字体栈没有更换。桌面模拟窄视口不等于真实手机、软键盘或触屏测试。未验证 Safari、Firefox、屏幕阅读器或系统高对比度。

Web Locks 在支持的同源 Fieldnote 标签页间协调写入；不支持该 API 时保留写前检查，但没有原子事务保证。直接从 DevTools/旧客户端写 localStorage 也不遵守锁。sessionStorage 支持当前标签页刷新恢复，不提供关闭标签页之后的长期版本库。原来的单条笔记模型没有扩展为多记录、自动合并或服务器协作。

## 来源（读取于 2026-10-30）

- 项目基础：`evidence/index-before.html`、`styles-before.css`、`app-before.js`，授权出处 `TASK.md`。
- [Bootstrap Modal 5.3](https://getbootstrap.com/docs/5.3/components/modal/)：研究候选，实际 demo 截图；未采用其实现代码。
- [MDN storage event](https://developer.mozilla.org/en-US/docs/Web/API/Window/storage_event)：同源跨标签页事件边界。
- [Zotero PDF Reader and Note Editor](https://www.zotero.org/support/pdf_reader)：标注附带来源回链、笔记阅读关系。
- [W3C Web Annotation Data Model](https://www.w3.org/TR/annotation-model/#text-quote-selector)：文本定位、来源与版本信息。

这些资料支持各自的机制与研究判断。Fieldnote 的实际外观与行为以本项目截图、实现和断言为准。
