/* A content-design fixture with real browser-local writes and source-owned messages. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const root = document.documentElement;
  const KEY = 'ui-spec-content-note-v1';
  let locale = 'zh';
  let status = '';
  let pending = null;
  let savedRecord = null;
  let storageState = 'unknown';
  let draftEdited = false;
  let draftTouched = false;
  let retryAction = null;
  let baseRecord = null;
  let conflict = null;
  let comparedSignature = null;
  let recoveryAvailable = true;
  const RECOVERY_KEY = KEY + ':conflict-draft';
  const signature = record => JSON.stringify(record ? {title:record.title,body:record.body} : null);
  const draftRecord = () => ({title:$('note-title').value,body:$('note-body').value});
  const copy = {
    zh: {
      brandSubtitle:'研究笔记',eyebrow:'研究空间 / 笔记',scope:'本地演示',step:'记录想法',pageTitle:'把研究线索整理成笔记',pageIntro:'先记下问题和背景，再回来继续完善。',titleLabel:'笔记标题',titleHint:'用一句话写清想研究的问题',titlePlaceholder:'例如：城市供热如何降低高峰负荷？',bodyLabel:'背景与线索',optional:'选填',bodyHint:'补充已有材料、疑问或仍需核查的判断',bodyPlaceholder:'记下材料、想法或需要验证的线索…',save:'保存笔记',saving:'正在保存到此浏览器…',saved:'笔记已保存在此浏览器。',savedEarlier:'上一版已保存。当前修改仍需再次保存。',edited:'当前修改尚未保存。',missing:'填写笔记标题后再保存。',failed:'当前无法保存这份笔记。输入内容仍在页面中。',retry:'重试保存',storage:'仅保存在当前浏览器',asideStep:'继续研究',asideTitle:'最近保存',asideIntro:'已保存的笔记会显示在这里，便于继续编辑。',recentEmpty:'还没有保存的笔记',recentEmptyHint:'保存后可在此查看',recentSaved:'已保存 · 当前浏览器',disclosure:'这是交互演示。笔记会保存在此浏览器中，不会发送到外部服务。',previewSettings:'预览状态设置',failureSwitch:'模拟写入失败',slowSwitch:'延迟写入 1 秒',loadLong:'填写较长标题',reset:'清除本地演示数据',fixtureLabel:'内容与交互状态实例 · 本地运行',langButton:'EN',langAria:'EN · Switch to English',themeDark:'切换深色主题',themeLight:'切换浅色主题',resetDone:'本地演示数据已清除。',clearFailed:'未能清除本地演示数据。当前输入仍在页面中，请重试。',clearRetry:'重试清除',readFailed:'暂时无法读取已保存的笔记。当前输入仍在页面中，请重试读取后再保存。',invalidStored:'已保存的笔记数据无法识别。请在预览设置中清除本地演示数据后再保存。',readRetry:'重试读取',readRecovered:'已重新读取本地笔记。',readRecoveredEmpty:'本地存储已恢复，尚无已保存的笔记。',readRecoveredEmptyDraft:'本地存储已恢复。当前输入尚未保存。',readRecoveredDraft:'已重新读取本地笔记。当前输入仍在页面中，保存后会替换已存内容。',recentUnreadable:'暂时无法读取笔记',recentUnreadableHint:'重试读取后可确认已保存的内容',longTitle:'比较不同城市在能源供应高峰期间如何调节供热需求，并梳理可供进一步核查的具体研究证据',htmlTitle:'Fieldnote · 研究笔记',skip:'跳到主要内容'
    },
    en: {
      brandSubtitle:'Research notes',eyebrow:'Research / Notes',scope:'Local demo',step:'Capture an idea',pageTitle:'Turn a research lead into a note',pageIntro:'Start with the question and its context. Return to the same note as your research develops.',titleLabel:'Note title',titleHint:'Name the question you want to investigate',titlePlaceholder:'For example: Reducing peak demand',bodyLabel:'Context and leads',optional:'Optional',bodyHint:'Add sources, open questions, or assumptions to check',bodyPlaceholder:'Capture the source material or questions to verify…',save:'Save note',saving:'Saving in this browser…',saved:'Note saved in this browser.',savedEarlier:'An earlier version was saved. Save again to keep your new edits.',edited:'You have unsaved changes.',missing:'Add a note title before saving.',failed:'This note could not be saved. Your text is still here.',retry:'Try saving again',storage:'Saved only in this browser',asideStep:'Continue your work',asideTitle:'Recently saved',asideIntro:'Saved notes appear here so you can return to your work.',recentEmpty:'No notes saved yet',recentEmptyHint:'Your note will appear after saving',recentSaved:'Saved · This browser',disclosure:'This is an interactive demo. Notes stay in this browser and are not sent to an external service.',previewSettings:'Preview state controls',failureSwitch:'Simulate a write failure',slowSwitch:'Delay the write by 1 second',loadLong:'Use a longer example title',reset:'Clear local demo data',fixtureLabel:'Content and state example · Local demo',langButton:'中文',langAria:'切换到中文',themeDark:'Switch to dark theme',themeLight:'Switch to light theme',resetDone:'Local demo data cleared.',clearFailed:'Local demo data could not be cleared. Your text is still here. Try again.',clearRetry:'Try clearing again',readFailed:'Saved notes could not be read. Your text is still here. Try reading again before saving.',invalidStored:'The saved note data is not readable. Clear local demo data in the preview controls before saving.',readRetry:'Try reading again',readRecovered:'The local note has been read again.',readRecoveredEmpty:'Local storage is available again. No notes have been saved.',readRecoveredEmptyDraft:'Local storage is available again. Your current text has not been saved.',readRecoveredDraft:'The local note has been read again. Your current text is still here. Saving will replace the stored note.',recentUnreadable:'Saved note unavailable',recentUnreadableHint:'Try reading again to check the saved content',longTitle:'Compare how different cities manage district-heating demand during peak energy use and identify which evidence needs to be verified',htmlTitle:'Fieldnote · Research notes',skip:'Skip to main content'
    }
  };

  Object.assign(copy.zh, {
    conflictBanner:'这份笔记在另一标签页更新了',conflictHint:'你的草稿仍在。请比较两个版本，再决定保留哪一份。',
    compare:'比较两个版本',compareEyebrow:'版本比较',conflictTitle:'想保留哪一个版本？',conflictExplanation:'另一标签页保存了这份笔记。你的草稿尚未保存，两份文本都在这里。',
    mineHeading:'我的草稿',otherHeading:'另一标签页',unsavedLabel:'尚未保存',savedLabel:'已保存',deletedLabel:'已清除',
    keepMine:'保留我的草稿',useOther:'采用另一版本',later:'稍后决定',choiceHint:'保留草稿后仍需保存；采用另一版本会替换当前草稿。',
    conflictStatus:'存在两个版本，请比较后再保存。',draftKept:'已保留你的草稿。保存后将替换另一标签页的版本。',otherUsed:'已采用另一标签页的版本。',externalUpdated:'已载入另一标签页保存的最新版本。',
    externalCleared:'笔记已在另一标签页清除。',deletedTitle:'笔记已被清除',deletedBody:'另一标签页清除了本地笔记。采用此版本会清空当前编辑器。',
    emptyTitle:'（未填写标题）',emptyBody:'（正文为空）',newerUpdate:'另一标签页又更新了内容。请重新核对下方版本，再作选择。',
    earlierVersions:'更早收到的版本',recoveryLimited:'两份文本暂留在此页面。暂时无法备份草稿，请勿关闭此标签页。',
    recoveredConflict:'已恢复待处理的草稿。请比较两个版本后再保存。'
  });
  Object.assign(copy.en, {
    conflictBanner:'This note changed in another tab',conflictHint:'Your draft is still here. Compare both versions and choose which text to keep.',
    compare:'Compare versions',compareEyebrow:'Version comparison',conflictTitle:'Which version would you like to keep?',conflictExplanation:'Another tab saved this note while you had unsaved changes. Both versions are here.',
    mineHeading:'My draft',otherHeading:'Other tab',unsavedLabel:'Unsaved',savedLabel:'Saved',deletedLabel:'Cleared',
    keepMine:'Keep my draft',useOther:'Use other version',later:'Decide later',choiceHint:'Keep your draft to continue editing, then save. Using the other version replaces your draft.',
    conflictStatus:'There are two versions. Compare them before saving.',draftKept:'Your draft is kept. Saving will replace the version from the other tab.',otherUsed:'The version from the other tab is now in the editor.',externalUpdated:'The latest version saved in another tab is now in the editor.',
    externalCleared:'The note was cleared in another tab.',deletedTitle:'Note cleared',deletedBody:'The other tab cleared the local note. Using this version empties your editor.',
    emptyTitle:'(No title entered)',emptyBody:'(Empty note)',newerUpdate:'The other tab updated the note again. Review the versions below before choosing.',
    earlierVersions:'Earlier versions received',recoveryLimited:'Both texts are kept on this page. A draft backup is unavailable. Keep this tab open.',
    recoveredConflict:'Your unresolved draft has been restored. Compare both versions before saving.'
  });
  function t(name) { return copy[locale][name]; }
  function currentRecord() { return {title:$('note-title').value.trim(),body:$('note-body').value}; }
  function parseRecord(raw) {
    const data = raw === null ? null : JSON.parse(raw);
    if (raw !== null && (!data || typeof data.title !== 'string' || !data.title.trim() || data.title.length > 150 || typeof data.body !== 'string' || data.body.length > 3000)) throw new SyntaxError('Unrecognized note data');
    return data ? {title:data.title,body:data.body} : null;
  }
  function isDirty() {
    return baseRecord ? signature(currentRecord()) !== signature(baseRecord) : Boolean($('note-title').value || $('note-body').value);
  }
  function updateControls() {
    $('save').disabled = pending !== null || storageState !== 'ready';
    $('save').setAttribute('aria-busy',String(pending !== null));
  }
  function showStatus(next) {
    status = next;
    const retry=$('retry'), hadFocus=document.activeElement===retry;
    retryAction=({failed:'save',readFailed:'read',invalidStored:'read',clearFailed:'clear'})[next] || null;
    $('state-message').textContent=next?t(next):'';
    $('state-message').parentElement.dataset.status=retryAction?'error':next;
    retry.hidden=retryAction===null;
    if(retryAction) retry.textContent=t(({save:'retry',read:'readRetry',clear:'clearRetry'})[retryAction]);
    if(hadFocus && retry.hidden) $('note-title').focus();
  }
  function renderSaved() {
    if(storageState!=='ready') { $('recent-title').textContent=t('recentUnreadable');$('recent-meta').textContent=t('recentUnreadableHint');return; }
    $('recent-title').textContent=savedRecord?savedRecord.title:t('recentEmpty');
    $('recent-meta').textContent=t(savedRecord?'recentSaved':'recentEmptyHint');
  }
  function cancelPending() {
    if(pending) clearTimeout(pending.timer);
    pending=null;updateControls();
  }
  function storeRecovery() {
    if(!conflict) return;
    try { sessionStorage.setItem(RECOVERY_KEY,JSON.stringify({draft:draftRecord(),base:baseRecord,versions:conflict.versions}));recoveryAvailable=true; }
    catch { recoveryAvailable=false; }
  }
  function discardRecovery() { try { sessionStorage.removeItem(RECOVERY_KEY); } catch {} }
  function renderConflict() {
    $('conflict-banner').hidden=!conflict;
    if(!conflict) return;
    $('conflict-banner-detail').textContent=t(recoveryAvailable?'conflictHint':'recoveryLimited');
  }
  function enterConflict(incoming) {
    cancelPending();savedRecord=incoming;storageState='ready';
    if(!conflict) conflict={incoming,versions:[]};
    if(!conflict.versions.some(v=>signature(v)===signature(incoming))) conflict.versions.push(incoming);
    conflict.incoming=incoming;
    storeRecovery();renderConflict();renderSaved();showStatus('conflictStatus');updateControls();
    if($('conflict-dialog').open) {
      // Keep the displayed snapshot stable. A later click must re-review new data.
      $('comparison-update').hidden=false;
      $('comparison-update').textContent=t('newerUpdate');
    }
  }
  function applyRecord(record) {
    $('note-title').value=record?record.title:'';
    $('note-body').value=record?record.body:'';
    baseRecord=record;savedRecord=record;draftEdited=false;draftTouched=false;
    clearFieldError();renderSaved();updateControls();
  }
  function syncExternal() {
    try {
      const incoming=parseRecord(localStorage.getItem(KEY));
      storageState='ready';
      if(conflict && signature(incoming)===signature(conflict.incoming)) {renderSaved();updateControls();return;}
      if(signature(incoming)===signature(baseRecord) && !conflict) {renderSaved();updateControls();return;}
      if(conflict || isDirty() || pending) {
        if(signature(incoming)===signature(currentRecord())) {
          cancelPending();conflict=null;discardRecovery();renderConflict();applyRecord(incoming);showStatus('externalUpdated');
          if($('conflict-dialog').open) $('conflict-dialog').close();
        } else enterConflict(incoming);
      } else {applyRecord(incoming);showStatus(incoming?'externalUpdated':'externalCleared');}
    } catch(error) { cancelPending();storageState='unavailable';showStatus(error instanceof SyntaxError?'invalidStored':'readFailed');renderSaved();updateControls(); }
  }
  function readStored(initial=false) {
    try {
      const data=parseRecord(localStorage.getItem(KEY));storageState='ready';
      if(!draftTouched && !conflict) {applyRecord(data);if(!initial) showStatus(data?'readRecovered':'readRecoveredEmpty');}
      else if(signature(data)!==signature(baseRecord)) enterConflict(data);
      else {savedRecord=data;if(!initial) showStatus(data?'readRecoveredDraft':'readRecoveredEmptyDraft');}
    } catch(error) {storageState='unavailable';showStatus(error instanceof SyntaxError?'invalidStored':'readFailed');}
    renderSaved();updateControls();
  }
  function restoreRecovery() {
    try {
      const raw=sessionStorage.getItem(RECOVERY_KEY);if(!raw) return;
      const recovery=JSON.parse(raw), draft=recovery.draft;
      if(!draft || typeof draft.title!=='string'||draft.title.length>150||typeof draft.body!=='string'||draft.body.length>3000||!Array.isArray(recovery.versions)) return;
      const versions=recovery.versions.map(v=>parseRecord(v===null?null:JSON.stringify(v)));
      baseRecord=parseRecord(recovery.base===null?null:JSON.stringify(recovery.base));
      $('note-title').value=draft.title;$('note-body').value=draft.body;draftTouched=true;draftEdited=true;
      conflict={incoming:savedRecord,versions};
      if(storageState==='ready') enterConflict(savedRecord);
      else {renderConflict();}
      if(storageState==='ready') showStatus('recoveredConflict');
    } catch { recoveryAvailable=false; }
  }
  function fillComparison() {
    if(!conflict) return;
    const mine=draftRecord(),other=conflict.incoming;
    $('mine-title').textContent=mine.title||t('emptyTitle');$('mine-body').textContent=mine.body||t('emptyBody');
    $('other-title').textContent=other?other.title:t('deletedTitle');$('other-body').textContent=other?(other.body||t('emptyBody')):t('deletedBody');
    $('other-badge').textContent=t(other?'savedLabel':'deletedLabel');
    $('mine-text').setAttribute('aria-label',t('mineHeading'));$('other-text').setAttribute('aria-label',t('otherHeading'));
    const earlier=conflict.versions.filter(v=>signature(v)!==signature(other));
    $('conflict-history').hidden=earlier.length===0;
    $('history-label').textContent=`${t('earlierVersions')} (${earlier.length})`;
    $('history-content').replaceChildren();
    for(const version of earlier) {
      const article=document.createElement('article'),title=document.createElement('strong'),body=document.createElement('p');
      title.textContent=version?version.title:t('deletedTitle');body.textContent=version?version.body:t('deletedBody');article.append(title,body);$('history-content').append(article);
    }
    comparedSignature=signature(other);
  }
  function openComparison() {
    if(!conflict) return;
    fillComparison();$('comparison-update').hidden=true;
    if(!$('conflict-dialog').open) $('conflict-dialog').showModal();
  }
  function chooseVersion(mine) {
    if(!conflict) return;
    // Selection is valid only for the version the user actually inspected.
    try {
      const latest=parseRecord(localStorage.getItem(KEY));
      if(signature(latest)!==comparedSignature) {
        enterConflict(latest);fillComparison();$('comparison-update').hidden=false;$('comparison-update').textContent=t('newerUpdate');return;
      }
      baseRecord=latest;savedRecord=latest;storageState='ready';
      if(!mine) applyRecord(latest);
      else {draftTouched=true;draftEdited=isDirty();}
      conflict=null;discardRecovery();renderConflict();$('conflict-dialog').close();
      showStatus(mine?'draftKept':'otherUsed');renderSaved();updateControls();
    } catch(error) {storageState='unavailable';showStatus(error instanceof SyntaxError?'invalidStored':'readFailed');updateControls();$('conflict-dialog').close();}
  }
  function renderLocale() {
    root.lang=locale==='zh'?'zh-CN':'en';document.title=t('htmlTitle');
    for(const element of document.querySelectorAll('[data-i18n]')) element.textContent=t(element.dataset.i18n);
    $('skip').textContent=t('skip');$('locale-toggle').textContent=t('langButton');$('locale-toggle').setAttribute('aria-label',t('langAria'));$('locale-toggle').lang=locale==='zh'?'en':'zh-CN';
    $('note-title').placeholder=t('titlePlaceholder');$('note-body').placeholder=t('bodyPlaceholder');
    document.querySelector('.context-panel').setAttribute('aria-label',locale==='zh'?'研究笔记预览':'Research note preview');
    $('theme-toggle').setAttribute('aria-label',t(root.dataset.theme==='dark'?'themeLight':'themeDark'));
    if(!$('title-error').hidden) $('title-error').textContent=t('missing');
    showStatus(status);renderSaved();renderConflict();
    if($('conflict-dialog').open) fillComparison();
  }
  function clearFieldError() {$('title-error').hidden=true;$('title-error').textContent='';$('note-title').removeAttribute('aria-invalid');}
  function submit() {
    if(pending!==null||storageState!=='ready')return;
    if(conflict){openComparison();return;}
    const record=currentRecord();
    if(!record.title) {$('note-title').setAttribute('aria-invalid','true');$('title-error').hidden=false;$('title-error').textContent=t('missing');showStatus('');$('note-title').focus();return;}
    clearFieldError();
    const expected=signature(baseRecord),snapshot=signature(record),operation={timer:null};pending=operation;showStatus('saving');updateControls();
    const commit=()=>{
      if(pending!==operation)return;
      try {
        const latest=parseRecord(localStorage.getItem(KEY));
        if(signature(latest)!==expected) {enterConflict(latest);return;}
        if($('simulate-failure').checked)throw new Error('Simulated write failure');
        localStorage.setItem(KEY,snapshot);
        pending=null;baseRecord=record;savedRecord=record;draftEdited=signature(currentRecord())!==snapshot;draftTouched=draftEdited;
        discardRecovery();showStatus(draftEdited?'savedEarlier':'saved');renderSaved();
      } catch(error) {
        pending=null;
        if(error instanceof SyntaxError){storageState='unavailable';showStatus('invalidStored');renderSaved();}
        else showStatus('failed');
      }
      updateControls();
    };
    operation.timer=setTimeout(()=>{
      if(pending!==operation)return;
      // The lock coordinates current Fieldnote tabs. Preflight remains in the fallback.
      if(navigator.locks?.request) navigator.locks.request(KEY,commit).catch(()=>{if(pending===operation){pending=null;showStatus('failed');updateControls();}});
      else commit();
    },$('simulate-slow').checked?1000:140);
  }
  function clearStored() {
    cancelPending();
    try{localStorage.removeItem(KEY);}catch{showStatus('clearFailed');return;}
    conflict=null;discardRecovery();renderConflict();if($('conflict-dialog').open)$('conflict-dialog').close();
    storageState='ready';applyRecord(null);showStatus('resetDone');
  }
  function markEdited() {
    draftTouched=true;draftEdited=isDirty();
    if(conflict){storeRecovery();renderConflict();showStatus('conflictStatus');return;}
    if(!pending && !['readFailed','invalidStored','clearFailed','failed'].includes(status))showStatus(draftEdited?'edited':(savedRecord?'saved':''));
  }
  $('note-form').addEventListener('submit',event=>{event.preventDefault();submit();});
  $('retry').addEventListener('click',()=>{if(retryAction==='save')submit();else if(retryAction==='read')readStored();else if(retryAction==='clear')clearStored();});
  $('note-body').addEventListener('input',markEdited);
  $('note-title').addEventListener('input',()=>{markEdited();if($('note-title').value.trim())clearFieldError();});
  $('locale-toggle').addEventListener('click',()=>{locale=locale==='zh'?'en':'zh';renderLocale();});
  $('theme-toggle').addEventListener('click',()=>{root.dataset.theme=root.dataset.theme==='dark'?'light':'dark';renderLocale();});
  $('long-example').addEventListener('click',()=>{$('note-title').value=t('longTitle');$('note-title').dispatchEvent(new Event('input'));$('note-title').focus();});
  $('reset').addEventListener('click',clearStored);
  $('compare').addEventListener('click',openComparison);
  $('keep-mine').addEventListener('click',()=>chooseVersion(true));
  $('use-other').addEventListener('click',()=>chooseVersion(false));
  $('conflict-dialog').addEventListener('close',()=>{$('conflict-dialog').returnValue='';comparedSignature=null;});
  window.addEventListener('storage',event=>{if(event.storageArea===localStorage&&(event.key===KEY||event.key===null))syncExternal();});
  window.addEventListener('focus',()=>{if(storageState==='ready')syncExternal();});
  window.addEventListener('beforeunload',event=>{if(isDirty()||conflict){event.preventDefault();event.returnValue='';}});
  readStored(true);restoreRecovery();renderLocale();
})();
