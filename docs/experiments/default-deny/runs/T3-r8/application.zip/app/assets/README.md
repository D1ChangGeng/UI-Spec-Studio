# Fieldnote mark
Original compact F with a folded upper corner, created for this task under TASK.md's explicit identity authorization. Editable SVG light and dark exports use the existing palette. Runtime geometry is the same inline SVG in index.html; its color comes from the existing theme variables. The brand slot remains 37 × 37 px with a 10 px corner radius.

Two original alternatives were rendered at the same size and on both backgrounds in ../../evidence/brand-options.png. The solid F was chosen for legibility at the actual use size. No third-party mark or code was adopted.
