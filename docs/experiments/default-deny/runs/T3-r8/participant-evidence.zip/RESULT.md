# Fieldnote 本地实现交付

入口：http://127.0.0.1:4313/

实现源：app/index.html、app/styles.css、app/app.js。原创品牌可编辑输出在 app/assets/fieldnote-mark-light.svg 与 fieldnote-mark-dark.svg。运行说明在 app/README.md。

已完成：占位 14px / 输入 15px，保留49px标题与145px正文控件；Fieldnote品牌；跨标签双版本提示和比较、两种选择、稍后处理、冲突会话恢复、存储前复查。未添加虚构引文或支持关系。

核心8组合运行验证通过；见 evidence/verification-matrix.json。截图实际查看范围、失败轨迹与最后修复范围见 evidence/DESIGN.md。

**未闭合问题**：补充的延迟保存与外部写入时序断言失败，仍需定位；最后的重复聚焦提示守卫尚未重跑验证；长正文滚动、外部删除、原生存储故障及同时提交补充场景未完成。现有 failure/retry 等截图未逐张视觉查看。工作窗口到达，未把这些项目标为通过。

引文支持研究：evidence/FUTURE-EVIDENCE.md。推荐按判断关联引文与原文位置；需要稳定笔记/来源/引文/判断ID、版本、定位、关系类型、创建与复核来源。当前title/body无法证明支持关系。
