# Fieldnote · 本轮设计与证据

## 已知目标与边界
本轮为现有本地应用的一次增量：保留 TASK.md 已接受的布局、配色、编辑器/最近保存关系，修改共享占位文字层级和品牌，补上跨标签并发编辑比较。引用支持视图只进行研究，不创建当前数据没有的引文/支撑边。

## 当前事实与研究判断（实施前）
- app/app.js 的持久化内容为一个 `{title, body}` 记录；有保存快照、延迟写入、错误与重试，但没有 storage 事件或版本比较机制。
- before-1440.png / before-390.png 已实际查看：标题与正文占位符均为 15px，控件高度分别为 49px / 145px。测试浏览器没有中文字库，字形呈方框；随后由运行环境提供 FONTCONFIG_FILE=/tmp/ui-spec-fonts/fonts.conf 供所有检查使用；未改变产品字体声明。字号与控件比例保持。
- 已读 ui-spec 全部八份公共参考，及 integration/evidence-map/evidence-actions。
- 现代 Web 指南 `dialog`（2026-10-30 检索）建议原生 dialog、showModal、明确名称、安全初始焦点、原生 Esc 与焦点返回、滚动隔离；本轮继承平台交互，视觉沿用本产品 token。
- 既有 status/retry 行只能表达状态，不能阅读两份完整文本。原生确认弹窗也无法并列查看长文本。TASK.md 明确允许本地比较呈现，因此只新增该局部，使用现有色板、边界、按钮和字号。

## 选择与待检验问题
1. 占位文字 15 → 14px，输入仍 15px，宽高/padding/line-height 不变。中英/明暗均需查看。
2. 原创折页 F：比较实心 F 的折角和轮廓纸页内嵌 F。优先试验前者，以更少细节保持 37px 品牌槽的辨认；不复制第三方标志。具体选择以实际小尺寸试验为准。
3. 冲突：先在编辑器内提示，用户打开 native dialog；桌面双列、窄屏上下。两侧明确属于“我的草稿”和“另一标签页”，全文可选可滚动；关闭不作选择。选草稿只保留草稿，仍需显式保存；选另一版本替换草稿。提交前重新读取，支持时用 Web Locks 协调本应用标签页，延迟提交遇到变化应停止而非覆盖。
4. 后续证据视图：优先“论点 + 引文列表 + 回到原文”，图结构仅在关系拓扑本身是问题时考虑。当前标题/自由文本不能推导引文实体或支撑关系。

## 一手来源与实际观测
- https://www.zotero.org/support/pdf_reader ：已读注释加入笔记、回到原文的说明；已实际查看官方 pdf-reader.jpg（Zotero 6 示例）与 add-note-from-annotations.png。可见左侧注释列表、中间原文、右侧笔记与引用出处；该截图不证明本应用可自动识别支持关系。只借鉴可回溯关联，未采用 Zotero 代码。
- https://www.w3.org/TR/annotation-model/#text-quote-selector ：已读 exact/prefix/suffix 与 source、selector。用于未来数据建模；不把注释关系等同于“证实论点”。
- https://code.visualstudio.com/docs/sourcecontrol/merge-conflicts ：已读命名两侧、比较/接受任一方或两者、需复查结果的说明；官方三栏图已获取并实际查看：两侧等宽，上方比较与下方结果分离。只借鉴先阅读两侧再明确选择的关系，不采用其技术信息密度。技术任务有不同语义，本轮不用 current/incoming 黑箱命名，不引入三方 Git 模型。
- https://developer.mozilla.org/en-US/docs/Web/API/Window/storage_event ：同源其他标签页收到 storage 事件，写入者本身不收到。
- https://developer.mozilla.org/en-US/docs/Web/API/Web_Locks_API ：同源任务可请求同一锁协调访问；不保证不遵守该锁的旧页面/外部脚本。

## 字体与环境调整
初始环境截图存在方框字形。曾尝试获取 Noto 官方字体并压缩，压缩缺少 Brotli，未采用该路径。随后采用运行负责人提供的 `/tmp/ui-spec-fonts/fonts.conf` 与 Noto Sans SC 进行验证；已撤下所有临时产品字体改动。产品仍保留原有系统字体栈。

## 初次实际结果
已查看 first-empty-desktop.png、first-conflict-desktop.png、first-conflict-mobile-en-dark.png 和 brand-options.png。桌面双列让角色和段落直接对应，手机上下排布仍可见选择及稍后操作；空态控件比例保留。实心 F 在 37px 中更清楚，纸页轮廓方案的小内部 F 更细，因此采用实心折角方案。当前原生 dialog 使用浏览器焦点与 Esc 行为，未增加自制焦点陷阱。

## 尚待验证
初次本地试验、品牌两方案比较、指定 8 个尺寸/主题/语言组合、输入/空态、焦点、双标签两种选择、刷新恢复、写失败/重试、延迟提交期间编辑/外部写入、空标题、外部清除。各项须以真实测试与已查看截图更新，不以文件存在替代检查。

## 交付时验证范围与剩余问题

工作窗口到达时停止扩展检查。`verification-matrix.json` 保留完整 8 组合核心路径的 8 条通过记录：390×844 / 1440×900 × zh/en × light/dark，空态、输入、15px/14px、49px/145px、键盘焦点、双标签两个选择、Esc/焦点返回、模拟写入失败与重试、实际存储刷新。另通过再次更新要求重看与冲突会话刷新恢复，以及保存快照后仍保留随后输入。

实际查看：before 两截图（无中文字形）、first-empty-desktop / first-conflict-desktop / first-conflict-mobile-en-dark、brand-options、focus-* 全部8张、conflict-* 全部8张，以及三张一手参考图。entered/failure/retry/chosen 等矩阵截图已生成，尚未逐张打开进行视觉审查。没有播放连续视频，不声称连续运动质量或真实设备体验。

补充测试在 `external-change-cancels-pending-save` 断言处中断：试图在 1 秒延迟期间通过另一页输入并点击保存，但存储最终值不符合测试预期。重载另一页后再次运行仍失败。需要用受控时钟确认外部写入确实发生在待提交窗口内，并判断是测试时序还是实现缺陷；目前该路径未通过，不宣称已验证。源码中有取消 pending 与保存前比对保护，但源码不能替代此项运行证据。失败后的长正文滚动、外部删除、原生读/写/删除故障、同时提交场景未执行完成。

视觉检查还发现：Tab 进入浏览器界面再返回时，focus 检查对同一已知冲突重复调用 enterConflict，误显示“再次更新”。已增加 incoming 与当前冲突相同则直接返回的守卫；`node --check app/app.js` 通过。该最后修复尚未运行完整回归，现有 conflict-* 图为修复前证据，不能冒充修复后的截图。

字体环境仍只由 FONTCONFIG_FILE 补足；产品未追加字体资源。工作没有发布到外部。
