from playwright.sync_api import sync_playwright
from pathlib import Path
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome', headless=True, args=['--no-sandbox'])
    for width,height in [(1440,900),(390,844)]:
        page=browser.new_page(viewport={'width':width,'height':height},device_scale_factor=1)
        page.goto('http://127.0.0.1:4313/')
        page.screenshot(path=f'evidence/before-{width}.png')
        print(width, page.locator('#note-title').evaluate('(e)=>({font:getComputedStyle(e).fontSize,placeholder:getComputedStyle(e,"::placeholder").fontSize,height:e.offsetHeight})'))
        page.close()
    browser.close()
