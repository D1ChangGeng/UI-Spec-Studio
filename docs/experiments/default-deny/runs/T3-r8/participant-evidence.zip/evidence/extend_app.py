from pathlib import Path
p=Path('app/app.js');s=p.read_text();prefix=s[:s.index('  function t(name)')]
prefix=prefix.replace("  let retryAction = null;", """  let retryAction = null;
  let baseRecord = null;
  let conflict = null;
  let comparedSignature = null;
  let recoveryAvailable = true;
  const RECOVERY_KEY = KEY + ':conflict-draft';
  const signature = record => JSON.stringify(record ? {title:record.title,body:record.body} : null);
  const draftRecord = () => ({title:$('note-title').value,body:$('note-body').value});""")
prefix=prefix.replace("htmlTitle:'研究笔记 · 内容设计实例'", "htmlTitle:'Fieldnote · 研究笔记'").replace("htmlTitle:'Research notes · Content design example'", "htmlTitle:'Fieldnote · Research notes'")
extra=r'''
  Object.assign(copy.zh, {
    conflictBanner:'这份笔记在另一标签页更新了',conflictHint:'你的草稿仍在。请比较两个版本，再决定保留哪一份。',
    compare:'比较两个版本',compareEyebrow:'版本比较',conflictTitle:'想保留哪一个版本？',conflictExplanation:'另一标签页保存了这份笔记。你的草稿尚未保存，两份文本都在这里。',
    mineHeading:'我的草稿',otherHeading:'另一标签页',unsavedLabel:'尚未保存',savedLabel:'已保存',deletedLabel:'已清除',
    keepMine:'保留我的草稿',useOther:'采用另一版本',later:'稍后决定',choiceHint:'保留草稿后仍需保存；采用另一版本会替换当前草稿。',
    conflictStatus:'存在两个版本，请比较后再保存。',draftKept:'已保留你的草稿。保存后将替换另一标签页的版本。',otherUsed:'已采用另一标签页的版本。',externalUpdated:'已载入另一标签页保存的最新版本。',
    externalCleared:'笔记已在另一标签页清除。',deletedTitle:'笔记已被清除',deletedBody:'另一标签页清除了本地笔记。采用此版本会清空当前编辑器。',
    emptyTitle:'（未填写标题）',emptyBody:'（正文为空）',newerUpdate:'另一标签页又更新了内容。请重新核对下方版本，再作选择。',
    earlierVersions:'更早收到的版本',recoveryLimited:'两份文本暂留在此页面。暂时无法备份草稿，请勿关闭此标签页。',
    recoveredConflict:'已恢复待处理的草稿。请比较两个版本后再保存。'
  });
  Object.assign(copy.en, {
    conflictBanner:'This note changed in another tab',conflictHint:'Your draft is still here. Compare both versions and choose which text to keep.',
    compare:'Compare versions',compareEyebrow:'Version comparison',conflictTitle:'Which version would you like to keep?',conflictExplanation:'Another tab saved this note while you had unsaved changes. Both versions are here.',
    mineHeading:'My draft',otherHeading:'Other tab',unsavedLabel:'Unsaved',savedLabel:'Saved',deletedLabel:'Cleared',
    keepMine:'Keep my draft',useOther:'Use other version',later:'Decide later',choiceHint:'Keep your draft to continue editing, then save. Using the other version replaces your draft.',
    conflictStatus:'There are two versions. Compare them before saving.',draftKept:'Your draft is kept. Saving will replace the version from the other tab.',otherUsed:'The version from the other tab is now in the editor.',externalUpdated:'The latest version saved in another tab is now in the editor.',
    externalCleared:'The note was cleared in another tab.',deletedTitle:'Note cleared',deletedBody:'The other tab cleared the local note. Using this version empties your editor.',
    emptyTitle:'(No title entered)',emptyBody:'(Empty note)',newerUpdate:'The other tab updated the note again. Review the versions below before choosing.',
    earlierVersions:'Earlier versions received',recoveryLimited:'Both texts are kept on this page. A draft backup is unavailable. Keep this tab open.',
    recoveredConflict:'Your unresolved draft has been restored. Compare both versions before saving.'
  });
  function t(name) { return copy[locale][name]; }
  function currentRecord() { return {title:$('note-title').value.trim(),body:$('note-body').value}; }
  function parseRecord(raw) {
    const data = raw === null ? null : JSON.parse(raw);
    if (raw !== null && (!data || typeof data.title !== 'string' || !data.title.trim() || data.title.length > 150 || typeof data.body !== 'string' || data.body.length > 3000)) throw new SyntaxError('Unrecognized note data');
    return data ? {title:data.title,body:data.body} : null;
  }
  function isDirty() {
    return baseRecord ? signature(currentRecord()) !== signature(baseRecord) : Boolean($('note-title').value || $('note-body').value);
  }
  function updateControls() {
    $('save').disabled = pending !== null || storageState !== 'ready';
    $('save').setAttribute('aria-busy',String(pending !== null));
  }
  function showStatus(next) {
    status = next;
    const retry=$('retry'), hadFocus=document.activeElement===retry;
    retryAction=({failed:'save',readFailed:'read',invalidStored:'read',clearFailed:'clear'})[next] || null;
    $('state-message').textContent=next?t(next):'';
    $('state-message').parentElement.dataset.status=retryAction?'error':next;
    retry.hidden=retryAction===null;
    if(retryAction) retry.textContent=t(({save:'retry',read:'readRetry',clear:'clearRetry'})[retryAction]);
    if(hadFocus && retry.hidden) $('note-title').focus();
  }
  function renderSaved() {
    if(storageState!=='ready') { $('recent-title').textContent=t('recentUnreadable');$('recent-meta').textContent=t('recentUnreadableHint');return; }
    $('recent-title').textContent=savedRecord?savedRecord.title:t('recentEmpty');
    $('recent-meta').textContent=t(savedRecord?'recentSaved':'recentEmptyHint');
  }
  function cancelPending() {
    if(pending) clearTimeout(pending.timer);
    pending=null;updateControls();
  }
  function storeRecovery() {
    if(!conflict) return;
    try { sessionStorage.setItem(RECOVERY_KEY,JSON.stringify({draft:draftRecord(),base:baseRecord,versions:conflict.versions}));recoveryAvailable=true; }
    catch { recoveryAvailable=false; }
  }
  function discardRecovery() { try { sessionStorage.removeItem(RECOVERY_KEY); } catch {} }
  function renderConflict() {
    $('conflict-banner').hidden=!conflict;
    if(!conflict) return;
    $('conflict-banner-detail').textContent=t(recoveryAvailable?'conflictHint':'recoveryLimited');
  }
  function enterConflict(incoming) {
    cancelPending();savedRecord=incoming;storageState='ready';
    if(!conflict) conflict={incoming,versions:[]};
    if(!conflict.versions.some(v=>signature(v)===signature(incoming))) conflict.versions.push(incoming);
    conflict.incoming=incoming;
    storeRecovery();renderConflict();renderSaved();showStatus('conflictStatus');updateControls();
    if($('conflict-dialog').open) {
      // Keep the displayed snapshot stable. A later click must re-review new data.
      $('comparison-update').hidden=false;
      $('comparison-update').textContent=t('newerUpdate');
    }
  }
  function applyRecord(record) {
    $('note-title').value=record?record.title:'';
    $('note-body').value=record?record.body:'';
    baseRecord=record;savedRecord=record;draftEdited=false;draftTouched=false;
    clearFieldError();renderSaved();updateControls();
  }
  function syncExternal() {
    try {
      const incoming=parseRecord(localStorage.getItem(KEY));
      storageState='ready';
      if(signature(incoming)===signature(baseRecord) && !conflict) {renderSaved();updateControls();return;}
      if(conflict || isDirty() || pending) {
        if(signature(incoming)===signature(currentRecord())) {
          cancelPending();conflict=null;discardRecovery();renderConflict();applyRecord(incoming);showStatus('externalUpdated');
          if($('conflict-dialog').open) $('conflict-dialog').close();
        } else enterConflict(incoming);
      } else {applyRecord(incoming);showStatus(incoming?'externalUpdated':'externalCleared');}
    } catch(error) { cancelPending();storageState='unavailable';showStatus(error instanceof SyntaxError?'invalidStored':'readFailed');renderSaved();updateControls(); }
  }
  function readStored(initial=false) {
    try {
      const data=parseRecord(localStorage.getItem(KEY));storageState='ready';
      if(!draftTouched && !conflict) {applyRecord(data);if(!initial) showStatus(data?'readRecovered':'readRecoveredEmpty');}
      else if(signature(data)!==signature(baseRecord)) enterConflict(data);
      else {savedRecord=data;if(!initial) showStatus(data?'readRecoveredDraft':'readRecoveredEmptyDraft');}
    } catch(error) {storageState='unavailable';showStatus(error instanceof SyntaxError?'invalidStored':'readFailed');}
    renderSaved();updateControls();
  }
  function restoreRecovery() {
    try {
      const raw=sessionStorage.getItem(RECOVERY_KEY);if(!raw) return;
      const recovery=JSON.parse(raw), draft=recovery.draft;
      if(!draft || typeof draft.title!=='string'||draft.title.length>150||typeof draft.body!=='string'||draft.body.length>3000||!Array.isArray(recovery.versions)) return;
      const versions=recovery.versions.map(v=>parseRecord(v===null?null:JSON.stringify(v)));
      baseRecord=parseRecord(recovery.base===null?null:JSON.stringify(recovery.base));
      $('note-title').value=draft.title;$('note-body').value=draft.body;draftTouched=true;draftEdited=true;
      conflict={incoming:savedRecord,versions};
      if(storageState==='ready') enterConflict(savedRecord);
      else {renderConflict();}
      if(storageState==='ready') showStatus('recoveredConflict');
    } catch { recoveryAvailable=false; }
  }
  function fillComparison() {
    if(!conflict) return;
    const mine=draftRecord(),other=conflict.incoming;
    $('mine-title').textContent=mine.title||t('emptyTitle');$('mine-body').textContent=mine.body||t('emptyBody');
    $('other-title').textContent=other?other.title:t('deletedTitle');$('other-body').textContent=other?(other.body||t('emptyBody')):t('deletedBody');
    $('other-badge').textContent=t(other?'savedLabel':'deletedLabel');
    $('mine-text').setAttribute('aria-label',t('mineHeading'));$('other-text').setAttribute('aria-label',t('otherHeading'));
    const earlier=conflict.versions.filter(v=>signature(v)!==signature(other));
    $('conflict-history').hidden=earlier.length===0;
    $('history-label').textContent=`${t('earlierVersions')} (${earlier.length})`;
    $('history-content').replaceChildren();
    for(const version of earlier) {
      const article=document.createElement('article'),title=document.createElement('strong'),body=document.createElement('p');
      title.textContent=version?version.title:t('deletedTitle');body.textContent=version?version.body:t('deletedBody');article.append(title,body);$('history-content').append(article);
    }
    comparedSignature=signature(other);
  }
  function openComparison() {
    if(!conflict) return;
    fillComparison();$('comparison-update').hidden=true;
    if(!$('conflict-dialog').open) $('conflict-dialog').showModal();
  }
  function chooseVersion(mine) {
    if(!conflict) return;
    // Selection is valid only for the version the user actually inspected.
    try {
      const latest=parseRecord(localStorage.getItem(KEY));
      if(signature(latest)!==comparedSignature) {
        enterConflict(latest);fillComparison();$('comparison-update').hidden=false;$('comparison-update').textContent=t('newerUpdate');return;
      }
      baseRecord=latest;savedRecord=latest;storageState='ready';
      if(!mine) applyRecord(latest);
      else {draftTouched=true;draftEdited=isDirty();}
      conflict=null;discardRecovery();renderConflict();$('conflict-dialog').close();
      showStatus(mine?'draftKept':'otherUsed');renderSaved();updateControls();
    } catch(error) {storageState='unavailable';showStatus(error instanceof SyntaxError?'invalidStored':'readFailed');updateControls();$('conflict-dialog').close();}
  }
  function renderLocale() {
    root.lang=locale==='zh'?'zh-CN':'en';document.title=t('htmlTitle');
    for(const element of document.querySelectorAll('[data-i18n]')) element.textContent=t(element.dataset.i18n);
    $('skip').textContent=t('skip');$('locale-toggle').textContent=t('langButton');$('locale-toggle').setAttribute('aria-label',t('langAria'));$('locale-toggle').lang=locale==='zh'?'en':'zh-CN';
    $('note-title').placeholder=t('titlePlaceholder');$('note-body').placeholder=t('bodyPlaceholder');
    document.querySelector('.context-panel').setAttribute('aria-label',locale==='zh'?'研究笔记预览':'Research note preview');
    $('theme-toggle').setAttribute('aria-label',t(root.dataset.theme==='dark'?'themeLight':'themeDark'));
    if(!$('title-error').hidden) $('title-error').textContent=t('missing');
    showStatus(status);renderSaved();renderConflict();
    if($('conflict-dialog').open) fillComparison();
  }
  function clearFieldError() {$('title-error').hidden=true;$('title-error').textContent='';$('note-title').removeAttribute('aria-invalid');}
  function submit() {
    if(pending!==null||storageState!=='ready')return;
    if(conflict){openComparison();return;}
    const record=currentRecord();
    if(!record.title) {$('note-title').setAttribute('aria-invalid','true');$('title-error').hidden=false;$('title-error').textContent=t('missing');showStatus('');$('note-title').focus();return;}
    clearFieldError();
    const expected=signature(baseRecord),snapshot=signature(record),operation={timer:null};pending=operation;showStatus('saving');updateControls();
    const commit=()=>{
      if(pending!==operation)return;
      try {
        const latest=parseRecord(localStorage.getItem(KEY));
        if(signature(latest)!==expected) {enterConflict(latest);return;}
        if($('simulate-failure').checked)throw new Error('Simulated write failure');
        localStorage.setItem(KEY,snapshot);
        pending=null;baseRecord=record;savedRecord=record;draftEdited=signature(currentRecord())!==snapshot;draftTouched=draftEdited;
        discardRecovery();showStatus(draftEdited?'savedEarlier':'saved');renderSaved();
      } catch(error) {
        pending=null;
        if(error instanceof SyntaxError){storageState='unavailable';showStatus('invalidStored');renderSaved();}
        else showStatus('failed');
      }
      updateControls();
    };
    operation.timer=setTimeout(()=>{
      if(pending!==operation)return;
      // The lock coordinates current Fieldnote tabs. Preflight remains in the fallback.
      if(navigator.locks?.request) navigator.locks.request(KEY,commit).catch(()=>{if(pending===operation){pending=null;showStatus('failed');updateControls();}});
      else commit();
    },$('simulate-slow').checked?1000:140);
  }
  function clearStored() {
    cancelPending();
    try{localStorage.removeItem(KEY);}catch{showStatus('clearFailed');return;}
    conflict=null;discardRecovery();renderConflict();if($('conflict-dialog').open)$('conflict-dialog').close();
    storageState='ready';applyRecord(null);showStatus('resetDone');
  }
  function markEdited() {
    draftTouched=true;draftEdited=isDirty();
    if(conflict){storeRecovery();renderConflict();showStatus('conflictStatus');return;}
    if(!pending && !['readFailed','invalidStored','clearFailed','failed'].includes(status))showStatus(draftEdited?'edited':(savedRecord?'saved':''));
  }
  $('note-form').addEventListener('submit',event=>{event.preventDefault();submit();});
  $('retry').addEventListener('click',()=>{if(retryAction==='save')submit();else if(retryAction==='read')readStored();else if(retryAction==='clear')clearStored();});
  $('note-body').addEventListener('input',markEdited);
  $('note-title').addEventListener('input',()=>{markEdited();if($('note-title').value.trim())clearFieldError();});
  $('locale-toggle').addEventListener('click',()=>{locale=locale==='zh'?'en':'zh';renderLocale();});
  $('theme-toggle').addEventListener('click',()=>{root.dataset.theme=root.dataset.theme==='dark'?'light':'dark';renderLocale();});
  $('long-example').addEventListener('click',()=>{$('note-title').value=t('longTitle');$('note-title').dispatchEvent(new Event('input'));$('note-title').focus();});
  $('reset').addEventListener('click',clearStored);
  $('compare').addEventListener('click',openComparison);
  $('keep-mine').addEventListener('click',()=>chooseVersion(true));
  $('use-other').addEventListener('click',()=>chooseVersion(false));
  $('conflict-dialog').addEventListener('close',()=>{$('conflict-dialog').returnValue='';comparedSignature=null;});
  window.addEventListener('storage',event=>{if(event.storageArea===localStorage&&(event.key===KEY||event.key===null))syncExternal();});
  window.addEventListener('focus',()=>{if(storageState==='ready')syncExternal();});
  window.addEventListener('beforeunload',event=>{if(isDirty()||conflict){event.preventDefault();event.returnValue='';}});
  readStored(true);restoreRecovery();renderLocale();
})();
'''
p.write_text(prefix+extra)
# Chinese font support belongs to the browser test environment supplied by the run owner.
p=Path('app/styles.css');s=p.read_text();s='\n'.join(line for line in s.split('\n') if not line.startswith('@font-face'));p.write_text(s)
