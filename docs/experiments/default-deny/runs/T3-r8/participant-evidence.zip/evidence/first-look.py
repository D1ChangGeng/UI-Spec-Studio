import os
os.environ['FONTCONFIG_FILE']='/tmp/ui-spec-fonts/fonts.conf'
from playwright.sync_api import sync_playwright
from pathlib import Path
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
 c=b.new_context(viewport={'width':1440,'height':900})
 a=c.new_page();a.goto('http://127.0.0.1:4313/');a.screenshot(path='evidence/first-empty-desktop.png')
 a.locator('#note-title').fill('城市供热研究');a.locator('#note-body').fill('我的草稿：先核查高峰时段的实际用量。\n保留这条尚未验证的线索。')
 other=c.new_page();other.goto('http://127.0.0.1:4313/');other.locator('#note-title').fill('城市供热研究 · 更新');other.locator('#note-body').fill('另一标签页：已经找到逐小时的供热记录。\n下一步比较不同气温条件。');other.locator('#save').click();other.wait_for_timeout(300)
 a.locator('#compare').click();a.screenshot(path='evidence/first-conflict-desktop.png')
 a.set_viewport_size({'width':390,'height':844});a.screenshot(path='evidence/first-conflict-mobile.png')
 a.locator('#compare-later').click();a.locator('#theme-toggle').click();a.locator('#locale-toggle').click();a.locator('#compare').click();a.screenshot(path='evidence/first-conflict-mobile-en-dark.png')
 study=c.new_page();study.set_viewport_size({'width':900,'height':400});study.goto(Path('evidence/brand-options.html').resolve().as_uri());study.screenshot(path='evidence/brand-options.png')
 b.close()
