import os,json,time,traceback
from pathlib import Path
os.environ['FONTCONFIG_FILE']='/tmp/ui-spec-fonts/fonts.conf'
from playwright.sync_api import sync_playwright,expect
ROOT=Path('evidence');BASE='http://127.0.0.1:4313/';KEY='ui-spec-content-note-v1';results=[];errors=[]
def record(name,**detail):results.append({'check':name,'result':'pass',**detail})
def stored(page):return page.evaluate('(k)=>JSON.parse(localStorage.getItem(k))',KEY)
def save(page):page.locator('#save').click();expect(page.locator('#save')).to_be_enabled(timeout=4000)
def settings(page):
 if not page.locator('details').first.get_attribute('open') is not None:page.locator('.fixture-controls summary').click()
def screenshot(page,name):page.screenshot(path=str(ROOT/(name+'.png')))
def fill(page,title,body):page.locator('#note-title').fill(title);page.locator('#note-body').fill(body)
def page_for(c):
 p=c.new_page();p.on('pageerror',lambda error:errors.append(str(error)));p.on('dialog',lambda d:d.accept());p.goto(BASE);return p
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/tmp/ui-spec-study-browsers/chrome-linux64/chrome',headless=True,args=['--no-sandbox'])
 try:
  for width,height in ([] if os.environ.get('ONLY_EDGES') else [(390,844),(1440,900)]):
   for locale in ['zh','en']:
    for theme in ['light','dark']:
     label=f'{width}-{locale}-{theme}';c=b.new_context(viewport={'width':width,'height':height},device_scale_factor=1);a=page_for(c)
     if locale=='en':a.locator('#locale-toggle').click()
     if theme=='dark':a.locator('#theme-toggle').click()
     a.evaluate('document.fonts.ready');screenshot(a,'empty-'+label)
     dimensions=a.locator('#note-title').evaluate('(e)=>({font:getComputedStyle(e).fontSize,placeholder:getComputedStyle(e,"::placeholder").fontSize,height:e.offsetHeight})')
     bodydim=a.locator('#note-body').evaluate('(e)=>({font:getComputedStyle(e).fontSize,placeholder:getComputedStyle(e,"::placeholder").fontSize,height:e.offsetHeight})')
     assert dimensions=={'font':'15px','placeholder':'14px','height':49},dimensions
     assert bodydim=={'font':'15px','placeholder':'14px','height':145},bodydim
     a.locator('#note-title').click();a.keyboard.press('Tab');assert a.locator('#note-body').evaluate('(e)=>document.activeElement===e && e.matches(":focus-visible")')
     screenshot(a,'focus-'+label)
     localtitle='城市供热研究' if locale=='zh' else 'Understanding peak heating demand'
     localbody='先核查逐小时用量。\n这份草稿保留待验证的判断。' if locale=='zh' else 'Check hourly demand first.\nKeep this assumption open until the source is verified.'
     fill(a,localtitle,localbody);save(a);assert stored(a)['body']==localbody;screenshot(a,'entered-'+label)
     remote=page_for(c);a.locator('#note-body').fill(localbody+'\nLocal draft / 我的修改')
     remotebody='另一版本 / Other version\nSource records are available for comparison.'
     fill(remote,localtitle+' · B',remotebody);save(remote);expect(a.locator('#conflict-banner')).to_be_visible()
     assert a.locator('#note-body').input_value().endswith('Local draft / 我的修改')
     a.locator('#compare').click();assert a.locator('#compare-later').evaluate('(e)=>document.activeElement===e')
     assert a.locator('#other-body').inner_text()==remotebody
     for _ in range(8):a.keyboard.press('Tab');assert a.evaluate('document.activeElement===document.body || document.querySelector("#conflict-dialog").contains(document.activeElement)')
     screenshot(a,'conflict-'+label)
     a.keyboard.press('Escape');expect(a.locator('#conflict-dialog')).not_to_be_visible();assert a.locator('#compare').evaluate('(e)=>document.activeElement===e')
     assert stored(a)['body']==remotebody
     a.locator('#compare').click();a.locator('#keep-mine').click();assert a.locator('#note-body').input_value().endswith('Local draft / 我的修改');assert stored(a)['body']==remotebody
     save(a);assert stored(a)['body'].endswith('Local draft / 我的修改')
     # A new actual cross-tab conflict, resolved with the other version.
     a.locator('#note-body').fill('Second local draft / 第二草稿');fill(remote,localtitle+' · C','Accepted other / 采用另一份');save(remote)
     expect(a.locator('#conflict-banner')).to_be_visible();a.locator('#compare').click();a.locator('#use-other').click()
     assert a.locator('#note-body').input_value()=='Accepted other / 采用另一份';assert stored(a)['body']=='Accepted other / 采用另一份';screenshot(a,'chosen-'+label)
     # Existing failure and retry through visible preview controls.
     settings(a);a.locator('#simulate-failure').check();fill(a,localtitle,'Recover me / 保留重试文本');save(a)
     expect(a.locator('#retry')).to_be_visible();assert stored(a)['body']=='Accepted other / 采用另一份';assert a.locator('#note-body').input_value()=='Recover me / 保留重试文本';screenshot(a,'failure-'+label)
     a.locator('#simulate-failure').uncheck();a.locator('#retry').click();expect(a.locator('#save')).to_be_enabled();assert stored(a)['body']=='Recover me / 保留重试文本';assert a.locator('#note-title').evaluate('(e)=>document.activeElement===e');screenshot(a,'retry-'+label)
     a.reload();assert a.locator('#note-body').input_value()=='Recover me / 保留重试文本'
     assert a.evaluate('document.documentElement.scrollWidth<=innerWidth')
     record('matrix-'+label,viewport=[width,height],locale=locale,theme=theme,dimensions=dimensions,body=bodydim,states=['empty','entered','keyboard-focus','conflict-keep-mine','conflict-use-other','Esc-postpone-focus-return','write-failure','retry','reload'])
     c.close();print('PASS',label,flush=True)
  # Timing, repeated external updates, reload recovery, full-length text, deletion.
  c=b.new_context(viewport={'width':390,'height':844});a=page_for(c);fill(a,'Base','Original');save(a);other=page_for(c)
  a.locator('#note-body').fill('Local preserved');fill(other,'Remote 1','Incoming one');save(other);a.locator('#compare').click()
  fill(other,'Remote 2','Incoming two');save(other);a.locator('#use-other').click()
  assert a.locator('#conflict-dialog').is_visible();assert a.locator('#other-body').inner_text()=='Incoming two';assert a.locator('#note-body').input_value()=='Local preserved'
  assert a.locator('#conflict-history').is_visible();a.locator('#compare-later').click();a.reload();assert a.locator('#note-body').input_value()=='Local preserved';expect(a.locator('#conflict-banner')).to_be_visible();a.locator('#compare').click();assert a.locator('#other-body').inner_text()=='Incoming two';a.locator('#keep-mine').click();save(a)
  record('new-update-requires-review-and-session-reload-restores-both')
  settings(a);a.locator('#simulate-slow').check();a.locator('#note-body').fill('Pending snapshot');a.locator('#save').click();expect(a.locator('#save')).to_be_disabled();a.locator('#note-body').fill('Edited during pending');a.wait_for_timeout(1150);assert stored(a)['body']=='Pending snapshot';assert a.locator('#note-body').input_value()=='Edited during pending';assert '上一版' in a.locator('#state-message').inner_text();record('edit-during-delayed-write-keeps-new-draft')
  other.reload();a.locator('#save').click();fill(other,'External interrupts','External wins until choice');save(other);a.wait_for_timeout(1100);assert stored(a)['body']=='External wins until choice';assert a.locator('#note-body').input_value()=='Edited during pending';expect(a.locator('#conflict-banner')).to_be_visible();record('external-change-cancels-pending-save')
  a.locator('#compare').click();a.locator('#use-other').click();a.locator('#simulate-slow').uncheck()
  a.locator('#note-body').fill('Long local text.\n'+('数据证据与假设仍需区分。'*230)[:2950]);fill(other,'Long incoming','Other evidence.\n'+('来源记录需要保留上下文。'*230)[:2950]);save(other)
  a.locator('#compare').click();screenshot(a,'long-conflict-mobile');assert a.locator('#mine-text').evaluate('(e)=>e.scrollHeight>e.clientHeight');a.locator('#mine-text').focus();a.keyboard.press('End');assert a.locator('#mine-text').evaluate('(e)=>e.scrollTop>0');a.locator('#compare-later').click();record('long-comparison-scroll-and-reachable-actions')
  settings(other);other.locator('#reset').click();a.locator('#compare').click();a.locator('#use-other').click();assert a.locator('#note-title').input_value()=='';assert a.locator('#note-body').input_value()=='';record('external-delete-compared-and-chosen')
  # Native Storage boundary failures, restored without replacing the draft.
  fill(a,'Native write','Retain fault draft');a.evaluate("window.originalSet=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(k==='ui-spec-content-note-v1')throw new DOMException('Injected','QuotaExceededError');return window.originalSet.call(this,k,v)}")
  save(a);expect(a.locator('#retry')).to_be_visible();a.evaluate('Storage.prototype.setItem=window.originalSet');a.locator('#retry').click();expect(a.locator('#save')).to_be_enabled();assert stored(a)['body']=='Retain fault draft';record('native-storage-write-failure-retry')
  a.evaluate("window.originalRemove=Storage.prototype.removeItem;Storage.prototype.removeItem=function(k){if(k==='ui-spec-content-note-v1')throw new Error('Injected removal failure');return window.originalRemove.call(this,k)}")
  a.locator('#reset').click();expect(a.locator('#retry')).to_be_visible();assert a.locator('#note-body').input_value()=='Retain fault draft';a.evaluate('Storage.prototype.removeItem=window.originalRemove');a.locator('#retry').click();assert stored(a) is None;record('native-removal-failure-retry')
  # Required field + pending reset preserved.
  a.locator('#save').click();expect(a.locator('#title-error')).to_be_visible();assert a.locator('#note-title').get_attribute('aria-invalid')=='true'
  fill(a,'Pending cancelled','Will be cleared');a.locator('#simulate-slow').check();a.locator('#save').click();a.locator('#reset').click();a.wait_for_timeout(1100);assert stored(a) is None;record('required-title-and-pending-reset')
  c.close()
  # Initial read failure with a real pre-existing record.
  c=b.new_context(viewport={'width':1440,'height':900});seed=page_for(c);fill(seed,'Existing saved','Stored content');save(seed)
  c.add_init_script("window.readFault=true;const originalGet=Storage.prototype.getItem;Storage.prototype.getItem=function(k){if(window.readFault&&k==='ui-spec-content-note-v1')throw new Error('Injected read failure');return originalGet.call(this,k)}")
  a=page_for(c);expect(a.locator('#save')).to_be_disabled();fill(a,'New draft','Do not replace');a.evaluate('window.readFault=false');a.locator('#retry').click();expect(a.locator('#conflict-banner')).to_be_visible();assert a.locator('#note-body').input_value()=='Do not replace';record('read-retry-compares-instead-of-overwriting-draft');c.close()
  # Two pending submits are serialized, leaving one version to be explicitly resolved.
  c=b.new_context();a=page_for(c);fill(a,'Shared base','Original');save(a);other=page_for(c)
  fill(a,'Concurrent A','A');fill(other,'Concurrent B','B');a.locator('#save').click();other.locator('#save').click();a.wait_for_timeout(400)
  assert stored(a)['body'] in ['A','B'];loser=other if stored(a)['body']=='A' else a;expect(loser.locator('#conflict-banner')).to_be_visible();assert loser.locator('#note-body').input_value()!=stored(a)['body'];record('simultaneous-save-coordinates-tabs');c.close()
  assert not errors,errors
  record('console-no-page-errors',browser=b.version)
 except Exception as exc:
  results.append({'check':'run-interrupted','result':'fail','error':str(exc),'trace':traceback.format_exc()});print(traceback.format_exc(),flush=True)
 finally:
  (ROOT/'verification.json').write_text(json.dumps({'browser':b.version,'fontconfig':'/tmp/ui-spec-fonts/fonts.conf','results':results,'errors':errors},ensure_ascii=False,indent=2));b.close()
  print('RESULTS',len(results),flush=True)
