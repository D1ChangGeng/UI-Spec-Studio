# Fieldnote

A browser-local notebook with one continuous two-sided card. Open `http://127.0.0.1:8423/` while the supplied server is running, or from this workspace run:

```bash
python3 -m http.server 8423 --bind 127.0.0.1 --directory app
```

The app uses native `localStorage` under `ui-spec-temporal-note-v1`; there is no server account or synchronization. The inherited 900 ms save delay is an illustrative timing fixture, but the write, read, clear and retry boundaries are real browser Storage. The 600-character limit is inherited; over-limit text remains editable and visible with an explanation. A failed write retains the draft and previous stored value. A newer draft written during a pending save is not falsely marked saved.

## Design and source notes

This increment owns the note card, its faces, flip/reversal, readable writing composition and return to editing. It retains the original scene/object/faces mechanism, native controls and existing storage state machine. Warm paper, fine stacked edges, consistent face padding and a fixed center pivot give both faces the same physical identity. The 14-second decorative orbit is secondary to writing; pause and reduced-motion handling remain available. Theme switching is immediate to avoid transient low contrast.

David DeSandro's [Card Flip](https://3dtransforms.desandro.com/card-flip) was read and its public center-flip and slide-flip demos operated and captured in `../evidence/reference-*`. The comparison supports retaining the center pivot for a card that stays in place; the alternative slide-flip shifts the visible mass sideways. No new library or source-code package was imported. The reference is technique/context evidence, not a claim that its entire visual design was adopted. Its example code is MIT and its writing CC BY per the source. Current paper treatment and typography are project-owned adaptations of the supplied app. Fonts use the environment's installed families; no external font or image network dependency was added.

The existing saved-note view inherits the same material and type. On return, the textarea receives focus and its selection and internal scroll are restored; error recovery retains the retry focus. Input, locale and theme changes do not mutate persisted note text.

## Verification

`../verify_app.py` exercises the actual visible controls at 1440 × 900 and 390 × 844, light/dark and English/Chinese. It covers flipping, seven rapid reversals, stable scene/editor anchors, long-note scrolling, over-limit preservation, delayed save with newer edits, saved-view navigation, real native quota exhaustion, old-record retention, retry after freeing storage, selection/scroll return, reduced motion and persistence after reload. It never replaces Storage methods: the failure comes from filling the isolated browser origin to its native quota.

Run with the preinstalled environment:

```bash
PLAYWRIGHT_BROWSERS_PATH=/workspace/scratch/654b1ee6916f/ui-spec-browsers FONTCONFIG_FILE=/workspace/scratch/654b1ee6916f/ui-spec-fonts/fonts.conf /workspace/scratch/654b1ee6916f/ui-spec-preview-env/bin/python verify_app.py
```

`../evidence/checks.json` contains executed assertions, source hashes and screenshot capture brackets. PNGs and browser recordings preserve the actual runs. The image samples support layout, type, state and sampled progression; recordings require actual playback before claims about continuous perceived pacing. Chromium emulation does not establish Safari/Firefox behavior, physical touch/keyboard behavior or field frame delivery. No deployment was performed.
