# Fieldnote — continuation of the same note-card increment

## Working entry

The continuation runs at `http://127.0.0.1:8493/`:

```bash
python3 -m http.server 8493 --bind 127.0.0.1 --directory app
```

This is a separately archived correction of the existing Fieldnote increment. The original comparative endpoint remains frozen. Current implementation and new evidence live only in this continuation workspace.

## Corrected relationship

The earlier handler exposed the requested face immediately even while the CSS transform still visibly faced the other way. The reproduced 45 ms sample had m33 `0.999881`, `back aria-hidden=false`, `back inert=false`; Shift+Tab entered the invisible `preview-note`.

`app.js` now separates target intent from rendered exposure. `syncCardOrientation()` reads the current computed transform using `DOMMatrixReadOnly`; the sign of m33 selects the forward-facing surface. Within `abs(m33) < 0.025`, both faces are temporarily inert and hidden from accessibility because their nearly edge-on content is not a useful reading/focus destination. Before a focused face leaves exposure, focus moves to the stationary flip control.

An animation-frame loop runs only while the transform transition is active. Transition start/end/cancel, reduced-motion changes and view return resynchronize against the actual matrix. Tab key handling refreshes exposure before the browser selects a destination, and a focus-in guard covers programmatic focus between animation frames. Rapid reversals therefore follow the rendered rotation instead of assuming a duration or trusting `data-face`. The flip button label remains the next requested action; its pressed state follows the currently visible back.

The existing CSS material, layout, motion duration and surfaces are unchanged. Native localStorage read/write/clear/retry, the retained draft, 600-character save bound and inherited 900 ms demonstration delay remain in place. This is local browser persistence, with no account or synchronization service.

## Current verification

Run the focused continuation checks with the provided dependencies:

```bash
FONTCONFIG_FILE=/workspace/scratch/654b1ee6916f/ui-spec-fonts/fonts.conf /workspace/scratch/654b1ee6916f/ui-spec-preview-env/bin/python verify_continuation.py
FONTCONFIG_FILE=/workspace/scratch/654b1ee6916f/ui-spec-fonts/fonts.conf /workspace/scratch/654b1ee6916f/ui-spec-preview-env/bin/python check_ax_midpoint.py
```

The current run passed 166 assertions across 1440×900 / 390×844, both themes and English/Chinese. It recorded 2,575 natural-time post-animation-frame samples with no recorded orientation/aria-hidden/inert/focus mismatch. Every condition included samples inside the nearly edge-on threshold. Covered episodes include early Shift+Tab, keyboard access to the actually visible turning back, focus return as the back leaves view, seven rapid reversals, 580-character note scrolling, selection and scroll restoration on return, navigation during a turn, and reduced motion enabled during a turn.

Two representative conditions additionally saved a 580-character note through native Storage, filled the isolated origin to cause a real native quota failure, verified retained draft and previous record, freed storage and retried successfully.

`continuation-evidence/accessibility-tree.json` records actual Chromium accessibility-tree inspection: the preview node is excluded while m33 is `0.999338`, and included while the back is visibly turning toward the reader at m33 `-0.833086`. `continuation-evidence/verification.json` retains all samples, action marks, assertions and runtime source hashes. `before-focus.json` retains the reproduced failure. Screenshots show the actual intermediate states and long-text variants. The updated message recorder freezes media referenced by outward messages as well as the contemporaneous source.

These are Chromium emulation and sampled browser observations, not screen-reader speech tests, other-engine coverage, physical phone/keyboard checks or measurements of presented frames. The samples are not a continuous-video playback claim. README documentation was updated after the executed run; runtime source hashes in the report identify the tested implementation.

## Inherited visual/source context

The paper treatment, typography and center-pivot scene/object/faces structure are retained from the existing app. The original refinement compared David DeSandro's public [Card Flip](https://3dtransforms.desandro.com/card-flip) center and slide variants; its published example code is MIT and writing CC BY. No new package, font, image or third-party visual resource was introduced in this targeted correction. The prior visual decision and its original evidence remain historical rather than being counted as fresh continuation research or a changed comparison score.
