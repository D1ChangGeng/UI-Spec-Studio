from playwright.sync_api import sync_playwright
from pathlib import Path
import json
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900});page.goto('http://127.0.0.1:8493');cdp=page.context.new_cdp_session(page)
 root=cdp.send('DOM.getDocument')['root']['nodeId'];node=cdp.send('DOM.querySelector',{'nodeId':root,'selector':'#preview-note'})['nodeId']
 backend=cdp.send('DOM.describeNode',{'nodeId':node})['node']['backendNodeId']
 def snapshot(label):
  start=page.evaluate('performance.now()');tree=cdp.send('Accessibility.getPartialAXTree',{'nodeId':node,'fetchRelatives':False})['nodes'];actual=next(n for n in tree if n.get('backendDOMNodeId')==backend);end=page.evaluate("({t:performance.now(),m33:new DOMMatrixReadOnly(getComputedStyle(document.querySelector('#note-card')).transform).m33})")
  return {'label':label,'start':start,'end':end,'axIgnored':actual['ignored'],'reasons':actual.get('ignoredReasons',[])}
 page.click('#flip');page.wait_for_timeout(45);front=snapshot('front-facing early turn');assert front['end']['m33']>0 and front['axIgnored']
 page.wait_for_timeout(320);back=snapshot('back-facing while turning');assert back['end']['m33']<0 and not back['axIgnored']
 Path('continuation-evidence/accessibility-tree.json').write_text(json.dumps([front,back],indent=2));print(json.dumps([front,back]))
 b.close()
