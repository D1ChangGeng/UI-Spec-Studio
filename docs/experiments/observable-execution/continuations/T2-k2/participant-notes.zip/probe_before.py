from playwright.sync_api import sync_playwright
from pathlib import Path
import json
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900})
 page.goto('http://127.0.0.1:8493')
 page.click('#flip');page.wait_for_timeout(45)
 before=page.evaluate("({time:performance.now(),m33:new DOMMatrixReadOnly(getComputedStyle(document.querySelector('#note-card')).transform).m33,backHidden:document.querySelector('#card-back').getAttribute('aria-hidden'),backInert:document.querySelector('#card-back').inert})")
 page.keyboard.press('Shift+Tab')
 after=page.evaluate("({time:performance.now(),focus:document.activeElement.id,m33:new DOMMatrixReadOnly(getComputedStyle(document.querySelector('#note-card')).transform).m33})")
 page.screenshot(path='continuation-evidence/before-midflip.png',animations='allow')
 Path('continuation-evidence/before-focus.json').write_text(json.dumps({'beforeTab':before,'afterTab':after},indent=2));print(before,after)
 b.close()
