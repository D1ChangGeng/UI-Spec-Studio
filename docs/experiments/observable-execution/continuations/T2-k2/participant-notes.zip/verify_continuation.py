from pathlib import Path
from playwright.sync_api import sync_playwright
import json,hashlib
OUT=Path('continuation-evidence');checks=[];runs=[]
SNAP='''() => { const c=document.querySelector('#note-card'),f=document.querySelector('#card-front'),b=document.querySelector('#card-back');return {t:performance.now(),m33:new DOMMatrixReadOnly(getComputedStyle(c).transform).m33,frontHidden:f.getAttribute('aria-hidden'),backHidden:b.getAttribute('aria-hidden'),frontInert:f.inert,backInert:b.inert,active:document.activeElement.id,inFront:f.contains(document.activeElement),inBack:b.contains(document.activeElement),editorHidden:document.querySelector('#editor').hidden};}'''
def check(name,v):
 if not v:raise AssertionError(name)
 checks.append(name)
def valid(s):
 if s['editorHidden']:return True
 want=None if abs(s['m33'])<.025 else ('front' if s['m33']>0 else 'back')
 return (s['frontHidden']==str(want!='front').lower() and s['backHidden']==str(want!='back').lower() and s['frontInert']==(want!='front') and s['backInert']==(want!='back') and not(s['inFront'] and want!='front') and not(s['inBack'] and want!='back'))
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 for width,height in [(1440,900),(390,844)]:
  for theme in ['light','dark']:
   for locale in ['en','zh']:
    name=f'{width}-{theme}-{locale}';page=browser.new_page(viewport={'width':width,'height':height});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto('http://127.0.0.1:8493')
    if theme=='dark':page.click('#theme-toggle')
    if locale=='zh':page.click('#locale-toggle')
    page.evaluate('window.snap='+SNAP)
    page.evaluate('''() => {window.samples=[];window.sampling=true; const loop=()=>requestAnimationFrame(()=>setTimeout(()=>{if(window.sampling){window.samples.push(window.snap());loop()}},0));loop();}''')
    marks=[]
    def mark(label):
     s=page.evaluate(SNAP);s['label']=label;marks.append(s);return s
    page.click('#flip');page.wait_for_timeout(45);early=mark('forward-45ms-before-key')
    check(name+' early actual front',early['m33']>0)
    check(name+' early front exposure',valid(early))
    page.keyboard.press('Shift+Tab');s=mark('forward-45ms-after-shift-tab')
    check(name+' invisible back excluded from Shift+Tab',s['active']!='preview-note' and valid(s))
    page.screenshot(path=str(OUT/(name+'-early.png')),animations='allow')
    page.wait_for_timeout(280);page.locator('#flip').focus();page.keyboard.press('Shift+Tab');s=mark('visible-back-shift-tab')
    check(name+' visible back keyboard access',s['m33']<-.025 and s['active']=='preview-note' and valid(s))
    if name in ['1440-light-en','390-dark-zh']:page.screenshot(path=str(OUT/(name+'-turning-back.png')),animations='allow')
    page.wait_for_timeout(500)
    # Enter the still-visible back during its reversal, then let it leave view.
    page.click('#flip');page.wait_for_timeout(45);page.keyboard.press('Shift+Tab');s=mark('reverse-45ms-back-focus')
    check(name+' reversal visible back retains access',s['m33']<0 and s['active']=='preview-note' and valid(s))
    page.wait_for_timeout(800);s=mark('reverse-settled-focus-return')
    check(name+' leaving face focus moves to stable trigger',s['m33']>.99 and s['active']=='flip' and valid(s))
    for i,delay in enumerate([40,90,200,75,110,45,240]):
     page.click('#flip');page.wait_for_timeout(delay);page.locator('#flip').focus();page.keyboard.press('Shift+Tab');s=mark('rapid-'+str(i));check(name+f' rapid {i} actual orientation/focus',valid(s))
    page.wait_for_timeout(800)
    note=('长文仍然保留证据与问题。\n' if locale=='zh' else 'A long note retains evidence and questions.\n')*60;note=note[:580]
    page.fill('#note-text',note)
    if page.evaluate(SNAP)['m33']>0:page.click('#flip');page.wait_for_timeout(800)
    page.locator('#preview-note').focus();page.keyboard.press('End');page.locator('#preview-note').evaluate('(e)=>e.scrollTop=e.scrollHeight')
    check(name+' long note scroll',page.locator('#preview-note').evaluate('(e)=>e.scrollTop>0 && e.scrollHeight>e.clientHeight'))
    page.screenshot(path=str(OUT/(name+'-long-back.png')),animations='allow')
    page.locator('#note-text').focus();page.locator('#note-text').evaluate('(e)=>{e.setSelectionRange(30,50);e.scrollTop=45}')
    selection=page.locator('#note-text').evaluate('(e)=>[e.selectionStart,e.selectionEnd,e.scrollTop]')
    page.click('#saved-link');page.click('#return')
    check(name+' return draft/focus/selection',page.input_value('#note-text')==note and page.evaluate('document.activeElement.id')=='note-text' and page.locator('#note-text').evaluate('(e)=>[e.selectionStart,e.selectionEnd,e.scrollTop]')==selection)
    # Change the preference while CSS is still turning, then exercise its quiet equivalent.
    page.click('#flip');page.wait_for_timeout(45);page.emulate_media(reduced_motion='reduce');page.wait_for_timeout(30);s=mark('preference-changed-mid-turn')
    check(name+' reduced motion mid-turn sync',valid(s) and abs(s['m33'])>.99)
    page.click('#flip');page.locator('#flip').focus();page.keyboard.press('Shift+Tab');s=mark('reduced-motion-keyboard')
    check(name+' reduced motion immediate semantics',valid(s) and abs(s['m33'])>.99 and page.locator('#note-card').evaluate('(e)=>getComputedStyle(e).transitionDuration')=='0s')
    page.emulate_media(reduced_motion='no-preference');page.click('#flip');page.wait_for_timeout(100);page.click('#saved-link');page.wait_for_timeout(100);page.click('#return');page.wait_for_timeout(80)
    check(name+' return after hidden transition sync',valid(mark('navigation-interrupt')) and page.input_value('#note-text')==note)
    if name in ['1440-light-en','390-dark-zh']:
     page.click('#save');page.wait_for_timeout(950)
     check(name+' long 580-char native save',json.loads(page.evaluate("localStorage.getItem('ui-spec-temporal-note-v1')"))['text']==note)
     page.evaluate('''() => {let lo=0,hi=6*1024*1024;while(hi-lo>1){let m=(lo+hi)>>1;try{localStorage.setItem('__quota__','x'.repeat(m));lo=m}catch(e){hi=m}}}''')
     newer=note+' more';page.fill('#note-text',newer);page.click('#save');page.wait_for_timeout(950)
     check(name+' real failure retains draft and saved record',page.locator('#status-area').get_attribute('data-status')=='failed' and page.input_value('#note-text')==newer and json.loads(page.evaluate("localStorage.getItem('ui-spec-temporal-note-v1')"))['text']==note)
     page.evaluate("localStorage.removeItem('__quota__')");page.click('#retry');page.wait_for_timeout(950)
     check(name+' native retry',page.locator('#status-area').get_attribute('data-status')=='saved')
    page.evaluate('window.sampling=false');samples=page.evaluate('window.samples');bad=[s for s in samples if not valid(s)]
    runs.append({'condition':name,'marks':marks,'samples':samples,'mismatches':bad})
    check(name+' all post-frame orientation/exposure/focus samples',not bad)
    check(name+' no runtime errors',not errors);page.close()
 browser.close()
report={'checks':checks,'passed':len(checks),'runs':runs,'sampleCount':sum(len(r['samples']) for r in runs),'sourceHashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('app').glob('*') if p.is_file()},'limits':['Natural-time post-animation-frame samples; not hardware presented-frame measurements.','Chromium emulation only; no screen-reader speech or other browser engine test.']}
(OUT/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'passed':len(checks),'samples':report['sampleCount'],'mismatches':sum(len(r['mismatches']) for r in runs)}))
