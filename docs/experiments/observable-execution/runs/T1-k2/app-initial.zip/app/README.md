# Index local workspace

Run npm run dev -- --host 127.0.0.1 --port <assigned port>. The shared dependency symlink is read-only infrastructure; do not change that target. The lockfile identifies the actual toolchain. Work in this application source.
