import React from 'react';
import {collections} from './collections.js';
export default function App(){return <main><h1>Index</h1><p>Research collections</p>{collections.map(item=><article key={item.id}><h2>{item.title}</h2><p>{item.summary}</p></article>)}</main>;}
