export const collections = [
  {
    "id": "quiet",
    "category": "Design research",
    "title": "The quiet interface",
    "summary": "Interfaces that leave room for thought.",
    "count": "8 references",
    "updated": "October 28, 2026",
    "body": [
      "Interfaces that leave room for thought.",
      "This collection brings together observations, references and unresolved questions from our ongoing research. It is intended for close reading and return visits rather than a linear presentation.",
      "Look for the relationships between attention, scale and context. A useful detail becomes more valuable when it survives changes in content, screen size and the way a person moves through the work.",
      "The working notes remain provisional. Revisit the evidence, compare different contexts and keep the next useful question close to the material."
    ]
  },
  {
    "id": "city",
    "category": "Urban systems",
    "title": "A city after the last train",
    "summary": "Field observations on movement, light and shared space.",
    "count": "12 references",
    "updated": "October 27, 2026",
    "body": [
      "Field observations on movement, light and shared space.",
      "This collection brings together observations, references and unresolved questions from our ongoing research. It is intended for close reading and return visits rather than a linear presentation.",
      "Look for the relationships between attention, scale and context. A useful detail becomes more valuable when it survives changes in content, screen size and the way a person moves through the work.",
      "The working notes remain provisional. Revisit the evidence, compare different contexts and keep the next useful question close to the material."
    ]
  },
  {
    "id": "type",
    "category": "Typography",
    "title": "Type as a way of thinking",
    "summary": "How a change of measure, rhythm and contrast changes understanding.",
    "count": "6 references",
    "updated": "October 26, 2026",
    "body": [
      "How a change of measure, rhythm and contrast changes understanding.",
      "This collection brings together observations, references and unresolved questions from our ongoing research. It is intended for close reading and return visits rather than a linear presentation.",
      "Look for the relationships between attention, scale and context. A useful detail becomes more valuable when it survives changes in content, screen size and the way a person moves through the work.",
      "The working notes remain provisional. Revisit the evidence, compare different contexts and keep the next useful question close to the material."
    ]
  },
  {
    "id": "material",
    "category": "Visual craft",
    "title": "Between paper and light",
    "summary": "Surfaces, shadows and the feeling of objects on a screen.",
    "count": "9 references",
    "updated": "October 25, 2026",
    "body": [
      "Surfaces, shadows and the feeling of objects on a screen.",
      "This collection brings together observations, references and unresolved questions from our ongoing research. It is intended for close reading and return visits rather than a linear presentation.",
      "Look for the relationships between attention, scale and context. A useful detail becomes more valuable when it survives changes in content, screen size and the way a person moves through the work.",
      "The working notes remain provisional. Revisit the evidence, compare different contexts and keep the next useful question close to the material."
    ]
  },
  {
    "id": "time",
    "category": "Interaction",
    "title": "Keeping your place when everything around you is changing",
    "summary": "A collection of notes about continuity, repeated action and the moments between states.",
    "count": "14 references",
    "updated": "October 24, 2026",
    "body": [
      "A collection of notes about continuity, repeated action and the moments between states.",
      "This collection brings together observations, references and unresolved questions from our ongoing research. It is intended for close reading and return visits rather than a linear presentation.",
      "Look for the relationships between attention, scale and context. A useful detail becomes more valuable when it survives changes in content, screen size and the way a person moves through the work.",
      "The working notes remain provisional. Revisit the evidence, compare different contexts and keep the next useful question close to the material."
    ]
  },
  {
    "id": "future",
    "category": "Working notes",
    "title": "Ideas still taking shape",
    "summary": "Open questions and small experiments for the next project.",
    "count": "4 references",
    "updated": "October 23, 2026",
    "body": [
      "Open questions and small experiments for the next project.",
      "This collection brings together observations, references and unresolved questions from our ongoing research. It is intended for close reading and return visits rather than a linear presentation.",
      "Look for the relationships between attention, scale and context. A useful detail becomes more valuable when it survives changes in content, screen size and the way a person moves through the work.",
      "The working notes remain provisional. Revisit the evidence, compare different contexts and keep the next useful question close to the material."
    ]
  }
];
