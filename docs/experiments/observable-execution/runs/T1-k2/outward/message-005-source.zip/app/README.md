# Index

A local editorial workspace for the six supplied research collections.

## Run

Dependencies are already supplied. From this directory:

```sh
npm run dev -- --host 127.0.0.1 --port 8413
npm run build
```

Entry: http://127.0.0.1:8413/

## Behavior

- Search titles, categories, summaries and notes. Combine search with Saved, and sort by update order or title.
- Save and unsave collections on this browser using `index.saved.v1` in localStorage.
- Read a collection using a deep link such as `#collection/quiet`; return to the retained query, filter, order, list scroll and originating link focus.
- Reading offsets are remembered during the current app visit. Search/filter/order are represented in the URL; only saves are persisted across visits.
- Storage failures keep selections usable in memory, display an honest warning, and expose a retry. They do not claim durable persistence.
- Representative supplied notes and reference counts are retained. Individual linked source documents, cloud accounts and synchronization are outside this local app.

## Material source

`src/vendor/magic-card.tsx` is adapted from Magic UI, commit `efe76fc5755eca1142dd4f74c1d6f0ace2887e3c`; its MIT notice is in the same directory. The original source is preserved in `../resources/`. Index retains the radial surface/edge layers and reset/cleanup mechanism, configures subdued warm illumination, and adds reduced-motion/touch behavior plus a static keyboard focus treatment. The contrasting ShineBorder appears only in the development study at `/?study`.

`../DESIGN.md` keeps source decisions, observed scope and limitations. `../evidence/check_app.py` exercises actual visible controls and records screenshots/results in `../evidence/` using the supplied test environment. These are Chromium checks, not a claim of complete cross-browser or screen-reader testing.
