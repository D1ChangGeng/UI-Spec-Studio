import React, {useCallback, useEffect, useLayoutEffect, useRef, useState} from 'react';
import {ArrowLeft, ArrowUpRight, Bookmark, Search, X, ArrowDown, Library, RotateCcw} from 'lucide-react';
import {collections} from './collections.js';
import {MagicCard} from './vendor/magic-card';

const KEY='index.saved.v1';
const validIds=new Set(collections.map(c=>c.id));
function readSaved(){
  try { const raw=localStorage.getItem(KEY); const list=raw?JSON.parse(raw):[];
    if(!Array.isArray(list))throw new Error('invalid');
    return {ids:new Set(list.filter(id=>validIds.has(id))),error:false};
  }catch{return {ids:new Set(),error:'read'};}
}
function route(){try{const id=decodeURIComponent(location.hash.replace('#collection/',''));return validIds.has(id)?id:null;}catch{return null;}}
function SaveButton({item,saved,onToggle,large=false}){
 return <button type="button" className={`save-button ${large?'save-large':''} ${saved?'is-saved':''}`} aria-label={`${saved?'Unsave':'Save'} ${item.title}`} aria-pressed={saved} onClick={()=>onToggle(item.id)} title={saved?'Remove from saved':'Save collection'}><Bookmark size={17} fill={saved?'currentColor':'none'} strokeWidth={1.6}/>{large&&<span>{saved?'Saved':'Save collection'}</span>}</button>;
}
export default function App(){
 const initial=useRef(null); if(!initial.current)initial.current=readSaved();
 const [saved,setSaved]=useState(initial.current.ids);
 const [storageError,setStorageError]=useState(initial.current.error);
 const [status,setStatus]=useState('');
 const params=new URLSearchParams(location.search);
 const [query,setQuery]=useState(params.get('q')||'');
 const [savedOnly,setSavedOnly]=useState(params.get('saved')==='1');
 const [sort,setSort]=useState(params.get('sort')==='title'?'title':'recent');
 const [activeId,setActiveId]=useState(route);
 const activeRef=useRef(activeId),positions=useRef({list:0}),originId=useRef(null),navigated=useRef(false);
 const current=collections.find(c=>c.id===activeId);
 const searchRef=useRef(null),filterRef=useRef(null);
 const normalized=query.trim().toLowerCase();
 const shown=collections.filter(c=>(!savedOnly||saved.has(c.id))&&(!normalized||[c.title,c.summary,c.category,...c.body].join(' ').toLowerCase().includes(normalized))).sort((a,b)=>sort==='title'?a.title.localeCompare(b.title):0);
 const navigate=useCallback((id,push=true)=>{
   positions.current[activeRef.current||'list']=window.scrollY;
   if(id)originId.current=id;
   activeRef.current=id;navigated.current=true;setActiveId(id);
   if(push)history.pushState({index:true},'',`${location.pathname}${location.search}${id?`#collection/${id}`:''}`);
 },[]);
 useEffect(()=>{
  const pop=()=>navigate(route(),false);window.addEventListener('popstate',pop);
  const sync=e=>{if(e.key===KEY){const r=readSaved();if(!r.error){setSaved(r.ids);setStorageError(false);}}};window.addEventListener('storage',sync);
  return()=>{window.removeEventListener('popstate',pop);window.removeEventListener('storage',sync);};
 },[navigate]);
 useEffect(()=>{
  const p=new URLSearchParams();if(query)p.set('q',query);if(savedOnly)p.set('saved','1');if(sort==='title')p.set('sort','title');
  const qs=p.toString();history.replaceState(history.state,'',`${location.pathname}${qs?`?${qs}`:''}${location.hash}`);
 },[query,savedOnly,sort]);
 useLayoutEffect(()=>{
  if(!navigated.current&&!activeId)return;
  const frame=requestAnimationFrame(()=>{
   window.scrollTo({top:positions.current[activeId||'list']||0,behavior:'instant'});
   const el=activeId?document.getElementById('reader-title'):document.getElementById(`open-${originId.current}`)||document.getElementById('collection-title');
   el?.focus({preventScroll:true});
  });return()=>cancelAnimationFrame(frame);
 },[activeId]);
 useEffect(()=>{document.title=current?`${current.title} — Index`:'Index — Research collections';},[current]);
 function persist(next){
  try{localStorage.setItem(KEY,JSON.stringify([...next]));setStorageError(false);return true;}
  catch{setStorageError('write');return false;}
 }
 function toggle(id){
  const next=new Set(saved),was=next.has(id);was?next.delete(id):next.add(id);setSaved(next);
  const ok=persist(next);const title=collections.find(c=>c.id===id).title;
  setStatus(`${title} ${was?'removed from saved':ok?'saved on this device':'kept for this visit'}.`);
  if(savedOnly&&was&&!current)requestAnimationFrame(()=>filterRef.current?.focus());
 }
 function open(event,id){if(event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;event.preventDefault();navigate(id);}
 function changeFilter(next){setSavedOnly(next);if(current)navigate(null);}
 function clear(){setQuery('');setSavedOnly(false);searchRef.current?.focus();}
 return <>
  <a href="#main-content" className="skip-link">Skip to content</a>
  <header className="site-header"><div className="header-inner">
   <a className="wordmark" href={`${location.pathname}${location.search}`} onClick={e=>open(e,null)} aria-label="Index, back to collections">Index<span className="brand-dot">.</span></a>
   <span className="header-label">A personal research library</span>
   <div className="local-label"><span/> Local to this browser</div>
  </div></header>
  <main id="main-content" className="workspace">
  {storageError&&<div className="storage-warning" role="status"><div><strong>{storageError==='read'?'Saved collections could not be loaded.':'Kept for this visit.'}</strong> {storageError==='read'?'You can still browse and collect here. Try saving again to store your current selection.':'Browser storage is unavailable. Your current saves still work here, but may be lost after a refresh.'}</div><button type="button" onClick={()=>{if(persist(saved))setStatus('Your saved collections are now stored on this device.');}}><RotateCcw size={14}/> Try saving again</button></div>}
  {!current?<>
   <section className="collection-intro" aria-labelledby="collection-title"><div><p className="eyebrow">THE WORKING ARCHIVE <span> / </span> VOLUME 01</p><h1 id="collection-title" tabIndex={-1}>Collected thinking<span className="accent">.</span></h1><p className="intro-copy">Observations, references and ideas worth returning to.</p></div><div className="archive-stamp"><span>0{collections.length}</span><p>COLLECTIONS<br/>AND COUNTING</p></div></section>
   <section className="collection-tools" aria-label="Find collections">
    <div className="filters"><button type="button" className={!savedOnly?'active':''} onClick={()=>changeFilter(false)} aria-pressed={!savedOnly}>All collections <span>{collections.length}</span></button><button type="button" ref={filterRef} className={savedOnly?'active':''} onClick={()=>changeFilter(true)} aria-pressed={savedOnly}><Bookmark size={14}/> Saved <span>{saved.size}</span></button></div>
    <div className="search-field"><Search size={17}/><label className="sr-only" htmlFor="collection-search">Search collections</label><input id="collection-search" ref={searchRef} type="search" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search titles, topics, ideas…" autoComplete="off"/>{query&&<button type="button" aria-label="Clear search" onClick={()=>{setQuery('');searchRef.current?.focus();}}><X size={15}/></button>}</div>
   </section>
   <div className="results-row"><p aria-live="polite">{normalized?`${shown.length} ${shown.length===1?'collection':'collections'} for “${query.trim()}”`:savedOnly?`${shown.length} saved ${shown.length===1?'collection':'collections'}`:`${shown.length} collections to explore`}</p><label className="sort-control"><span className="sr-only">Sort collections</span><select value={sort} onChange={e=>setSort(e.target.value)}><option value="recent">Recently updated</option><option value="title">Title A–Z</option></select><ArrowDown size={12}/></label></div>
   {shown.length?<div className="collection-grid">{shown.map(item=><article key={item.id} className="collection-card" data-collection={item.id}><MagicCard className="card-material" gradientSize={320} gradientColor="#857050" gradientOpacity={.14} gradientFrom="#c7a477" gradientTo="#615440"><a id={`open-${item.id}`} className="card-link" href={`#collection/${item.id}`} onClick={e=>open(e,item.id)}><div className="card-top"><span className="card-category">{item.category}</span><span className="card-number">0{collections.indexOf(item)+1}</span></div><div className="card-editorial"><h2>{item.title}</h2><p>{item.summary}</p></div><div className="card-footer"><span>{item.count}<span className="metadata-dot">·</span>{item.updated.replace(/^(\w+) (\d+), (\d+)$/, (_,month,day)=>`${month.slice(0,3)} ${day}`)}</span><ArrowUpRight size={20} strokeWidth={1.4}/></div></a><SaveButton item={item} saved={saved.has(item.id)} onToggle={toggle}/></MagicCard></article>)}</div>:<section className="empty-state"><Library size={34} strokeWidth={1}/><p className="eyebrow">ROOM FOR DISCOVERY</p><h2>{normalized?'Nothing found, yet.':'Your reading shelf starts here.'}</h2><p>{normalized?'Try a different title, topic or phrase.': 'Save a collection to keep it close for your next visit.'}</p><button type="button" onClick={clear}>{normalized?'Reset search and filters':'Explore all collections'} <ArrowUpRight size={16}/></button></section>}
   <footer className="archive-footer"><span><span className="tiny-mark">✳</span> Keep a question open.</span><span>INDEX — A WORK IN PROGRESS</span></footer>
  </>:<>
   <nav className="reader-navigation" aria-label="Collection navigation"><a href={`${location.pathname}${location.search}`} onClick={e=>open(e,null)}><ArrowLeft size={17}/> Back to collections</a><span>COLLECTION 0{collections.indexOf(current)+1} / 0{collections.length}</span></nav>
   <article className="reader"><div className="reader-heading"><p className="eyebrow">{current.category} <span> / </span> WORKING NOTES</p><h1 id="reader-title" tabIndex={-1}>{current.title}</h1><p className="reader-deck">{current.summary}</p><div className="reader-meta"><p>{current.count}<span>·</span>Updated {current.updated}</p><SaveButton item={current} saved={saved.has(current.id)} onToggle={toggle} large/></div></div>
   <div className="reader-content"><aside><p className="eyebrow">IN THIS COLLECTION</p><a href="#reading-notes" onClick={e=>{e.preventDefault();document.getElementById('reading-notes')?.scrollIntoView({behavior:'instant'});}}>01 <span>Research notes</span></a><p className="reader-context">A place to follow a thread,<br/>and pick it up again.</p></aside><div className="reading-text"><p className="reading-label" id="reading-notes">01 — RESEARCH NOTES</p>{current.body.slice(1).map((paragraph,index)=><p key={index}>{paragraph}</p>)}<div className="editorial-note"><p>About this edition</p><span>This local collection contains representative research notes. Reference counts describe the supplied collection; individual source documents are not included.</span></div><p className="end-mark" aria-hidden="true">✳</p><a className="reader-bottom-return" href={`${location.pathname}${location.search}`} onClick={e=>open(e,null)}><ArrowLeft size={16}/> Return to your collection</a></div></div></article>
  </>}
  </main>
  <div className="sr-only" role="status" aria-live="polite">{status}</div>
 </>;
}
