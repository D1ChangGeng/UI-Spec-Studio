import React from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.jsx';
import SourceStudy from './SourceStudy.jsx';
import './styles.css';
createRoot(document.getElementById('root')).render(import.meta.env.DEV && new URLSearchParams(location.search).has('study') ? <SourceStudy/> : <App/>);
