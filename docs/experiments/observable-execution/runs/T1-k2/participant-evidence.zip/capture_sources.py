import asyncio, os, json
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
  page=await browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1,ignore_https_errors=True)
  await page.goto('http://127.0.0.1:8413/?study',wait_until='networkidle')
  await page.screenshot(path=str(ROOT/'source-trial-rest.png'))
  await page.mouse.move(245,340)
  await page.wait_for_timeout(350)
  await page.screenshot(path=str(ROOT/'source-trial-hover.png'))
  await page.mouse.move(540,450)
  await page.wait_for_timeout(350)
  await page.screenshot(path=str(ROOT/'source-trial-move.png'))
  results={}
  for name,url in [('magic-card','https://magicui.design/docs/components/magic-card'),('shine-border','https://magicui.design/docs/components/shine-border'),('arena','https://www.are.na/')]:
   try:
    await page.goto(url,wait_until='domcontentloaded',timeout=12000)
    await page.wait_for_timeout(1200)
    if name!='arena':
     heading=page.get_by_role('heading',name='Magic Card' if name=='magic-card' else 'Shine Border',exact=True)
     if await heading.count(): await heading.scroll_into_view_if_needed()
    await page.screenshot(path=str(ROOT/f'official-{name}.png'))
    results[name]={'title':await page.title(),'url':page.url}
   except Exception as ex: results[name]={'error':str(ex)[:200]}
  (ROOT/'source-observations.json').write_text(json.dumps(results,indent=2))
  print(results)
  await browser.close()
asyncio.run(main())
