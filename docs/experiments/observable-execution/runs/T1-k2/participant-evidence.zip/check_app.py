import asyncio, json, time
from pathlib import Path
from playwright.async_api import async_playwright, expect
ROOT=Path(__file__).resolve().parent
URL='http://127.0.0.1:8413/'
async def main():
 results={};errors=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
  ctx=await browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
  page=await ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto(URL,wait_until='networkidle')
  await expect(page.locator('.collection-card')).to_have_count(6)
  await page.screenshot(path=str(ROOT/'desktop.png'))
  card=page.locator('[data-collection="quiet"]');box=await card.bounding_box();episode=[]
  for name,x,y in [('enter',box['x']+50,box['y']+80),('move',box['x']+270,box['y']+180),('leave',10,10)]:
   await page.mouse.move(x,y,steps=8);await page.wait_for_timeout(230)
   episode.append({'state':name,'captured_at':await page.evaluate('performance.now()')})
   await page.screenshot(path=str(ROOT/f'light-{name}.png'))
  results['pointer_samples']=episode
  await page.get_by_role('searchbox').fill('quiet')
  await expect(page.locator('.collection-card')).to_have_count(1)
  await page.get_by_role('button',name='Save The quiet interface',exact=True).click()
  await expect(page.get_by_role('button',name='Unsave The quiet interface',exact=True)).to_have_attribute('aria-pressed','true')
  await page.get_by_role('button',name='Saved 1',exact=True).click()
  await page.locator('#open-quiet').click()
  await expect(page.locator('#reader-title')).to_have_text('The quiet interface')
  await page.screenshot(path=str(ROOT/'detail-desktop.png'))
  await page.get_by_role('link',name='Back to collections',exact=True).click()
  await expect(page.get_by_role('searchbox')).to_have_value('quiet')
  await expect(page.get_by_role('button',name='Saved 1',exact=True)).to_have_attribute('aria-pressed','true')
  assert await page.evaluate('document.activeElement.id')=='open-quiet'
  await page.reload(wait_until='networkidle')
  await expect(page.get_by_role('button',name='Unsave The quiet interface',exact=True)).to_be_visible()
  results['search_save_filter_detail_return_refresh']='passed'
  await page.get_by_role('button',name='Unsave The quiet interface',exact=True).click()
  await expect(page.locator('.collection-card')).to_have_count(0)
  await page.get_by_role('button',name='Reset search and filters').click()
  await page.get_by_role('searchbox').fill('zzzz-no-match')
  await page.screenshot(path=str(ROOT/'empty-search.png'))
  await page.get_by_role('button',name='Reset search and filters').click()
  await page.locator('#open-time').focus();await page.keyboard.press('Enter')
  await expect(page.locator('#reader-title')).to_contain_text('Keeping your place')
  await page.go_back();await expect(page.locator('.collection-card')).to_have_count(6)
  results['unsave_empty_keyboard_browser_back']='passed'
  await page.set_viewport_size({'width':390,'height':844})
  await page.goto(URL,wait_until='networkidle');await page.screenshot(path=str(ROOT/'mobile.png'))
  assert await page.evaluate('document.documentElement.scrollWidth<=window.innerWidth')
  await page.locator('#open-time').scroll_into_view_if_needed()
  origin=await page.evaluate('window.scrollY')
  await page.screenshot(path=str(ROOT/'mobile-long-card.png'))
  await page.locator('#open-time').click();await page.wait_for_timeout(100)
  await page.screenshot(path=str(ROOT/'detail-mobile-long.png'))
  await page.evaluate('window.scrollTo(0,500)');await page.wait_for_timeout(50)
  detail_y=await page.evaluate('window.scrollY')
  await page.get_by_role('link',name='Return to your collection',exact=True).click();await page.wait_for_timeout(100)
  restored=await page.evaluate('window.scrollY');assert abs(restored-origin)<3,(origin,restored)
  await page.locator('#open-time').click();await page.wait_for_timeout(100)
  resumed=await page.evaluate('window.scrollY')
  # The return link may scroll into view before the click; compare to remembered outgoing scroll.
  assert resumed>0
  assert await page.evaluate('document.documentElement.scrollWidth<=window.innerWidth')
  results['mobile_scroll']={'list_before':origin,'list_restored':restored,'reader_resumed':resumed}
  await page.goto(URL,wait_until='networkidle');await page.emulate_media(reduced_motion='reduce')
  await page.locator('#open-quiet').focus();await page.screenshot(path=str(ROOT/'mobile-keyboard-reduced.png'))
  material=page.locator('[data-collection="quiet"] .card-material')
  before=await material.evaluate('(e)=>getComputedStyle(e).backgroundImage')
  await page.mouse.move(170,520);after=await material.evaluate('(e)=>getComputedStyle(e).backgroundImage')
  assert before==after
  results['reduced_motion_static_material']='passed'
  await ctx.close()
  failctx=await browser.new_context(viewport={'width':390,'height':844})
  await failctx.add_init_script("Storage.prototype.setItem=function(){throw new DOMException('Storage blocked','QuotaExceededError')}")
  failpage=await failctx.new_page();await failpage.goto(URL,wait_until='networkidle')
  await failpage.get_by_role('button',name='Save The quiet interface',exact=True).click()
  await expect(failpage.locator('.storage-warning')).to_be_visible()
  await expect(failpage.get_by_role('button',name='Unsave The quiet interface',exact=True)).to_have_attribute('aria-pressed','true')
  await failpage.get_by_role('button',name='Saved 1',exact=True).click()
  await expect(failpage.locator('.collection-card')).to_have_count(1)
  await failpage.screenshot(path=str(ROOT/'storage-failure-mobile.png'))
  results['injected_storage_write_failure']='passed: current save remains usable, persistent warning visible'
  await failctx.close();await browser.close()
 results['page_errors']=errors;assert not errors
 (ROOT/'verification.json').write_text(json.dumps(results,indent=2))
 print(json.dumps(results,indent=2))
asyncio.run(main())
