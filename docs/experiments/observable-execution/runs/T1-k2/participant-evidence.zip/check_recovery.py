import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright,expect
ROOT=Path(__file__).resolve().parent
async def main():
 results={}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
  c=await b.new_context(viewport={'width':390,'height':844})
  await c.add_init_script("window.realSetItem=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('injected')}")
  page=await c.new_page();await page.goto('http://127.0.0.1:8413/',wait_until='networkidle')
  await page.get_by_role('button',name='Save The quiet interface',exact=True).click()
  await page.evaluate('() => { Storage.prototype.setItem=window.realSetItem; }')
  await page.get_by_role('button',name='Try saving again',exact=True).click()
  await expect(page.locator('.storage-warning')).to_have_count(0)
  assert json.loads(await page.evaluate("localStorage.getItem('index.saved.v1')"))==['quiet']
  results['retry_after_write_failure']='passed: memory selection written and warning cleared'
  await page.get_by_role('button',name='Saved 1',exact=True).click()
  await page.locator('#open-quiet').click()
  await page.get_by_role('button',name='Unsave The quiet interface',exact=True).click()
  await page.get_by_role('link',name='Back to collections',exact=True).click()
  await expect(page.get_by_role('button',name='Saved 0',exact=True)).to_have_attribute('aria-pressed','true')
  assert await page.evaluate('document.activeElement.id')=='collection-title'
  results['unsave_detail_return_to_empty_saved']='passed: saved filter retained, focus restored to heading'
  await page.evaluate("localStorage.setItem('index.saved.v1','{bad')")
  await page.goto('http://127.0.0.1:8413/#collection/%E0%A4%A',wait_until='networkidle')
  await expect(page.locator('.storage-warning')).to_contain_text('could not be loaded')
  await expect(page.locator('.collection-card')).to_have_count(6)
  results['corrupt_storage_malformed_hash']='passed: collection remains usable, honest load error'
  await c.close();await b.close()
 (ROOT/'recovery-verification.json').write_text(json.dumps(results,indent=2));print(results)
asyncio.run(main())
