/* Adapted from Magic UI MagicCard, MIT, efe76fc5755eca1142dd4f74c1d6f0ace2887e3c.
 * Copyright (c) Magic UI. Full notice: app/LICENSE-MagicUI.md.
 * Retains motion-value radial surface/edge layers; adds input parity and reduced motion. */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { motion, useMotionTemplate, useMotionValue, useReducedMotion } from 'motion/react';
export default function MagicCard({ children }) {
  const reduced=useReducedMotion(), root=useRef(null);
  const [active,setActive]=useState(false);
  const x=useMotionValue(-300), y=useMotionValue(-300);
  const background=useMotionTemplate`radial-gradient(300px circle at ${x}px ${y}px, #b99b73, #5b4c3b 36%, #353634 100%)`;
  const surface=useMotionTemplate`radial-gradient(300px circle at ${x}px ${y}px, rgba(193,145,86,.13), transparent 100%)`;
  const reset=useCallback(()=>setActive(false),[]);
  const center=()=>{const r=root.current?.getBoundingClientRect();if(r){x.set(r.width/2);y.set(r.height/3);}};
  useEffect(()=>{const out=e=>{if(!e.relatedTarget)reset();};const hidden=()=>{if(document.hidden)reset();};window.addEventListener('pointerout',out);window.addEventListener('blur',reset);document.addEventListener('visibilitychange',hidden);return()=>{window.removeEventListener('pointerout',out);window.removeEventListener('blur',reset);document.removeEventListener('visibilitychange',hidden);};},[reset]);
  return <article ref={root} className="magic-card" data-active={active} onPointerEnter={e=>{if(e.pointerType!=='touch'){if(reduced)center();setActive(true);}}} onPointerMove={e=>{if(reduced||e.pointerType==='touch')return;const r=e.currentTarget.getBoundingClientRect();x.set(e.clientX-r.left);y.set(e.clientY-r.top);}} onPointerLeave={()=>{if(root.current?.contains(document.activeElement)){center();return;}reset();}} onFocusCapture={()=>{center();setActive(true);}} onBlurCapture={e=>{if(!e.currentTarget.contains(e.relatedTarget))reset();}}>
    <motion.div aria-hidden="true" className="card-light-edge" style={{background}}/><div aria-hidden="true" className="card-base"/><motion.div aria-hidden="true" className="card-light-surface" style={{background:surface}}/><div className="card-content">{children}</div>
  </article>;
}
