# Index

An editorial research collection workspace. React + Vite; supplied dependencies are already installed.

## Run

```sh
npm run dev -- --host 127.0.0.1 --port 8411
```

Open http://127.0.0.1:8411/. Build with `npm run build`.

## Behavior

- Search titles, categories, summaries and collection notes. `/` focuses search.
- Combine search with the Saved filter. Bookmark controls toggle a collection independently from opening it.
- Saved IDs persist to `localStorage` under `index.saved.v1`.
- Search/filter/detail parameters live in the URL. Browser Back/Forward and visible return links work.
- The current tab remembers list scroll, opener focus and each collection's reading position. These scroll memories are not retained after a full reload.
- If storage is unavailable, current-tab changes remain usable, a persistent message states the limitation, and Retry saving writes the latest selection when storage recovers.

## Content and scope

The six provided records are sample collection notes. The listed reference counts are supplied metadata; the individual reference files are not included. No account, network data, cloud sync or editing backend is implemented.

## Design and source

`src/components/MagicCard.jsx` adapts the supplied MIT Magic UI MagicCard radial surface/edge layers. Its source revision is `efe76fc5755eca1142dd4f74c1d6f0ace2887e3c`; the required notice is in `LICENSE-MagicUI.md`. Focus, reduced motion, pointer leave and touch behavior are local adaptations. Native links/buttons own the working actions. Lucide supplies interface icons. The typography uses installed/system serif and sans families without remote font requests.

The local candidate harness is available in development at `/study.html`; it is not part of the production entry build. Source notes, screenshots, observed conditions and executable browser checks are in `../evidence/`.
