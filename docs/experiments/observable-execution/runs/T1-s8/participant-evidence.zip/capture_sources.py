from playwright.sync_api import sync_playwright
from pathlib import Path
import json,time
ROOT=Path(__file__).resolve().parent
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
 log=[]
 for name,url in [('official-magic','https://magicui.design/docs/components/magic-card'),('official-shine','https://magicui.design/docs/components/shine-border')]:
  try:
   page.goto(url,wait_until='domcontentloaded',timeout=15000)
   page.get_by_role('heading',name='Magic Card' if name.endswith('magic') else 'Shine Border',exact=True).scroll_into_view_if_needed(timeout=4000)
   page.wait_for_timeout(900)
   page.screenshot(path=str(ROOT/(name+'.png')))
   log.append({'source':url,'observed':'page captured','title':page.title()})
  except Exception as e:log.append({'source':url,'error':str(e)[:180]})
 (ROOT/'sources-run.json').write_text(json.dumps(log,indent=2))
 page.close()
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
 page.goto('http://127.0.0.1:8411/study.html',wait_until='networkidle')
 page.screenshot(path=str(ROOT/'trial-rest.png'))
 for name,x,y in [('gradient',235,300),('orb',640,300),('shine',1100,300)]:
  page.mouse.move(x,y,steps=12);page.wait_for_timeout(450);page.screenshot(path=str(ROOT/('trial-'+name+'.png')))
 page.mouse.move(30,30);page.wait_for_timeout(400);page.screenshot(path=str(ROOT/'trial-leave.png'))
 (ROOT/'sources-run.json').write_text(json.dumps(log,indent=2))
 b.close()
