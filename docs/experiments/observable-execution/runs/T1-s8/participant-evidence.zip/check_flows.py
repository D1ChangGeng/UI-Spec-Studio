from playwright.sync_api import sync_playwright,expect
from pathlib import Path
import json,time
ROOT=Path(__file__).resolve().parent
BASE='http://127.0.0.1:8411/'
checks=[]
def ok(name,detail=True):checks.append({'check':name,'passed':True,'detail':detail})
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 c=b.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
 page=c.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(BASE,wait_until='networkidle')
 expect(page.locator('.magic-card')).to_have_count(6);ok('Initial six collections')
 page.screenshot(path=str(ROOT/'desktop-final.png'))
 page.get_by_role('button',name='Save The quiet interface',exact=True).click()
 expect(page.get_by_role('button',name='Unsave The quiet interface',exact=True)).to_have_attribute('aria-pressed','true')
 assert page.evaluate("JSON.parse(localStorage.getItem('index.saved.v1')).includes('quiet')");ok('Save writes actual localStorage')
 page.reload(wait_until='networkidle');expect(page.get_by_role('button',name='Unsave The quiet interface',exact=True)).to_be_visible();ok('Saved state survives reload')
 page.get_by_role('button',name='Saved 1',exact=True).click();expect(page.locator('.magic-card')).to_have_count(1)
 page.get_by_role('searchbox',name='Search collections').fill('QUIET')
 expect(page.locator('.magic-card')).to_have_count(1);ok('Saved-only and case-insensitive search compose')
 page.get_by_role('link',name='The quiet interface',exact=True).click();expect(page.locator('.reader-article h1')).to_be_focused()
 expect(page.locator('.reader-article h1')).to_have_text('The quiet interface')
 page.get_by_role('link',name='Back to collections').click()
 expect(page.get_by_role('searchbox')).to_have_value('QUIET');expect(page.get_by_role('button',name='Saved 1',exact=True)).to_have_attribute('aria-pressed','true');expect(page.locator('#open-quiet')).to_be_focused();ok('Detail return restores query, saved filter and opener focus')
 page.get_by_role('button',name='Unsave The quiet interface',exact=True).click();expect(page.locator('.magic-card')).to_have_count(0);expect(page.get_by_role('button',name='Saved 0',exact=True)).to_be_focused();ok('Unsave filtered final item restores usable focus')
 page.get_by_role('button',name='Reset filters').click();expect(page.locator('.magic-card')).to_have_count(6)
 page.get_by_role('searchbox').fill('not-a-collection');expect(page.get_by_role('heading',name='No matching collections.')).to_be_visible();page.screenshot(path=str(ROOT/'desktop-empty.png'));ok('No-results recovery')
 page.get_by_role('button',name='Reset filters').click()
 page.locator('#open-quiet').focus();page.screenshot(path=str(ROOT/'desktop-keyboard.png'));page.keyboard.press('Enter');expect(page.locator('.reader-article h1')).to_be_focused();ok('Keyboard link opens reader and routes focus')
 page.go_back();expect(page.locator('#open-quiet')).to_be_focused();page.go_forward();expect(page.locator('.reader-article h1')).to_have_text('The quiet interface');ok('Browser back and forward navigate real views')
 page.goto(BASE+'?collection=type',wait_until='networkidle');page.get_by_role('link',name='Back to collections').click();expect(page.locator('.magic-card')).to_have_count(6);ok('Direct detail entry has a safe return')
 # Failure injection is restricted to storage, preserving the actual UI path.
 page.evaluate("() => {window.originalSetItem=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw new DOMException('Quota exceeded','QuotaExceededError')};}")
 page.get_by_role('button',name='Save The quiet interface',exact=True).click();expect(page.locator('.storage-warning')).to_be_visible();expect(page.get_by_role('button',name='Unsave The quiet interface',exact=True)).to_have_attribute('aria-pressed','true')
 page.get_by_role('button',name='Saved 1',exact=True).click();expect(page.locator('.magic-card')).to_have_count(1);page.screenshot(path=str(ROOT/'storage-failure.png'));ok('Write failure keeps usable saved state with honest warning')
 page.get_by_role('button',name='Retry saving').click();expect(page.locator('.storage-warning')).to_be_visible()
 page.evaluate('() => { Storage.prototype.setItem=window.originalSetItem; }');page.get_by_role('button',name='Retry saving').click();expect(page.locator('.storage-warning')).to_have_count(0);assert page.evaluate("JSON.parse(localStorage.getItem('index.saved.v1')).includes('quiet')");ok('Retry persists latest current-tab state after recovery')
 page.reload(wait_until='networkidle');expect(page.locator('.magic-card')).to_have_count(1);ok('Recovered save survives actual refresh')
 assert not errors;ok('No browser runtime errors',errors)
 # Fresh touch-sized context; preserve actual list and each reader position.
 mobile=b.new_context(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True)
 m=mobile.new_page();m.goto(BASE,wait_until='networkidle');m.screenshot(path=str(ROOT/'mobile-final.png'))
 assert not m.evaluate('document.documentElement.scrollWidth>innerWidth');ok('390px collection has no horizontal overflow')
 m.get_by_role('link',name='Keeping your place when everything around you is changing',exact=True).scroll_into_view_if_needed();m.wait_for_timeout(80)
 before=m.evaluate('scrollY');m.locator('#open-time').click();expect(m.locator('.reader-article h1')).to_be_focused()
 m.screenshot(path=str(ROOT/'mobile-detail-final.png'));m.evaluate('scrollTo(0,500)');m.wait_for_timeout(80);read_y=m.evaluate('scrollY');m.go_back();m.wait_for_timeout(100)
 after=m.evaluate('scrollY');assert abs(before-after)<3,(before,after);ok('Mobile list scroll is restored',{'before':before,'after':after})
 m.locator('#open-time').click();m.wait_for_timeout(100);resumed=m.evaluate('scrollY');assert abs(resumed-read_y)<3;ok('Reader position is remembered on reopening',{'reading':read_y,'resumed':resumed})
 # Return link was below the sampled reading position and scrolls to its own location before activation.
 m.go_back();m.wait_for_timeout(100);m.locator('#open-time').scroll_into_view_if_needed();m.screenshot(path=str(ROOT/'mobile-long-final.png'))
 reduced=b.new_context(viewport={'width':1440,'height':900},reduced_motion='reduce')
 r=reduced.new_page();r.goto(BASE,wait_until='networkidle');r.locator('#open-quiet').focus();r.screenshot(path=str(ROOT/'reduced-motion-focus.png'))
 surface=r.locator('.card-light-surface').first
 first=surface.evaluate('(el)=>getComputedStyle(el).backgroundImage');r.mouse.move(100,400);r.mouse.move(400,550,steps=6);r.wait_for_timeout(80);last=surface.evaluate('(el)=>getComputedStyle(el).backgroundImage')
 assert first==last;assert surface.evaluate('(el)=>getComputedStyle(el).transitionDuration')=='0s';ok('Reduced motion has static illumination and no light transition')
 r.keyboard.press('Enter');expect(r.locator('.reader-article h1')).to_be_focused();ok('Reduced-motion keyboard reading remains usable')
 # Accessibility resilience in narrow width and text spacing.
 m.goto(BASE,wait_until='networkidle');m.add_style_tag(content='* {letter-spacing: .12em !important;word-spacing: .16em !important;line-height:1.5 !important;} p{margin-bottom:2em !important;}')
 assert not m.evaluate('document.documentElement.scrollWidth>innerWidth');ok('390px increased text spacing reflows without horizontal overflow')
 (ROOT/'checks.json').write_text(json.dumps({'checks':checks,'errors':errors,'browser':b.version,'viewport_desktop':[1440,900],'viewport_mobile':[390,844],'device_note':'Chromium desktop and touch viewport emulation; no physical device or screen reader run'},indent=2))
 c.close();mobile.close();reduced.close();b.close()
print(json.dumps(checks,indent=2))
