# Index / active SPEC 01

## Current goal and boundary
A useful local collection workspace: find → save → read → resume. One connected increment owns collection cards, query/filter, persistent bookmarks, readable detail and focus/scroll continuity. Existing six collection records remain the content authority; their reference counts are metadata, not an implemented full reference library. No server, login or cloud sync.

## Experience and provisional direction
A research reader comes first to scan titles or search, then opens a collection and returns to the same selection and position. Editorial graphite, warm ivory, serif display + sans controls, warm brass accent. A restrained indexed grid should keep all six records discoverable, while detail uses a narrow sustained reading measure. Direction is delegated/provisional, not owner approved.

## Decisions and evidence-producing actions
- D1 / L0–L2: collection/detail with shared header. Preserve query, saved-only filter, opener focus, list scroll and each collection's reading position. Test a complete desktop/mobile return journey and browser history.
- D2 / L3–L4: soft illumination must follow pointer while text remains stable. Exact MIT Magic UI sources acquired in resources at commit efe76fc5755eca1142dd4f74c1d6f0ace2887e3c. Official pages read; the initial browser attempt failed, and a later public-page retry was captured and viewed. Local study at /study.html compares gradient, orb and ShineBorder with identical content. Local resting, hover/move/leave and timed edge states were captured and viewed before choosing the gradient variant.
- D3 / L3–L5: native links and buttons own semantics; decoration is aria-hidden. Reading is a document, not a blocking dialog. Keyboard focus needs an equally considered static warm edge; reduced-motion should remove pointer tracking, preserve focus and all actions.
- D4 / L1–L5: localStorage saves IDs after an explicit toggle. A failed write keeps current-tab changes, persistent warning and retry. Search/navigation state remains in memory and URL; storage is not allowed to make core reading fail. Next action: real refresh plus injected quota/security failures.

## Source comparison notes
Pending actual renders. Source-only observations: gradient uses radial surface and border layers driven by motion values; orb adds spring follow and blur; ShineBorder uses background-position over a timer and does not implement pointer ownership. The whole publication composition remains custom product work; these candidates only carry card light/material.

## Trial observation / decision
Viewed local source renders trial-rest, trial-gradient, trial-orb, trial-shine and trial-leave at 1440×900. Gradient creates a legible localized warm field and edge while type remains still. Orb's soft field at this low intensity contributes little extra value and its source leaves the edge coordinate active after pointer leave; ShineBorder lights unrelated edges on a timer. Choose gradient, preserve radial surface and edge layers/Motion values; add opacity exit, static focus positioning, reduced-motion pointer suppression and clean global reset. Whole composition and semantic controls are project-owned work. Official browser demos failed with ERR_CERT_AUTHORITY_INVALID; official page text was retrieved, visual evidence is explicitly a local rendering of licensed source.


## Current verified result
- Desktop 1440×900: six complete cards fit the initial viewport. Compact header/tool spacing and removing an artificial title max-width repaired the initially clipped second row. Serif titles remain dominant; quiet metadata and restrained brass accents connect cards and reader.
- Mobile 390×844: one-column collection, long title without truncation, naturally scrolling reader, and compact storage warning. Actual captures viewed: desktop-final, mobile-final, mobile-detail-final, mobile-long-final, mobile-storage-failure, keyboard-real-tab, reduced-motion-focus and empty-settled.
- Real UI checks in checks.json exercise actual localStorage writes and reload, composed query/saved filters, empty recovery, visible return, browser history, focus, mobile list restoration (1283 → 1283), reader restoration (500 → 500), injected storage failures and recovery, reduced motion, and expanded text spacing.
- Sampled optical episode light-01 through light-07 was actually viewed, including entry, settled light, movement, reversal and fade-out. Text stays fixed, the warm field follows the pointer, and the inactive surface returns. temporal-inspection.json stores actual capture-time brackets. This is sampled visual evidence, not a frame-rate benchmark or continuous video review.
- Actual keyboard Tab traversal reaches the first opening link through named controls and visibly illuminates a warm static focus outline. Reduced-motion preserves that treatment and disables gradient tracking/transition.
- Failure messaging was reconciled with footer and reader notes: when writes fail, the UI says current-tab storage rather than claiming browser persistence. Retry writes the latest in-memory set after storage recovers.

## Official source follow-up
The initial certificate errors remain in sources-run.json. Public documentation pages were subsequently rendered in a browser context tolerant of the host TLS interception; official-magic-retry.png and official-shine-retry.png were viewed. They show the source's default login-form composition and ShineBorder's multi-color edge. These are distinct from the exact supplied local revision and its dark editorial trials; no claim is made that the official default supplies this product's typography or full collection layout.

## Remaining scope / maintenance
Owner acceptance remains pending. Only Chromium desktop and touch viewport emulation were run; physical iOS/Android, Safari/Firefox, screen-reader output and sustained-device performance were not measured. Content is the supplied sample notes; referenced source files, authentication, cloud sync and authoring remain outside the local product boundary. Search/filter URLs and saved IDs survive reload; per-reader/list scroll memories last for the current tab session only. CSS uses system font fallbacks, so exact glyph metrics can differ on other operating systems. The local trial is a dev-only entry. Vite cache is isolated in this workspace, outside application source.
