from playwright.sync_api import sync_playwright,expect
from pathlib import Path
import hashlib,json,datetime
root=Path(__file__).resolve().parent.parent
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto('http://127.0.0.1:8411/',wait_until='networkidle');expect(page.locator('.magic-card')).to_have_count(6);assert not errors
 page.screenshot(path=str(root/'evidence/desktop-final.png'))
 page.screenshot(path=str(root/'evidence/desktop-header-detail.png'),clip={'x':0,'y':0,'width':1440,'height':335})
 print(page.evaluate("({scroll:scrollY,header:document.querySelector('.site-header').getBoundingClientRect().toJSON()})"))
 files=['app/src/App.jsx','app/src/styles.css','app/src/components/MagicCard.jsx','app/vite.config.js','app/index.html','app/src/collections.js']
 result={'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'entry':'http://127.0.0.1:8411/','source_sha256':{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files},'flow_checks':len(json.loads((root/'evidence/checks.json').read_text())['checks']),'final_smoke':{'cards':6,'page_errors':errors,'overflow':page.evaluate('document.documentElement.scrollWidth>innerWidth')},'build_log':'build.log','source_notes':'design-decisions.md','temporal_evidence':'temporal-inspection.json'}
 (root/'evidence/final-manifest.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));b.close()
