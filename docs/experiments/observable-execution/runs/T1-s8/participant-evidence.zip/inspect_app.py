from playwright.sync_api import sync_playwright
from pathlib import Path
import json,time
ROOT=Path(__file__).resolve().parent
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
 errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('http://127.0.0.1:8411/',wait_until='networkidle')
 page.screenshot(path=str(ROOT/'desktop-initial.png'))
 page.mouse.move(215,435);page.wait_for_timeout(320);page.screenshot(path=str(ROOT/'desktop-hover.png'))
 page.get_by_role('link',name='The quiet interface',exact=True).click()
 page.wait_for_timeout(100)
 page.screenshot(path=str(ROOT/'desktop-detail.png'))
 page.get_by_role('link',name='Back to collections').click()
 page.wait_for_timeout(150)
 page.set_viewport_size({'width':390,'height':844})
 page.screenshot(path=str(ROOT/'mobile-initial.png'))
 page.get_by_role('link',name='Keeping your place when everything around you is changing',exact=True).scroll_into_view_if_needed()
 page.screenshot(path=str(ROOT/'mobile-long-card.png'))
 page.get_by_role('link',name='Keeping your place when everything around you is changing',exact=True).click()
 page.wait_for_timeout(150)
 page.screenshot(path=str(ROOT/'mobile-long-detail.png'))
 (ROOT/'initial-inspection.json').write_text(json.dumps({'errors':errors,'overflow':page.evaluate('document.documentElement.scrollWidth > innerWidth'),'title':page.title()},indent=2))
 b.close()
