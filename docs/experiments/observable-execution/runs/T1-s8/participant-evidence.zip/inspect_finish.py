from playwright.sync_api import sync_playwright,expect
from pathlib import Path
import json,time
ROOT=Path(__file__).resolve().parent
BASE='http://127.0.0.1:8411/'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
 page.goto(BASE,wait_until='networkidle')
 tab_order=[]
 for i in range(20):
  page.keyboard.press('Tab')
  current=page.evaluate("({tag:document.activeElement.tagName,id:document.activeElement.id,name:document.activeElement.getAttribute('aria-label')||document.activeElement.innerText})")
  tab_order.append(current)
  if current['id']=='open-quiet':break
 assert current['id']=='open-quiet'
 assert page.evaluate("document.activeElement.matches(':focus-visible')")
 page.wait_for_timeout(320)
 page.screenshot(path=str(ROOT/'keyboard-real-tab.png'))
 page.keyboard.press('Enter');expect(page.locator('.reader-article h1')).to_be_focused();page.screenshot(path=str(ROOT/'desktop-detail-final.png'))
 page.get_by_role('link',name='Back to collections').click();page.wait_for_timeout(100)
 page.goto(BASE,wait_until='networkidle')
 box=page.locator('.magic-card').first.bounding_box()
 clip={'x':box['x']-3,'y':box['y']-3,'width':box['width']+6,'height':box['height']+6}
 frames=[]
 def capture(name):
  start=page.evaluate('performance.now()');page.screenshot(path=str(ROOT/('light-'+name+'.png')),clip=clip);end=page.evaluate('performance.now()')
  frames.append({'frame':'light-'+name+'.png','start_ms':start,'end_ms':end,'active':page.locator('.magic-card').first.get_attribute('data-active'),'surface':page.locator('.card-light-surface').first.evaluate('(e)=>({background:getComputedStyle(e).backgroundImage,opacity:getComputedStyle(e).opacity})')})
 capture('01-rest');page.mouse.move(box['x']+55,box['y']+50);page.wait_for_timeout(70);capture('02-enter');page.wait_for_timeout(240);capture('03-settled');page.mouse.move(box['x']+box['width']-60,box['y']+box['height']-55,steps=18);page.wait_for_timeout(80);capture('04-move');page.mouse.move(box['x']+60,box['y']+70,steps=10);page.wait_for_timeout(50);capture('05-reverse');page.mouse.move(20,20);page.wait_for_timeout(70);capture('06-leave');page.wait_for_timeout(260);capture('07-restored')
 assert frames[0]['surface']['opacity']=='0' and frames[-1]['surface']['opacity']=='0'
 assert frames[2]['surface']['background']!=frames[3]['surface']['background']
 (ROOT/'temporal-inspection.json').write_text(json.dumps({'tab_order':tab_order,'frames':frames,'note':'Natural input, ordered timestamp-bracketed screenshots; sampled states do not establish frame rate or continuous playback.'},indent=2))
 # Narrow storage-error recovery display and malformed storage read.
 small=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 small.goto(BASE,wait_until='networkidle')
 small.evaluate("() => {Storage.prototype.setItem=function(){throw new DOMException('blocked','SecurityError')};}")
 small.get_by_role('button',name='Save The quiet interface',exact=True).click();expect(small.locator('.storage-warning')).to_be_visible();small.screenshot(path=str(ROOT/'mobile-storage-failure.png'))
 assert not small.evaluate('document.documentElement.scrollWidth>innerWidth')
 expect(small.locator('.site-footer')).to_contain_text('Changes kept in this tab')
 # Official demonstration screenshots using a public-read context tolerant of this host's TLS interception.
 official=b.new_context(viewport={'width':1440,'height':900},ignore_https_errors=True)
 results=[]
 for name,url,title in [('magic','https://magicui.design/docs/components/magic-card','Magic Card'),('shine','https://magicui.design/docs/components/shine-border','Shine Border')]:
  doc=official.new_page()
  try:
   doc.goto(url,wait_until='domcontentloaded',timeout=15000)
   doc.get_by_role('heading',name=title,exact=True).scroll_into_view_if_needed(timeout=5000)
   doc.wait_for_timeout(700);doc.screenshot(path=str(ROOT/('official-'+name+'-retry.png')))
   results.append({'url':url,'result':'captured public demo','title':doc.title()})
  except Exception as e:results.append({'url':url,'result':str(e)[:200]})
  doc.close()
 (ROOT/'official-demo-retry.json').write_text(json.dumps(results,indent=2))
 b.close()
print(json.dumps({'tab_sequence':tab_order,'frames':len(frames),'official':results},indent=2))
