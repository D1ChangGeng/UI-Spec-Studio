from playwright.sync_api import sync_playwright
import json
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900});page.goto('http://127.0.0.1:8411/',wait_until='networkidle')
 print(json.dumps(page.evaluate("Object.fromEntries(['.site-header','.collection-heading','.collection-tools','.collection-meta','.collection-grid','.site-footer'].map(s=>{let r=document.querySelector(s).getBoundingClientRect();return[s,{y:r.y,height:r.height}]}))")))
 print(json.dumps(page.locator('.magic-card').evaluate_all('(els)=>els.map(e=>({height:e.getBoundingClientRect().height,title:e.querySelector(\'h2\').getBoundingClientRect().height}))')))
 b.close()
