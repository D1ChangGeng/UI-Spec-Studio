import {
  require_react
} from "./chunk-ZZ5AAECM.js";
import "./chunk-ZPWHCABL.js";
export default require_react();
