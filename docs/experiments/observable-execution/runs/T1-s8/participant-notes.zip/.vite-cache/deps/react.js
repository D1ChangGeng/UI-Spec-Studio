import {
  require_react
} from "./chunk-JEUVAASC.js";
import "./chunk-ZPWHCABL.js";
export default require_react();
