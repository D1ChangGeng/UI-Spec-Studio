import React, {useEffect, useLayoutEffect, useRef, useState} from 'react';
import {flushSync} from 'react-dom';
import {ArrowUpRight, ArrowLeft, ArrowRight, Bookmark, Check, Search, X, Asterisk, Download, RotateCcw, BookOpen, HardDrive} from 'lucide-react';
import {MagicCard} from './components/magic-card';
import {collections} from './collections';

const STORAGE_KEY = 'index.saved-collections.v1';
const validIds = new Set(collections.map(item => item.id));
const readLocation = () => {
  const params = new URLSearchParams(location.search);
  const id = location.hash.startsWith('#collection/') ? location.hash.slice(12) : null;
  return {query: params.get('q') || '', savedOnly: params.get('saved') === '1', id: validIds.has(id) ? id : null};
};
function readSaved() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return {ids: [], issue: ''};
    const ids = JSON.parse(raw);
    if (!Array.isArray(ids) || ids.some(id => typeof id !== 'string')) throw new Error('Invalid saved data');
    return {ids: [...new Set(ids.filter(id => validIds.has(id)))], issue: ''};
  } catch {
    return {ids: [], issue: 'Your saved collections could not be read. You can still keep a collection in this tab.'};
  }
}
function urlFor(query, savedOnly, id = null) {
  const params = new URLSearchParams();
  if (query) params.set('q', query);
  if (savedOnly) params.set('saved', '1');
  return location.pathname + (params.size ? '?' + params.toString() : '') + (id ? '#collection/' + id : '');
}
const shortDate = date => date.replace('October ', 'Oct ').replace(', 2026', '');

function CollectionCard({item, number, saved, onOpen, onSave, href}) {
  return <article className="collection-card" data-collection={item.id}>
    <MagicCard className="collection-surface" gradientSize={330} gradientFrom="#c5a078" gradientTo="#665343" gradientColor="#c6a171" gradientOpacity={0.10}>
      <div className="card-content">
        <div className="card-topline"><span className="category">{item.category}</span><span className="folio">{String(number).padStart(2, '0')}</span></div>
        <h2 className={item.title.length > 45 ? 'long-title' : ''}><a id={'open-' + item.id} className="open-link" href={href} onClick={event => onOpen(event, item)}>{item.title}</a></h2>
        <p className="card-summary">{item.summary}</p>
        <div className="card-bottom"><span>{item.count}<span className="meta-dot">·</span>{shortDate(item.updated)}</span><ArrowUpRight size={17} strokeWidth={1.4} aria-hidden="true"/></div>
        <button className={'save-card' + (saved ? ' is-saved' : '')} aria-label={(saved ? 'Unsave collection: ' : 'Save collection: ') + item.title} aria-pressed={saved} onClick={() => onSave(item.id)} title={saved ? 'Remove from saved' : 'Save collection'}><Bookmark size={17} strokeWidth={1.5} fill={saved ? 'currentColor' : 'none'}/></button>
      </div>
    </MagicCard>
  </article>;
}

export default function App() {
  const [initial] = useState(() => ({...readLocation(), ...readSaved()}));
  const [query, setQuery] = useState(initial.query);
  const [savedOnly, setSavedOnly] = useState(initial.savedOnly);
  const [selectedId, setSelectedId] = useState(initial.id);
  const [saved, setSaved] = useState(initial.ids);
  const [storageIssue, setStorageIssue] = useState(initial.issue);
  const [status, setStatus] = useState('');
  const savedRef = useRef(initial.ids);
  const selectedRef = useRef(initial.id);
  const listContext = useRef({scroll: 0, focus: null});
  const readingPositions = useRef({});
  const searchRef = useRef(null);
  const firstPaint = useRef(true);
  const selected = collections.find(item => item.id === selectedId);
  const normalized = query.trim().toLocaleLowerCase();
  const words = normalized.split(/\s+/).filter(Boolean);
  const filtered = collections.filter(item => (!savedOnly || saved.includes(item.id)) && words.every(word => [item.title, item.category, item.summary, ...item.body].join(' ').toLocaleLowerCase().includes(word)));
  const referenceCount = collections.reduce((sum, item) => sum + parseInt(item.count, 10), 0);

  function restoreView(id) {
    if (selectedRef.current !== id) return;
    if (id) {
      document.getElementById('reading-title')?.focus({preventScroll: true});
      window.scrollTo({top: readingPositions.current[id] || 0, behavior: 'instant'});
    } else {
      const trigger = document.getElementById('open-' + listContext.current.focus);
      (trigger || document.getElementById('results-heading'))?.focus({preventScroll: true});
      window.scrollTo({top: listContext.current.scroll, behavior: 'instant'});
    }
  }
  function transitionTo(id) {
    const update = () => flushSync(() => setSelectedId(id));
    if (document.startViewTransition && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
      const transition = document.startViewTransition(update);
      transition.finished.then(() => restoreView(id), () => restoreView(id));
    } else { update(); restoreView(id); }
  }
  useEffect(() => {
    history.scrollRestoration = 'manual';
    function syncLocation() {
      if (selectedRef.current) readingPositions.current[selectedRef.current] = window.scrollY;
      const next = readLocation();
      setQuery(next.query);
      setSavedOnly(next.savedOnly);
      transitionTo(next.id);
    }
    function shortcut(event) {
      if (event.key === '/' && !event.metaKey && !event.ctrlKey && !selectedRef.current && !['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName) && !document.activeElement?.isContentEditable) {
        event.preventDefault();
        searchRef.current?.focus();
      }
    }
    window.addEventListener('popstate', syncLocation);
    window.addEventListener('keydown', shortcut);
    return () => {window.removeEventListener('popstate', syncLocation); window.removeEventListener('keydown', shortcut);};
  }, []);
  useLayoutEffect(() => {
    selectedRef.current = selectedId;
    document.title = selected ? selected.title + ' — Index' : 'Index — Research collections';
    if (firstPaint.current) {firstPaint.current = false; if (!selectedId) return;}
    const frame = requestAnimationFrame(() => {
      if (selectedId) {
        document.getElementById('reading-title')?.focus({preventScroll: true});
        window.scrollTo({top: readingPositions.current[selectedId] || 0, behavior: 'instant'});
      } else {
        const trigger = document.getElementById('open-' + listContext.current.focus);
        (trigger || document.getElementById('results-heading'))?.focus({preventScroll: true});
        window.scrollTo({top: listContext.current.scroll, behavior: 'instant'});
      }
    });
    return () => cancelAnimationFrame(frame);
  }, [selectedId]);

  function updateFilters(nextQuery, nextSaved) {
    setQuery(nextQuery); setSavedOnly(nextSaved);
    history.replaceState(history.state, '', urlFor(nextQuery, nextSaved));
  }
  function openCollection(event, item) {
    if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0) return;
    event.preventDefault();
    listContext.current = {scroll: window.scrollY, focus: item.id};
    history.pushState({indexDetail: true}, '', urlFor(query, savedOnly, item.id));
    transitionTo(item.id);
  }
  function backToCollection(event) {
    event?.preventDefault();
    if (selectedId) readingPositions.current[selectedId] = window.scrollY;
    if (history.state?.indexDetail) history.back();
    else {history.replaceState(null, '', urlFor(query, savedOnly)); transitionTo(null);}
  }
  function persist(ids, success) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(ids));
      setStorageIssue(''); setStatus(success);
      return true;
    } catch {
      setStorageIssue('Your changes are kept in this tab. Browser storage could not be updated, so they may be lost when you leave.');
      setStatus('Updated for this session only. Browser storage is unavailable.');
      return false;
    }
  }
  function toggleSaved(id) {
    const exists = savedRef.current.includes(id);
    const next = exists ? savedRef.current.filter(savedId => savedId !== id) : [...savedRef.current, id];
    savedRef.current = next; setSaved(next);
    const title = collections.find(item => item.id === id).title;
    persist(next, exists ? 'Removed “' + title + '” from saved.' : 'Saved “' + title + '” in this browser.');
    if (exists && savedOnly && !selectedId) {
      requestAnimationFrame(() => {
        const nextCard = document.querySelector('.collection-card .open-link');
        (nextCard || document.getElementById('results-heading'))?.focus({preventScroll: true});
      });
    }
  }
  function downloadSaved() {
    const data = {format: 'Index saved collections', version: 1, collections: collections.filter(item => savedRef.current.includes(item.id))};
    const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'}));
    const link = document.createElement('a'); link.href = url; link.download = 'index-saved-collections.json'; link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    setStatus('Downloaded a copy of your saved collections.');
  }

  return <>
    <a className="skip-link" href="#main">Skip to content</a>
    <header className="site-header"><div className="header-inner">
      <a className="brand" href={urlFor(query, savedOnly)} onClick={selected ? backToCollection : undefined} aria-label="Index, collection home">Index<span className="brand-star"><Asterisk size={25} strokeWidth={1.1} aria-hidden="true"/></span></a>
      <span className="brand-caption">An independent space<br/>for curious minds.</span>
      <div className="workspace-label"><span className="status-dot"/>Local workspace<span className="workspace-line"/><span className="edition">№ 001</span></div>
    </div></header>
    <div className="live-status sr-only" role="status" aria-live="polite">{status}</div>
    {storageIssue && <aside className="storage-notice" aria-label="Storage notice"><div><strong>Keep a copy of your saves.</strong><p>{storageIssue}</p></div><div className="notice-actions"><button onClick={() => persist(savedRef.current, 'Your saved collections are now stored in this browser.')}><RotateCcw size={14}/>Retry storage</button><button onClick={downloadSaved}><Download size={14}/>Download copy</button></div></aside>}
    <main id="main" className={selected ? 'main reading-main' : 'main'}>
      {selected ? <>
        <div className="reading-navigation"><a href={urlFor(query, savedOnly)} onClick={backToCollection}><ArrowLeft size={16}/>Back to {savedOnly ? 'saved collections' : 'the collection'}</a><span className="reading-index">COLLECTION {String(collections.indexOf(selected) + 1).padStart(2, '0')} / 06</span></div>
        <article className="reading-layout">
          <aside className="reading-margin"><div className="overline">FIELD NOTES</div><span className="reading-folio">{String(collections.indexOf(selected) + 1).padStart(2, '0')}</span><div className="margin-rule"/><div className="margin-meta"><span>{selected.category}</span><span>Updated<br/>{selected.updated}</span><span>{selected.count}</span></div></aside>
          <div className="reading-content"><div className="reading-kicker"><span className="overline">{selected.category}</span><span className="reading-time">2 MIN READ</span></div><h1 id="reading-title" tabIndex={-1}>{selected.title}</h1><p className="reading-deck">{selected.summary}</p>
            <div className="reading-actions"><button className={'save-reading' + (saved.includes(selected.id) ? ' is-saved' : '')} onClick={() => toggleSaved(selected.id)} aria-pressed={saved.includes(selected.id)}>{saved.includes(selected.id) ? <Check size={16}/> : <Bookmark size={16}/>} {saved.includes(selected.id) ? 'Saved' : 'Save collection'}</button><span>Kept in this browser</span></div>
            <div className="reading-body"><h2>Notes on this collection</h2>{selected.body.slice(1).map((paragraph, i) => <p key={i}>{paragraph}</p>)}</div>
            <div className="reference-note"><BookOpen size={19} strokeWidth={1.3}/><div><strong>About the references</strong><p>This local sample includes the collection overview. The {selected.count.replace(' references','')} individual reference links are not included.</p></div></div>
            <a className="return-link" href={urlFor(query, savedOnly)} onClick={backToCollection}><ArrowLeft size={16}/>Return to your place in the collection</a>
          </div>
        </article>
      </> : <>
        <section className="collection-heading" aria-labelledby="page-title"><div><div className="overline">A PERSONAL RESEARCH LIBRARY</div><h1 id="page-title">The collection<span>.</span></h1><p>References, observations, and ideas worth returning to.</p></div><div className="collection-stats"><span className="stat-number">{String(collections.length).padStart(2,'0')}</span><span>collections<br/>{referenceCount} references</span></div></section>
        <section className="collection-tools" aria-label="Find collections"><div className="filters"><button aria-pressed={!savedOnly} onClick={() => updateFilters(query, false)}>All collections<span>{collections.length}</span></button><button aria-pressed={savedOnly} onClick={() => updateFilters(query, true)}><Bookmark size={15} strokeWidth={1.5}/>Saved<span>{saved.length}</span></button></div><div className="search-field"><Search size={17} strokeWidth={1.5} aria-hidden="true"/><label className="sr-only" htmlFor="collection-search">Search collections</label><input ref={searchRef} id="collection-search" type="search" value={query} onChange={event => updateFilters(event.target.value, savedOnly)} placeholder="Search a title, topic, or idea…" aria-keyshortcuts="/" autoComplete="off"/>{query ? <button onClick={() => {updateFilters('', savedOnly); searchRef.current?.focus();}} aria-label="Clear search"><X size={15}/></button> : <kbd aria-hidden="true">/</kbd>}</div></section>
        <div className="results-line"><h2 id="results-heading" tabIndex={-1} aria-live="polite">{query.trim() ? `${filtered.length} ${filtered.length === 1 ? 'collection' : 'collections'} found` : savedOnly ? `${filtered.length} saved ${filtered.length === 1 ? 'collection' : 'collections'}` : 'Explore the archive'}</h2><span>{query.trim() || savedOnly ? 'YOUR VIEW' : 'RECENTLY UPDATED'}<span className="small-line"/></span></div>
        {filtered.length ? <div className="collection-grid">{filtered.map(item => <CollectionCard key={item.id} item={item} number={collections.indexOf(item)+1} saved={saved.includes(item.id)} onOpen={openCollection} onSave={toggleSaved} href={urlFor(query, savedOnly, item.id)}/>)}</div> : <section className="empty-state"><div className="empty-mark">{savedOnly && !query.trim() ? <Bookmark size={30} strokeWidth={1}/> : <Search size={30} strokeWidth={1}/>}</div><h2>{savedOnly && !query.trim() ? 'A shelf of your own.' : 'No matching collections.'}</h2><p>{savedOnly && !query.trim() ? 'Save a collection to keep it close. Your reading shelf starts with one good find.' : `Nothing matches “${query.trim()}”${savedOnly ? ' in your saved collections' : ''}. Try a different word or explore the full archive.`}</p><button onClick={() => updateFilters('', false)}>{savedOnly && !query.trim() ? 'Explore the collection' : 'Reset filters'}<ArrowRight size={16}/></button></section>}
        <div className="collection-bottom"><p><span className="small-star">✳</span>A little room for unfinished thinking.</p><span>{filtered.length} / {collections.length} COLLECTIONS</span></div>
      </>}
    </main>
    <footer className="site-footer"><span>INDEX <span className="footer-slash">/</span> A considered collection.</span><span><HardDrive size={13} strokeWidth={1.5}/>Saves stay in this browser. No account or cloud sync.</span></footer>
  </>;
}
