# Index — local research workspace

## Run

From this directory:

```bash
npm run dev -- --host 127.0.0.1 --port 8412
npm run build
```

Working entry: http://127.0.0.1:8412/

Use the supplied dependencies. The shared node_modules symlink is infrastructure; do not reinstall or modify its target.

## Product boundary

Six supplied sample collections are searchable by title, topic, summary and notes. All words in a query must match; case and surrounding whitespace are ignored. Saved-only filtering composes with search. The query/filter live in the URL and detail links can be opened directly.

Saves use browser localStorage under `index.saved-collections.v1`. There is no account, server, or cloud sync. Failed storage writes retain the current in-memory state and show a visible notice, retry action and JSON download. Invalid or unavailable storage does not prevent reading. Export is a recovery copy; import is not implemented.

Opening and returning retain the list anchor, query, filter and focus. Reopening a detail in the current tab resumes its reading position. Session reading positions are not persisted across a page reload. Reference counts come from the supplied data; individual reference URLs were not supplied and the detail view says so.

## Implementation and sources

- `src/App.jsx`: collection/card/reading views, URL navigation, focus and scroll state, persistence and recovery.
- `src/styles.css`: editorial layout, dark surfaces, display/body hierarchy, responsive and reduced-motion treatments.
- `src/components/magic-card.tsx`: focused adaptation of the supplied MIT Magic UI Magic Card, commit `efe76fc5755eca1142dd4f74c1d6f0ace2887e3c`. Retains pointer-driven layered radial surface and edge gradients; adds keyboard focus and reduced-motion behavior. License: `MAGIC-UI-LICENSE.md`.
- `/trial.html`: local source comparison using project content; this is not the official source website or a product screen. Shine Border was compared but is not imported into the product.
- `../DESIGN.md`: current design decisions, source observations and evidence scope.
- `../evidence/verification.json`: scoped browser checks and limitations. Prior harness failures remain in run archives.

## Verification

The workspace Python/Playwright runtime can run `../verify_app.py` with this server running; execute it from the workspace parent directory. `../verify_recovery.py` covers the supplemental recovery scenarios. Both use the supplied Chromium executable and authorized loopback sockets.

Inspected viewports: 1440×900 and 390×844. Checks exercise text search, empty states, local persistence/reload, keyboard focus, browser Back, retained scrolling, direct detail links, reduced motion, unsupported View Transitions, and injected storage failures. Mobile checks are emulation. Safari, Firefox, physical-device behavior and sustained frame-rate performance were not tested. No deployment was performed.
