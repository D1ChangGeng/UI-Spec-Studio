import React from 'react';
import {createRoot} from 'react-dom/client';
import {MagicCard} from './components/magic-card';
import {ShineBorder} from './components/shine-border';
import {collections} from './collections';
import './trial.css';
function Contents({item}) {return <div className="trial-content"><span>{item.category}</span><h2>{item.title}</h2><p>{item.summary}</p><footer>{item.count} <button>Open collection ↗</button></footer></div>}
createRoot(document.getElementById('root')).render(<main><p>LOCAL SOURCE RENDERING · INDEX CONTENT · NOT THE OFFICIAL WEBSITE</p><h1>Light around the reading.</h1><div className="trial-grid">{[collections[0],collections[4]].map(item=><section key={item.id}><h3>Pointer-driven · Magic Card</h3><MagicCard className="trial-card" gradientSize={350} gradientFrom="#bd9e77" gradientTo="#615346" gradientColor="#b4946b" gradientOpacity={0.10}><Contents item={item}/></MagicCard></section>)}{[collections[0],collections[4]].map(item=><section key={item.id}><h3>Time-driven · Shine Border</h3><div className="trial-card relative"><ShineBorder shineColor={['#bd9e77','#615346']} /><Contents item={item}/></div></section>)}</div></main>);
