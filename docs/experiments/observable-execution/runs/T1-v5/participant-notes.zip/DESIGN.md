# 当前设计模型 — Index

## 范围与事实
本次唯一正式增量：编辑式集合工具的查找、保存、阅读、返回完整路径。现有 React/Vite 与六条代表数据继续使用；记录数量来自 fixture，并未提供对应外部参考条目。仅本地浏览器保存，不连接账户或云端。

L0：给研究者一个可反复回来阅读的安静集合。L1：搜索/筛选 → 打开 → 保存/取消保存 → 返回恢复查询、滚动和焦点。L2：列表与独立阅读页共享页眉。L3：搜索、两种过滤、卡片、存储反馈。L4：近黑石墨、暖白、serif 展示字/无衬线正文、暖铜边光。L5：实际源码改造、1440×900 和 390×844 浏览器检查。

## 决策与下一项证据
- D1 集合结构：工作对象是六个集合，先搜索和比较再打开。Are.na 的公开 Explore 页面作为集合模型参考；抓取只读文字可确认搜索、视图与排序入口，官方页面的集合网格和独立筛选已实际截图并查看。其服务账户和内容范围不适合移植，保留现有数据和本地边界，定制编辑式版面。
- D2 卡片材料：Magic UI Magic Card 与 Shine Border 均有锁定源码和 MIT 许可。前者指针位置决定径向表面/边缘光，后者按时间循环。采用 Magic Card 的 gradient 模式；真实短/长标题的本地运行比较已检查亮度、正文对比和无指针状态，观察与适配见下文。
- D3 阅读连续性：详情采用文档页而非模态框，让长标题/正文自然流动；列表查询、过滤与滚动由同一状态所有者保持。打开时焦点转到标题，返回时恢复原卡片（若已不在保存筛选结果，回到结果标题）。已通过实际打开、浏览器返回、重新打开与键盘焦点检查。
- D4 存储：localStorage 保存集合 ID；写失败仍保留本次会话状态，明确说明尚未持久化，可重试或下载副本。写失败、读失败、空结果、已保存空列表已分别验证。

## 来源
- supplied resources/sources.json — Magic UI commit efe76fc5755eca1142dd4f74c1d6f0ace2887e3c；原始文件在 resources/。
- https://magicui.design/docs/components/magic-card
- https://magicui.design/docs/components/shine-border
- https://www.are.na/explore
- modern-web-guidance.txt：环境已获取的 motion、dialog、scroll、same-document transition 指南。使用 focus 路由、reduced motion、原生文档滚动和能力检测；不新增依赖。

当前为代理决定的可逆实现方向，未声称用户已验收。原始演示、试样与产品验证结果见下方记录及 evidence/。

## 09:32 更新：已观察的比较与首次产品结果
- 官方演示截图已实际打开：Magic Card 白色登录示例在指针附近呈局部彩色边缘，Shine Border 在无输入时仍呈连续亮边。官网演示不等同于当前深色主题；本地试样负责后者。Are.na Explore 实际画面有独立搜索、筛选与方形集合对象，继承“先集合、再内容”的关系，未移植其服务/图像/账户模型。
- trial-rest、trial-hover、trial-edge 已逐张查看：暖色径向表面不改变文字/位置，长标题自然换行；连续边框对无操作卡片也施加注意力。采用 Magic Card gradient，保留多层背景形成 1px 边光与 motion value 坐标。发现试样的普通边框 CSS 会遮挡原始边光，已移除覆盖。Keyboard focus 使用静态顶部照明与明确焦点轮廓；reduced motion 不响应指针位置。
- 第一版 1440×900、390×844 与移动端长标题详情已截图并查看。没有水平溢出、没有浏览器异常。手机详情截图暴露了导航后视口偏离顶部的问题；已把焦点/滚动恢复加入 view transition 完成后，并保留无 API/减少动态效果时的即时路径，待复检。
- 页面身份与排版属于本项目原创组合，未声称完整页模板复用。系统 serif 负责标题与编辑感，Arial 负责正文与可操作控件；不依赖远程字体/图片。

## 交付状态与证据边界

当前工作入口：http://127.0.0.1:8412/ 。现有 app/ 已完成实际产品路径，非纯静态演示。正文和参考数量继承六条供应数据；没有编造单条参考链接。界面使用英文数据/文案，任务对外沟通使用中文。

- 查找：标题、分类、摘要、笔记的多词搜索；保存筛选与搜索组合；URL 保留筛选；空状态可恢复。
- 保存：真实 localStorage 写入/刷新读回通过。读异常和写失败均保留可用阅读体验；写失败状态维持在当前内存，提示在滚动位置可见，提供实际 JSON 下载和重试，成功后消除警告。下载副本未提供导入。
- 连续性：列表用原卡片相对视口位置恢复，以容纳错误提示改变页面高度；详情按集合保留本次会话阅读位置。标题进入焦点、原卡片返回焦点、保存筛选取消最后一项后的结果标题焦点均有检查。阅读位置不跨刷新持久化。
- 视觉：桌面和移动列表、长标题卡片、详情首屏/正文末尾、空状态、键盘静态光照、存储失败状态均已查看。pointer-center/edge/reverse/leave 是自然时间顺序截图，记录偏移见 pointer-episode.json；不是完整视频或帧率测试。
- 工程：生产构建成功，evidence/build.log 保留全部输出；依赖里的 use client 指令有 Vite 忽略提示。evidence/delivered-source-sha256.json 标识交付源码。没有重新安装或修改共享依赖。

最终 evidence/verification.json 记录 22 项范围明确的浏览器检查，均通过；原始验证脚本里两处 Playwright 故障注入表达式返回函数，导致测试工具调用失败，均已修正并完成局部续验。历史失败记录在 verification-run1.json 与 verification-run2.json，没有将工具错误称为产品缺陷或抹掉记录。

关键实际截图：desktop-final.png、mobile-final.png、desktop-detail-final.png、mobile-detail-final.png、mobile-long-card.png、mobile-detail-bottom.png、storage-failure-while-scrolled.png、keyboard-reduced-motion.png。桌面 900px 高度下第二排卡片底部需要少量文档滚动；所有内容和底部操作均可到达，不采用截断标题或固定高度裁剪。

未验证：Safari、Firefox、物理手机/实际软键盘、完整屏幕阅读器会话、持续运行帧率与现场性能。移动端是 Chromium 390×844 触摸模拟。存储失败是明确注入的边界场景；成功持久化和下载使用真实浏览器能力。未部署外部服务。代理已实施与检查，不等于用户已验收。
