import json, os, time
from pathlib import Path
from playwright.sync_api import sync_playwright
os.environ["FONTCONFIG_FILE"]="/workspace/scratch/654b1ee6916f/ui-spec-fonts/fonts.conf"
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path="/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell",headless=True,args=["--no-sandbox"])
 page=browser.new_page(viewport={"width":1440,"height":900},device_scale_factor=1,color_scheme="dark",ignore_https_errors=True)
 records=[]
 for key,url in [("magic-card","https://magicui.design/docs/components/magic-card"),("shine-border","https://magicui.design/docs/components/shine-border"),("arena","https://www.are.na/explore")]:
  try:
   page.goto(url,wait_until="domcontentloaded",timeout=25000)
   page.wait_for_timeout(2200)
   if key!="arena":
    page.get_by_role("heading",name="Magic Card" if key=="magic-card" else "Shine Border",exact=True).first.scroll_into_view_if_needed()
   page.screenshot(path=f"evidence/source-{key}-rest.png")
   if key=="magic-card":
    field=page.get_by_placeholder("name@example.com").first
    field.scroll_into_view_if_needed()
    box=field.bounding_box()
    if box:
     page.mouse.move(box["x"]+40,box["y"]-20)
     page.wait_for_timeout(350)
     page.screenshot(path=f"evidence/source-{key}-hover.png")
   if key=="shine-border":
    page.wait_for_timeout(3000)
    page.screenshot(path=f"evidence/source-{key}-later.png")
   records.append({"source":url,"status":"captured","title":page.title()})
  except Exception as e: records.append({"source":url,"status":"failed","error":str(e)})
 Path("evidence/source-captures.json").write_text(json.dumps(records,indent=2))
 print(json.dumps(records))
 browser.close()
