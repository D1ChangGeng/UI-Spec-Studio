import os, json, re, time
from pathlib import Path
from playwright.sync_api import sync_playwright, expect
os.environ['FONTCONFIG_FILE']='/workspace/scratch/654b1ee6916f/ui-spec-fonts/fonts.conf'
ROOT=Path(__file__).parent
URL='http://127.0.0.1:8412/'
KEY='index.saved-collections.v1'
results=[]
errors=[]
def record(name, detail=''):
    results.append({'check':name,'result':'pass','detail':detail})
def no_overflow(page, name):
    sizes=page.evaluate('({width:innerWidth,document:document.documentElement.scrollWidth})')
    assert sizes['document']<=sizes['width'],sizes
    record(name,str(sizes))
def wait_view(page):
    page.wait_for_timeout(400)
def screenshot(page, name):
    page.screenshot(path=str(ROOT/'evidence'/name))
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
    context=browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
    page=context.new_page()
    page.on('pageerror',lambda error:errors.append(str(error)))
    page.set_default_timeout(6000)
    try:
        page.goto(URL,wait_until='networkidle')
        expect(page.locator('.collection-card')).to_have_count(6)
        no_overflow(page,'1440×900 list: no horizontal overflow')
        screenshot(page,'desktop-final.png')
        surface=page.locator('.collection-surface').first
        rect=surface.bounding_box()
        before=surface.get_attribute('style')
        frames=[]
        start=time.monotonic()
        for name, x,y in [('center',rect['x']+170,rect['y']+90),('edge',rect['x']+rect['width']-15,rect['y']+20),('reverse',rect['x']+20,rect['y']+rect['height']-20),('leave',30,20)]:
            page.mouse.move(x,y,steps=8)
            page.wait_for_timeout(120)
            screenshot(page,'pointer-'+name+'.png')
            frames.append({'phase':name,'offset_s':round(time.monotonic()-start,3),'x':x,'y':y})
        (ROOT/'evidence'/'pointer-episode.json').write_text(json.dumps(frames,indent=2))
        record('Pointer illumination: center → edge → reversal → leave captured','Ordered natural-time screenshots; no frame-rate claim.')
        page.locator('[data-collection="quiet"] .save-card').click()
        assert json.loads(page.evaluate(f'localStorage.getItem({json.dumps(KEY)})'))==['quiet']
        page.reload(wait_until='networkidle')
        expect(page.locator('[data-collection="quiet"] .save-card')).to_have_attribute('aria-pressed','true')
        record('Saving persists across reload')
        page.keyboard.press('/')
        expect(page.locator('#collection-search')).to_be_focused()
        page.locator('#collection-search').fill('  QUIET  ')
        expect(page.locator('.collection-card')).to_have_count(1)
        page.locator('#open-quiet').click()
        wait_view(page)
        expect(page.locator('#reading-title')).to_have_text('The quiet interface')
        expect(page.locator('#reading-title')).to_be_focused()
        assert page.evaluate('scrollY')==0
        page.get_by_role('link',name='Back to the collection',exact=True).click()
        wait_view(page)
        expect(page.locator('#collection-search')).to_have_value('  QUIET  ')
        expect(page.locator('#open-quiet')).to_be_focused()
        record('Search shortcut, case/whitespace search, detail heading focus and return context')
        page.get_by_role('button',name='Clear search',exact=True).click()
        page.get_by_role('button',name=re.compile('^Saved')).click()
        expect(page.locator('.collection-card')).to_have_count(1)
        page.locator('[data-collection="quiet"] .save-card').click()
        expect(page.locator('.collection-card')).to_have_count(0)
        expect(page.locator('#results-heading')).to_be_focused()
        screenshot(page,'saved-empty.png')
        record('Saved-only filter, unsave removal and focus fallback')
        page.get_by_role('button',name='Explore the collection',exact=True).click()
        page.locator('#collection-search').fill('unlikely-no-match')
        expect(page.locator('.empty-state')).to_be_visible()
        screenshot(page,'search-empty.png')
        page.get_by_role('button',name='Reset filters',exact=True).click()
        expect(page.locator('.collection-card')).to_have_count(6)
        record('Empty search state and reset action')
        page.locator('#collection-search').fill('Interaction')
        expect(page.locator('.collection-card')).to_have_count(1)
        page.locator('#open-time').click()
        wait_view(page)
        screenshot(page,'desktop-detail-final.png')
        assert page.evaluate('scrollY')==0
        no_overflow(page,'Desktop long-title detail: no horizontal overflow')
        page.mouse.wheel(0,380)
        page.wait_for_timeout(250)
        reading_scroll=page.evaluate('scrollY')
        page.go_back()
        wait_view(page)
        expect(page.locator('#collection-search')).to_have_value('Interaction')
        expect(page.locator('#open-time')).to_be_focused()
        page.locator('#open-time').click()
        wait_view(page)
        assert abs(page.evaluate('scrollY')-reading_scroll)<3,{'expected':reading_scroll,'actual':page.evaluate('scrollY')}
        record('Browser Back and reopening restore reading position',str(reading_scroll))
        page.go_back()
        wait_view(page)
        page.get_by_role('button',name='Clear search',exact=True).click()
        page.locator('#open-time').scroll_into_view_if_needed()
        list_scroll=page.evaluate('scrollY')
        page.locator('#open-time').click()
        wait_view(page)
        page.go_back()
        wait_view(page)
        assert abs(page.evaluate('scrollY')-list_scroll)<3
        record('List scroll and opening-card focus restored',str(list_scroll))
        context.close()

        mobile=browser.new_context(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True)
        page=mobile.new_page()
        page.on('pageerror',lambda error:errors.append(str(error)))
        page.goto(URL,wait_until='networkidle')
        screenshot(page,'mobile-final.png')
        no_overflow(page,'390×844 list: no horizontal overflow')
        page.locator('#open-time').scroll_into_view_if_needed()
        mobile_list_scroll=page.evaluate('scrollY')
        page.locator('#open-time').tap()
        wait_view(page)
        assert page.evaluate('scrollY')==0,{'mobile detail scroll':page.evaluate('scrollY')}
        screenshot(page,'mobile-detail-final.png')
        no_overflow(page,'390×844 long-title detail: no horizontal overflow')
        page.mouse.wheel(0,550)
        page.wait_for_timeout(250)
        screenshot(page,'mobile-detail-reading.png')
        page.go_back()
        wait_view(page)
        assert abs(page.evaluate('scrollY')-mobile_list_scroll)<3
        expect(page.locator('#open-time')).to_be_focused()
        record('Mobile tap, long title, reading and return to list scroll',str(mobile_list_scroll))
        mobile.close()

        reduced=browser.new_context(viewport={'width':1440,'height':900},reduced_motion='reduce')
        page=reduced.new_page()
        page.goto(URL,wait_until='networkidle')
        surface=page.locator('.collection-surface').first
        initial_style=surface.get_attribute('style')
        box=surface.bounding_box()
        page.mouse.move(box['x']+100,box['y']+70)
        page.wait_for_timeout(120)
        assert surface.get_attribute('style')==initial_style
        page.locator('#open-quiet').focus()
        screenshot(page,'keyboard-reduced-motion.png')
        page.keyboard.press('Enter')
        expect(page.locator('#reading-title')).to_be_focused()
        assert page.evaluate('scrollY')==0
        record('Reduced motion disables pointer tracking; keyboard open and focus remain usable')
        reduced.close()

        failure=browser.new_context(viewport={'width':390,'height':844})
        failure.add_init_script('''(() => {const original=Storage.prototype.setItem; window.restoreStorage=()=>Storage.prototype.setItem=original; Storage.prototype.setItem=function(key,value){if(key==='index.saved-collections.v1')throw new DOMException('Storage blocked for test','QuotaExceededError');return original.call(this,key,value)};})()''')
        page=failure.new_page()
        page.goto(URL,wait_until='networkidle')
        page.locator('[data-collection="quiet"] .save-card').click()
        expect(page.locator('.storage-notice')).to_contain_text('kept in this tab')
        expect(page.locator('[data-collection="quiet"] .save-card')).to_have_attribute('aria-pressed','true')
        assert page.evaluate(f'localStorage.getItem({json.dumps(KEY)})') is None
        page.evaluate('scrollTo(0,0)')
        screenshot(page,'mobile-storage-failure.png')
        no_overflow(page,'Storage failure banner at 390×844: no horizontal overflow')
        with page.expect_download() as info:
            page.get_by_role('button',name='Download copy',exact=True).click()
        download=info.value
        download.save_as(str(ROOT/'evidence'/'recovery-copy.json'))
        exported=json.loads((ROOT/'evidence'/'recovery-copy.json').read_text())
        assert exported['collections'][0]['id']=='quiet'
        page.evaluate('() => { window.restoreStorage(); }')
        page.get_by_role('button',name='Retry storage',exact=True).click()
        expect(page.locator('.storage-notice')).to_have_count(0)
        assert json.loads(page.evaluate(f'localStorage.getItem({json.dumps(KEY)})'))==['quiet']
        record('Simulated storage write failure: session state retained, real download and retry recovery')
        failure.close()

        malformed=browser.new_context(viewport={'width':1440,'height':900})
        malformed.add_init_script("localStorage.setItem('index.saved-collections.v1','malformed-json')")
        page=malformed.new_page()
        page.goto(URL,wait_until='networkidle')
        expect(page.locator('.storage-notice')).to_contain_text('could not be read')
        expect(page.locator('.collection-card')).to_have_count(6)
        record('Malformed stored data: explanatory notice and usable collection')
        malformed.close()

        fallback=browser.new_context(viewport={'width':390,'height':844})
        fallback.add_init_script("document.startViewTransition=undefined")
        page=fallback.new_page()
        page.goto(URL+'#collection/time',wait_until='networkidle')
        expect(page.locator('#reading-title')).to_be_visible()
        page.get_by_role('link',name='Back to the collection',exact=True).click()
        expect(page.locator('.collection-card')).to_have_count(6)
        page.locator('#open-quiet').focus()
        page.keyboard.press('Enter')
        expect(page.locator('#reading-title')).to_be_focused()
        record('Direct detail URL and no-View-Transitions fallback')
        fallback.close()
        assert not errors,errors
        record('No uncaught browser errors in exercised product journeys')
    except Exception as e:
        results.append({'check':'Execution stopped at first failing assertion','result':'fail','detail':str(e)})
        try:screenshot(page,'verification-failure.png')
        except:pass
        print('FAILED:',repr(e))
    finally:
        browser.close()
        output={'viewport_targets':['1440×900','390×844'],'checks':results,'browser_errors':errors,'limitations':['Chromium only; mobile is emulated, not a physical device.','Storage failures are injected fixtures; successful localStorage persistence uses the real browser.','Pointer screenshots sample ordered states and do not establish frame-rate performance.']}
        (ROOT/'evidence'/'verification.json').write_text(json.dumps(output,ensure_ascii=False,indent=2))
        print(json.dumps(output,ensure_ascii=False,indent=2))

if any(item['result']=='fail' for item in results):
    raise SystemExit(1)
