from playwright.sync_api import sync_playwright
from pathlib import Path
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
 page.goto('http://127.0.0.1:8423')
 page.screenshot(path='evidence/before-desktop.png')
 page.set_viewport_size({'width':390,'height':844})
 page.screenshot(path='evidence/before-mobile.png')
 b.close()
