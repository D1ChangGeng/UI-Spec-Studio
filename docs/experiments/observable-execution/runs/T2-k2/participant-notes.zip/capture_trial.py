from playwright.sync_api import sync_playwright
from pathlib import Path
import json
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1,ignore_https_errors=True)
 page.goto('http://127.0.0.1:8423');page.screenshot(path='evidence/trial-desktop.png')
 page.click('#flip');page.wait_for_timeout(800);page.screenshot(path='evidence/trial-back.png')
 page.set_viewport_size({'width':390,'height':844});page.click('#locale-toggle');page.click('#theme-toggle');page.wait_for_timeout(250);page.screenshot(path='evidence/trial-mobile-dark.png')
 try:
  page.goto('https://3dtransforms.desandro.com/card-flip',timeout=15000)
  page.set_viewport_size({'width':1200,'height':900});page.screenshot(path='evidence/reference-desandro.png',full_page=True)
  print('reference-scenes',page.locator('.scene').count())
  for i in range(page.locator('.scene').count()):
   scene=page.locator('.scene').nth(i)
   scene.scroll_into_view_if_needed();scene.screenshot(path=f'evidence/reference-{i}-front.png')
   scene.click();page.wait_for_timeout(300);scene.screenshot(path=f'evidence/reference-{i}-mid.png');page.wait_for_timeout(900);scene.screenshot(path=f'evidence/reference-{i}-back.png')
 except Exception as e:print('Reference rendering unavailable:',str(e)[:200])
 b.close()
