from pathlib import Path
from playwright.sync_api import sync_playwright
import json,hashlib
out=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 for width,height in [(1440,900),(390,844)]:
  for theme in ['light','dark']:
   for locale in ['en','zh']:
    page=b.new_page(viewport={'width':width,'height':height},device_scale_factor=1)
    page.goto('http://127.0.0.1:8423')
    if theme=='dark':page.click('#theme-toggle')
    if locale=='zh':page.click('#locale-toggle')
    name=f'final-{width}-{theme}-{locale}'
    page.screenshot(path='evidence/'+name+'.png')
    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
    bounds=page.locator('.preview-actions').evaluate('(e)=>[...e.children].map(b=>({x:b.getBoundingClientRect().x,r:b.getBoundingClientRect().right}))')
    assert bounds[0]['r']<bounds[1]['x']
    page.click('#flip');page.wait_for_timeout(800);page.screenshot(path='evidence/'+name+'-back.png')
    out.append({'condition':name,'overflow':False,'actionOverlap':False});page.close()
 b.close()
Path('evidence/final-render-checks.json').write_text(json.dumps({'conditions':out,'reason':'Increase secondary action labels to 12px after the full behavior run; recheck both faces and action spacing.','sourceHashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('app').glob('*') if p.is_file()}},indent=2))
print('Final rendering: all 8 conditions and both faces captured; no horizontal overflow or action overlap.')
