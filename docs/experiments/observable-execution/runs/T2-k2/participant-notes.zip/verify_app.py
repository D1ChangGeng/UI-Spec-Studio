from pathlib import Path
from playwright.sync_api import sync_playwright
import json,time,hashlib
OUT=Path('evidence');OUT.mkdir(exist_ok=True)
KEY='ui-spec-temporal-note-v1'
report={'checks':[],'episodes':[],'limits':['Chromium desktop emulation; no real touchscreen or Safari/Firefox run.','900 ms save delay is an inherited demonstration fixture; writes use native localStorage.','Screenshots are natural-time samples, not proof of presented frame rate.']}
def check(label,condition):
 assert condition,label
 report['checks'].append(label)
def snap(page,name):
 start=page.evaluate('performance.now()');page.screenshot(path=str(OUT/(name+'.png')),animations='allow');end=page.evaluate('performance.now()')
 report['episodes'].append({'capture':name+'.png','bracketMs':[start,end],'face':page.locator('#note-card').get_attribute('data-face')})
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
 for width,height in [(1440,900),(390,844)]:
  for theme in ['light','dark']:
   for locale in ['en','zh']:
    tag=f'{width}-{theme}-{locale}'
    ctx=b.new_context(viewport={'width':width,'height':height},device_scale_factor=1,record_video_dir=str(OUT/'videos'),record_video_size={'width':width,'height':height})
    page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto('http://127.0.0.1:8423');page.evaluate('document.fonts.ready')
    if theme=='dark':page.click('#theme-toggle')
    if locale=='zh':page.click('#locale-toggle')
    snap(page,tag+'-front')
    check(tag+' no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
    baseline=page.locator('#card-space').bounding_box();editor=page.locator('.editor-fields').bounding_box()
    page.click('#flip')
    if tag=='1440-light-en':
     for name,wait in [('turn-early',100),('turn-middle',150),('turn-late',150),('turn-end',400)]:
      page.wait_for_timeout(wait);snap(page,name)
    else:page.wait_for_timeout(800)
    snap(page,tag+'-back')
    check(tag+' back semantics',page.locator('#card-front').evaluate('(e)=>e.inert') and not page.locator('#card-back').evaluate('(e)=>e.inert'))
    # Seven rapid visible-control reversals; latest intent should be front.
    for i in range(7):
     page.click('#flip');page.wait_for_timeout(55)
     if tag=='1440-light-en':snap(page,f'reverse-{i}')
    page.wait_for_timeout(800)
    check(tag+' rapid latest intent',page.locator('#note-card').get_attribute('data-face')=='front')
    check(tag+' stable card anchor',page.locator('#card-space').bounding_box()==baseline)
    check(tag+' stable editor anchor',page.locator('.editor-fields').bounding_box()==editor)
    long=('供热研究：保留已有证据，继续核对时段与需求。\n' if locale=='zh' else 'A longer note keeps evidence and open questions together.\n')*40
    page.fill('#note-text',long)
    check(tag+' over-limit retained',page.input_value('#note-text')==long and page.locator('#save').is_disabled() and page.locator('#note-text').get_attribute('aria-invalid')=='true')
    page.click('#flip');page.wait_for_timeout(800)
    page.locator('#preview-note').focus();page.keyboard.press('End');page.locator('#preview-note').evaluate('(e)=>e.scrollTop=e.scrollHeight')
    check(tag+' long back scroll',page.locator('#preview-note').evaluate('(e)=>e.scrollHeight>e.clientHeight && e.scrollTop>0'))
    snap(page,tag+'-long-back')
    first='First saved version / 已存版本'
    page.fill('#note-text',first);page.click('#save')
    check(tag+' delayed save pending',page.locator('#status-area').get_attribute('data-status')=='saving' and page.evaluate('(k)=>localStorage.getItem(k)',KEY) is None)
    draft=first+' — keep this newer draft while saving.'
    page.fill('#note-text',draft);page.click('#saved-link')
    check(tag+' pending collection labelled',page.locator('#collection-status').inner_text()!='')
    page.wait_for_timeout(950)
    check(tag+' submitted snapshot saved',json.loads(page.evaluate('(k)=>localStorage.getItem(k)',KEY))['text']==first)
    check(tag+' newer draft survives navigation',page.input_value('#note-text')==draft)
    snap(page,tag+'-saved')
    page.click('#return')
    check(tag+' return focus',page.evaluate('document.activeElement.id')=='note-text')
    # Save a native version and verify a real quota exhaustion, never replace Storage methods.
    page.click('#save');page.wait_for_timeout(950)
    quota=page.evaluate('''() => {
      let lo=0,hi=6*1024*1024,lastError='';
      while(hi-lo>1){const mid=Math.floor((lo+hi)/2);try{localStorage.setItem('__test_quota__','x'.repeat(mid));lo=mid}catch(e){hi=mid;lastError=e.name}}
      return {filled:lo,error:lastError};
    }''')
    failed=draft+' This addition must remain after the native write fails.'
    page.fill('#note-text',failed);page.click('#save');page.wait_for_timeout(950)
    check(tag+' native quota error exercised',quota['error']=='QuotaExceededError')
    check(tag+' failure truthfully displayed',page.locator('#status-area').get_attribute('data-status')=='failed' and page.locator('#retry').is_visible())
    check(tag+' failure retains current draft',page.input_value('#note-text')==failed)
    check(tag+' failure retains persisted version',json.loads(page.evaluate('(k)=>localStorage.getItem(k)',KEY))['text']==draft)
    snap(page,tag+'-write-failure')
    page.click('#saved-link')
    check(tag+' failed collection keeps previous note',page.locator('#saved-text').inner_text()==draft)
    page.click('#return');check(tag+' recovery focus',page.evaluate('document.activeElement.id')=='retry')
    page.evaluate("localStorage.removeItem('__test_quota__')");page.click('#retry');page.wait_for_timeout(950)
    check(tag+' native retry saved',page.locator('#status-area').get_attribute('data-status')=='saved' and json.loads(page.evaluate('(k)=>localStorage.getItem(k)',KEY))['text']==failed)
    page.locator('#note-text').focus();page.locator('#note-text').evaluate('(e)=>{e.setSelectionRange(4,12);e.scrollTop=14}')
    selection=page.locator('#note-text').evaluate('(e)=>[e.selectionStart,e.selectionEnd,e.scrollTop]')
    page.click('#saved-link');page.click('#return')
    check(tag+' caret and textarea scroll restored',page.locator('#note-text').evaluate('(e)=>[e.selectionStart,e.selectionEnd,e.scrollTop]')==selection)
    page.emulate_media(reduced_motion='reduce');page.click('#flip')
    check(tag+' reduced motion immediate',page.locator('#note-card').evaluate('(e)=>getComputedStyle(e).transitionDuration')=='0s' and page.locator('.orbit-arm').evaluate('(e)=>getComputedStyle(e).animationName')=='none')
    check(tag+' reduced motion meaning',page.locator('#motion-toggle').is_disabled() and page.input_value('#note-text')==failed)
    page.reload();check(tag+' reload persistence',page.input_value('#note-text')==failed)
    check(tag+' no runtime errors',not errors)
    ctx.close()
 b.close()
report['sourceHashes']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('app').glob('*') if p.is_file()}
report['passed']=len(report['checks'])
Path('evidence/checks.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
print(json.dumps({'passed':report['passed'],'captures':len(report['episodes'])}))
