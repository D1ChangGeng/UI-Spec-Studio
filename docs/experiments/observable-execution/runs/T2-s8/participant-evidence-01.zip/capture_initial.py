from playwright.sync_api import sync_playwright
from pathlib import Path
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell', args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1,ignore_https_errors=True)
 page.goto('http://127.0.0.1:8421'); page.screenshot(path='evidence/before-desktop.png')
 try:
  page.goto('https://3dtransforms.desandro.com/card-flip',wait_until='domcontentloaded',timeout=20000)
  page.screenshot(path='evidence/reference-desandro.png',full_page=True)
  Path('evidence/reference-desandro.html').write_text(page.content())
  print('iframes',page.locator('iframe').count())
 except Exception as e: print(type(e).__name__,str(e)[:200])
 b.close()
