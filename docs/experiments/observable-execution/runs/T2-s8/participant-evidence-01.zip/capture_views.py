from playwright.sync_api import sync_playwright
from pathlib import Path
import json,time
out=Path('evidence')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('http://127.0.0.1:8421');page.screenshot(path=str(out/'after-desktop-front.png'))
 page.locator('#flip').click();page.wait_for_timeout(850);page.screenshot(path=str(out/'after-desktop-back.png'))
 page.locator('#theme-toggle').click();page.screenshot(path=str(out/'after-desktop-dark.png'))
 page.set_viewport_size({'width':390,'height':844});page.locator('#locale-toggle').click();page.screenshot(path=str(out/'after-mobile-dark.png'),full_page=True)
 page.locator('#theme-toggle').click();page.locator('#flip').click();page.wait_for_timeout(850);page.screenshot(path=str(out/'after-mobile-light.png'),full_page=True)
 print(json.dumps({'errors':errors,'mobileWidth':page.evaluate('document.documentElement.scrollWidth'),'viewport':390}))
 b.close()
