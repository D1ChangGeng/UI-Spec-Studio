from playwright.sync_api import sync_playwright
from pathlib import Path
import json,hashlib
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
 page.goto('http://127.0.0.1:8421');page.locator('#locale-toggle').click();text='记录今天的观察，保留需要进一步确认的问题。\n'*20
 page.locator('#note-text').fill(text);page.locator('#save').click();page.wait_for_timeout(1100)
 page.locator('#note-text').evaluate('(e)=>e.setSelectionRange(7,14)');page.locator('#saved-link').click()
 box=page.locator('#return').bounding_box();assert 0<=box['y'] and box['y']+box['height']<=844
 page.screenshot(path='evidence/final-mobile-saved-return.png')
 page.locator('#theme-toggle').click();page.screenshot(path='evidence/final-mobile-saved-return-dark.png')
 page.locator('#return').click();assert page.evaluate('document.activeElement.id')=='note-text';assert page.locator('#note-text').input_value()==text;assert page.locator('#note-text').evaluate('(e)=>[e.selectionStart,e.selectionEnd]')==[7,14]
 page.set_viewport_size({'width':1440,'height':900});page.locator('#saved-link').click();box2=page.locator('#return').bounding_box();assert box2['y']+box2['height']<900
 page.screenshot(path='evidence/final-desktop-saved-return.png');page.locator('#return').click();assert page.evaluate('document.activeElement.id')=='note-text'
 b.close()
result={'returnVisibleMobile':box,'returnVisibleDesktop':box2,'draftFocusSelectionPreserved':True,'source':{str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in Path('app').glob('*') if f.is_file()}}
Path('evidence/final-return-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))
