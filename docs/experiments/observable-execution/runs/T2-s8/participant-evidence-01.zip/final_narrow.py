from playwright.sync_api import sync_playwright
from pathlib import Path
import json
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
 page.goto('http://127.0.0.1:8421');page.locator('#locale-toggle').click()
 page.screenshot(path='evidence/final-mobile-default-full.png',full_page=True)
 page.locator('#theme-toggle').click();page.screenshot(path='evidence/final-mobile-default-dark-full.png',full_page=True)
 # Begin with an actual confirmed version, then exhaust browser quota.
 page.locator('#save').click();page.wait_for_timeout(1000)
 quota=page.evaluate('''() => {let i=0;for(const n of [1048576,65536,4096,256,16,1]){for(let j=0;j<100;j++){try{localStorage.setItem('fill-'+i,'x'.repeat(n));i++}catch(e){break}}}return i}''')
 draft='记录今天的观察，保留需要进一步确认的问题。\n'*20
 page.locator('#note-text').fill(draft);page.locator('#save').click();page.wait_for_timeout(1000)
 assert page.locator('#status-area').get_attribute('data-status')=='failed'
 page.locator('#retry').scroll_into_view_if_needed();page.screenshot(path='evidence/final-mobile-quota-failure.png')
 page.locator('#theme-toggle').click();page.locator('#retry').scroll_into_view_if_needed();page.screenshot(path='evidence/final-mobile-quota-failure-light.png')
 assert page.locator('#note-text').input_value()==draft
 page.evaluate('''() => {Object.keys(localStorage).filter(k=>k.startsWith('fill-')).forEach(k=>localStorage.removeItem(k))}''')
 page.locator('#retry').click();page.wait_for_timeout(1000)
 assert page.locator('#status-area').get_attribute('data-status')=='saved'
 page.locator('#saved-link').click();page.screenshot(path='evidence/final-mobile-saved.png');page.locator('#return').click()
 assert page.evaluate('document.activeElement.id')=='note-text'
 assert page.locator('#note-text').input_value()==draft
 assert page.evaluate('document.documentElement.scrollWidth')==390
 print(json.dumps({'narrowNativeFailure':True,'narrowRetry':True,'narrowReturn':True,'fillKeys':quota,'chars':len(draft)}))
 b.close()
