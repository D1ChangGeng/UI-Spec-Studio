from playwright.sync_api import sync_playwright
from pathlib import Path
import json,hashlib
checks=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1);page.goto('http://127.0.0.1:8421')
 for w,h in [(1440,900),(390,844)]:
  page.set_viewport_size({'width':w,'height':h})
  for locale in ['en','zh']:
   if page.locator('html').get_attribute('lang')!=('en' if locale=='en' else 'zh-CN'):page.locator('#locale-toggle').click()
   page.evaluate('scrollTo(0,0)');page.screenshot(path=f'evidence/delivery-{w}-{locale}.png',full_page=w==390)
   check=page.locator('.card-copy h2').evaluate('(e)=>({height:e.clientHeight,scroll:e.scrollHeight,wrap:getComputedStyle(e).textWrap})');assert check['height']==check['scroll'];checks.append({'width':w,'locale':locale,**check})
 b.close()
Path('evidence/final-visual-check.json').write_text(json.dumps({'checks':checks,'source':{str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in Path('app').glob('*') if f.is_file()}},indent=2));print(json.dumps(checks))
