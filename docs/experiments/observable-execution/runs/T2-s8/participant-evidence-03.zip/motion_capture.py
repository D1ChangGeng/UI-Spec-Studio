from playwright.sync_api import sync_playwright
from pathlib import Path
import json,base64
OUT=Path('evidence/motion');OUT.mkdir(exist_ok=True)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
 page.goto('http://127.0.0.1:8421');page.locator('#note-text').fill('Notice what changed. Keep the question open.');page.locator('#motion-toggle').click()
 cdp=page.context.new_cdp_session(page);frames=[]
 def frame(e):
  i=len(frames);(OUT/f'{i:03d}.jpg').write_bytes(base64.b64decode(e['data']));frames.append({'index':i,'timestamp':e['metadata']['timestamp']});cdp.send('Page.screencastFrameAck',{'sessionId':e['sessionId']})
 cdp.on('Page.screencastFrame',frame);cdp.send('Page.startScreencast',{'format':'jpeg','quality':90,'maxWidth':1440,'maxHeight':900,'everyNthFrame':1})
 page.wait_for_timeout(180);actions=[]
 for delay in [780,110,90,800]:
  actions.append({'before':page.evaluate('Date.now()'),'next':'flip'});page.locator('#flip').click();page.wait_for_timeout(delay)
 cdp.send('Page.stopScreencast');page.screenshot(path=str(OUT/'settled.png'))
 (OUT/'timeline.json').write_text(json.dumps({'frames':frames,'actions':actions},indent=2));b.close()
 print(json.dumps({'frames':len(frames),'actions':actions}))
