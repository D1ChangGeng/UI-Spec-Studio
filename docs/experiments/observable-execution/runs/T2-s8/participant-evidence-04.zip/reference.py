from playwright.sync_api import sync_playwright
from pathlib import Path
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1200,'height':850},ignore_https_errors=True)
 page.goto('https://3dtransforms.desandro.com/card-flip',wait_until='domcontentloaded')
 cards=page.locator('.card')
 print('cards',cards.count())
 for i in range(cards.count()):
  cards.nth(i).scroll_into_view_if_needed(); page.screenshot(path=f'evidence/reference-{i}-front.png')
  cards.nth(i).click();page.wait_for_timeout(250);page.screenshot(path=f'evidence/reference-{i}-turn.png');page.wait_for_timeout(900);page.screenshot(path=f'evidence/reference-{i}-back.png')
 page.goto('https://css3dlab.edgarasneverdauskas.com/models/businesscard/',wait_until='domcontentloaded')
 page.screenshot(path='evidence/reference-businesscard.png');Path('evidence/reference-businesscard.html').write_text(page.content())
 b.close()
