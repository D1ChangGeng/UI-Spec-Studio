from playwright.sync_api import sync_playwright
from pathlib import Path
import json,time,hashlib
OUT=Path('evidence');KEY='ui-spec-temporal-note-v1';results=[]
def check(name,ok,detail=None):
 results.append({'check':name,'pass':bool(ok),'detail':detail})
 if not ok: raise AssertionError(name+': '+str(detail))
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 ctx=b.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
 page=ctx.new_page();errors=[];requests=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:requests.append(r.url))
 page.goto('http://127.0.0.1:8421');page.wait_for_timeout(100)
 page.screenshot(path=str(OUT/'final-desktop-front.png'))
 long=('Observation: retain the evidence and leave the question open.\n'*10)[:590]
 page.locator('#note-text').fill(long)
 page.locator('#flip').click();page.wait_for_timeout(800)
 page.screenshot(path=str(OUT/'final-desktop-back-long.png'))
 page.locator('#preview-note').focus();page.keyboard.press('End');page.keyboard.press('Control+End');page.wait_for_function("document.getElementById('preview-note').scrollTop > 0")
 check('long preview scrolls',page.locator('#preview-note').evaluate('(e)=>e.scrollHeight>e.clientHeight && e.scrollTop>0'))
 page.locator('#flip').click();page.wait_for_timeout(100)
 page.locator('#flip').click();page.wait_for_timeout(70)
 page.locator('#flip').click();page.wait_for_timeout(850)
 check('rapid flip resolves latest intent',page.locator('#note-card').get_attribute('data-face')=='front')
 check('front semantic state',page.locator('#card-back').evaluate('(e)=>e.inert') and not page.locator('#card-front').evaluate('(e)=>e.inert'))
 # Stable source identity, animated progress and stationary anchor during a natural-time episode.
 page.evaluate('window.cardIdentity=document.getElementById("note-card")')
 page.locator('#note-text').fill('A thought kept in view.')
 frames=[];page.locator('#flip').click();start=page.evaluate('performance.now()')
 for i in range(11):
  a=page.evaluate('performance.now()');state=page.locator('#note-card').evaluate('(e)=>({transform:getComputedStyle(e).transform,box:document.getElementById("card-space").getBoundingClientRect().toJSON()})')
  page.screenshot(path=str(OUT/f'flip-{i:02d}.png'));z=page.evaluate('performance.now()');frames.append({'frame':i,'captureStart':a,'captureEnd':z,'sinceInput':a-start,**state});page.wait_for_timeout(35)
 check('one card node retained',page.evaluate('window.cardIdentity===document.getElementById("note-card")'))
 check('stationary scene anchor',len({(f['box']['x'],f['box']['y'],f['box']['width'],f['box']['height']) for f in frames})==1)
 (OUT/'flip-timestamps.json').write_text(json.dumps(frames,indent=2))
 # First real save and newer edits while pending.
 submitted='The first confirmed version.';newer='A newer thought, still a draft.'
 page.locator('#note-text').fill(submitted);page.locator('#save').click()
 check('native storage still empty while pending',page.evaluate('(k)=>localStorage.getItem(k)',KEY) is None)
 page.locator('#note-text').fill(newer);page.locator('#saved-link').click()
 check('pending collection explicitly marked',page.locator('#collection-status').inner_text()=='Saving in this browser…')
 page.wait_for_timeout(1050)
 check('submitted snapshot persisted',json.loads(page.evaluate('(k)=>localStorage.getItem(k)',KEY))['text']==submitted)
 check('newer edit completion truthful','Save again' in page.locator('#collection-status').inner_text())
 page.locator('#return').click();check('draft retained after return',page.locator('#note-text').input_value()==newer)
 check('return focus to editor',page.evaluate('document.activeElement.id')=='note-text')
 page.locator('#note-text').evaluate('(e)=>e.setSelectionRange(4,9)');page.locator('#saved-link').click();page.locator('#return').click()
 check('selection retained',page.locator('#note-text').evaluate('(e)=>[e.selectionStart,e.selectionEnd]')==[4,9])
 # A real quota failure: fill native Storage in descending chunks. No Storage prototype mocks.
 quota=page.evaluate('''() => { let i=0,total=0,failures=[]; for (const size of [1048576,65536,4096,256,16,1]) {for(let n=0;n<100;n++){try {localStorage.setItem('fieldnote-quota-'+i,'x'.repeat(size));i++;total+=size;}catch(e){failures.push(e.name);break;}}} window.quotaKeys=Array.from({length:i},(_,j)=>'fieldnote-quota-'+j);return {i,total,failures};}''')
 check('real browser quota exhausted','QuotaExceededError' in quota['failures'],quota)
 page.locator('#note-text').fill(long);page.locator('#save').click();page.wait_for_timeout(1050)
 check('failed write reports failure',page.locator('#status-area').get_attribute('data-status')=='failed')
 check('failed write retains full draft',page.locator('#note-text').input_value()==long)
 check('failed write preserves saved version',json.loads(page.evaluate('(k)=>localStorage.getItem(k)',KEY))['text']==submitted)
 page.screenshot(path=str(OUT/'native-quota-failure.png'))
 page.locator('#saved-link').click();check('saved view shows old version after failure',page.locator('#saved-text').inner_text()==submitted)
 page.locator('#return').click();check('failed return focus to retry',page.evaluate('document.activeElement.id')=='retry')
 page.evaluate('window.quotaKeys.forEach(k=>localStorage.removeItem(k))');page.locator('#retry').click();page.wait_for_timeout(1050)
 check('retry writes native storage',json.loads(page.evaluate('(k)=>localStorage.getItem(k)',KEY))['text']==long)
 page.reload();check('reload restores saved text',page.locator('#note-text').input_value()==long)
 # Full long text retained beyond inherited bound.
 over='长笔记。'*200;page.locator('#note-text').fill(over)
 check('over-limit draft retained',page.locator('#note-text').input_value()==over)
 check('over-limit save disabled with invalid field',page.locator('#save').is_disabled() and page.locator('#note-text').get_attribute('aria-invalid')=='true')
 page.locator('#note-text').fill(long)
 # Both locales/themes at target widths, actual viewport captures.
 for width,height in [(1440,900),(390,844)]:
  page.set_viewport_size({'width':width,'height':height})
  for locale in ['en','zh']:
   if page.locator('html').get_attribute('lang')!=('en' if locale=='en' else 'zh-CN'):page.locator('#locale-toggle').click()
   for theme in ['light','dark']:
    if page.locator('html').get_attribute('data-theme')!=theme:page.locator('#theme-toggle').click()
    page.evaluate('scrollTo(0,0)');page.screenshot(path=str(OUT/f'final-{width}-{locale}-{theme}.png'))
    check(f'{width} {locale} {theme} no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
    check(f'{width} {locale} {theme} draft preserved',page.locator('#note-text').input_value()==long)
 # Reduced motion and keyboard: no rotation animation but complete semantic surface.
 page.emulate_media(reduced_motion='reduce');page.locator('#flip').click()
 check('reduced-motion no transition',page.locator('#note-card').evaluate('(e)=>getComputedStyle(e).transitionDuration')=='0s')
 check('reduced-motion face and focus',page.locator('#card-front').evaluate('(e)=>e.inert') and page.evaluate('document.activeElement.id')=='flip')
 check('reduced-motion orbit quiet',page.locator('#motion-toggle').is_disabled())
 page.locator('#preview-note').focus();page.keyboard.press('Control+End')
 page.screenshot(path=str(OUT/'final-mobile-reduced-long.png'))
 check('no runtime errors',not errors,errors)
 check('no accidental network dependency',all(u.startswith('http://127.0.0.1:8421/') or u.startswith('data:') for u in requests),requests)
 ctx.close();b.close()
report={'checks':results,'scope':'Chromium desktop emulation, DPR 1; native Storage quota exhaustion, no write mock. Ordered screenshots, no continuous video playback.','source':{str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in Path('app').glob('*') if f.is_file()}}
(OUT/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({'passed':len(results),'failed':sum(not x['pass'] for x in results)},ensure_ascii=False))
