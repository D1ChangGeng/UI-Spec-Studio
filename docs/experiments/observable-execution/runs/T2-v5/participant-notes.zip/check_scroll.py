from playwright.sync_api import sync_playwright
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900});page.goto('http://127.0.0.1:8422');page.locator('#note-text').fill(('Line of writing to remember.\n'*25)[:600]);page.locator('#flip').click();page.wait_for_timeout(850);page.locator('#preview-note').focus();page.keyboard.press('End')
 for delay in [0,100,400]:
  page.wait_for_timeout(delay);print(delay,page.locator('#preview-note').evaluate('(e)=>({top:e.scrollTop,h:e.clientHeight,sh:e.scrollHeight,active:document.activeElement.id})'))
 b.close()
