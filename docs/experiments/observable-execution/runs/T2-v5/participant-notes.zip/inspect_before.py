from playwright.sync_api import sync_playwright
import json
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
 page.goto('http://127.0.0.1:8422');page.screenshot(path='evidence/before-desktop.png')
 page.set_viewport_size({'width':390,'height':844});page.screenshot(path='evidence/before-mobile.png')
 try:
  page.set_viewport_size({'width':1100,'height':850});page.goto('https://3dtransforms.desandro.com/card-flip',wait_until='domcontentloaded',timeout=20000)
  page.screenshot(path='evidence/reference-desandro.png',full_page=True)
  print(page.locator('iframe').evaluate_all('(els)=>els.map(e=>e.src)'))
 except Exception as e: print(str(e))
 b.close()
