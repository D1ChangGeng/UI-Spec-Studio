from playwright.sync_api import sync_playwright
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1100,'height':850},ignore_https_errors=True)
 page.goto('https://3dtransforms.desandro.com/card-flip',wait_until='domcontentloaded',timeout=20000)
 print(page.locator('.card').count())
 page.locator('.card').nth(1).scroll_into_view_if_needed()
 page.screenshot(path='evidence/reference-center.png')
 page.locator('.card').nth(1).click();page.wait_for_timeout(300);page.screenshot(path='evidence/reference-center-mid.png');page.wait_for_timeout(800)
 page.locator('.card').last.scroll_into_view_if_needed();page.locator('.card').last.click();page.wait_for_timeout(350);page.screenshot(path='evidence/reference-slide-mid.png')
 b.close()
