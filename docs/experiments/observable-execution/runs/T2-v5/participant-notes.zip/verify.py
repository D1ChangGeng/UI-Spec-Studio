from playwright.sync_api import sync_playwright
import json, time, hashlib
from pathlib import Path
ROOT=Path(__file__).parent
KEY='ui-spec-temporal-note-v1'
checks=[]
def check(name, value):
 checks.append({'check':name,'pass':bool(value)})
 assert value,name
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 context=b.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
 page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('http://127.0.0.1:8422');page.wait_for_timeout(100)
 page.screenshot(path='evidence/final-desktop.png')
 for width,height in [(1440,900),(390,844)]:
  page.set_viewport_size({'width':width,'height':height})
  for lang in ['en','zh']:
   if page.locator('html').get_attribute('lang') != ('zh-CN' if lang=='zh' else 'en'):page.locator('#locale-toggle').click()
   for theme in ['light','dark']:
    if page.locator('html').get_attribute('data-theme') != theme:page.locator('#theme-toggle').click()
    page.screenshot(path=f'evidence/{width}-{lang}-{theme}-front.png')
    check(f'no horizontal overflow {width} {lang} {theme}',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
    page.locator('#flip').click();page.wait_for_timeout(800)
    page.screenshot(path=f'evidence/{width}-{lang}-{theme}-back.png')
    check(f'back semantics {width} {lang} {theme}',page.locator('#card-front').get_attribute('aria-hidden')=='true' and page.locator('#card-back').get_attribute('aria-hidden')=='false')
    page.locator('#flip').click();page.wait_for_timeout(800)
 # Natural-time reversal sequence with actual capture brackets.
 page.set_viewport_size({'width':1440,'height':900})
 if page.locator('html').get_attribute('lang')!='en':page.locator('#locale-toggle').click()
 if page.locator('html').get_attribute('data-theme')!='light':page.locator('#theme-toggle').click()
 anchor=page.locator('#card-space').bounding_box();frames=[]
 for i,delay in enumerate([90,90,120,90,100,600]):
  page.locator('#flip').click();page.wait_for_timeout(delay)
  before=page.evaluate('performance.now()');page.screenshot(path=f'evidence/flip-{i:02}.png');after=page.evaluate('performance.now()')
  frames.append({'index':i,'capture_start':before,'capture_end':after,'matrix':page.locator('#note-card').evaluate('(e)=>getComputedStyle(e).transform'),'anchor':page.locator('#card-space').bounding_box()})
 page.wait_for_timeout(800)
 check('six rapid reversals finish front',page.locator('#note-card').get_attribute('data-face')=='front')
 check('layout anchor unchanged',all(x['anchor']==anchor for x in frames))
 (ROOT/'evidence/flip-timing.json').write_text(json.dumps(frames,indent=2))
 # Saving remains a real boundary: read Storage before and after 900 ms.
 page.locator('#note-text').fill('The submitted thought.');page.locator('#save').click()
 check('save reports pending',page.locator('#status').inner_text()=='Saving in this browser…')
 check('not written during delay',page.evaluate(f'localStorage.getItem("{KEY}")') is None)
 page.locator('#note-text').fill('A newer thought, still being written.')
 page.locator('#saved-link').click();page.wait_for_timeout(1000)
 check('saved submitted version',json.loads(page.evaluate(f'localStorage.getItem("{KEY}")'))['text']=='The submitted thought.')
 page.locator('#return').click()
 check('newer draft retained',page.locator('#note-text').input_value()=='A newer thought, still being written.')
 check('return focuses editor',page.evaluate('document.activeElement.id')=='note-text')
 # Native storage quota: fill actual origin storage to its limit, no API mock.
 page.evaluate('''() => {let low=0,high=6*1024*1024;while(low+1<high){const mid=Math.floor((low+high)/2);try{localStorage.setItem('quota-pressure','x'.repeat(mid));low=mid}catch(e){if(e.name!=='QuotaExceededError')throw e;high=mid}}window.quotaFilled=low}''')
 draft=('观察城市供热的高峰时段，记录天气、建筑用途与用能差异。\n'*30)[:600]
 page.locator('#note-text').fill(draft);page.locator('#save').click();page.wait_for_timeout(1050)
 check('native write failure announced',page.locator('#status-area').get_attribute('data-status')=='failed')
 check('failed draft intact',page.locator('#note-text').input_value()==draft)
 check('previous saved record intact',json.loads(page.evaluate(f'localStorage.getItem("{KEY}")'))['text']=='The submitted thought.')
 page.screenshot(path='evidence/failed-native-quota.png')
 page.locator('#saved-link').click();page.screenshot(path='evidence/failed-saved-view.png')
 check('saved view tells actual failure','could not be saved' in page.locator('#collection-status').inner_text())
 page.locator('#return').click();check('recovery focus',page.evaluate('document.activeElement.id')=='retry')
 page.evaluate("localStorage.removeItem('quota-pressure')");page.locator('#retry').click();page.wait_for_timeout(1050)
 check('retry native write succeeds',json.loads(page.evaluate(f'localStorage.getItem("{KEY}")'))['text']==draft)
 page.locator('#flip').click();page.wait_for_timeout(800)
 page.locator('#preview-note').focus();page.keyboard.press('End');page.wait_for_function("(() => {const e=document.getElementById('preview-note');return e.scrollTop+e.clientHeight>=e.scrollHeight-2})()");page.screenshot(path='evidence/long-note-desktop.png')
 check('long preview reached its end',page.locator('#preview-note').evaluate('(e)=>e.scrollTop+e.clientHeight>=e.scrollHeight-2'))
 check('long preview scrollable',page.locator('#preview-note').evaluate('(e)=>e.scrollHeight>e.clientHeight'))
 page.set_viewport_size({'width':390,'height':844});page.screenshot(path='evidence/long-note-mobile.png')
 page.locator('#note-text').fill(draft+'x')
 check('oversize draft remains whole',len(page.locator('#note-text').input_value())==601)
 check('oversize save disabled',page.locator('#save').is_disabled())
 page.reload();check('reload restores persisted draft',page.locator('#note-text').input_value()==draft)
 page.emulate_media(reduced_motion='reduce');page.locator('#flip').click()
 check('reduced motion has no transition',page.locator('#note-card').evaluate('(e)=>getComputedStyle(e).transitionDuration')=='0s')
 check('reduced motion face meaningful',page.locator('#card-back').get_attribute('aria-hidden')=='false')
 check('reduced ambient stopped',page.locator('.orbit-arm').evaluate('(e)=>getComputedStyle(e).animationName')=='none')
 page.locator('#preview-note').focus();page.locator('#saved-link').click();page.locator('#return').click();check('reduced return focus',page.evaluate('document.activeElement.id')=='note-text')
 page.screenshot(path='evidence/reduced-mobile.png')
 check('no browser errors',not errors)
 report={'checks':checks,'errors':errors,'browser':b.version,'viewports':[[1440,900],[390,844]],'pixelRatio':1,'quotaFailure':'Native localStorage capacity exhausted; no Storage monkeypatch','source_sha256':{n:hashlib.sha256((ROOT/'app'/n).read_bytes()).hexdigest() for n in ['index.html','styles.css','app.js']},'limits':['Chromium desktop emulation; no real phone or Safari/Firefox','Ordered natural-time frames, no measured frame delivery']}
 (ROOT/'evidence/checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
 print(json.dumps({'passed':len(checks),'errors':errors,'browser':b.version}))
 context.close();b.close()
