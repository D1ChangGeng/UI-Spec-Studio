import json, os, sys, hashlib
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'evidence'
PHASE = sys.argv[1]
os.environ['FONTCONFIG_FILE']='/workspace/scratch/654b1ee6916f/ui-spec-fonts/fonts.conf'
METRICS = '''() => Object.fromEntries(['note-title','note-body'].map(id => {
 const el=document.getElementById(id), s=getComputedStyle(el), p=getComputedStyle(el,'::placeholder'), r=el.getBoundingClientRect();
 return [id,{font:s.fontSize,placeholderFont:p.fontSize,color:p.color,opacity:p.opacity,background:s.backgroundColor,width:r.width,height:r.height,padding:s.padding,lineHeight:s.lineHeight,outline:s.outlineWidth}];
}))'''
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
 results={'phase':PHASE,'browser':browser.version,'dpr':1,'css_sha256':hashlib.sha256((ROOT/'app/styles.css').read_bytes()).hexdigest(),'cases':[]}
 for width,height in [(390,844),(1440,900)]:
  for locale in ['zh','en']:
   for theme in ['light','dark']:
    key=f'{width}-{locale}-{theme}'
    ctx=browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1)
    page=ctx.new_page()
    errors=[]
    page.on('pageerror',lambda e: errors.append(str(e)))
    page.goto('http://127.0.0.1:8433/')
    page.evaluate('document.fonts.ready')
    if locale=='en':page.locator('#locale-toggle').click()
    if theme=='dark':page.locator('#theme-toggle').click()
    page.locator('#theme-toggle').focus()
    page.keyboard.press('Tab')
    assert page.locator('#note-title').evaluate('(e)=>e===document.activeElement')
    assert page.locator('#note-title').evaluate('(e)=>e.matches(":focus-visible")')
    page.evaluate('window.scrollTo(0,0)')
    page.screenshot(path=str(OUT/f'{PHASE}-{key}-empty-title-focus.png'))
    metrics=page.evaluate(METRICS)
    case={'case':key,'metrics':metrics,'titleKeyboardFocus':True}
    if PHASE=='after':
     before=json.loads((OUT/'before.json').read_text())
     old=next(x for x in before['cases'] if x['case']==key)['metrics']
     for id in metrics:
      assert metrics[id]['font']=='15px'
      assert metrics[id]['placeholderFont']=='14px'
      for prop in ['width','height','padding','lineHeight','font']:
       assert old[id][prop]==metrics[id][prop],(key,id,prop,old[id][prop],metrics[id][prop])
     page.keyboard.press('Tab')
     assert page.locator('#note-body').evaluate('(e)=>e===document.activeElement && e.matches(":focus-visible")')
     page.evaluate('window.scrollTo(0,0)')
     page.screenshot(path=str(OUT/f'after-{key}-empty-body-focus.png'))
     title='城市供热与高峰负荷' if locale=='zh' else 'Reducing peak demand'
     body='记录材料与问题，稍后继续核查。\nResearch context and next steps.' if locale=='zh' else 'Capture the source material and open questions.\n记录需要核查的线索。'
     page.locator('#note-title').fill(title)
     page.locator('#note-body').fill(body)
     page.evaluate('window.scrollTo(0,0)')
     page.screenshot(path=str(OUT/f'after-{key}-entered-body-focus.png'))
     page.locator('#save').click()
     page.wait_for_function('document.querySelector(".state-area").dataset.status === "saved"')
     record=page.evaluate('JSON.parse(localStorage.getItem("ui-spec-content-note-v1"))')
     assert record=={'title':title,'body':body}
     assert page.locator('#recent-title').inner_text()==title
     page.reload()
     assert page.locator('#note-title').input_value()==title
     assert page.locator('#note-body').input_value()==body
     if locale=='en':page.locator('#locale-toggle').click()
     if theme=='dark':page.locator('#theme-toggle').click()
     page.locator('details summary').click()
     page.locator('#simulate-failure').check()
     page.locator('#note-title').fill(title+' — retry')
     page.locator('#save').click()
     page.locator('#retry').wait_for(state='visible')
     assert page.locator('#note-title').input_value()==title+' — retry'
     assert page.evaluate('JSON.parse(localStorage.getItem("ui-spec-content-note-v1")).title')==title
     page.locator('#simulate-failure').uncheck()
     page.locator('#retry').focus()
     page.keyboard.press('Enter')
     page.wait_for_function('document.querySelector(".state-area").dataset.status === "saved"')
     assert page.evaluate('JSON.parse(localStorage.getItem("ui-spec-content-note-v1")).title')==title+' — retry'
     assert page.locator('#note-title').evaluate('(e)=>e===document.activeElement')
     case.update(bodyKeyboardFocus=True,geometryPreserved=True,nativeSave=True,reloadRestoration=True,simulatedFailureRetainsDraft=True,keyboardRetry=True,retryFocusReturn=True)
    case['errors']=errors
    assert not errors
    case['horizontalOverflow']=page.evaluate('document.documentElement.scrollWidth>innerWidth')
    assert not case['horizontalOverflow']
    results['cases'].append(case)
    ctx.close()
 browser.close()
 (OUT/f'{PHASE}.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
 print(json.dumps({'phase':PHASE,'cases':len(results['cases']),'result':'passed'},ensure_ascii=False))
