import json, os
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parent
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell', args=['--no-sandbox'])
    report = {'browser': browser.version, 'viewports': {}}
    for width,height in [(390,844),(1440,900)]:
      for locale in ['zh','en']:
        for theme in ['light','dark']:
          page=browser.new_page(viewport={'width':width,'height':height},device_scale_factor=1)
          page.goto('http://127.0.0.1:8431/')
          if locale=='en': page.locator('#locale-toggle').click()
          if theme=='dark': page.locator('#theme-toggle').click()
          page.evaluate('document.fonts.ready')
          page.locator('#main-title').click()
          key=f'{width}-{locale}-{theme}'
          page.screenshot(path=str(ROOT/f'before-{key}.png'))
          page.locator('#note-form').screenshot(path=str(ROOT/f'before-fields-{key}.png'))
          report['viewports'][key]=page.evaluate('''() => Object.fromEntries(['note-title','note-body','save'].map(id=>{const e=document.getElementById(id),s=getComputedStyle(e),p=getComputedStyle(e,'::placeholder'),r=e.getBoundingClientRect();return[id,{fontSize:s.fontSize,lineHeight:s.lineHeight,padding:s.padding,height:r.height,width:r.width,placeholderSize:p.fontSize,placeholderOpacity:p.opacity,placeholderColor:p.color,background:s.backgroundColor}]}))''')
          page.close()
    (ROOT/'before-metrics.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    browser.close()
print(json.dumps(report,ensure_ascii=False))
