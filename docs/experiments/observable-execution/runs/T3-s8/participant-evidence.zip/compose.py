import json
from pathlib import Path
from PIL import Image, ImageDraw
ROOT=Path(__file__).resolve().parent
report=json.loads((ROOT/"verification.json").read_text())
# Unscaled overview strips retain the viewport captures separately.
for case in report['cases']:
    key=case['id']
    paths=[ROOT/f'fields-{key}-{state}.png' for state in ['empty','title-focus','body-focus','entered']]
    ims=[Image.open(path).convert('RGB') for path in paths]
    w=max(im.width for im in ims);h=max(im.height for im in ims)
    canvas=Image.new('RGB',(2*w,2*(h+25)),'#dddddd');d=ImageDraw.Draw(canvas)
    for i,(im,state) in enumerate(zip(ims,['Empty','Keyboard title focus','Keyboard body focus','Entered content'])):
        x=(i%2)*w;y=(i//2)*(h+25)
        d.text((x+8,y+5),f'{key} / {state}',fill='black');canvas.paste(im,(x,y+25))
    canvas.save(ROOT/f'inspect-{key}.png')
