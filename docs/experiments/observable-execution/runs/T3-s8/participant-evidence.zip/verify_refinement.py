"""Reproducible scoped browser checks for the placeholder refinement."""
import hashlib, json, math, re, time
from pathlib import Path
from playwright.sync_api import sync_playwright, expect
ROOT=Path(__file__).resolve().parent
BASE=json.loads((ROOT/'before-metrics.json').read_text())['viewports']
KEY='ui-spec-content-note-v1'
report={'boundary':'real browser localStorage; injected failure controls explicitly identified','browser':None,'device_scale_factor':1,'zoom':'100%','cases':[],'viewed_images':[],'unverified':['real mobile device and software keyboard','Safari and Firefox','screen-reader announcements','independent user comprehension']}

def rgb(s): return [float(x) for x in re.findall(r'[\d.]+',s)[:3]]
def luminance(v):
    c=[x/255 for x in v]
    c=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in c]
    return sum(x*y for x,y in zip(c,[.2126,.7152,.0722]))
def contrast(fg,bg,opacity):
    fg=[a*opacity+b*(1-opacity) for a,b in zip(fg,bg)]
    hi,lo=sorted([luminance(fg),luminance(bg)],reverse=True)
    return (hi+.05)/(lo+.05)
def metrics(page):
    return page.evaluate('''() => Object.fromEntries(['note-title','note-body','save'].map(id=>{const e=document.getElementById(id),s=getComputedStyle(e),p=getComputedStyle(e,'::placeholder'),r=e.getBoundingClientRect();return[id,{fontSize:s.fontSize,lineHeight:s.lineHeight,padding:s.padding,height:r.height,width:r.width,placeholderSize:p.fontSize,placeholderOpacity:p.opacity,placeholderColor:p.color,background:s.backgroundColor}]}))''')
def fieldshot(page,path):
    page.evaluate('window.scrollTo(0,0)')
    box=page.locator('#note-form').bounding_box()
    width=page.viewport_size['width'];height=page.viewport_size['height']
    x=max(0,box['x']-8);y=max(0,box['y']-8)
    page.screenshot(path=str(path),clip={'x':x,'y':y,'width':min(width-x,box['width']+16),'height':min(height-y,box['height']+16)},caret='initial')
def capture(page,key,state):
    page.evaluate('window.scrollTo(0,0)')
    page.screenshot(path=str(ROOT/f'after-{key}-{state}.png'),caret='initial')
    fieldshot(page,ROOT/f'fields-{key}-{state}.png')

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',args=['--no-sandbox'])
    report['browser']=browser.version
    for width,height in [(390,844),(1440,900)]:
      for locale in ['zh','en']:
       for theme in ['light','dark']:
        key=f'{width}-{locale}-{theme}'
        context=browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1)
        page=context.new_page(); errors=[]; page.on('pageerror',lambda e: errors.append(str(e)))
        page.goto('http://127.0.0.1:8431/')
        if locale=='en': page.locator('#locale-toggle').click()
        if theme=='dark': page.locator('#theme-toggle').click()
        page.evaluate('document.fonts.ready')
        page.locator('#main-title').click()
        got=metrics(page)
        for id in ['note-title','note-body','save']:
            for prop in ['fontSize','lineHeight','padding','height','width']:
                assert got[id][prop]==BASE[key][id][prop],(key,id,prop,got[id],BASE[key][id])
        ratios={}
        for id in ['note-title','note-body']:
            m=got[id]
            assert m['fontSize']=='15px' and m['placeholderSize']=='14px'
            ratios[id]=contrast(rgb(m['placeholderColor']),rgb(m['background']),float(m['placeholderOpacity']))
            assert ratios[id]>=4.5
        assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
        capture(page,key,'empty')
        # Reach both empty fields using the real keyboard tab order.
        page.locator('#theme-toggle').focus()
        page.keyboard.press('Tab');expect(page.locator('#note-title')).to_be_focused()
        assert page.locator('#note-title').evaluate('e=>e.matches(":focus-visible")')
        capture(page,key,'title-focus')
        page.keyboard.press('Tab');expect(page.locator('#note-body')).to_be_focused()
        assert page.locator('#note-body').evaluate('e=>e.matches(":focus-visible")')
        capture(page,key,'body-focus')
        title='城市供热如何降低高峰负荷？' if locale=='zh' else 'How can cities reduce peak heating demand?'
        body='比较已有材料与待核查线索。\n保留中文、English 与标点。' if locale=='zh' else 'Compare source material and open questions.\nKeep Chinese 中文 and punctuation readable.'
        page.locator('#note-title').fill(title)
        page.locator('#note-body').fill(body)
        capture(page,key,'entered')
        # Real write and reload restoration.
        page.locator('#save').click()
        expect(page.locator('.state-area')).to_have_attribute('data-status','saved')
        assert page.evaluate('(key)=>JSON.parse(localStorage.getItem(key))',KEY)=={'title':title,'body':body}
        expect(page.locator('#recent-title')).to_have_text(title)
        page.reload();expect(page.locator('#note-title')).to_have_value(title);expect(page.locator('#note-body')).to_have_value(body)
        if locale=='en': page.locator('#locale-toggle').click()
        if theme=='dark': page.locator('#theme-toggle').click()
        page.locator('summary').click();page.locator('#simulate-failure').check()
        retry_title=title+' · 2';page.locator('#note-title').fill(retry_title)
        page.locator('#save').click();expect(page.locator('#retry')).to_be_visible()
        expect(page.locator('.state-area')).to_have_attribute('data-status','error')
        expect(page.locator('#note-title')).to_have_value(retry_title)
        assert page.evaluate('(key)=>JSON.parse(localStorage.getItem(key)).title',KEY)==title
        page.locator('#simulate-failure').uncheck()
        page.locator('#retry').focus();page.keyboard.press('Enter')
        expect(page.locator('.state-area')).to_have_attribute('data-status','saved')
        expect(page.locator('#retry')).to_be_hidden();expect(page.locator('#note-title')).to_be_focused()
        assert page.evaluate('(key)=>JSON.parse(localStorage.getItem(key)).title',KEY)==retry_title
        page.locator('summary').click();capture(page,key,'retried')
        assert errors==[],errors
        report['cases'].append({'id':key,'viewport':[width,height],'metrics':got,'placeholder_contrast':ratios,'checks':['empty fields','14px placeholders / unchanged 15px entered text','unchanged input, textarea and save geometry','keyboard title and body focus','entered mixed-script multiline content','no horizontal overflow','actual localStorage save','reload restoration','simulated failure retains draft and prior save','keyboard retry writes latest draft and returns focus','no page errors']})
        context.close()
    browser.close()
report['source_sha256']=hashlib.sha256((ROOT.parent/'app/styles.css').read_bytes()).hexdigest()
(ROOT/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'browser':report['browser'],'case_count':len(report['cases']),'checks_per_case':len(report['cases'][0]['checks']),'contrast_light':report['cases'][0]['placeholder_contrast'],'contrast_dark':report['cases'][1]['placeholder_contrast'],'result':'PASS'},ensure_ascii=False))
