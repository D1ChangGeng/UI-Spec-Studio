from pathlib import Path
import json, os, sys
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent
phase=sys.argv[1]
os.environ['FONTCONFIG_FILE']='/workspace/scratch/654b1ee6916f/ui-spec-fonts/fonts.conf'
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/workspace/scratch/654b1ee6916f/ui-spec-browsers/chrome-headless-shell-linux64/chrome-headless-shell',headless=True,args=['--no-sandbox'])
    results=[]
    for width,height in [(390,844),(1440,900)]:
      for locale in ['zh','en']:
       for theme in ['light','dark']:
        context=browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1)
        page=context.new_page()
        errors=[]
        page.on('pageerror',lambda error: errors.append(str(error)))
        page.goto('http://127.0.0.1:8432/')
        page.evaluate('document.fonts.ready')
        if locale=='en':page.locator('#locale-toggle').click()
        if theme=='dark':page.locator('#theme-toggle').click()
        page.evaluate('window.scrollTo(0,0)')
        name=f'{phase}-{width}-{locale}-{theme}'
        page.screenshot(path=str(ROOT/f'{name}-empty.png'))
        data=page.locator('#note-title, #note-body').evaluate_all('''els => els.map(e => {const s=getComputedStyle(e),p=getComputedStyle(e,'::placeholder'),r=e.getBoundingClientRect();return {id:e.id,font:s.fontSize,placeholder:p.fontSize,opacity:p.opacity,color:p.color,background:s.backgroundColor,lineHeight:s.lineHeight,padding:s.padding,height:r.height,width:r.width,x:r.x,y:r.y}})''')
        if phase=='after':
          assert all(x['font']=='15px' and x['placeholder']=='14px' and x['opacity']=='1' for x in data),data
          assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
          page.locator('#locale-toggle').focus()
          page.keyboard.press('Tab')
          page.keyboard.press('Tab')
          assert page.locator('#note-title').evaluate("e=>document.activeElement===e && e.matches(':focus-visible')")
          page.screenshot(path=str(ROOT/f'{name}-title-focus.png'))
          page.keyboard.press('Tab')
          assert page.locator('#note-body').evaluate("e=>document.activeElement===e && e.matches(':focus-visible')")
          page.screenshot(path=str(ROOT/f'{name}-body-focus.png'))
          title='供热需求的研究问题' if locale=='zh' else 'Researching peak heating demand'
          body='比较材料与已有判断，记录下一步需要核查的线索。' if locale=='zh' else 'Compare the source material and record the questions to verify next.'
          page.locator('#note-title').fill(title)
          page.locator('#note-body').fill(body)
          page.evaluate('window.scrollTo(0,0)')
          page.screenshot(path=str(ROOT/f'{name}-entered.png'))
          page.locator('#save').click()
          page.wait_for_function("document.querySelector('.state-area').dataset.status==='saved'")
          stored=page.evaluate("JSON.parse(localStorage.getItem('ui-spec-content-note-v1'))")
          assert stored=={'title':title,'body':body}
          assert page.locator('#recent-title').inner_text()==title
          page.locator('summary').click()
          page.locator('#simulate-failure').check()
          page.locator('#note-title').fill(title+' 2')
          page.locator('#save').click()
          page.wait_for_function("document.querySelector('.state-area').dataset.status==='error'")
          assert page.locator('#retry').is_visible()
          assert page.locator('#note-title').input_value()==title+' 2'
          assert page.locator('#note-body').input_value()==body
          assert page.evaluate("JSON.parse(localStorage.getItem('ui-spec-content-note-v1')).title")==title
          page.screenshot(path=str(ROOT/f'{name}-failure.png'))
          page.locator('#simulate-failure').uncheck()
          page.locator('#retry').focus()
          page.keyboard.press('Enter')
          page.wait_for_function("document.querySelector('.state-area').dataset.status==='saved'")
          assert page.locator('#retry').is_hidden()
          assert page.locator('#note-title').evaluate('e=>document.activeElement===e')
          assert page.evaluate("JSON.parse(localStorage.getItem('ui-spec-content-note-v1')).title")==title+' 2'
          page.screenshot(path=str(ROOT/f'{name}-retry-saved.png'))
          page.reload()
          assert page.locator('#note-title').input_value()==title+' 2'
          assert page.locator('#note-body').input_value()==body
        assert not errors,errors
        results.append({'viewport':[width,height],'locale':locale,'theme':theme,'fields':data,'console_errors':errors,'save_retry_reload':'passed' if phase=='after' else 'not tested'})
        context.close()
    browser.close()
    (ROOT/f'{phase}-checks.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    print(json.dumps({'phase':phase,'combinations':len(results),'result':'passed'},ensure_ascii=False))
